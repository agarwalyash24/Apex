# just-diff

## 5.1.1

### Patch Changes

- fix: reorder exports to set default last #488

## 5.1.0

### Minor Changes

- package.json updates to fix #467 and #483

## 5.0.3

### Patch Changes

- Keep ESMs in sync with commonJS modules

## 5.0.2

### Patch Changes

- Fixed issue where remove diffs were sometimes not reversed
