export function isPlainObject(o: any): boolean;
