import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import "core-js/modules/es.promise";
import _setTimeout from "@babel/runtime-corejs3/core-js-stable/set-timeout";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime-corejs3/helpers/objectWithoutProperties";

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context2; _forEachInstanceProperty(_context2 = ownKeys(Object(source), true)).call(_context2, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context3; _forEachInstanceProperty(_context3 = ownKeys(Object(source))).call(_context3, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 * @file Manages Salesforce Metadata API
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { EventEmitter } from 'events';
import { Readable } from 'stream';
import FormData from 'form-data';
import { registerModule } from '../jsforce';
import SOAP from '../soap';
import { isObject } from '../util/function';
import { ApiSchemas } from './metadata/schema';
export * from './metadata/schema';
/**
 *
 */

/**
 *
 */
function deallocateTypeWithMetadata(metadata) {
  const _ref = metadata,
        {
    $
  } = _ref,
        md = _objectWithoutProperties(_ref, ["$"]);

  return md;
}

function assignTypeWithMetadata(metadata, type) {
  const convert = md => _objectSpread({
    ['@xsi:type']: type
  }, md);

  return _Array$isArray(metadata) ? _mapInstanceProperty(metadata).call(metadata, convert) : convert(metadata);
}
/**
 * Class for Salesforce Metadata API
 */


export class MetadataApi {
  /**
   * Polling interval in milliseconds
   */

  /**
   * Polling timeout in milliseconds
   */

  /**
   *
   */
  constructor(conn) {
    _defineProperty(this, "_conn", void 0);

    _defineProperty(this, "pollInterval", 1000);

    _defineProperty(this, "pollTimeout", 10000);

    this._conn = conn;
  }
  /**
   * Call Metadata API SOAP endpoint
   *
   * @private
   */


  async _invoke(method, message, schema) {
    const soapEndpoint = new SOAP(this._conn, {
      xmlns: 'http://soap.sforce.com/2006/04/metadata',
      endpointUrl: `${this._conn.instanceUrl}/services/Soap/m/${this._conn.version}`
    });
    const res = await soapEndpoint.invoke(method, message, schema ? {
      result: schema
    } : undefined, ApiSchemas);
    return res.result;
  }
  /**
   * Add one or more new metadata components to the organization.
   */


  create(type, metadata) {
    const isArray = _Array$isArray(metadata);

    metadata = assignTypeWithMetadata(metadata, type);
    const schema = isArray ? [ApiSchemas.SaveResult] : ApiSchemas.SaveResult;
    return this._invoke('createMetadata', {
      metadata
    }, schema);
  }
  /**
   * Read specified metadata components in the organization.
   */


  async read(type, fullNames) {
    var _context;

    const ReadResultSchema = type in ApiSchemas ? {
      type: ApiSchemas.ReadResult.type,
      props: {
        records: [type]
      }
    } : ApiSchemas.ReadResult;
    const res = await this._invoke('readMetadata', {
      type,
      fullNames
    }, ReadResultSchema);
    return _Array$isArray(fullNames) ? _mapInstanceProperty(_context = res.records).call(_context, deallocateTypeWithMetadata) : deallocateTypeWithMetadata(res.records[0]);
  }
  /**
   * Update one or more metadata components in the organization.
   */


  update(type, metadata) {
    const isArray = _Array$isArray(metadata);

    metadata = assignTypeWithMetadata(metadata, type);
    const schema = isArray ? [ApiSchemas.SaveResult] : ApiSchemas.SaveResult;
    return this._invoke('updateMetadata', {
      metadata
    }, schema);
  }
  /**
   * Upsert one or more components in your organization's data.
   */


  upsert(type, metadata) {
    const isArray = _Array$isArray(metadata);

    metadata = assignTypeWithMetadata(metadata, type);
    const schema = isArray ? [ApiSchemas.UpsertResult] : ApiSchemas.UpsertResult;
    return this._invoke('upsertMetadata', {
      metadata
    }, schema);
  }
  /**
   * Deletes specified metadata components in the organization.
   */


  delete(type, fullNames) {
    const schema = _Array$isArray(fullNames) ? [ApiSchemas.SaveResult] : ApiSchemas.SaveResult;
    return this._invoke('deleteMetadata', {
      type,
      fullNames
    }, schema);
  }
  /**
   * Rename fullname of a metadata component in the organization
   */


  rename(type, oldFullName, newFullName) {
    return this._invoke('renameMetadata', {
      type,
      oldFullName,
      newFullName
    }, ApiSchemas.SaveResult);
  }
  /**
   * Retrieves the metadata which describes your organization, including Apex classes and triggers,
   * custom objects, custom fields on standard objects, tab sets that define an app,
   * and many other components.
   */


  describe(asOfVersion) {
    if (!asOfVersion) {
      asOfVersion = this._conn.version;
    }

    return this._invoke('describeMetadata', {
      asOfVersion
    }, ApiSchemas.DescribeMetadataResult);
  }
  /**
   * Retrieves property information about metadata components in your organization
   */


  list(queries, asOfVersion) {
    if (!asOfVersion) {
      asOfVersion = this._conn.version;
    }

    return this._invoke('listMetadata', {
      queries,
      asOfVersion
    }, [ApiSchemas.FileProperties]);
  }
  /**
   * Checks the status of asynchronous metadata calls
   */


  checkStatus(asyncProcessId) {
    const res = this._invoke('checkStatus', {
      asyncProcessId
    }, ApiSchemas.AsyncResult);

    return new AsyncResultLocator(this, res);
  }
  /**
   * Retrieves XML file representations of components in an organization
   */


  retrieve(request) {
    const res = this._invoke('retrieve', {
      request
    }, ApiSchemas.RetrieveResult);

    return new RetrieveResultLocator(this, res);
  }
  /**
   * Checks the status of declarative metadata call retrieve() and returns the zip file contents
   */


  checkRetrieveStatus(asyncProcessId) {
    return this._invoke('checkRetrieveStatus', {
      asyncProcessId
    }, ApiSchemas.RetrieveResult);
  }
  /**
   * Will deploy a recently validated deploy request
   *
   * @param options.id = the deploy ID that's been validated already from a previous checkOnly deploy request
   * @param options.rest = a boolean whether or not to use the REST API
   * @returns the deploy ID of the recent validation request
   */


  async deployRecentValidation(options) {
    const {
      id,
      rest
    } = options;
    let response;

    if (rest) {
      const messageBody = _JSON$stringify({
        validatedDeployRequestId: id
      });

      const requestInfo = {
        method: 'POST',
        url: `${this._conn._baseUrl()}/metadata/deployRequest`,
        body: messageBody,
        headers: {
          'content-type': 'application/json'
        }
      };
      const requestOptions = {
        headers: 'json'
      }; // This is the deploy ID of the deployRecentValidation response, not
      // the already validated deploy ID (i.e., validateddeployrequestid).
      // REST returns an object with an id property, SOAP returns the id as a string directly.

      response = (await this._conn.request(requestInfo, requestOptions)).id;
    } else {
      response = await this._invoke('deployRecentValidation', {
        validationId: id
      });
    }

    return response;
  }
  /**
   * Deploy components into an organization using zipped file representations
   * using the REST Metadata API instead of SOAP
   */


  deployRest(zipInput, options = {}) {
    const form = new FormData();
    form.append('file', zipInput, {
      contentType: 'application/zip',
      filename: 'package.xml'
    }); // Add the deploy options

    form.append('entity_content', _JSON$stringify({
      deployOptions: options
    }), {
      contentType: 'application/json'
    });
    const request = {
      url: '/metadata/deployRequest',
      method: 'POST',
      headers: _objectSpread({}, form.getHeaders()),
      body: form.getBuffer()
    };

    const res = this._conn.request(request);

    return new DeployResultLocator(this, res);
  }
  /**
   * Deploy components into an organization using zipped file representations
   */


  deploy(zipInput, options = {}) {
    const res = (async () => {
      const zipContentB64 = await new _Promise((resolve, reject) => {
        if (isObject(zipInput) && 'pipe' in zipInput && typeof zipInput.pipe === 'function') {
          const bufs = [];
          zipInput.on('data', d => bufs.push(d));
          zipInput.on('error', reject);
          zipInput.on('end', () => {
            resolve(_concatInstanceProperty(Buffer).call(Buffer, bufs).toString('base64'));
          }); // zipInput.resume();
        } else if (zipInput instanceof Buffer) {
          resolve(zipInput.toString('base64'));
        } else if (zipInput instanceof String || typeof zipInput === 'string') {
          resolve(zipInput);
        } else {
          throw 'Unexpected zipInput type';
        }
      });
      return this._invoke('deploy', {
        ZipFile: zipContentB64,
        DeployOptions: options
      }, ApiSchemas.DeployResult);
    })();

    return new DeployResultLocator(this, res);
  }
  /**
   * Checks the status of declarative metadata call deploy()
   */


  checkDeployStatus(asyncProcessId, includeDetails = false) {
    return this._invoke('checkDeployStatus', {
      asyncProcessId,
      includeDetails
    }, ApiSchemas.DeployResult);
  }

}
/*--------------------------------------------*/

/**
 * The locator class for Metadata API asynchronous call result
 */

export class AsyncResultLocator extends EventEmitter {
  /**
   *
   */
  constructor(meta, promise) {
    super();

    _defineProperty(this, "_meta", void 0);

    _defineProperty(this, "_promise", void 0);

    _defineProperty(this, "_id", void 0);

    this._meta = meta;
    this._promise = promise;
  }
  /**
   * Promise/A+ interface
   * http://promises-aplus.github.io/promises-spec/
   *
   * @method Metadata~AsyncResultLocator#then
   */


  then(onResolve, onReject) {
    return this._promise.then(onResolve, onReject);
  }
  /**
   * Check the status of async request
   */


  async check() {
    const result = await this._promise;
    this._id = result.id;
    return await this._meta.checkStatus(result.id);
  }
  /**
   * Polling until async call status becomes complete or error
   */


  poll(interval, timeout) {
    const startTime = new Date().getTime();

    const poll = async () => {
      try {
        const now = new Date().getTime();

        if (startTime + timeout < now) {
          let errMsg = 'Polling time out.';

          if (this._id) {
            errMsg += ' Process Id = ' + this._id;
          }

          this.emit('error', new Error(errMsg));
          return;
        }

        const result = await this.check();

        if (result.done) {
          this.emit('complete', result);
        } else {
          this.emit('progress', result);

          _setTimeout(poll, interval);
        }
      } catch (err) {
        this.emit('error', err);
      }
    };

    _setTimeout(poll, interval);
  }
  /**
   * Check and wait until the async requests become in completed status
   */


  complete() {
    return new _Promise((resolve, reject) => {
      this.on('complete', resolve);
      this.on('error', reject);
      this.poll(this._meta.pollInterval, this._meta.pollTimeout);
    });
  }

}
/*--------------------------------------------*/

/**
 * The locator class to track retreive() Metadata API call result
 */

export class RetrieveResultLocator extends AsyncResultLocator {
  /**
   * Check and wait until the async request becomes in completed status,
   * and retrieve the result data.
   */
  async complete() {
    const result = await super.complete();
    return this._meta.checkRetrieveStatus(result.id);
  }
  /**
   * Change the retrieved result to Node.js readable stream
   */


  stream() {
    const resultStream = new Readable();
    let reading = false;

    resultStream._read = async () => {
      if (reading) {
        return;
      }

      reading = true;

      try {
        const result = await this.complete();
        resultStream.push(Buffer.from(result.zipFile, 'base64'));
        resultStream.push(null);
      } catch (e) {
        resultStream.emit('error', e);
      }
    };

    return resultStream;
  }

}
/*--------------------------------------------*/

/**
 * The locator class to track deploy() Metadata API call result
 *
 * @protected
 * @class Metadata~DeployResultLocator
 * @extends Metadata~AsyncResultLocator
 * @param {Metadata} meta - Metadata API object
 * @param {Promise.<Metadata~AsyncResult>} result - Promise object for async result of deploy() call
 */

export class DeployResultLocator extends AsyncResultLocator {
  /**
   * Check and wait until the async request becomes in completed status,
   * and retrieve the result data.
   */
  async complete(includeDetails) {
    const result = await super.complete();
    return this._meta.checkDeployStatus(result.id, includeDetails);
  }

}
/*--------------------------------------------*/

/*
 * Register hook in connection instantiation for dynamically adding this API module features
 */

registerModule('metadata', conn => new MetadataApi(conn));
export default MetadataApi;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9hcGkvbWV0YWRhdGEudHMiXSwibmFtZXMiOlsiRXZlbnRFbWl0dGVyIiwiUmVhZGFibGUiLCJGb3JtRGF0YSIsInJlZ2lzdGVyTW9kdWxlIiwiU09BUCIsImlzT2JqZWN0IiwiQXBpU2NoZW1hcyIsImRlYWxsb2NhdGVUeXBlV2l0aE1ldGFkYXRhIiwibWV0YWRhdGEiLCIkIiwibWQiLCJhc3NpZ25UeXBlV2l0aE1ldGFkYXRhIiwidHlwZSIsImNvbnZlcnQiLCJNZXRhZGF0YUFwaSIsImNvbnN0cnVjdG9yIiwiY29ubiIsIl9jb25uIiwiX2ludm9rZSIsIm1ldGhvZCIsIm1lc3NhZ2UiLCJzY2hlbWEiLCJzb2FwRW5kcG9pbnQiLCJ4bWxucyIsImVuZHBvaW50VXJsIiwiaW5zdGFuY2VVcmwiLCJ2ZXJzaW9uIiwicmVzIiwiaW52b2tlIiwicmVzdWx0IiwidW5kZWZpbmVkIiwiY3JlYXRlIiwiaXNBcnJheSIsIlNhdmVSZXN1bHQiLCJyZWFkIiwiZnVsbE5hbWVzIiwiUmVhZFJlc3VsdFNjaGVtYSIsIlJlYWRSZXN1bHQiLCJwcm9wcyIsInJlY29yZHMiLCJ1cGRhdGUiLCJ1cHNlcnQiLCJVcHNlcnRSZXN1bHQiLCJkZWxldGUiLCJyZW5hbWUiLCJvbGRGdWxsTmFtZSIsIm5ld0Z1bGxOYW1lIiwiZGVzY3JpYmUiLCJhc09mVmVyc2lvbiIsIkRlc2NyaWJlTWV0YWRhdGFSZXN1bHQiLCJsaXN0IiwicXVlcmllcyIsIkZpbGVQcm9wZXJ0aWVzIiwiY2hlY2tTdGF0dXMiLCJhc3luY1Byb2Nlc3NJZCIsIkFzeW5jUmVzdWx0IiwiQXN5bmNSZXN1bHRMb2NhdG9yIiwicmV0cmlldmUiLCJyZXF1ZXN0IiwiUmV0cmlldmVSZXN1bHQiLCJSZXRyaWV2ZVJlc3VsdExvY2F0b3IiLCJjaGVja1JldHJpZXZlU3RhdHVzIiwiZGVwbG95UmVjZW50VmFsaWRhdGlvbiIsIm9wdGlvbnMiLCJpZCIsInJlc3QiLCJyZXNwb25zZSIsIm1lc3NhZ2VCb2R5IiwidmFsaWRhdGVkRGVwbG95UmVxdWVzdElkIiwicmVxdWVzdEluZm8iLCJ1cmwiLCJfYmFzZVVybCIsImJvZHkiLCJoZWFkZXJzIiwicmVxdWVzdE9wdGlvbnMiLCJ2YWxpZGF0aW9uSWQiLCJkZXBsb3lSZXN0IiwiemlwSW5wdXQiLCJmb3JtIiwiYXBwZW5kIiwiY29udGVudFR5cGUiLCJmaWxlbmFtZSIsImRlcGxveU9wdGlvbnMiLCJnZXRIZWFkZXJzIiwiZ2V0QnVmZmVyIiwiRGVwbG95UmVzdWx0TG9jYXRvciIsImRlcGxveSIsInppcENvbnRlbnRCNjQiLCJyZXNvbHZlIiwicmVqZWN0IiwicGlwZSIsImJ1ZnMiLCJvbiIsImQiLCJwdXNoIiwiQnVmZmVyIiwidG9TdHJpbmciLCJTdHJpbmciLCJaaXBGaWxlIiwiRGVwbG95T3B0aW9ucyIsIkRlcGxveVJlc3VsdCIsImNoZWNrRGVwbG95U3RhdHVzIiwiaW5jbHVkZURldGFpbHMiLCJtZXRhIiwicHJvbWlzZSIsIl9tZXRhIiwiX3Byb21pc2UiLCJ0aGVuIiwib25SZXNvbHZlIiwib25SZWplY3QiLCJjaGVjayIsIl9pZCIsInBvbGwiLCJpbnRlcnZhbCIsInRpbWVvdXQiLCJzdGFydFRpbWUiLCJEYXRlIiwiZ2V0VGltZSIsIm5vdyIsImVyck1zZyIsImVtaXQiLCJFcnJvciIsImRvbmUiLCJlcnIiLCJjb21wbGV0ZSIsInBvbGxJbnRlcnZhbCIsInBvbGxUaW1lb3V0Iiwic3RyZWFtIiwicmVzdWx0U3RyZWFtIiwicmVhZGluZyIsIl9yZWFkIiwiZnJvbSIsInppcEZpbGUiLCJlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTQSxZQUFULFFBQTZCLFFBQTdCO0FBQ0EsU0FBU0MsUUFBVCxRQUF5QixRQUF6QjtBQUNBLE9BQU9DLFFBQVAsTUFBcUIsV0FBckI7QUFDQSxTQUFTQyxjQUFULFFBQStCLFlBQS9CO0FBRUEsT0FBT0MsSUFBUCxNQUFpQixTQUFqQjtBQUNBLFNBQVNDLFFBQVQsUUFBeUIsa0JBQXpCO0FBRUEsU0FDRUMsVUFERixRQWVPLG1CQWZQO0FBZ0JBLGNBQWMsbUJBQWQ7QUFFQTtBQUNBO0FBQ0E7O0FBaUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVNDLDBCQUFULENBQXdEQyxRQUF4RCxFQUF3RTtBQUN0RSxlQUFxQkEsUUFBckI7QUFBQSxRQUFNO0FBQUVDLElBQUFBO0FBQUYsR0FBTjtBQUFBLFFBQWNDLEVBQWQ7O0FBQ0EsU0FBT0EsRUFBUDtBQUNEOztBQUVELFNBQVNDLHNCQUFULENBQWdDSCxRQUFoQyxFQUFpRUksSUFBakUsRUFBK0U7QUFDN0UsUUFBTUMsT0FBTyxHQUFJSCxFQUFEO0FBQXFCLEtBQUMsV0FBRCxHQUFlRTtBQUFwQyxLQUE2Q0YsRUFBN0MsQ0FBaEI7O0FBQ0EsU0FBTyxlQUFjRixRQUFkLElBQTBCLHFCQUFBQSxRQUFRLE1BQVIsQ0FBQUEsUUFBUSxFQUFLSyxPQUFMLENBQWxDLEdBQWtEQSxPQUFPLENBQUNMLFFBQUQsQ0FBaEU7QUFDRDtBQUVEO0FBQ0E7QUFDQTs7O0FBQ0EsT0FBTyxNQUFNTSxXQUFOLENBQW9DO0FBR3pDO0FBQ0Y7QUFDQTs7QUFHRTtBQUNGO0FBQ0E7O0FBR0U7QUFDRjtBQUNBO0FBQ0VDLEVBQUFBLFdBQVcsQ0FBQ0MsSUFBRCxFQUFzQjtBQUFBOztBQUFBLDBDQVZWLElBVVU7O0FBQUEseUNBTFgsS0FLVzs7QUFDL0IsU0FBS0MsS0FBTCxHQUFhRCxJQUFiO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRSxRQUFNRSxPQUFOLENBQ0VDLE1BREYsRUFFRUMsT0FGRixFQUdFQyxNQUhGLEVBSUU7QUFDQSxVQUFNQyxZQUFZLEdBQUcsSUFBSWxCLElBQUosQ0FBUyxLQUFLYSxLQUFkLEVBQXFCO0FBQ3hDTSxNQUFBQSxLQUFLLEVBQUUseUNBRGlDO0FBRXhDQyxNQUFBQSxXQUFXLEVBQUcsR0FBRSxLQUFLUCxLQUFMLENBQVdRLFdBQVksb0JBQW1CLEtBQUtSLEtBQUwsQ0FBV1MsT0FBUTtBQUZyQyxLQUFyQixDQUFyQjtBQUlBLFVBQU1DLEdBQUcsR0FBRyxNQUFNTCxZQUFZLENBQUNNLE1BQWIsQ0FDaEJULE1BRGdCLEVBRWhCQyxPQUZnQixFQUdoQkMsTUFBTSxHQUFJO0FBQUVRLE1BQUFBLE1BQU0sRUFBRVI7QUFBVixLQUFKLEdBQXdDUyxTQUg5QixFQUloQnhCLFVBSmdCLENBQWxCO0FBTUEsV0FBT3FCLEdBQUcsQ0FBQ0UsTUFBWDtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFnQkVFLEVBQUFBLE1BQU0sQ0FBQ25CLElBQUQsRUFBZUosUUFBZixFQUFnRDtBQUNwRCxVQUFNd0IsT0FBTyxHQUFHLGVBQWN4QixRQUFkLENBQWhCOztBQUNBQSxJQUFBQSxRQUFRLEdBQUdHLHNCQUFzQixDQUFDSCxRQUFELEVBQVdJLElBQVgsQ0FBakM7QUFDQSxVQUFNUyxNQUFNLEdBQUdXLE9BQU8sR0FBRyxDQUFDMUIsVUFBVSxDQUFDMkIsVUFBWixDQUFILEdBQTZCM0IsVUFBVSxDQUFDMkIsVUFBOUQ7QUFDQSxXQUFPLEtBQUtmLE9BQUwsQ0FBYSxnQkFBYixFQUErQjtBQUFFVixNQUFBQTtBQUFGLEtBQS9CLEVBQTZDYSxNQUE3QyxDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQWdCRSxRQUFNYSxJQUFOLENBQVd0QixJQUFYLEVBQXlCdUIsU0FBekIsRUFBdUQ7QUFBQTs7QUFDckQsVUFBTUMsZ0JBQWdCLEdBQ3BCeEIsSUFBSSxJQUFJTixVQUFSLEdBQ0s7QUFDQ00sTUFBQUEsSUFBSSxFQUFFTixVQUFVLENBQUMrQixVQUFYLENBQXNCekIsSUFEN0I7QUFFQzBCLE1BQUFBLEtBQUssRUFBRTtBQUNMQyxRQUFBQSxPQUFPLEVBQUUsQ0FBQzNCLElBQUQ7QUFESjtBQUZSLEtBREwsR0FPSU4sVUFBVSxDQUFDK0IsVUFSakI7QUFTQSxVQUFNVixHQUFlLEdBQUcsTUFBTSxLQUFLVCxPQUFMLENBQzVCLGNBRDRCLEVBRTVCO0FBQUVOLE1BQUFBLElBQUY7QUFBUXVCLE1BQUFBO0FBQVIsS0FGNEIsRUFHNUJDLGdCQUg0QixDQUE5QjtBQUtBLFdBQU8sZUFBY0QsU0FBZCxJQUNILGdDQUFBUixHQUFHLENBQUNZLE9BQUosaUJBQWdCaEMsMEJBQWhCLENBREcsR0FFSEEsMEJBQTBCLENBQUNvQixHQUFHLENBQUNZLE9BQUosQ0FBWSxDQUFaLENBQUQsQ0FGOUI7QUFHRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBbUJFQyxFQUFBQSxNQUFNLENBQUM1QixJQUFELEVBQWVKLFFBQWYsRUFBZ0Q7QUFDcEQsVUFBTXdCLE9BQU8sR0FBRyxlQUFjeEIsUUFBZCxDQUFoQjs7QUFDQUEsSUFBQUEsUUFBUSxHQUFHRyxzQkFBc0IsQ0FBQ0gsUUFBRCxFQUFXSSxJQUFYLENBQWpDO0FBQ0EsVUFBTVMsTUFBTSxHQUFHVyxPQUFPLEdBQUcsQ0FBQzFCLFVBQVUsQ0FBQzJCLFVBQVosQ0FBSCxHQUE2QjNCLFVBQVUsQ0FBQzJCLFVBQTlEO0FBQ0EsV0FBTyxLQUFLZixPQUFMLENBQWEsZ0JBQWIsRUFBK0I7QUFBRVYsTUFBQUE7QUFBRixLQUEvQixFQUE2Q2EsTUFBN0MsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFnQkVvQixFQUFBQSxNQUFNLENBQUM3QixJQUFELEVBQWVKLFFBQWYsRUFBZ0Q7QUFDcEQsVUFBTXdCLE9BQU8sR0FBRyxlQUFjeEIsUUFBZCxDQUFoQjs7QUFDQUEsSUFBQUEsUUFBUSxHQUFHRyxzQkFBc0IsQ0FBQ0gsUUFBRCxFQUFXSSxJQUFYLENBQWpDO0FBQ0EsVUFBTVMsTUFBTSxHQUFHVyxPQUFPLEdBQ2xCLENBQUMxQixVQUFVLENBQUNvQyxZQUFaLENBRGtCLEdBRWxCcEMsVUFBVSxDQUFDb0MsWUFGZjtBQUdBLFdBQU8sS0FBS3hCLE9BQUwsQ0FBYSxnQkFBYixFQUErQjtBQUFFVixNQUFBQTtBQUFGLEtBQS9CLEVBQTZDYSxNQUE3QyxDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQU9Fc0IsRUFBQUEsTUFBTSxDQUFDL0IsSUFBRCxFQUFldUIsU0FBZixFQUE2QztBQUNqRCxVQUFNZCxNQUFNLEdBQUcsZUFBY2MsU0FBZCxJQUNYLENBQUM3QixVQUFVLENBQUMyQixVQUFaLENBRFcsR0FFWDNCLFVBQVUsQ0FBQzJCLFVBRmY7QUFHQSxXQUFPLEtBQUtmLE9BQUwsQ0FBYSxnQkFBYixFQUErQjtBQUFFTixNQUFBQSxJQUFGO0FBQVF1QixNQUFBQTtBQUFSLEtBQS9CLEVBQW9EZCxNQUFwRCxDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFdUIsRUFBQUEsTUFBTSxDQUNKaEMsSUFESSxFQUVKaUMsV0FGSSxFQUdKQyxXQUhJLEVBSWlCO0FBQ3JCLFdBQU8sS0FBSzVCLE9BQUwsQ0FDTCxnQkFESyxFQUVMO0FBQUVOLE1BQUFBLElBQUY7QUFBUWlDLE1BQUFBLFdBQVI7QUFBcUJDLE1BQUFBO0FBQXJCLEtBRkssRUFHTHhDLFVBQVUsQ0FBQzJCLFVBSE4sQ0FBUDtBQUtEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0VjLEVBQUFBLFFBQVEsQ0FBQ0MsV0FBRCxFQUF3RDtBQUM5RCxRQUFJLENBQUNBLFdBQUwsRUFBa0I7QUFDaEJBLE1BQUFBLFdBQVcsR0FBRyxLQUFLL0IsS0FBTCxDQUFXUyxPQUF6QjtBQUNEOztBQUNELFdBQU8sS0FBS1IsT0FBTCxDQUNMLGtCQURLLEVBRUw7QUFBRThCLE1BQUFBO0FBQUYsS0FGSyxFQUdMMUMsVUFBVSxDQUFDMkMsc0JBSE4sQ0FBUDtBQUtEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRUMsRUFBQUEsSUFBSSxDQUNGQyxPQURFLEVBRUZILFdBRkUsRUFHeUI7QUFDM0IsUUFBSSxDQUFDQSxXQUFMLEVBQWtCO0FBQ2hCQSxNQUFBQSxXQUFXLEdBQUcsS0FBSy9CLEtBQUwsQ0FBV1MsT0FBekI7QUFDRDs7QUFDRCxXQUFPLEtBQUtSLE9BQUwsQ0FBYSxjQUFiLEVBQTZCO0FBQUVpQyxNQUFBQSxPQUFGO0FBQVdILE1BQUFBO0FBQVgsS0FBN0IsRUFBdUQsQ0FDNUQxQyxVQUFVLENBQUM4QyxjQURpRCxDQUF2RCxDQUFQO0FBR0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFQyxFQUFBQSxXQUFXLENBQUNDLGNBQUQsRUFBeUI7QUFDbEMsVUFBTTNCLEdBQUcsR0FBRyxLQUFLVCxPQUFMLENBQ1YsYUFEVSxFQUVWO0FBQUVvQyxNQUFBQTtBQUFGLEtBRlUsRUFHVmhELFVBQVUsQ0FBQ2lELFdBSEQsQ0FBWjs7QUFLQSxXQUFPLElBQUlDLGtCQUFKLENBQXVCLElBQXZCLEVBQTZCN0IsR0FBN0IsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRThCLEVBQUFBLFFBQVEsQ0FBQ0MsT0FBRCxFQUFvQztBQUMxQyxVQUFNL0IsR0FBRyxHQUFHLEtBQUtULE9BQUwsQ0FDVixVQURVLEVBRVY7QUFBRXdDLE1BQUFBO0FBQUYsS0FGVSxFQUdWcEQsVUFBVSxDQUFDcUQsY0FIRCxDQUFaOztBQUtBLFdBQU8sSUFBSUMscUJBQUosQ0FBMEIsSUFBMUIsRUFBZ0NqQyxHQUFoQyxDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFa0MsRUFBQUEsbUJBQW1CLENBQUNQLGNBQUQsRUFBa0Q7QUFDbkUsV0FBTyxLQUFLcEMsT0FBTCxDQUNMLHFCQURLLEVBRUw7QUFBRW9DLE1BQUFBO0FBQUYsS0FGSyxFQUdMaEQsVUFBVSxDQUFDcUQsY0FITixDQUFQO0FBS0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0UsUUFBYUcsc0JBQWIsQ0FBb0NDLE9BQXBDLEVBR29CO0FBQ2xCLFVBQU07QUFBRUMsTUFBQUEsRUFBRjtBQUFNQyxNQUFBQTtBQUFOLFFBQWVGLE9BQXJCO0FBQ0EsUUFBSUcsUUFBSjs7QUFDQSxRQUFJRCxJQUFKLEVBQVU7QUFDUixZQUFNRSxXQUFXLEdBQUcsZ0JBQWU7QUFDakNDLFFBQUFBLHdCQUF3QixFQUFFSjtBQURPLE9BQWYsQ0FBcEI7O0FBSUEsWUFBTUssV0FBd0IsR0FBRztBQUMvQmxELFFBQUFBLE1BQU0sRUFBRSxNQUR1QjtBQUUvQm1ELFFBQUFBLEdBQUcsRUFBRyxHQUFFLEtBQUtyRCxLQUFMLENBQVdzRCxRQUFYLEVBQXNCLHlCQUZDO0FBRy9CQyxRQUFBQSxJQUFJLEVBQUVMLFdBSHlCO0FBSS9CTSxRQUFBQSxPQUFPLEVBQUU7QUFDUCwwQkFBZ0I7QUFEVDtBQUpzQixPQUFqQztBQVFBLFlBQU1DLGNBQWMsR0FBRztBQUFFRCxRQUFBQSxPQUFPLEVBQUU7QUFBWCxPQUF2QixDQWJRLENBY1I7QUFDQTtBQUNBOztBQUNBUCxNQUFBQSxRQUFRLEdBQUcsQ0FDVCxNQUFNLEtBQUtqRCxLQUFMLENBQVd5QyxPQUFYLENBQW1DVyxXQUFuQyxFQUFnREssY0FBaEQsQ0FERyxFQUVUVixFQUZGO0FBR0QsS0FwQkQsTUFvQk87QUFDTEUsTUFBQUEsUUFBUSxHQUFHLE1BQU0sS0FBS2hELE9BQUwsQ0FBYSx3QkFBYixFQUF1QztBQUN0RHlELFFBQUFBLFlBQVksRUFBRVg7QUFEd0MsT0FBdkMsQ0FBakI7QUFHRDs7QUFFRCxXQUFPRSxRQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTs7O0FBQ0VVLEVBQUFBLFVBQVUsQ0FDUkMsUUFEUSxFQUVSZCxPQUErQixHQUFHLEVBRjFCLEVBR2dCO0FBQ3hCLFVBQU1lLElBQUksR0FBRyxJQUFJNUUsUUFBSixFQUFiO0FBQ0E0RSxJQUFBQSxJQUFJLENBQUNDLE1BQUwsQ0FBWSxNQUFaLEVBQW9CRixRQUFwQixFQUE4QjtBQUM1QkcsTUFBQUEsV0FBVyxFQUFFLGlCQURlO0FBRTVCQyxNQUFBQSxRQUFRLEVBQUU7QUFGa0IsS0FBOUIsRUFGd0IsQ0FPeEI7O0FBQ0FILElBQUFBLElBQUksQ0FBQ0MsTUFBTCxDQUFZLGdCQUFaLEVBQThCLGdCQUFlO0FBQUVHLE1BQUFBLGFBQWEsRUFBRW5CO0FBQWpCLEtBQWYsQ0FBOUIsRUFBMEU7QUFDeEVpQixNQUFBQSxXQUFXLEVBQUU7QUFEMkQsS0FBMUU7QUFJQSxVQUFNdEIsT0FBb0IsR0FBRztBQUMzQlksTUFBQUEsR0FBRyxFQUFFLHlCQURzQjtBQUUzQm5ELE1BQUFBLE1BQU0sRUFBRSxNQUZtQjtBQUczQnNELE1BQUFBLE9BQU8sb0JBQU9LLElBQUksQ0FBQ0ssVUFBTCxFQUFQLENBSG9CO0FBSTNCWCxNQUFBQSxJQUFJLEVBQUVNLElBQUksQ0FBQ00sU0FBTDtBQUpxQixLQUE3Qjs7QUFNQSxVQUFNekQsR0FBRyxHQUFHLEtBQUtWLEtBQUwsQ0FBV3lDLE9BQVgsQ0FBZ0NBLE9BQWhDLENBQVo7O0FBRUEsV0FBTyxJQUFJMkIsbUJBQUosQ0FBd0IsSUFBeEIsRUFBOEIxRCxHQUE5QixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFMkQsRUFBQUEsTUFBTSxDQUNKVCxRQURJLEVBRUpkLE9BQStCLEdBQUcsRUFGOUIsRUFHb0I7QUFDeEIsVUFBTXBDLEdBQUcsR0FBRyxDQUFDLFlBQVk7QUFDdkIsWUFBTTRELGFBQWEsR0FBRyxNQUFNLGFBQVksQ0FBQ0MsT0FBRCxFQUFVQyxNQUFWLEtBQXFCO0FBQzNELFlBQ0VwRixRQUFRLENBQUN3RSxRQUFELENBQVIsSUFDQSxVQUFVQSxRQURWLElBRUEsT0FBT0EsUUFBUSxDQUFDYSxJQUFoQixLQUF5QixVQUgzQixFQUlFO0FBQ0EsZ0JBQU1DLElBQWMsR0FBRyxFQUF2QjtBQUNBZCxVQUFBQSxRQUFRLENBQUNlLEVBQVQsQ0FBWSxNQUFaLEVBQXFCQyxDQUFELElBQU9GLElBQUksQ0FBQ0csSUFBTCxDQUFVRCxDQUFWLENBQTNCO0FBQ0FoQixVQUFBQSxRQUFRLENBQUNlLEVBQVQsQ0FBWSxPQUFaLEVBQXFCSCxNQUFyQjtBQUNBWixVQUFBQSxRQUFRLENBQUNlLEVBQVQsQ0FBWSxLQUFaLEVBQW1CLE1BQU07QUFDdkJKLFlBQUFBLE9BQU8sQ0FBQyx3QkFBQU8sTUFBTSxNQUFOLENBQUFBLE1BQU0sRUFBUUosSUFBUixDQUFOLENBQW9CSyxRQUFwQixDQUE2QixRQUE3QixDQUFELENBQVA7QUFDRCxXQUZELEVBSkEsQ0FPQTtBQUNELFNBWkQsTUFZTyxJQUFJbkIsUUFBUSxZQUFZa0IsTUFBeEIsRUFBZ0M7QUFDckNQLFVBQUFBLE9BQU8sQ0FBQ1gsUUFBUSxDQUFDbUIsUUFBVCxDQUFrQixRQUFsQixDQUFELENBQVA7QUFDRCxTQUZNLE1BRUEsSUFBSW5CLFFBQVEsWUFBWW9CLE1BQXBCLElBQThCLE9BQU9wQixRQUFQLEtBQW9CLFFBQXRELEVBQWdFO0FBQ3JFVyxVQUFBQSxPQUFPLENBQUNYLFFBQUQsQ0FBUDtBQUNELFNBRk0sTUFFQTtBQUNMLGdCQUFNLDBCQUFOO0FBQ0Q7QUFDRixPQXBCMkIsQ0FBNUI7QUFzQkEsYUFBTyxLQUFLM0QsT0FBTCxDQUNMLFFBREssRUFFTDtBQUNFZ0YsUUFBQUEsT0FBTyxFQUFFWCxhQURYO0FBRUVZLFFBQUFBLGFBQWEsRUFBRXBDO0FBRmpCLE9BRkssRUFNTHpELFVBQVUsQ0FBQzhGLFlBTk4sQ0FBUDtBQVFELEtBL0JXLEdBQVo7O0FBaUNBLFdBQU8sSUFBSWYsbUJBQUosQ0FBd0IsSUFBeEIsRUFBOEIxRCxHQUE5QixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFMEUsRUFBQUEsaUJBQWlCLENBQ2YvQyxjQURlLEVBRWZnRCxjQUF1QixHQUFHLEtBRlgsRUFHUTtBQUN2QixXQUFPLEtBQUtwRixPQUFMLENBQ0wsbUJBREssRUFFTDtBQUNFb0MsTUFBQUEsY0FERjtBQUVFZ0QsTUFBQUE7QUFGRixLQUZLLEVBTUxoRyxVQUFVLENBQUM4RixZQU5OLENBQVA7QUFRRDs7QUFwWXdDO0FBdVkzQzs7QUFFQTtBQUNBO0FBQ0E7O0FBQ0EsT0FBTyxNQUFNNUMsa0JBQU4sU0FHR3hELFlBSEgsQ0FHZ0I7QUFLckI7QUFDRjtBQUNBO0FBQ0VlLEVBQUFBLFdBQVcsQ0FBQ3dGLElBQUQsRUFBdUJDLE9BQXZCLEVBQXNEO0FBQy9EOztBQUQrRDs7QUFBQTs7QUFBQTs7QUFFL0QsU0FBS0MsS0FBTCxHQUFhRixJQUFiO0FBQ0EsU0FBS0csUUFBTCxHQUFnQkYsT0FBaEI7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0VHLEVBQUFBLElBQUksQ0FDRkMsU0FERSxFQUVGQyxRQUZFLEVBR2M7QUFDaEIsV0FBTyxLQUFLSCxRQUFMLENBQWNDLElBQWQsQ0FBbUJDLFNBQW5CLEVBQThCQyxRQUE5QixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFLFFBQU1DLEtBQU4sR0FBYztBQUNaLFVBQU1qRixNQUFNLEdBQUcsTUFBTSxLQUFLNkUsUUFBMUI7QUFDQSxTQUFLSyxHQUFMLEdBQVdsRixNQUFNLENBQUNtQyxFQUFsQjtBQUNBLFdBQU8sTUFBTSxLQUFLeUMsS0FBTCxDQUFXcEQsV0FBWCxDQUF1QnhCLE1BQU0sQ0FBQ21DLEVBQTlCLENBQWI7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0VnRCxFQUFBQSxJQUFJLENBQUNDLFFBQUQsRUFBbUJDLE9BQW5CLEVBQW9DO0FBQ3RDLFVBQU1DLFNBQVMsR0FBRyxJQUFJQyxJQUFKLEdBQVdDLE9BQVgsRUFBbEI7O0FBQ0EsVUFBTUwsSUFBSSxHQUFHLFlBQVk7QUFDdkIsVUFBSTtBQUNGLGNBQU1NLEdBQUcsR0FBRyxJQUFJRixJQUFKLEdBQVdDLE9BQVgsRUFBWjs7QUFDQSxZQUFJRixTQUFTLEdBQUdELE9BQVosR0FBc0JJLEdBQTFCLEVBQStCO0FBQzdCLGNBQUlDLE1BQU0sR0FBRyxtQkFBYjs7QUFDQSxjQUFJLEtBQUtSLEdBQVQsRUFBYztBQUNaUSxZQUFBQSxNQUFNLElBQUksbUJBQW1CLEtBQUtSLEdBQWxDO0FBQ0Q7O0FBQ0QsZUFBS1MsSUFBTCxDQUFVLE9BQVYsRUFBbUIsSUFBSUMsS0FBSixDQUFVRixNQUFWLENBQW5CO0FBQ0E7QUFDRDs7QUFDRCxjQUFNMUYsTUFBTSxHQUFHLE1BQU0sS0FBS2lGLEtBQUwsRUFBckI7O0FBQ0EsWUFBSWpGLE1BQU0sQ0FBQzZGLElBQVgsRUFBaUI7QUFDZixlQUFLRixJQUFMLENBQVUsVUFBVixFQUFzQjNGLE1BQXRCO0FBQ0QsU0FGRCxNQUVPO0FBQ0wsZUFBSzJGLElBQUwsQ0FBVSxVQUFWLEVBQXNCM0YsTUFBdEI7O0FBQ0Esc0JBQVdtRixJQUFYLEVBQWlCQyxRQUFqQjtBQUNEO0FBQ0YsT0FqQkQsQ0FpQkUsT0FBT1UsR0FBUCxFQUFZO0FBQ1osYUFBS0gsSUFBTCxDQUFVLE9BQVYsRUFBbUJHLEdBQW5CO0FBQ0Q7QUFDRixLQXJCRDs7QUFzQkEsZ0JBQVdYLElBQVgsRUFBaUJDLFFBQWpCO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFVyxFQUFBQSxRQUFRLEdBQUc7QUFDVCxXQUFPLGFBQWUsQ0FBQ3BDLE9BQUQsRUFBVUMsTUFBVixLQUFxQjtBQUN6QyxXQUFLRyxFQUFMLENBQVEsVUFBUixFQUFvQkosT0FBcEI7QUFDQSxXQUFLSSxFQUFMLENBQVEsT0FBUixFQUFpQkgsTUFBakI7QUFDQSxXQUFLdUIsSUFBTCxDQUFVLEtBQUtQLEtBQUwsQ0FBV29CLFlBQXJCLEVBQW1DLEtBQUtwQixLQUFMLENBQVdxQixXQUE5QztBQUNELEtBSk0sQ0FBUDtBQUtEOztBQTNFb0I7QUE4RXZCOztBQUNBO0FBQ0E7QUFDQTs7QUFDQSxPQUFPLE1BQU1sRSxxQkFBTixTQUFzREosa0JBQXRELENBR0w7QUFDQTtBQUNGO0FBQ0E7QUFDQTtBQUNFLFFBQU1vRSxRQUFOLEdBQWlCO0FBQ2YsVUFBTS9GLE1BQU0sR0FBRyxNQUFNLE1BQU0rRixRQUFOLEVBQXJCO0FBQ0EsV0FBTyxLQUFLbkIsS0FBTCxDQUFXNUMsbUJBQVgsQ0FBK0JoQyxNQUFNLENBQUNtQyxFQUF0QyxDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFK0QsRUFBQUEsTUFBTSxHQUFHO0FBQ1AsVUFBTUMsWUFBWSxHQUFHLElBQUkvSCxRQUFKLEVBQXJCO0FBQ0EsUUFBSWdJLE9BQU8sR0FBRyxLQUFkOztBQUNBRCxJQUFBQSxZQUFZLENBQUNFLEtBQWIsR0FBcUIsWUFBWTtBQUMvQixVQUFJRCxPQUFKLEVBQWE7QUFDWDtBQUNEOztBQUNEQSxNQUFBQSxPQUFPLEdBQUcsSUFBVjs7QUFDQSxVQUFJO0FBQ0YsY0FBTXBHLE1BQU0sR0FBRyxNQUFNLEtBQUsrRixRQUFMLEVBQXJCO0FBQ0FJLFFBQUFBLFlBQVksQ0FBQ2xDLElBQWIsQ0FBa0JDLE1BQU0sQ0FBQ29DLElBQVAsQ0FBWXRHLE1BQU0sQ0FBQ3VHLE9BQW5CLEVBQTRCLFFBQTVCLENBQWxCO0FBQ0FKLFFBQUFBLFlBQVksQ0FBQ2xDLElBQWIsQ0FBa0IsSUFBbEI7QUFDRCxPQUpELENBSUUsT0FBT3VDLENBQVAsRUFBVTtBQUNWTCxRQUFBQSxZQUFZLENBQUNSLElBQWIsQ0FBa0IsT0FBbEIsRUFBMkJhLENBQTNCO0FBQ0Q7QUFDRixLQVpEOztBQWFBLFdBQU9MLFlBQVA7QUFDRDs7QUE5QkQ7QUFpQ0Y7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLE9BQU8sTUFBTTNDLG1CQUFOLFNBQW9EN0Isa0JBQXBELENBR0w7QUFDQTtBQUNGO0FBQ0E7QUFDQTtBQUNFLFFBQU1vRSxRQUFOLENBQWV0QixjQUFmLEVBQXlDO0FBQ3ZDLFVBQU16RSxNQUFNLEdBQUcsTUFBTSxNQUFNK0YsUUFBTixFQUFyQjtBQUNBLFdBQU8sS0FBS25CLEtBQUwsQ0FBV0osaUJBQVgsQ0FBNkJ4RSxNQUFNLENBQUNtQyxFQUFwQyxFQUF3Q3NDLGNBQXhDLENBQVA7QUFDRDs7QUFSRDtBQVdGOztBQUNBO0FBQ0E7QUFDQTs7QUFDQW5HLGNBQWMsQ0FBQyxVQUFELEVBQWNhLElBQUQsSUFBVSxJQUFJRixXQUFKLENBQWdCRSxJQUFoQixDQUF2QixDQUFkO0FBRUEsZUFBZUYsV0FBZiIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGZpbGUgTWFuYWdlcyBTYWxlc2ZvcmNlIE1ldGFkYXRhIEFQSVxuICogQGF1dGhvciBTaGluaWNoaSBUb21pdGEgPHNoaW5pY2hpLnRvbWl0YUBnbWFpbC5jb20+XG4gKi9cbmltcG9ydCB7IEV2ZW50RW1pdHRlciB9IGZyb20gJ2V2ZW50cyc7XG5pbXBvcnQgeyBSZWFkYWJsZSB9IGZyb20gJ3N0cmVhbSc7XG5pbXBvcnQgRm9ybURhdGEgZnJvbSAnZm9ybS1kYXRhJztcbmltcG9ydCB7IHJlZ2lzdGVyTW9kdWxlIH0gZnJvbSAnLi4vanNmb3JjZSc7XG5pbXBvcnQgQ29ubmVjdGlvbiBmcm9tICcuLi9jb25uZWN0aW9uJztcbmltcG9ydCBTT0FQIGZyb20gJy4uL3NvYXAnO1xuaW1wb3J0IHsgaXNPYmplY3QgfSBmcm9tICcuLi91dGlsL2Z1bmN0aW9uJztcbmltcG9ydCB7IFNjaGVtYSwgU29hcFNjaGVtYURlZiwgU29hcFNjaGVtYSwgSHR0cFJlcXVlc3QgfSBmcm9tICcuLi90eXBlcyc7XG5pbXBvcnQge1xuICBBcGlTY2hlbWFzLFxuICBNZXRhZGF0YSxcbiAgUmVhZFJlc3VsdCxcbiAgU2F2ZVJlc3VsdCxcbiAgVXBzZXJ0UmVzdWx0LFxuICBMaXN0TWV0YWRhdGFRdWVyeSxcbiAgRmlsZVByb3BlcnRpZXMsXG4gIERlc2NyaWJlTWV0YWRhdGFSZXN1bHQsXG4gIFJldHJpZXZlUmVxdWVzdCxcbiAgRGVwbG95T3B0aW9ucyxcbiAgUmV0cmlldmVSZXN1bHQsXG4gIERlcGxveVJlc3VsdCxcbiAgQXN5bmNSZXN1bHQsXG4gIEFwaVNjaGVtYVR5cGVzLFxufSBmcm9tICcuL21ldGFkYXRhL3NjaGVtYSc7XG5leHBvcnQgKiBmcm9tICcuL21ldGFkYXRhL3NjaGVtYSc7XG5cbi8qKlxuICpcbiAqL1xudHlwZSBNZXRhZGF0YVR5cGVfPFxuICBLIGV4dGVuZHMga2V5b2YgQXBpU2NoZW1hVHlwZXMgPSBrZXlvZiBBcGlTY2hlbWFUeXBlc1xuPiA9IEsgZXh0ZW5kcyBrZXlvZiBBcGlTY2hlbWFUeXBlc1xuICA/IEFwaVNjaGVtYVR5cGVzW0tdIGV4dGVuZHMgTWV0YWRhdGFcbiAgICA/IEtcbiAgICA6IG5ldmVyXG4gIDogbmV2ZXI7XG5cbmV4cG9ydCB0eXBlIE1ldGFkYXRhVHlwZSA9IE1ldGFkYXRhVHlwZV87XG5cbmV4cG9ydCB0eXBlIE1ldGFkYXRhRGVmaW5pdGlvbjxcbiAgVCBleHRlbmRzIHN0cmluZyxcbiAgTSBleHRlbmRzIE1ldGFkYXRhID0gTWV0YWRhdGFcbj4gPSBNZXRhZGF0YSBleHRlbmRzIE1cbiAgPyBUIGV4dGVuZHMga2V5b2YgQXBpU2NoZW1hVHlwZXMgJiBNZXRhZGF0YVR5cGVcbiAgICA/IEFwaVNjaGVtYVR5cGVzW1RdIGV4dGVuZHMgTWV0YWRhdGFcbiAgICAgID8gQXBpU2NoZW1hVHlwZXNbVF1cbiAgICAgIDogTWV0YWRhdGFcbiAgICA6IE1ldGFkYXRhXG4gIDogTTtcblxudHlwZSBEZWVwUGFydGlhbDxUPiA9IFQgZXh0ZW5kcyBhbnlbXVxuICA/IERlZXBQYXJ0aWFsPFRbbnVtYmVyXT5bXVxuICA6IFQgZXh0ZW5kcyBvYmplY3RcbiAgPyB7IFtLIGluIGtleW9mIFRdPzogRGVlcFBhcnRpYWw8VFtLXT4gfVxuICA6IFQ7XG5cbmV4cG9ydCB0eXBlIElucHV0TWV0YWRhdGFEZWZpbml0aW9uPFxuICBUIGV4dGVuZHMgc3RyaW5nLFxuICBNIGV4dGVuZHMgTWV0YWRhdGEgPSBNZXRhZGF0YVxuPiA9IERlZXBQYXJ0aWFsPE1ldGFkYXRhRGVmaW5pdGlvbjxULCBNPj47XG5cbi8qKlxuICpcbiAqL1xuZnVuY3Rpb24gZGVhbGxvY2F0ZVR5cGVXaXRoTWV0YWRhdGE8TSBleHRlbmRzIE1ldGFkYXRhPihtZXRhZGF0YTogTSk6IE0ge1xuICBjb25zdCB7ICQsIC4uLm1kIH0gPSBtZXRhZGF0YSBhcyBhbnk7XG4gIHJldHVybiBtZDtcbn1cblxuZnVuY3Rpb24gYXNzaWduVHlwZVdpdGhNZXRhZGF0YShtZXRhZGF0YTogTWV0YWRhdGEgfCBNZXRhZGF0YVtdLCB0eXBlOiBzdHJpbmcpIHtcbiAgY29uc3QgY29udmVydCA9IChtZDogTWV0YWRhdGEpID0+ICh7IFsnQHhzaTp0eXBlJ106IHR5cGUsIC4uLm1kIH0pO1xuICByZXR1cm4gQXJyYXkuaXNBcnJheShtZXRhZGF0YSkgPyBtZXRhZGF0YS5tYXAoY29udmVydCkgOiBjb252ZXJ0KG1ldGFkYXRhKTtcbn1cblxuLyoqXG4gKiBDbGFzcyBmb3IgU2FsZXNmb3JjZSBNZXRhZGF0YSBBUElcbiAqL1xuZXhwb3J0IGNsYXNzIE1ldGFkYXRhQXBpPFMgZXh0ZW5kcyBTY2hlbWE+IHtcbiAgX2Nvbm46IENvbm5lY3Rpb248Uz47XG5cbiAgLyoqXG4gICAqIFBvbGxpbmcgaW50ZXJ2YWwgaW4gbWlsbGlzZWNvbmRzXG4gICAqL1xuICBwb2xsSW50ZXJ2YWw6IG51bWJlciA9IDEwMDA7XG5cbiAgLyoqXG4gICAqIFBvbGxpbmcgdGltZW91dCBpbiBtaWxsaXNlY29uZHNcbiAgICovXG4gIHBvbGxUaW1lb3V0OiBudW1iZXIgPSAxMDAwMDtcblxuICAvKipcbiAgICpcbiAgICovXG4gIGNvbnN0cnVjdG9yKGNvbm46IENvbm5lY3Rpb248Uz4pIHtcbiAgICB0aGlzLl9jb25uID0gY29ubjtcbiAgfVxuXG4gIC8qKlxuICAgKiBDYWxsIE1ldGFkYXRhIEFQSSBTT0FQIGVuZHBvaW50XG4gICAqXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBhc3luYyBfaW52b2tlKFxuICAgIG1ldGhvZDogc3RyaW5nLFxuICAgIG1lc3NhZ2U6IG9iamVjdCxcbiAgICBzY2hlbWE/OiBTb2FwU2NoZW1hIHwgU29hcFNjaGVtYURlZixcbiAgKSB7XG4gICAgY29uc3Qgc29hcEVuZHBvaW50ID0gbmV3IFNPQVAodGhpcy5fY29ubiwge1xuICAgICAgeG1sbnM6ICdodHRwOi8vc29hcC5zZm9yY2UuY29tLzIwMDYvMDQvbWV0YWRhdGEnLFxuICAgICAgZW5kcG9pbnRVcmw6IGAke3RoaXMuX2Nvbm4uaW5zdGFuY2VVcmx9L3NlcnZpY2VzL1NvYXAvbS8ke3RoaXMuX2Nvbm4udmVyc2lvbn1gLFxuICAgIH0pO1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHNvYXBFbmRwb2ludC5pbnZva2UoXG4gICAgICBtZXRob2QsXG4gICAgICBtZXNzYWdlLFxuICAgICAgc2NoZW1hID8gKHsgcmVzdWx0OiBzY2hlbWEgfSBhcyBTb2FwU2NoZW1hKSA6IHVuZGVmaW5lZCxcbiAgICAgIEFwaVNjaGVtYXMsXG4gICAgKTtcbiAgICByZXR1cm4gcmVzLnJlc3VsdDtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGQgb25lIG9yIG1vcmUgbmV3IG1ldGFkYXRhIGNvbXBvbmVudHMgdG8gdGhlIG9yZ2FuaXphdGlvbi5cbiAgICovXG4gIGNyZWF0ZTxcbiAgICBNIGV4dGVuZHMgTWV0YWRhdGEgPSBNZXRhZGF0YSxcbiAgICBUIGV4dGVuZHMgTWV0YWRhdGFUeXBlID0gTWV0YWRhdGFUeXBlLFxuICAgIE1EIGV4dGVuZHMgSW5wdXRNZXRhZGF0YURlZmluaXRpb248VCwgTT4gPSBJbnB1dE1ldGFkYXRhRGVmaW5pdGlvbjxULCBNPlxuICA+KHR5cGU6IFQsIG1ldGFkYXRhOiBNRFtdKTogUHJvbWlzZTxTYXZlUmVzdWx0W10+O1xuICBjcmVhdGU8XG4gICAgTSBleHRlbmRzIE1ldGFkYXRhID0gTWV0YWRhdGEsXG4gICAgVCBleHRlbmRzIE1ldGFkYXRhVHlwZSA9IE1ldGFkYXRhVHlwZSxcbiAgICBNRCBleHRlbmRzIElucHV0TWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+ID0gSW5wdXRNZXRhZGF0YURlZmluaXRpb248VCwgTT5cbiAgPih0eXBlOiBULCBtZXRhZGF0YTogTUQpOiBQcm9taXNlPFNhdmVSZXN1bHQ+O1xuICBjcmVhdGU8XG4gICAgTSBleHRlbmRzIE1ldGFkYXRhID0gTWV0YWRhdGEsXG4gICAgVCBleHRlbmRzIE1ldGFkYXRhVHlwZSA9IE1ldGFkYXRhVHlwZSxcbiAgICBNRCBleHRlbmRzIElucHV0TWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+ID0gSW5wdXRNZXRhZGF0YURlZmluaXRpb248VCwgTT5cbiAgPih0eXBlOiBULCBtZXRhZGF0YTogTUQgfCBNRFtdKTogUHJvbWlzZTxTYXZlUmVzdWx0IHwgU2F2ZVJlc3VsdFtdPjtcbiAgY3JlYXRlKHR5cGU6IHN0cmluZywgbWV0YWRhdGE6IE1ldGFkYXRhIHwgTWV0YWRhdGFbXSkge1xuICAgIGNvbnN0IGlzQXJyYXkgPSBBcnJheS5pc0FycmF5KG1ldGFkYXRhKTtcbiAgICBtZXRhZGF0YSA9IGFzc2lnblR5cGVXaXRoTWV0YWRhdGEobWV0YWRhdGEsIHR5cGUpO1xuICAgIGNvbnN0IHNjaGVtYSA9IGlzQXJyYXkgPyBbQXBpU2NoZW1hcy5TYXZlUmVzdWx0XSA6IEFwaVNjaGVtYXMuU2F2ZVJlc3VsdDtcbiAgICByZXR1cm4gdGhpcy5faW52b2tlKCdjcmVhdGVNZXRhZGF0YScsIHsgbWV0YWRhdGEgfSwgc2NoZW1hKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZWFkIHNwZWNpZmllZCBtZXRhZGF0YSBjb21wb25lbnRzIGluIHRoZSBvcmdhbml6YXRpb24uXG4gICAqL1xuICByZWFkPFxuICAgIE0gZXh0ZW5kcyBNZXRhZGF0YSA9IE1ldGFkYXRhLFxuICAgIFQgZXh0ZW5kcyBNZXRhZGF0YVR5cGUgPSBNZXRhZGF0YVR5cGUsXG4gICAgTUQgZXh0ZW5kcyBNZXRhZGF0YURlZmluaXRpb248VCwgTT4gPSBNZXRhZGF0YURlZmluaXRpb248VCwgTT5cbiAgPih0eXBlOiBULCBmdWxsTmFtZXM6IHN0cmluZ1tdKTogUHJvbWlzZTxNRFtdPjtcbiAgcmVhZDxcbiAgICBNIGV4dGVuZHMgTWV0YWRhdGEgPSBNZXRhZGF0YSxcbiAgICBUIGV4dGVuZHMgTWV0YWRhdGFUeXBlID0gTWV0YWRhdGFUeXBlLFxuICAgIE1EIGV4dGVuZHMgTWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+ID0gTWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+XG4gID4odHlwZTogVCwgZnVsbE5hbWVzOiBzdHJpbmcpOiBQcm9taXNlPE1EPjtcbiAgcmVhZDxcbiAgICBNIGV4dGVuZHMgTWV0YWRhdGEgPSBNZXRhZGF0YSxcbiAgICBUIGV4dGVuZHMgTWV0YWRhdGFUeXBlID0gTWV0YWRhdGFUeXBlLFxuICAgIE1EIGV4dGVuZHMgTWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+ID0gTWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+XG4gID4odHlwZTogVCwgZnVsbE5hbWVzOiBzdHJpbmcgfCBzdHJpbmdbXSk6IFByb21pc2U8TUQgfCBNRFtdPjtcbiAgYXN5bmMgcmVhZCh0eXBlOiBzdHJpbmcsIGZ1bGxOYW1lczogc3RyaW5nIHwgc3RyaW5nW10pIHtcbiAgICBjb25zdCBSZWFkUmVzdWx0U2NoZW1hID1cbiAgICAgIHR5cGUgaW4gQXBpU2NoZW1hc1xuICAgICAgICA/ICh7XG4gICAgICAgICAgICB0eXBlOiBBcGlTY2hlbWFzLlJlYWRSZXN1bHQudHlwZSxcbiAgICAgICAgICAgIHByb3BzOiB7XG4gICAgICAgICAgICAgIHJlY29yZHM6IFt0eXBlXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSBhcyBjb25zdClcbiAgICAgICAgOiBBcGlTY2hlbWFzLlJlYWRSZXN1bHQ7XG4gICAgY29uc3QgcmVzOiBSZWFkUmVzdWx0ID0gYXdhaXQgdGhpcy5faW52b2tlKFxuICAgICAgJ3JlYWRNZXRhZGF0YScsXG4gICAgICB7IHR5cGUsIGZ1bGxOYW1lcyB9LFxuICAgICAgUmVhZFJlc3VsdFNjaGVtYSxcbiAgICApO1xuICAgIHJldHVybiBBcnJheS5pc0FycmF5KGZ1bGxOYW1lcylcbiAgICAgID8gcmVzLnJlY29yZHMubWFwKGRlYWxsb2NhdGVUeXBlV2l0aE1ldGFkYXRhKVxuICAgICAgOiBkZWFsbG9jYXRlVHlwZVdpdGhNZXRhZGF0YShyZXMucmVjb3Jkc1swXSk7XG4gIH1cblxuICAvKipcbiAgICogVXBkYXRlIG9uZSBvciBtb3JlIG1ldGFkYXRhIGNvbXBvbmVudHMgaW4gdGhlIG9yZ2FuaXphdGlvbi5cbiAgICovXG4gIHVwZGF0ZTxcbiAgICBNIGV4dGVuZHMgTWV0YWRhdGEgPSBNZXRhZGF0YSxcbiAgICBUIGV4dGVuZHMgc3RyaW5nID0gc3RyaW5nLFxuICAgIE1EIGV4dGVuZHMgSW5wdXRNZXRhZGF0YURlZmluaXRpb248VCwgTT4gPSBJbnB1dE1ldGFkYXRhRGVmaW5pdGlvbjxULCBNPlxuICA+KHR5cGU6IFQsIG1ldGFkYXRhOiBQYXJ0aWFsPE1EPltdKTogUHJvbWlzZTxTYXZlUmVzdWx0W10+O1xuICB1cGRhdGU8XG4gICAgTSBleHRlbmRzIE1ldGFkYXRhID0gTWV0YWRhdGEsXG4gICAgVCBleHRlbmRzIHN0cmluZyA9IHN0cmluZyxcbiAgICBNRCBleHRlbmRzIElucHV0TWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+ID0gSW5wdXRNZXRhZGF0YURlZmluaXRpb248VCwgTT5cbiAgPih0eXBlOiBULCBtZXRhZGF0YTogUGFydGlhbDxNRD4pOiBQcm9taXNlPFNhdmVSZXN1bHQ+O1xuICB1cGRhdGU8XG4gICAgTSBleHRlbmRzIE1ldGFkYXRhID0gTWV0YWRhdGEsXG4gICAgVCBleHRlbmRzIHN0cmluZyA9IHN0cmluZyxcbiAgICBNRCBleHRlbmRzIElucHV0TWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+ID0gSW5wdXRNZXRhZGF0YURlZmluaXRpb248VCwgTT5cbiAgPihcbiAgICB0eXBlOiBULFxuICAgIG1ldGFkYXRhOiBQYXJ0aWFsPE1EPiB8IFBhcnRpYWw8TUQ+W10sXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdCB8IFNhdmVSZXN1bHRbXT47XG4gIHVwZGF0ZSh0eXBlOiBzdHJpbmcsIG1ldGFkYXRhOiBNZXRhZGF0YSB8IE1ldGFkYXRhW10pIHtcbiAgICBjb25zdCBpc0FycmF5ID0gQXJyYXkuaXNBcnJheShtZXRhZGF0YSk7XG4gICAgbWV0YWRhdGEgPSBhc3NpZ25UeXBlV2l0aE1ldGFkYXRhKG1ldGFkYXRhLCB0eXBlKTtcbiAgICBjb25zdCBzY2hlbWEgPSBpc0FycmF5ID8gW0FwaVNjaGVtYXMuU2F2ZVJlc3VsdF0gOiBBcGlTY2hlbWFzLlNhdmVSZXN1bHQ7XG4gICAgcmV0dXJuIHRoaXMuX2ludm9rZSgndXBkYXRlTWV0YWRhdGEnLCB7IG1ldGFkYXRhIH0sIHNjaGVtYSk7XG4gIH1cblxuICAvKipcbiAgICogVXBzZXJ0IG9uZSBvciBtb3JlIGNvbXBvbmVudHMgaW4geW91ciBvcmdhbml6YXRpb24ncyBkYXRhLlxuICAgKi9cbiAgdXBzZXJ0PFxuICAgIE0gZXh0ZW5kcyBNZXRhZGF0YSA9IE1ldGFkYXRhLFxuICAgIFQgZXh0ZW5kcyBzdHJpbmcgPSBzdHJpbmcsXG4gICAgTUQgZXh0ZW5kcyBJbnB1dE1ldGFkYXRhRGVmaW5pdGlvbjxULCBNPiA9IElucHV0TWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+XG4gID4odHlwZTogVCwgbWV0YWRhdGE6IE1EW10pOiBQcm9taXNlPFVwc2VydFJlc3VsdFtdPjtcbiAgdXBzZXJ0PFxuICAgIE0gZXh0ZW5kcyBNZXRhZGF0YSA9IE1ldGFkYXRhLFxuICAgIFQgZXh0ZW5kcyBzdHJpbmcgPSBzdHJpbmcsXG4gICAgTUQgZXh0ZW5kcyBJbnB1dE1ldGFkYXRhRGVmaW5pdGlvbjxULCBNPiA9IElucHV0TWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+XG4gID4odHlwZTogVCwgbWV0YWRhdGE6IE1EKTogUHJvbWlzZTxVcHNlcnRSZXN1bHQ+O1xuICB1cHNlcnQ8XG4gICAgTSBleHRlbmRzIE1ldGFkYXRhID0gTWV0YWRhdGEsXG4gICAgVCBleHRlbmRzIHN0cmluZyA9IHN0cmluZyxcbiAgICBNRCBleHRlbmRzIElucHV0TWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+ID0gSW5wdXRNZXRhZGF0YURlZmluaXRpb248VCwgTT5cbiAgPih0eXBlOiBULCBtZXRhZGF0YTogTUQgfCBNRFtdKTogUHJvbWlzZTxVcHNlcnRSZXN1bHQgfCBVcHNlcnRSZXN1bHRbXT47XG4gIHVwc2VydCh0eXBlOiBzdHJpbmcsIG1ldGFkYXRhOiBNZXRhZGF0YSB8IE1ldGFkYXRhW10pIHtcbiAgICBjb25zdCBpc0FycmF5ID0gQXJyYXkuaXNBcnJheShtZXRhZGF0YSk7XG4gICAgbWV0YWRhdGEgPSBhc3NpZ25UeXBlV2l0aE1ldGFkYXRhKG1ldGFkYXRhLCB0eXBlKTtcbiAgICBjb25zdCBzY2hlbWEgPSBpc0FycmF5XG4gICAgICA/IFtBcGlTY2hlbWFzLlVwc2VydFJlc3VsdF1cbiAgICAgIDogQXBpU2NoZW1hcy5VcHNlcnRSZXN1bHQ7XG4gICAgcmV0dXJuIHRoaXMuX2ludm9rZSgndXBzZXJ0TWV0YWRhdGEnLCB7IG1ldGFkYXRhIH0sIHNjaGVtYSk7XG4gIH1cblxuICAvKipcbiAgICogRGVsZXRlcyBzcGVjaWZpZWQgbWV0YWRhdGEgY29tcG9uZW50cyBpbiB0aGUgb3JnYW5pemF0aW9uLlxuICAgKi9cbiAgZGVsZXRlKHR5cGU6IHN0cmluZywgZnVsbE5hbWVzOiBzdHJpbmdbXSk6IFByb21pc2U8U2F2ZVJlc3VsdFtdPjtcbiAgZGVsZXRlKHR5cGU6IHN0cmluZywgZnVsbE5hbWVzOiBzdHJpbmcpOiBQcm9taXNlPFNhdmVSZXN1bHQ+O1xuICBkZWxldGUoXG4gICAgdHlwZTogc3RyaW5nLFxuICAgIGZ1bGxOYW1lczogc3RyaW5nIHwgc3RyaW5nW10sXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdCB8IFNhdmVSZXN1bHRbXT47XG4gIGRlbGV0ZSh0eXBlOiBzdHJpbmcsIGZ1bGxOYW1lczogc3RyaW5nIHwgc3RyaW5nW10pIHtcbiAgICBjb25zdCBzY2hlbWEgPSBBcnJheS5pc0FycmF5KGZ1bGxOYW1lcylcbiAgICAgID8gW0FwaVNjaGVtYXMuU2F2ZVJlc3VsdF1cbiAgICAgIDogQXBpU2NoZW1hcy5TYXZlUmVzdWx0O1xuICAgIHJldHVybiB0aGlzLl9pbnZva2UoJ2RlbGV0ZU1ldGFkYXRhJywgeyB0eXBlLCBmdWxsTmFtZXMgfSwgc2NoZW1hKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5hbWUgZnVsbG5hbWUgb2YgYSBtZXRhZGF0YSBjb21wb25lbnQgaW4gdGhlIG9yZ2FuaXphdGlvblxuICAgKi9cbiAgcmVuYW1lKFxuICAgIHR5cGU6IHN0cmluZyxcbiAgICBvbGRGdWxsTmFtZTogc3RyaW5nLFxuICAgIG5ld0Z1bGxOYW1lOiBzdHJpbmcsXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdD4ge1xuICAgIHJldHVybiB0aGlzLl9pbnZva2UoXG4gICAgICAncmVuYW1lTWV0YWRhdGEnLFxuICAgICAgeyB0eXBlLCBvbGRGdWxsTmFtZSwgbmV3RnVsbE5hbWUgfSxcbiAgICAgIEFwaVNjaGVtYXMuU2F2ZVJlc3VsdCxcbiAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHJpZXZlcyB0aGUgbWV0YWRhdGEgd2hpY2ggZGVzY3JpYmVzIHlvdXIgb3JnYW5pemF0aW9uLCBpbmNsdWRpbmcgQXBleCBjbGFzc2VzIGFuZCB0cmlnZ2VycyxcbiAgICogY3VzdG9tIG9iamVjdHMsIGN1c3RvbSBmaWVsZHMgb24gc3RhbmRhcmQgb2JqZWN0cywgdGFiIHNldHMgdGhhdCBkZWZpbmUgYW4gYXBwLFxuICAgKiBhbmQgbWFueSBvdGhlciBjb21wb25lbnRzLlxuICAgKi9cbiAgZGVzY3JpYmUoYXNPZlZlcnNpb24/OiBzdHJpbmcpOiBQcm9taXNlPERlc2NyaWJlTWV0YWRhdGFSZXN1bHQ+IHtcbiAgICBpZiAoIWFzT2ZWZXJzaW9uKSB7XG4gICAgICBhc09mVmVyc2lvbiA9IHRoaXMuX2Nvbm4udmVyc2lvbjtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX2ludm9rZShcbiAgICAgICdkZXNjcmliZU1ldGFkYXRhJyxcbiAgICAgIHsgYXNPZlZlcnNpb24gfSxcbiAgICAgIEFwaVNjaGVtYXMuRGVzY3JpYmVNZXRhZGF0YVJlc3VsdCxcbiAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHJpZXZlcyBwcm9wZXJ0eSBpbmZvcm1hdGlvbiBhYm91dCBtZXRhZGF0YSBjb21wb25lbnRzIGluIHlvdXIgb3JnYW5pemF0aW9uXG4gICAqL1xuICBsaXN0KFxuICAgIHF1ZXJpZXM6IExpc3RNZXRhZGF0YVF1ZXJ5IHwgTGlzdE1ldGFkYXRhUXVlcnlbXSxcbiAgICBhc09mVmVyc2lvbj86IHN0cmluZyxcbiAgKTogUHJvbWlzZTxGaWxlUHJvcGVydGllc1tdPiB7XG4gICAgaWYgKCFhc09mVmVyc2lvbikge1xuICAgICAgYXNPZlZlcnNpb24gPSB0aGlzLl9jb25uLnZlcnNpb247XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9pbnZva2UoJ2xpc3RNZXRhZGF0YScsIHsgcXVlcmllcywgYXNPZlZlcnNpb24gfSwgW1xuICAgICAgQXBpU2NoZW1hcy5GaWxlUHJvcGVydGllcyxcbiAgICBdKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDaGVja3MgdGhlIHN0YXR1cyBvZiBhc3luY2hyb25vdXMgbWV0YWRhdGEgY2FsbHNcbiAgICovXG4gIGNoZWNrU3RhdHVzKGFzeW5jUHJvY2Vzc0lkOiBzdHJpbmcpIHtcbiAgICBjb25zdCByZXMgPSB0aGlzLl9pbnZva2UoXG4gICAgICAnY2hlY2tTdGF0dXMnLFxuICAgICAgeyBhc3luY1Byb2Nlc3NJZCB9LFxuICAgICAgQXBpU2NoZW1hcy5Bc3luY1Jlc3VsdCxcbiAgICApO1xuICAgIHJldHVybiBuZXcgQXN5bmNSZXN1bHRMb2NhdG9yKHRoaXMsIHJlcyk7XG4gIH1cblxuICAvKipcbiAgICogUmV0cmlldmVzIFhNTCBmaWxlIHJlcHJlc2VudGF0aW9ucyBvZiBjb21wb25lbnRzIGluIGFuIG9yZ2FuaXphdGlvblxuICAgKi9cbiAgcmV0cmlldmUocmVxdWVzdDogUGFydGlhbDxSZXRyaWV2ZVJlcXVlc3Q+KSB7XG4gICAgY29uc3QgcmVzID0gdGhpcy5faW52b2tlKFxuICAgICAgJ3JldHJpZXZlJyxcbiAgICAgIHsgcmVxdWVzdCB9LFxuICAgICAgQXBpU2NoZW1hcy5SZXRyaWV2ZVJlc3VsdCxcbiAgICApO1xuICAgIHJldHVybiBuZXcgUmV0cmlldmVSZXN1bHRMb2NhdG9yKHRoaXMsIHJlcyk7XG4gIH1cblxuICAvKipcbiAgICogQ2hlY2tzIHRoZSBzdGF0dXMgb2YgZGVjbGFyYXRpdmUgbWV0YWRhdGEgY2FsbCByZXRyaWV2ZSgpIGFuZCByZXR1cm5zIHRoZSB6aXAgZmlsZSBjb250ZW50c1xuICAgKi9cbiAgY2hlY2tSZXRyaWV2ZVN0YXR1cyhhc3luY1Byb2Nlc3NJZDogc3RyaW5nKTogUHJvbWlzZTxSZXRyaWV2ZVJlc3VsdD4ge1xuICAgIHJldHVybiB0aGlzLl9pbnZva2UoXG4gICAgICAnY2hlY2tSZXRyaWV2ZVN0YXR1cycsXG4gICAgICB7IGFzeW5jUHJvY2Vzc0lkIH0sXG4gICAgICBBcGlTY2hlbWFzLlJldHJpZXZlUmVzdWx0LFxuICAgICk7XG4gIH1cblxuICAvKipcbiAgICogV2lsbCBkZXBsb3kgYSByZWNlbnRseSB2YWxpZGF0ZWQgZGVwbG95IHJlcXVlc3RcbiAgICpcbiAgICogQHBhcmFtIG9wdGlvbnMuaWQgPSB0aGUgZGVwbG95IElEIHRoYXQncyBiZWVuIHZhbGlkYXRlZCBhbHJlYWR5IGZyb20gYSBwcmV2aW91cyBjaGVja09ubHkgZGVwbG95IHJlcXVlc3RcbiAgICogQHBhcmFtIG9wdGlvbnMucmVzdCA9IGEgYm9vbGVhbiB3aGV0aGVyIG9yIG5vdCB0byB1c2UgdGhlIFJFU1QgQVBJXG4gICAqIEByZXR1cm5zIHRoZSBkZXBsb3kgSUQgb2YgdGhlIHJlY2VudCB2YWxpZGF0aW9uIHJlcXVlc3RcbiAgICovXG4gIHB1YmxpYyBhc3luYyBkZXBsb3lSZWNlbnRWYWxpZGF0aW9uKG9wdGlvbnM6IHtcbiAgICBpZDogc3RyaW5nO1xuICAgIHJlc3Q/OiBib29sZWFuO1xuICB9KTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBjb25zdCB7IGlkLCByZXN0IH0gPSBvcHRpb25zO1xuICAgIGxldCByZXNwb25zZTogc3RyaW5nO1xuICAgIGlmIChyZXN0KSB7XG4gICAgICBjb25zdCBtZXNzYWdlQm9keSA9IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdmFsaWRhdGVkRGVwbG95UmVxdWVzdElkOiBpZCxcbiAgICAgIH0pO1xuXG4gICAgICBjb25zdCByZXF1ZXN0SW5mbzogSHR0cFJlcXVlc3QgPSB7XG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICB1cmw6IGAke3RoaXMuX2Nvbm4uX2Jhc2VVcmwoKX0vbWV0YWRhdGEvZGVwbG95UmVxdWVzdGAsXG4gICAgICAgIGJvZHk6IG1lc3NhZ2VCb2R5LFxuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgJ2NvbnRlbnQtdHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSxcbiAgICAgIH07XG4gICAgICBjb25zdCByZXF1ZXN0T3B0aW9ucyA9IHsgaGVhZGVyczogJ2pzb24nIH07XG4gICAgICAvLyBUaGlzIGlzIHRoZSBkZXBsb3kgSUQgb2YgdGhlIGRlcGxveVJlY2VudFZhbGlkYXRpb24gcmVzcG9uc2UsIG5vdFxuICAgICAgLy8gdGhlIGFscmVhZHkgdmFsaWRhdGVkIGRlcGxveSBJRCAoaS5lLiwgdmFsaWRhdGVkZGVwbG95cmVxdWVzdGlkKS5cbiAgICAgIC8vIFJFU1QgcmV0dXJucyBhbiBvYmplY3Qgd2l0aCBhbiBpZCBwcm9wZXJ0eSwgU09BUCByZXR1cm5zIHRoZSBpZCBhcyBhIHN0cmluZyBkaXJlY3RseS5cbiAgICAgIHJlc3BvbnNlID0gKFxuICAgICAgICBhd2FpdCB0aGlzLl9jb25uLnJlcXVlc3Q8eyBpZDogc3RyaW5nIH0+KHJlcXVlc3RJbmZvLCByZXF1ZXN0T3B0aW9ucylcbiAgICAgICkuaWQ7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJlc3BvbnNlID0gYXdhaXQgdGhpcy5faW52b2tlKCdkZXBsb3lSZWNlbnRWYWxpZGF0aW9uJywge1xuICAgICAgICB2YWxpZGF0aW9uSWQ6IGlkLFxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHJlc3BvbnNlO1xuICB9XG5cbiAgLyoqXG4gICAqIERlcGxveSBjb21wb25lbnRzIGludG8gYW4gb3JnYW5pemF0aW9uIHVzaW5nIHppcHBlZCBmaWxlIHJlcHJlc2VudGF0aW9uc1xuICAgKiB1c2luZyB0aGUgUkVTVCBNZXRhZGF0YSBBUEkgaW5zdGVhZCBvZiBTT0FQXG4gICAqL1xuICBkZXBsb3lSZXN0KFxuICAgIHppcElucHV0OiBCdWZmZXIsXG4gICAgb3B0aW9uczogUGFydGlhbDxEZXBsb3lPcHRpb25zPiA9IHt9LFxuICApOiBEZXBsb3lSZXN1bHRMb2NhdG9yPFM+IHtcbiAgICBjb25zdCBmb3JtID0gbmV3IEZvcm1EYXRhKCk7XG4gICAgZm9ybS5hcHBlbmQoJ2ZpbGUnLCB6aXBJbnB1dCwge1xuICAgICAgY29udGVudFR5cGU6ICdhcHBsaWNhdGlvbi96aXAnLFxuICAgICAgZmlsZW5hbWU6ICdwYWNrYWdlLnhtbCcsXG4gICAgfSk7XG5cbiAgICAvLyBBZGQgdGhlIGRlcGxveSBvcHRpb25zXG4gICAgZm9ybS5hcHBlbmQoJ2VudGl0eV9jb250ZW50JywgSlNPTi5zdHJpbmdpZnkoeyBkZXBsb3lPcHRpb25zOiBvcHRpb25zIH0pLCB7XG4gICAgICBjb250ZW50VHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgIH0pO1xuXG4gICAgY29uc3QgcmVxdWVzdDogSHR0cFJlcXVlc3QgPSB7XG4gICAgICB1cmw6ICcvbWV0YWRhdGEvZGVwbG95UmVxdWVzdCcsXG4gICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgIGhlYWRlcnM6IHsgLi4uZm9ybS5nZXRIZWFkZXJzKCkgfSxcbiAgICAgIGJvZHk6IGZvcm0uZ2V0QnVmZmVyKCksXG4gICAgfTtcbiAgICBjb25zdCByZXMgPSB0aGlzLl9jb25uLnJlcXVlc3Q8QXN5bmNSZXN1bHQ+KHJlcXVlc3QpO1xuXG4gICAgcmV0dXJuIG5ldyBEZXBsb3lSZXN1bHRMb2NhdG9yKHRoaXMsIHJlcyk7XG4gIH1cblxuICAvKipcbiAgICogRGVwbG95IGNvbXBvbmVudHMgaW50byBhbiBvcmdhbml6YXRpb24gdXNpbmcgemlwcGVkIGZpbGUgcmVwcmVzZW50YXRpb25zXG4gICAqL1xuICBkZXBsb3koXG4gICAgemlwSW5wdXQ6IFJlYWRhYmxlIHwgQnVmZmVyIHwgc3RyaW5nLFxuICAgIG9wdGlvbnM6IFBhcnRpYWw8RGVwbG95T3B0aW9ucz4gPSB7fSxcbiAgKTogRGVwbG95UmVzdWx0TG9jYXRvcjxTPiB7XG4gICAgY29uc3QgcmVzID0gKGFzeW5jICgpID0+IHtcbiAgICAgIGNvbnN0IHppcENvbnRlbnRCNjQgPSBhd2FpdCBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgIGlmIChcbiAgICAgICAgICBpc09iamVjdCh6aXBJbnB1dCkgJiZcbiAgICAgICAgICAncGlwZScgaW4gemlwSW5wdXQgJiZcbiAgICAgICAgICB0eXBlb2YgemlwSW5wdXQucGlwZSA9PT0gJ2Z1bmN0aW9uJ1xuICAgICAgICApIHtcbiAgICAgICAgICBjb25zdCBidWZzOiBCdWZmZXJbXSA9IFtdO1xuICAgICAgICAgIHppcElucHV0Lm9uKCdkYXRhJywgKGQpID0+IGJ1ZnMucHVzaChkKSk7XG4gICAgICAgICAgemlwSW5wdXQub24oJ2Vycm9yJywgcmVqZWN0KTtcbiAgICAgICAgICB6aXBJbnB1dC5vbignZW5kJywgKCkgPT4ge1xuICAgICAgICAgICAgcmVzb2x2ZShCdWZmZXIuY29uY2F0KGJ1ZnMpLnRvU3RyaW5nKCdiYXNlNjQnKSk7XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgLy8gemlwSW5wdXQucmVzdW1lKCk7XG4gICAgICAgIH0gZWxzZSBpZiAoemlwSW5wdXQgaW5zdGFuY2VvZiBCdWZmZXIpIHtcbiAgICAgICAgICByZXNvbHZlKHppcElucHV0LnRvU3RyaW5nKCdiYXNlNjQnKSk7XG4gICAgICAgIH0gZWxzZSBpZiAoemlwSW5wdXQgaW5zdGFuY2VvZiBTdHJpbmcgfHwgdHlwZW9mIHppcElucHV0ID09PSAnc3RyaW5nJykge1xuICAgICAgICAgIHJlc29sdmUoemlwSW5wdXQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRocm93ICdVbmV4cGVjdGVkIHppcElucHV0IHR5cGUnO1xuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgcmV0dXJuIHRoaXMuX2ludm9rZShcbiAgICAgICAgJ2RlcGxveScsXG4gICAgICAgIHtcbiAgICAgICAgICBaaXBGaWxlOiB6aXBDb250ZW50QjY0LFxuICAgICAgICAgIERlcGxveU9wdGlvbnM6IG9wdGlvbnMsXG4gICAgICAgIH0sXG4gICAgICAgIEFwaVNjaGVtYXMuRGVwbG95UmVzdWx0LFxuICAgICAgKTtcbiAgICB9KSgpO1xuXG4gICAgcmV0dXJuIG5ldyBEZXBsb3lSZXN1bHRMb2NhdG9yKHRoaXMsIHJlcyk7XG4gIH1cblxuICAvKipcbiAgICogQ2hlY2tzIHRoZSBzdGF0dXMgb2YgZGVjbGFyYXRpdmUgbWV0YWRhdGEgY2FsbCBkZXBsb3koKVxuICAgKi9cbiAgY2hlY2tEZXBsb3lTdGF0dXMoXG4gICAgYXN5bmNQcm9jZXNzSWQ6IHN0cmluZyxcbiAgICBpbmNsdWRlRGV0YWlsczogYm9vbGVhbiA9IGZhbHNlLFxuICApOiBQcm9taXNlPERlcGxveVJlc3VsdD4ge1xuICAgIHJldHVybiB0aGlzLl9pbnZva2UoXG4gICAgICAnY2hlY2tEZXBsb3lTdGF0dXMnLFxuICAgICAge1xuICAgICAgICBhc3luY1Byb2Nlc3NJZCxcbiAgICAgICAgaW5jbHVkZURldGFpbHMsXG4gICAgICB9LFxuICAgICAgQXBpU2NoZW1hcy5EZXBsb3lSZXN1bHQsXG4gICAgKTtcbiAgfVxufVxuXG4vKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuLyoqXG4gKiBUaGUgbG9jYXRvciBjbGFzcyBmb3IgTWV0YWRhdGEgQVBJIGFzeW5jaHJvbm91cyBjYWxsIHJlc3VsdFxuICovXG5leHBvcnQgY2xhc3MgQXN5bmNSZXN1bHRMb2NhdG9yPFxuICBTIGV4dGVuZHMgU2NoZW1hLFxuICBSIGV4dGVuZHMge30gPSBBc3luY1Jlc3VsdFxuPiBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIF9tZXRhOiBNZXRhZGF0YUFwaTxTPjtcbiAgX3Byb21pc2U6IFByb21pc2U8QXN5bmNSZXN1bHQ+O1xuICBfaWQ6IHN0cmluZyB8IHVuZGVmaW5lZDtcblxuICAvKipcbiAgICpcbiAgICovXG4gIGNvbnN0cnVjdG9yKG1ldGE6IE1ldGFkYXRhQXBpPFM+LCBwcm9taXNlOiBQcm9taXNlPEFzeW5jUmVzdWx0Pikge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy5fbWV0YSA9IG1ldGE7XG4gICAgdGhpcy5fcHJvbWlzZSA9IHByb21pc2U7XG4gIH1cblxuICAvKipcbiAgICogUHJvbWlzZS9BKyBpbnRlcmZhY2VcbiAgICogaHR0cDovL3Byb21pc2VzLWFwbHVzLmdpdGh1Yi5pby9wcm9taXNlcy1zcGVjL1xuICAgKlxuICAgKiBAbWV0aG9kIE1ldGFkYXRhfkFzeW5jUmVzdWx0TG9jYXRvciN0aGVuXG4gICAqL1xuICB0aGVuPFUsIFY+KFxuICAgIG9uUmVzb2x2ZT86ICgocmVzdWx0OiBBc3luY1Jlc3VsdCkgPT4gVSB8IFByb21pc2U8VT4pIHwgbnVsbCB8IHVuZGVmaW5lZCxcbiAgICBvblJlamVjdD86ICgoZXJyOiBFcnJvcikgPT4gViB8IFByb21pc2U8Vj4pIHwgbnVsbCB8IHVuZGVmaW5lZCxcbiAgKTogUHJvbWlzZTxVIHwgVj4ge1xuICAgIHJldHVybiB0aGlzLl9wcm9taXNlLnRoZW4ob25SZXNvbHZlLCBvblJlamVjdCk7XG4gIH1cblxuICAvKipcbiAgICogQ2hlY2sgdGhlIHN0YXR1cyBvZiBhc3luYyByZXF1ZXN0XG4gICAqL1xuICBhc3luYyBjaGVjaygpIHtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB0aGlzLl9wcm9taXNlO1xuICAgIHRoaXMuX2lkID0gcmVzdWx0LmlkO1xuICAgIHJldHVybiBhd2FpdCB0aGlzLl9tZXRhLmNoZWNrU3RhdHVzKHJlc3VsdC5pZCk7XG4gIH1cblxuICAvKipcbiAgICogUG9sbGluZyB1bnRpbCBhc3luYyBjYWxsIHN0YXR1cyBiZWNvbWVzIGNvbXBsZXRlIG9yIGVycm9yXG4gICAqL1xuICBwb2xsKGludGVydmFsOiBudW1iZXIsIHRpbWVvdXQ6IG51bWJlcikge1xuICAgIGNvbnN0IHN0YXJ0VGltZSA9IG5ldyBEYXRlKCkuZ2V0VGltZSgpO1xuICAgIGNvbnN0IHBvbGwgPSBhc3luYyAoKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpLmdldFRpbWUoKTtcbiAgICAgICAgaWYgKHN0YXJ0VGltZSArIHRpbWVvdXQgPCBub3cpIHtcbiAgICAgICAgICBsZXQgZXJyTXNnID0gJ1BvbGxpbmcgdGltZSBvdXQuJztcbiAgICAgICAgICBpZiAodGhpcy5faWQpIHtcbiAgICAgICAgICAgIGVyck1zZyArPSAnIFByb2Nlc3MgSWQgPSAnICsgdGhpcy5faWQ7XG4gICAgICAgICAgfVxuICAgICAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBuZXcgRXJyb3IoZXJyTXNnKSk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHRoaXMuY2hlY2soKTtcbiAgICAgICAgaWYgKHJlc3VsdC5kb25lKSB7XG4gICAgICAgICAgdGhpcy5lbWl0KCdjb21wbGV0ZScsIHJlc3VsdCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGhpcy5lbWl0KCdwcm9ncmVzcycsIHJlc3VsdCk7XG4gICAgICAgICAgc2V0VGltZW91dChwb2xsLCBpbnRlcnZhbCk7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIHNldFRpbWVvdXQocG9sbCwgaW50ZXJ2YWwpO1xuICB9XG5cbiAgLyoqXG4gICAqIENoZWNrIGFuZCB3YWl0IHVudGlsIHRoZSBhc3luYyByZXF1ZXN0cyBiZWNvbWUgaW4gY29tcGxldGVkIHN0YXR1c1xuICAgKi9cbiAgY29tcGxldGUoKSB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlPFI+KChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIHRoaXMub24oJ2NvbXBsZXRlJywgcmVzb2x2ZSk7XG4gICAgICB0aGlzLm9uKCdlcnJvcicsIHJlamVjdCk7XG4gICAgICB0aGlzLnBvbGwodGhpcy5fbWV0YS5wb2xsSW50ZXJ2YWwsIHRoaXMuX21ldGEucG9sbFRpbWVvdXQpO1xuICAgIH0pO1xuICB9XG59XG5cbi8qLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuLyoqXG4gKiBUaGUgbG9jYXRvciBjbGFzcyB0byB0cmFjayByZXRyZWl2ZSgpIE1ldGFkYXRhIEFQSSBjYWxsIHJlc3VsdFxuICovXG5leHBvcnQgY2xhc3MgUmV0cmlldmVSZXN1bHRMb2NhdG9yPFMgZXh0ZW5kcyBTY2hlbWE+IGV4dGVuZHMgQXN5bmNSZXN1bHRMb2NhdG9yPFxuICBTLFxuICBSZXRyaWV2ZVJlc3VsdFxuPiB7XG4gIC8qKlxuICAgKiBDaGVjayBhbmQgd2FpdCB1bnRpbCB0aGUgYXN5bmMgcmVxdWVzdCBiZWNvbWVzIGluIGNvbXBsZXRlZCBzdGF0dXMsXG4gICAqIGFuZCByZXRyaWV2ZSB0aGUgcmVzdWx0IGRhdGEuXG4gICAqL1xuICBhc3luYyBjb21wbGV0ZSgpIHtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBzdXBlci5jb21wbGV0ZSgpO1xuICAgIHJldHVybiB0aGlzLl9tZXRhLmNoZWNrUmV0cmlldmVTdGF0dXMocmVzdWx0LmlkKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDaGFuZ2UgdGhlIHJldHJpZXZlZCByZXN1bHQgdG8gTm9kZS5qcyByZWFkYWJsZSBzdHJlYW1cbiAgICovXG4gIHN0cmVhbSgpIHtcbiAgICBjb25zdCByZXN1bHRTdHJlYW0gPSBuZXcgUmVhZGFibGUoKTtcbiAgICBsZXQgcmVhZGluZyA9IGZhbHNlO1xuICAgIHJlc3VsdFN0cmVhbS5fcmVhZCA9IGFzeW5jICgpID0+IHtcbiAgICAgIGlmIChyZWFkaW5nKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHJlYWRpbmcgPSB0cnVlO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdGhpcy5jb21wbGV0ZSgpO1xuICAgICAgICByZXN1bHRTdHJlYW0ucHVzaChCdWZmZXIuZnJvbShyZXN1bHQuemlwRmlsZSwgJ2Jhc2U2NCcpKTtcbiAgICAgICAgcmVzdWx0U3RyZWFtLnB1c2gobnVsbCk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIHJlc3VsdFN0cmVhbS5lbWl0KCdlcnJvcicsIGUpO1xuICAgICAgfVxuICAgIH07XG4gICAgcmV0dXJuIHJlc3VsdFN0cmVhbTtcbiAgfVxufVxuXG4vKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cbi8qKlxuICogVGhlIGxvY2F0b3IgY2xhc3MgdG8gdHJhY2sgZGVwbG95KCkgTWV0YWRhdGEgQVBJIGNhbGwgcmVzdWx0XG4gKlxuICogQHByb3RlY3RlZFxuICogQGNsYXNzIE1ldGFkYXRhfkRlcGxveVJlc3VsdExvY2F0b3JcbiAqIEBleHRlbmRzIE1ldGFkYXRhfkFzeW5jUmVzdWx0TG9jYXRvclxuICogQHBhcmFtIHtNZXRhZGF0YX0gbWV0YSAtIE1ldGFkYXRhIEFQSSBvYmplY3RcbiAqIEBwYXJhbSB7UHJvbWlzZS48TWV0YWRhdGF+QXN5bmNSZXN1bHQ+fSByZXN1bHQgLSBQcm9taXNlIG9iamVjdCBmb3IgYXN5bmMgcmVzdWx0IG9mIGRlcGxveSgpIGNhbGxcbiAqL1xuZXhwb3J0IGNsYXNzIERlcGxveVJlc3VsdExvY2F0b3I8UyBleHRlbmRzIFNjaGVtYT4gZXh0ZW5kcyBBc3luY1Jlc3VsdExvY2F0b3I8XG4gIFMsXG4gIERlcGxveVJlc3VsdFxuPiB7XG4gIC8qKlxuICAgKiBDaGVjayBhbmQgd2FpdCB1bnRpbCB0aGUgYXN5bmMgcmVxdWVzdCBiZWNvbWVzIGluIGNvbXBsZXRlZCBzdGF0dXMsXG4gICAqIGFuZCByZXRyaWV2ZSB0aGUgcmVzdWx0IGRhdGEuXG4gICAqL1xuICBhc3luYyBjb21wbGV0ZShpbmNsdWRlRGV0YWlscz86IGJvb2xlYW4pIHtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBzdXBlci5jb21wbGV0ZSgpO1xuICAgIHJldHVybiB0aGlzLl9tZXRhLmNoZWNrRGVwbG95U3RhdHVzKHJlc3VsdC5pZCwgaW5jbHVkZURldGFpbHMpO1xuICB9XG59XG5cbi8qLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuLypcbiAqIFJlZ2lzdGVyIGhvb2sgaW4gY29ubmVjdGlvbiBpbnN0YW50aWF0aW9uIGZvciBkeW5hbWljYWxseSBhZGRpbmcgdGhpcyBBUEkgbW9kdWxlIGZlYXR1cmVzXG4gKi9cbnJlZ2lzdGVyTW9kdWxlKCdtZXRhZGF0YScsIChjb25uKSA9PiBuZXcgTWV0YWRhdGFBcGkoY29ubikpO1xuXG5leHBvcnQgZGVmYXVsdCBNZXRhZGF0YUFwaTtcbiJdfQ==