import _parseInt from "@babel/runtime-corejs3/core-js-stable/parse-int";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

/**
 * Faye Client extensions: https://faye.jcoglan.com/browser/extensions.html
 *
 * For use with Streaming.prototype.createClient()
 **/

/*-------------------------------------------*/

/**
 * Constructor for an auth failure detector extension
 *
 * Based on new feature released with Salesforce Spring '18:
 * https://releasenotes.docs.salesforce.com/en-us/spring18/release-notes/rn_messaging_cometd_auth_validation.htm?edition=&impact=
 *
 * Example triggering error message:
 *
 * ```
 * {
 *   "ext":{
 *     "sfdc":{"failureReason":"401::Authentication invalid"},
 *     "replay":true},
 *   "advice":{"reconnect":"none"},
 *   "channel":"/meta/handshake",
 *   "error":"403::Handshake denied",
 *   "successful":false
 * }
 * ```
 *
 * Example usage:
 *
 * ```javascript
 * const jsforce = require('jsforce');
 * const { StreamingExtension } = require('jsforce/api/streaming');
 *
 * const conn = new jsforce.Connection({ … });
 *
 * const channel = "/event/My_Event__e";
 *
 * // Exit the Node process when auth fails
 * const exitCallback = () => process.exit(1);
 * const authFailureExt = new StreamingExtension.AuthFailure(exitCallback);
 *
 * const fayeClient = conn.streaming.createClient([ authFailureExt ]);
 *
 * const subscription = fayeClient.subscribe(channel, data => {
 *   console.log('topic received data', data);
 * });
 *
 * subscription.cancel();
 * ```
 *
 * @param {Function} failureCallback - Invoked when authentication becomes invalid
 */
export class AuthFailure {
  constructor(failureCallback) {
    _defineProperty(this, "_failureCallback", void 0);

    this._failureCallback = failureCallback;
  }

  incoming(message, callback) {
    if ((message.channel === '/meta/connect' || message.channel === '/meta/handshake') && message.advice && message.advice.reconnect == 'none') {
      this._failureCallback(message);
    } else {
      callback(message);
    }
  }

}
/*-------------------------------------------*/

const REPLAY_FROM_KEY = 'replay';
/**
 * Constructor for a durable streaming replay extension
 *
 * Modified from original Salesforce demo source code:
 * https://github.com/developerforce/SalesforceDurableStreamingDemo/blob/3d4a56eac956f744ad6c22e6a8141b6feb57abb9/staticresources/cometdReplayExtension.resource
 *
 * Example usage:
 *
 * ```javascript
 * const jsforce = require('jsforce');
 * const { StreamingExtension } = require('jsforce/api/streaming');
 
 * const conn = new jsforce.Connection({ … });
 *
 * const channel = "/event/My_Event__e";
 * const replayId = -2; // -2 is all retained events
 *
 * const replayExt = new StreamingExtension.Replay(channel, replayId);
 *
 * const fayeClient = conn.streaming.createClient([ replayExt ]);
 *
 * const subscription = fayeClient.subscribe(channel, data => {
 *   console.log('topic received data', data);
 * });
 *
 * subscription.cancel();
 * ```
 */

export class Replay {
  constructor(channel, replayId) {
    _defineProperty(this, "_extensionEnabled", void 0);

    _defineProperty(this, "_replay", void 0);

    _defineProperty(this, "_channel", void 0);

    this._extensionEnabled = replayId != null;
    this._channel = channel;
    this._replay = replayId;
  }

  setExtensionEnabled(extensionEnabled) {
    this._extensionEnabled = extensionEnabled;
  }

  setReplay(replay) {
    this._replay = _parseInt(replay, 10);
  }

  setChannel(channel) {
    this._channel = channel;
  }

  incoming(message, callback) {
    if (message.channel === '/meta/handshake') {
      if (message.ext && message.ext[REPLAY_FROM_KEY] == true) {
        this._extensionEnabled = true;
      }
    } else if (message.channel === this._channel && message.data && message.data.event && message.data.event.replayId) {
      this._replay = message.data.event.replayId;
    }

    callback(message);
  }

  outgoing(message, callback) {
    if (message.channel === '/meta/subscribe') {
      if (this._extensionEnabled) {
        if (!message.ext) {
          message.ext = {};
        }

        const replayFromMap = {
          [this._channel]: this._replay
        }; // add "ext : { "replay" : { CHANNEL : REPLAY_VALUE }}" to subscribe message

        message.ext[REPLAY_FROM_KEY] = replayFromMap;
      }
    }

    callback(message);
  }

}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9hcGkvc3RyZWFtaW5nL2V4dGVuc2lvbi50cyJdLCJuYW1lcyI6WyJBdXRoRmFpbHVyZSIsImNvbnN0cnVjdG9yIiwiZmFpbHVyZUNhbGxiYWNrIiwiX2ZhaWx1cmVDYWxsYmFjayIsImluY29taW5nIiwibWVzc2FnZSIsImNhbGxiYWNrIiwiY2hhbm5lbCIsImFkdmljZSIsInJlY29ubmVjdCIsIlJFUExBWV9GUk9NX0tFWSIsIlJlcGxheSIsInJlcGxheUlkIiwiX2V4dGVuc2lvbkVuYWJsZWQiLCJfY2hhbm5lbCIsIl9yZXBsYXkiLCJzZXRFeHRlbnNpb25FbmFibGVkIiwiZXh0ZW5zaW9uRW5hYmxlZCIsInNldFJlcGxheSIsInJlcGxheSIsInNldENoYW5uZWwiLCJleHQiLCJkYXRhIiwiZXZlbnQiLCJvdXRnb2luZyIsInJlcGxheUZyb21NYXAiXSwibWFwcGluZ3MiOiI7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTyxNQUFNQSxXQUFOLENBQWtCO0FBR3ZCQyxFQUFBQSxXQUFXLENBQUNDLGVBQUQsRUFBNEI7QUFBQTs7QUFDckMsU0FBS0MsZ0JBQUwsR0FBd0JELGVBQXhCO0FBQ0Q7O0FBRURFLEVBQUFBLFFBQVEsQ0FBQ0MsT0FBRCxFQUFlQyxRQUFmLEVBQW1DO0FBQ3pDLFFBQ0UsQ0FBQ0QsT0FBTyxDQUFDRSxPQUFSLEtBQW9CLGVBQXBCLElBQ0NGLE9BQU8sQ0FBQ0UsT0FBUixLQUFvQixpQkFEdEIsS0FFQUYsT0FBTyxDQUFDRyxNQUZSLElBR0FILE9BQU8sQ0FBQ0csTUFBUixDQUFlQyxTQUFmLElBQTRCLE1BSjlCLEVBS0U7QUFDQSxXQUFLTixnQkFBTCxDQUFzQkUsT0FBdEI7QUFDRCxLQVBELE1BT087QUFDTEMsTUFBQUEsUUFBUSxDQUFDRCxPQUFELENBQVI7QUFDRDtBQUNGOztBQWxCc0I7QUFxQnpCOztBQUNBLE1BQU1LLGVBQWUsR0FBRyxRQUF4QjtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLE9BQU8sTUFBTUMsTUFBTixDQUFhO0FBS2xCVixFQUFBQSxXQUFXLENBQUNNLE9BQUQsRUFBa0JLLFFBQWxCLEVBQTRDO0FBQUE7O0FBQUE7O0FBQUE7O0FBQ3JELFNBQUtDLGlCQUFMLEdBQXlCRCxRQUFRLElBQUksSUFBckM7QUFDQSxTQUFLRSxRQUFMLEdBQWdCUCxPQUFoQjtBQUNBLFNBQUtRLE9BQUwsR0FBZUgsUUFBZjtBQUNEOztBQUVESSxFQUFBQSxtQkFBbUIsQ0FBQ0MsZ0JBQUQsRUFBNEI7QUFDN0MsU0FBS0osaUJBQUwsR0FBeUJJLGdCQUF6QjtBQUNEOztBQUVEQyxFQUFBQSxTQUFTLENBQUNDLE1BQUQsRUFBaUI7QUFDeEIsU0FBS0osT0FBTCxHQUFlLFVBQVNJLE1BQVQsRUFBaUIsRUFBakIsQ0FBZjtBQUNEOztBQUVEQyxFQUFBQSxVQUFVLENBQUNiLE9BQUQsRUFBa0I7QUFDMUIsU0FBS08sUUFBTCxHQUFnQlAsT0FBaEI7QUFDRDs7QUFFREgsRUFBQUEsUUFBUSxDQUFDQyxPQUFELEVBQWVDLFFBQWYsRUFBbUM7QUFDekMsUUFBSUQsT0FBTyxDQUFDRSxPQUFSLEtBQW9CLGlCQUF4QixFQUEyQztBQUN6QyxVQUFJRixPQUFPLENBQUNnQixHQUFSLElBQWVoQixPQUFPLENBQUNnQixHQUFSLENBQVlYLGVBQVosS0FBZ0MsSUFBbkQsRUFBeUQ7QUFDdkQsYUFBS0csaUJBQUwsR0FBeUIsSUFBekI7QUFDRDtBQUNGLEtBSkQsTUFJTyxJQUNMUixPQUFPLENBQUNFLE9BQVIsS0FBb0IsS0FBS08sUUFBekIsSUFDQVQsT0FBTyxDQUFDaUIsSUFEUixJQUVBakIsT0FBTyxDQUFDaUIsSUFBUixDQUFhQyxLQUZiLElBR0FsQixPQUFPLENBQUNpQixJQUFSLENBQWFDLEtBQWIsQ0FBbUJYLFFBSmQsRUFLTDtBQUNBLFdBQUtHLE9BQUwsR0FBZVYsT0FBTyxDQUFDaUIsSUFBUixDQUFhQyxLQUFiLENBQW1CWCxRQUFsQztBQUNEOztBQUNETixJQUFBQSxRQUFRLENBQUNELE9BQUQsQ0FBUjtBQUNEOztBQUVEbUIsRUFBQUEsUUFBUSxDQUFDbkIsT0FBRCxFQUFlQyxRQUFmLEVBQW1DO0FBQ3pDLFFBQUlELE9BQU8sQ0FBQ0UsT0FBUixLQUFvQixpQkFBeEIsRUFBMkM7QUFDekMsVUFBSSxLQUFLTSxpQkFBVCxFQUE0QjtBQUMxQixZQUFJLENBQUNSLE9BQU8sQ0FBQ2dCLEdBQWIsRUFBa0I7QUFDaEJoQixVQUFBQSxPQUFPLENBQUNnQixHQUFSLEdBQWMsRUFBZDtBQUNEOztBQUNELGNBQU1JLGFBQWEsR0FBRztBQUNwQixXQUFDLEtBQUtYLFFBQU4sR0FBaUIsS0FBS0M7QUFERixTQUF0QixDQUowQixDQU8xQjs7QUFDQVYsUUFBQUEsT0FBTyxDQUFDZ0IsR0FBUixDQUFZWCxlQUFaLElBQStCZSxhQUEvQjtBQUNEO0FBQ0Y7O0FBQ0RuQixJQUFBQSxRQUFRLENBQUNELE9BQUQsQ0FBUjtBQUNEOztBQXJEaUIiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEZheWUgQ2xpZW50IGV4dGVuc2lvbnM6IGh0dHBzOi8vZmF5ZS5qY29nbGFuLmNvbS9icm93c2VyL2V4dGVuc2lvbnMuaHRtbFxuICpcbiAqIEZvciB1c2Ugd2l0aCBTdHJlYW1pbmcucHJvdG90eXBlLmNyZWF0ZUNsaWVudCgpXG4gKiovXG5cbi8qLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG4vKipcbiAqIENvbnN0cnVjdG9yIGZvciBhbiBhdXRoIGZhaWx1cmUgZGV0ZWN0b3IgZXh0ZW5zaW9uXG4gKlxuICogQmFzZWQgb24gbmV3IGZlYXR1cmUgcmVsZWFzZWQgd2l0aCBTYWxlc2ZvcmNlIFNwcmluZyAnMTg6XG4gKiBodHRwczovL3JlbGVhc2Vub3Rlcy5kb2NzLnNhbGVzZm9yY2UuY29tL2VuLXVzL3NwcmluZzE4L3JlbGVhc2Utbm90ZXMvcm5fbWVzc2FnaW5nX2NvbWV0ZF9hdXRoX3ZhbGlkYXRpb24uaHRtP2VkaXRpb249JmltcGFjdD1cbiAqXG4gKiBFeGFtcGxlIHRyaWdnZXJpbmcgZXJyb3IgbWVzc2FnZTpcbiAqXG4gKiBgYGBcbiAqIHtcbiAqICAgXCJleHRcIjp7XG4gKiAgICAgXCJzZmRjXCI6e1wiZmFpbHVyZVJlYXNvblwiOlwiNDAxOjpBdXRoZW50aWNhdGlvbiBpbnZhbGlkXCJ9LFxuICogICAgIFwicmVwbGF5XCI6dHJ1ZX0sXG4gKiAgIFwiYWR2aWNlXCI6e1wicmVjb25uZWN0XCI6XCJub25lXCJ9LFxuICogICBcImNoYW5uZWxcIjpcIi9tZXRhL2hhbmRzaGFrZVwiLFxuICogICBcImVycm9yXCI6XCI0MDM6OkhhbmRzaGFrZSBkZW5pZWRcIixcbiAqICAgXCJzdWNjZXNzZnVsXCI6ZmFsc2VcbiAqIH1cbiAqIGBgYFxuICpcbiAqIEV4YW1wbGUgdXNhZ2U6XG4gKlxuICogYGBgamF2YXNjcmlwdFxuICogY29uc3QganNmb3JjZSA9IHJlcXVpcmUoJ2pzZm9yY2UnKTtcbiAqIGNvbnN0IHsgU3RyZWFtaW5nRXh0ZW5zaW9uIH0gPSByZXF1aXJlKCdqc2ZvcmNlL2FwaS9zdHJlYW1pbmcnKTtcbiAqXG4gKiBjb25zdCBjb25uID0gbmV3IGpzZm9yY2UuQ29ubmVjdGlvbih7IOKApiB9KTtcbiAqXG4gKiBjb25zdCBjaGFubmVsID0gXCIvZXZlbnQvTXlfRXZlbnRfX2VcIjtcbiAqXG4gKiAvLyBFeGl0IHRoZSBOb2RlIHByb2Nlc3Mgd2hlbiBhdXRoIGZhaWxzXG4gKiBjb25zdCBleGl0Q2FsbGJhY2sgPSAoKSA9PiBwcm9jZXNzLmV4aXQoMSk7XG4gKiBjb25zdCBhdXRoRmFpbHVyZUV4dCA9IG5ldyBTdHJlYW1pbmdFeHRlbnNpb24uQXV0aEZhaWx1cmUoZXhpdENhbGxiYWNrKTtcbiAqXG4gKiBjb25zdCBmYXllQ2xpZW50ID0gY29ubi5zdHJlYW1pbmcuY3JlYXRlQ2xpZW50KFsgYXV0aEZhaWx1cmVFeHQgXSk7XG4gKlxuICogY29uc3Qgc3Vic2NyaXB0aW9uID0gZmF5ZUNsaWVudC5zdWJzY3JpYmUoY2hhbm5lbCwgZGF0YSA9PiB7XG4gKiAgIGNvbnNvbGUubG9nKCd0b3BpYyByZWNlaXZlZCBkYXRhJywgZGF0YSk7XG4gKiB9KTtcbiAqXG4gKiBzdWJzY3JpcHRpb24uY2FuY2VsKCk7XG4gKiBgYGBcbiAqXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBmYWlsdXJlQ2FsbGJhY2sgLSBJbnZva2VkIHdoZW4gYXV0aGVudGljYXRpb24gYmVjb21lcyBpbnZhbGlkXG4gKi9cbmV4cG9ydCBjbGFzcyBBdXRoRmFpbHVyZSB7XG4gIF9mYWlsdXJlQ2FsbGJhY2s6IEZ1bmN0aW9uO1xuXG4gIGNvbnN0cnVjdG9yKGZhaWx1cmVDYWxsYmFjazogRnVuY3Rpb24pIHtcbiAgICB0aGlzLl9mYWlsdXJlQ2FsbGJhY2sgPSBmYWlsdXJlQ2FsbGJhY2s7XG4gIH1cblxuICBpbmNvbWluZyhtZXNzYWdlOiBhbnksIGNhbGxiYWNrOiBGdW5jdGlvbikge1xuICAgIGlmIChcbiAgICAgIChtZXNzYWdlLmNoYW5uZWwgPT09ICcvbWV0YS9jb25uZWN0JyB8fFxuICAgICAgICBtZXNzYWdlLmNoYW5uZWwgPT09ICcvbWV0YS9oYW5kc2hha2UnKSAmJlxuICAgICAgbWVzc2FnZS5hZHZpY2UgJiZcbiAgICAgIG1lc3NhZ2UuYWR2aWNlLnJlY29ubmVjdCA9PSAnbm9uZSdcbiAgICApIHtcbiAgICAgIHRoaXMuX2ZhaWx1cmVDYWxsYmFjayhtZXNzYWdlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY2FsbGJhY2sobWVzc2FnZSk7XG4gICAgfVxuICB9XG59XG5cbi8qLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5jb25zdCBSRVBMQVlfRlJPTV9LRVkgPSAncmVwbGF5JztcblxuLyoqXG4gKiBDb25zdHJ1Y3RvciBmb3IgYSBkdXJhYmxlIHN0cmVhbWluZyByZXBsYXkgZXh0ZW5zaW9uXG4gKlxuICogTW9kaWZpZWQgZnJvbSBvcmlnaW5hbCBTYWxlc2ZvcmNlIGRlbW8gc291cmNlIGNvZGU6XG4gKiBodHRwczovL2dpdGh1Yi5jb20vZGV2ZWxvcGVyZm9yY2UvU2FsZXNmb3JjZUR1cmFibGVTdHJlYW1pbmdEZW1vL2Jsb2IvM2Q0YTU2ZWFjOTU2Zjc0NGFkNmMyMmU2YTgxNDFiNmZlYjU3YWJiOS9zdGF0aWNyZXNvdXJjZXMvY29tZXRkUmVwbGF5RXh0ZW5zaW9uLnJlc291cmNlXG4gKlxuICogRXhhbXBsZSB1c2FnZTpcbiAqXG4gKiBgYGBqYXZhc2NyaXB0XG4gKiBjb25zdCBqc2ZvcmNlID0gcmVxdWlyZSgnanNmb3JjZScpO1xuICogY29uc3QgeyBTdHJlYW1pbmdFeHRlbnNpb24gfSA9IHJlcXVpcmUoJ2pzZm9yY2UvYXBpL3N0cmVhbWluZycpO1xuIFxuICogY29uc3QgY29ubiA9IG5ldyBqc2ZvcmNlLkNvbm5lY3Rpb24oeyDigKYgfSk7XG4gKlxuICogY29uc3QgY2hhbm5lbCA9IFwiL2V2ZW50L015X0V2ZW50X19lXCI7XG4gKiBjb25zdCByZXBsYXlJZCA9IC0yOyAvLyAtMiBpcyBhbGwgcmV0YWluZWQgZXZlbnRzXG4gKlxuICogY29uc3QgcmVwbGF5RXh0ID0gbmV3IFN0cmVhbWluZ0V4dGVuc2lvbi5SZXBsYXkoY2hhbm5lbCwgcmVwbGF5SWQpO1xuICpcbiAqIGNvbnN0IGZheWVDbGllbnQgPSBjb25uLnN0cmVhbWluZy5jcmVhdGVDbGllbnQoWyByZXBsYXlFeHQgXSk7XG4gKlxuICogY29uc3Qgc3Vic2NyaXB0aW9uID0gZmF5ZUNsaWVudC5zdWJzY3JpYmUoY2hhbm5lbCwgZGF0YSA9PiB7XG4gKiAgIGNvbnNvbGUubG9nKCd0b3BpYyByZWNlaXZlZCBkYXRhJywgZGF0YSk7XG4gKiB9KTtcbiAqXG4gKiBzdWJzY3JpcHRpb24uY2FuY2VsKCk7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGNsYXNzIFJlcGxheSB7XG4gIF9leHRlbnNpb25FbmFibGVkOiBib29sZWFuO1xuICBfcmVwbGF5OiBudW1iZXIgfCBudWxsIHwgdW5kZWZpbmVkO1xuICBfY2hhbm5lbDogc3RyaW5nO1xuXG4gIGNvbnN0cnVjdG9yKGNoYW5uZWw6IHN0cmluZywgcmVwbGF5SWQ/OiBudW1iZXIgfCBudWxsKSB7XG4gICAgdGhpcy5fZXh0ZW5zaW9uRW5hYmxlZCA9IHJlcGxheUlkICE9IG51bGw7XG4gICAgdGhpcy5fY2hhbm5lbCA9IGNoYW5uZWw7XG4gICAgdGhpcy5fcmVwbGF5ID0gcmVwbGF5SWQ7XG4gIH1cblxuICBzZXRFeHRlbnNpb25FbmFibGVkKGV4dGVuc2lvbkVuYWJsZWQ6IGJvb2xlYW4pIHtcbiAgICB0aGlzLl9leHRlbnNpb25FbmFibGVkID0gZXh0ZW5zaW9uRW5hYmxlZDtcbiAgfVxuXG4gIHNldFJlcGxheShyZXBsYXk6IHN0cmluZykge1xuICAgIHRoaXMuX3JlcGxheSA9IHBhcnNlSW50KHJlcGxheSwgMTApO1xuICB9XG5cbiAgc2V0Q2hhbm5lbChjaGFubmVsOiBzdHJpbmcpIHtcbiAgICB0aGlzLl9jaGFubmVsID0gY2hhbm5lbDtcbiAgfVxuXG4gIGluY29taW5nKG1lc3NhZ2U6IGFueSwgY2FsbGJhY2s6IEZ1bmN0aW9uKSB7XG4gICAgaWYgKG1lc3NhZ2UuY2hhbm5lbCA9PT0gJy9tZXRhL2hhbmRzaGFrZScpIHtcbiAgICAgIGlmIChtZXNzYWdlLmV4dCAmJiBtZXNzYWdlLmV4dFtSRVBMQVlfRlJPTV9LRVldID09IHRydWUpIHtcbiAgICAgICAgdGhpcy5fZXh0ZW5zaW9uRW5hYmxlZCA9IHRydWU7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChcbiAgICAgIG1lc3NhZ2UuY2hhbm5lbCA9PT0gdGhpcy5fY2hhbm5lbCAmJlxuICAgICAgbWVzc2FnZS5kYXRhICYmXG4gICAgICBtZXNzYWdlLmRhdGEuZXZlbnQgJiZcbiAgICAgIG1lc3NhZ2UuZGF0YS5ldmVudC5yZXBsYXlJZFxuICAgICkge1xuICAgICAgdGhpcy5fcmVwbGF5ID0gbWVzc2FnZS5kYXRhLmV2ZW50LnJlcGxheUlkO1xuICAgIH1cbiAgICBjYWxsYmFjayhtZXNzYWdlKTtcbiAgfVxuXG4gIG91dGdvaW5nKG1lc3NhZ2U6IGFueSwgY2FsbGJhY2s6IEZ1bmN0aW9uKSB7XG4gICAgaWYgKG1lc3NhZ2UuY2hhbm5lbCA9PT0gJy9tZXRhL3N1YnNjcmliZScpIHtcbiAgICAgIGlmICh0aGlzLl9leHRlbnNpb25FbmFibGVkKSB7XG4gICAgICAgIGlmICghbWVzc2FnZS5leHQpIHtcbiAgICAgICAgICBtZXNzYWdlLmV4dCA9IHt9O1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHJlcGxheUZyb21NYXAgPSB7XG4gICAgICAgICAgW3RoaXMuX2NoYW5uZWxdOiB0aGlzLl9yZXBsYXksXG4gICAgICAgIH07XG4gICAgICAgIC8vIGFkZCBcImV4dCA6IHsgXCJyZXBsYXlcIiA6IHsgQ0hBTk5FTCA6IFJFUExBWV9WQUxVRSB9fVwiIHRvIHN1YnNjcmliZSBtZXNzYWdlXG4gICAgICAgIG1lc3NhZ2UuZXh0W1JFUExBWV9GUk9NX0tFWV0gPSByZXBsYXlGcm9tTWFwO1xuICAgICAgfVxuICAgIH1cbiAgICBjYWxsYmFjayhtZXNzYWdlKTtcbiAgfVxufVxuIl19