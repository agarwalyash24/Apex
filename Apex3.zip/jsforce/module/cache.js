import "core-js/modules/es.array.iterator";
import "core-js/modules/es.promise";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _indexOfInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/index-of";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

/**
 * @file Manages asynchronous method response cache
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { EventEmitter } from 'events';
/**
 * type def
 */

/**
 * Class for managing cache entry
 *
 * @private
 * @class
 * @constructor
 * @template T
 */
class CacheEntry extends EventEmitter {
  constructor(...args) {
    super(...args);

    _defineProperty(this, "_fetching", false);

    _defineProperty(this, "_value", undefined);
  }

  /**
   * Get value in the cache entry
   *
   * @param {() => Promise<T>} [callback] - Callback function callbacked the cache entry updated
   * @returns {T|undefined}
   */
  get(callback) {
    if (callback) {
      const cb = callback;
      this.once('value', v => cb(v));

      if (typeof this._value !== 'undefined') {
        this.emit('value', this._value);
      }
    }

    return this._value;
  }
  /**
   * Set value in the cache entry
   */


  set(value) {
    this._value = value;
    this.emit('value', this._value);
  }
  /**
   * Clear cached value
   */


  clear() {
    this._fetching = false;
    this._value = undefined;
  }

}
/**
 * create and return cache key from namespace and serialized arguments.
 * @private
 */


function createCacheKey(namespace, args) {
  var _context;

  return `${namespace || ''}(${_mapInstanceProperty(_context = [...args]).call(_context, a => _JSON$stringify(a)).join(',')})`;
}

function generateKeyString(options, scope, args) {
  return typeof options.key === 'string' ? options.key : typeof options.key === 'function' ? options.key.apply(scope, args) : createCacheKey(options.namespace, args);
}
/**
 * Caching manager for async methods
 *
 * @class
 * @constructor
 */


export class Cache {
  constructor() {
    _defineProperty(this, "_entries", {});
  }

  /**
   * retrive cache entry, or create if not exists.
   *
   * @param {String} [key] - Key of cache entry
   * @returns {CacheEntry}
   */
  get(key) {
    if (this._entries[key]) {
      return this._entries[key];
    }

    const entry = new CacheEntry();
    this._entries[key] = entry;
    return entry;
  }
  /**
   * clear cache entries prefix matching given key
   */


  clear(key) {
    for (const k of _Object$keys(this._entries)) {
      if (!key || _indexOfInstanceProperty(k).call(k, key) === 0) {
        this._entries[k].clear();
      }
    }
  }
  /**
   * Enable caching for async call fn to lookup the response cache first,
   * then invoke original if no cached value.
   */


  createCachedFunction(fn, scope, options = {
    strategy: 'NOCACHE'
  }) {
    const strategy = options.strategy;

    const $fn = (...args) => {
      const key = generateKeyString(options, scope, args);
      const entry = this.get(key);

      const executeFetch = async () => {
        entry._fetching = true;

        try {
          const result = await fn.apply(scope || this, args);
          entry.set({
            error: undefined,
            result
          });
          return result;
        } catch (error) {
          entry.set({
            error: error,
            result: undefined
          });
          throw error;
        }
      };

      let value;

      switch (strategy) {
        case 'IMMEDIATE':
          value = entry.get();

          if (!value) {
            throw new Error('Function call result is not cached yet.');
          }

          if (value.error) {
            throw value.error;
          }

          return value.result;

        case 'HIT':
          return (async () => {
            if (!entry._fetching) {
              // only when no other client is calling function
              await executeFetch();
            }

            return new _Promise((resolve, reject) => {
              entry.get(({
                error,
                result
              }) => {
                if (error) reject(error);else resolve(result);
              });
            });
          })();

        case 'NOCACHE':
        default:
          return executeFetch();
      }
    };

    $fn.clear = (...args) => {
      const key = generateKeyString(options, scope, args);
      this.clear(key);
    };

    return $fn;
  }

}
export default Cache;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9jYWNoZS50cyJdLCJuYW1lcyI6WyJFdmVudEVtaXR0ZXIiLCJDYWNoZUVudHJ5IiwidW5kZWZpbmVkIiwiZ2V0IiwiY2FsbGJhY2siLCJjYiIsIm9uY2UiLCJ2IiwiX3ZhbHVlIiwiZW1pdCIsInNldCIsInZhbHVlIiwiY2xlYXIiLCJfZmV0Y2hpbmciLCJjcmVhdGVDYWNoZUtleSIsIm5hbWVzcGFjZSIsImFyZ3MiLCJhIiwiam9pbiIsImdlbmVyYXRlS2V5U3RyaW5nIiwib3B0aW9ucyIsInNjb3BlIiwia2V5IiwiYXBwbHkiLCJDYWNoZSIsIl9lbnRyaWVzIiwiZW50cnkiLCJrIiwiY3JlYXRlQ2FjaGVkRnVuY3Rpb24iLCJmbiIsInN0cmF0ZWd5IiwiJGZuIiwiZXhlY3V0ZUZldGNoIiwicmVzdWx0IiwiZXJyb3IiLCJFcnJvciIsInJlc29sdmUiLCJyZWplY3QiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU0EsWUFBVCxRQUE2QixRQUE3QjtBQUVBO0FBQ0E7QUFDQTs7QUFjQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTUMsVUFBTixTQUE0QkQsWUFBNUIsQ0FBeUM7QUFBQTtBQUFBOztBQUFBLHVDQUNsQixLQURrQjs7QUFBQSxvQ0FFUkUsU0FGUTtBQUFBOztBQUl2QztBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDRUMsRUFBQUEsR0FBRyxDQUFDQyxRQUFELEVBQWlEO0FBQ2xELFFBQUlBLFFBQUosRUFBYztBQUNaLFlBQU1DLEVBQUUsR0FBR0QsUUFBWDtBQUNBLFdBQUtFLElBQUwsQ0FBVSxPQUFWLEVBQW9CQyxDQUFELElBQVVGLEVBQUUsQ0FBQ0UsQ0FBRCxDQUEvQjs7QUFDQSxVQUFJLE9BQU8sS0FBS0MsTUFBWixLQUF1QixXQUEzQixFQUF3QztBQUN0QyxhQUFLQyxJQUFMLENBQVUsT0FBVixFQUFtQixLQUFLRCxNQUF4QjtBQUNEO0FBQ0Y7O0FBQ0QsV0FBTyxLQUFLQSxNQUFaO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFRSxFQUFBQSxHQUFHLENBQUNDLEtBQUQsRUFBdUI7QUFDeEIsU0FBS0gsTUFBTCxHQUFjRyxLQUFkO0FBQ0EsU0FBS0YsSUFBTCxDQUFVLE9BQVYsRUFBbUIsS0FBS0QsTUFBeEI7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0VJLEVBQUFBLEtBQUssR0FBRztBQUNOLFNBQUtDLFNBQUwsR0FBaUIsS0FBakI7QUFDQSxTQUFLTCxNQUFMLEdBQWNOLFNBQWQ7QUFDRDs7QUFuQ3NDO0FBc0N6QztBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsU0FBU1ksY0FBVCxDQUF3QkMsU0FBeEIsRUFBa0RDLElBQWxELEVBQXVFO0FBQUE7O0FBQ3JFLFNBQVEsR0FBRUQsU0FBUyxJQUFJLEVBQUcsSUFBRyxpQ0FBQyxHQUFHQyxJQUFKLGtCQUNyQkMsQ0FBRCxJQUFPLGdCQUFlQSxDQUFmLENBRGUsRUFFMUJDLElBRjBCLENBRXJCLEdBRnFCLENBRWhCLEdBRmI7QUFHRDs7QUFFRCxTQUFTQyxpQkFBVCxDQUNFQyxPQURGLEVBRUVDLEtBRkYsRUFHRUwsSUFIRixFQUlVO0FBQ1IsU0FBTyxPQUFPSSxPQUFPLENBQUNFLEdBQWYsS0FBdUIsUUFBdkIsR0FDSEYsT0FBTyxDQUFDRSxHQURMLEdBRUgsT0FBT0YsT0FBTyxDQUFDRSxHQUFmLEtBQXVCLFVBQXZCLEdBQ0FGLE9BQU8sQ0FBQ0UsR0FBUixDQUFZQyxLQUFaLENBQWtCRixLQUFsQixFQUF5QkwsSUFBekIsQ0FEQSxHQUVBRixjQUFjLENBQUNNLE9BQU8sQ0FBQ0wsU0FBVCxFQUFvQkMsSUFBcEIsQ0FKbEI7QUFLRDtBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsT0FBTyxNQUFNUSxLQUFOLENBQVk7QUFBQTtBQUFBLHNDQUNzQyxFQUR0QztBQUFBOztBQUdqQjtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDRXJCLEVBQUFBLEdBQUcsQ0FBQ21CLEdBQUQsRUFBYztBQUNmLFFBQUksS0FBS0csUUFBTCxDQUFjSCxHQUFkLENBQUosRUFBd0I7QUFDdEIsYUFBTyxLQUFLRyxRQUFMLENBQWNILEdBQWQsQ0FBUDtBQUNEOztBQUNELFVBQU1JLEtBQUssR0FBRyxJQUFJekIsVUFBSixFQUFkO0FBQ0EsU0FBS3dCLFFBQUwsQ0FBY0gsR0FBZCxJQUFxQkksS0FBckI7QUFDQSxXQUFPQSxLQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFZCxFQUFBQSxLQUFLLENBQUNVLEdBQUQsRUFBZTtBQUNsQixTQUFLLE1BQU1LLENBQVgsSUFBZ0IsYUFBWSxLQUFLRixRQUFqQixDQUFoQixFQUE0QztBQUMxQyxVQUFJLENBQUNILEdBQUQsSUFBUSx5QkFBQUssQ0FBQyxNQUFELENBQUFBLENBQUMsRUFBU0wsR0FBVCxDQUFELEtBQW1CLENBQS9CLEVBQWtDO0FBQ2hDLGFBQUtHLFFBQUwsQ0FBY0UsQ0FBZCxFQUFpQmYsS0FBakI7QUFDRDtBQUNGO0FBQ0Y7QUFFRDtBQUNGO0FBQ0E7QUFDQTs7O0FBQ0VnQixFQUFBQSxvQkFBb0IsQ0FDbEJDLEVBRGtCLEVBRWxCUixLQUZrQixFQUdsQkQsT0FBdUIsR0FBRztBQUFFVSxJQUFBQSxRQUFRLEVBQUU7QUFBWixHQUhSLEVBSUU7QUFDcEIsVUFBTUEsUUFBUSxHQUFHVixPQUFPLENBQUNVLFFBQXpCOztBQUNBLFVBQU1DLEdBQVEsR0FBRyxDQUFDLEdBQUdmLElBQUosS0FBb0I7QUFDbkMsWUFBTU0sR0FBRyxHQUFHSCxpQkFBaUIsQ0FBQ0MsT0FBRCxFQUFVQyxLQUFWLEVBQWlCTCxJQUFqQixDQUE3QjtBQUNBLFlBQU1VLEtBQUssR0FBRyxLQUFLdkIsR0FBTCxDQUFTbUIsR0FBVCxDQUFkOztBQUNBLFlBQU1VLFlBQVksR0FBRyxZQUFZO0FBQy9CTixRQUFBQSxLQUFLLENBQUNiLFNBQU4sR0FBa0IsSUFBbEI7O0FBQ0EsWUFBSTtBQUNGLGdCQUFNb0IsTUFBTSxHQUFHLE1BQU1KLEVBQUUsQ0FBQ04sS0FBSCxDQUFTRixLQUFLLElBQUksSUFBbEIsRUFBd0JMLElBQXhCLENBQXJCO0FBQ0FVLFVBQUFBLEtBQUssQ0FBQ2hCLEdBQU4sQ0FBVTtBQUFFd0IsWUFBQUEsS0FBSyxFQUFFaEMsU0FBVDtBQUFvQitCLFlBQUFBO0FBQXBCLFdBQVY7QUFDQSxpQkFBT0EsTUFBUDtBQUNELFNBSkQsQ0FJRSxPQUFPQyxLQUFQLEVBQWM7QUFDZFIsVUFBQUEsS0FBSyxDQUFDaEIsR0FBTixDQUFVO0FBQUV3QixZQUFBQSxLQUFLLEVBQUVBLEtBQVQ7QUFBeUJELFlBQUFBLE1BQU0sRUFBRS9CO0FBQWpDLFdBQVY7QUFDQSxnQkFBTWdDLEtBQU47QUFDRDtBQUNGLE9BVkQ7O0FBV0EsVUFBSXZCLEtBQUo7O0FBQ0EsY0FBUW1CLFFBQVI7QUFDRSxhQUFLLFdBQUw7QUFDRW5CLFVBQUFBLEtBQUssR0FBR2UsS0FBSyxDQUFDdkIsR0FBTixFQUFSOztBQUNBLGNBQUksQ0FBQ1EsS0FBTCxFQUFZO0FBQ1Ysa0JBQU0sSUFBSXdCLEtBQUosQ0FBVSx5Q0FBVixDQUFOO0FBQ0Q7O0FBQ0QsY0FBSXhCLEtBQUssQ0FBQ3VCLEtBQVYsRUFBaUI7QUFDZixrQkFBTXZCLEtBQUssQ0FBQ3VCLEtBQVo7QUFDRDs7QUFDRCxpQkFBT3ZCLEtBQUssQ0FBQ3NCLE1BQWI7O0FBQ0YsYUFBSyxLQUFMO0FBQ0UsaUJBQU8sQ0FBQyxZQUFZO0FBQ2xCLGdCQUFJLENBQUNQLEtBQUssQ0FBQ2IsU0FBWCxFQUFzQjtBQUNwQjtBQUNBLG9CQUFNbUIsWUFBWSxFQUFsQjtBQUNEOztBQUNELG1CQUFPLGFBQVksQ0FBQ0ksT0FBRCxFQUFVQyxNQUFWLEtBQXFCO0FBQ3RDWCxjQUFBQSxLQUFLLENBQUN2QixHQUFOLENBQVUsQ0FBQztBQUFFK0IsZ0JBQUFBLEtBQUY7QUFBU0QsZ0JBQUFBO0FBQVQsZUFBRCxLQUF1QjtBQUMvQixvQkFBSUMsS0FBSixFQUFXRyxNQUFNLENBQUNILEtBQUQsQ0FBTixDQUFYLEtBQ0tFLE9BQU8sQ0FBQ0gsTUFBRCxDQUFQO0FBQ04sZUFIRDtBQUlELGFBTE0sQ0FBUDtBQU1ELFdBWE0sR0FBUDs7QUFZRixhQUFLLFNBQUw7QUFDQTtBQUNFLGlCQUFPRCxZQUFZLEVBQW5CO0FBekJKO0FBMkJELEtBMUNEOztBQTJDQUQsSUFBQUEsR0FBRyxDQUFDbkIsS0FBSixHQUFZLENBQUMsR0FBR0ksSUFBSixLQUFvQjtBQUM5QixZQUFNTSxHQUFHLEdBQUdILGlCQUFpQixDQUFDQyxPQUFELEVBQVVDLEtBQVYsRUFBaUJMLElBQWpCLENBQTdCO0FBQ0EsV0FBS0osS0FBTCxDQUFXVSxHQUFYO0FBQ0QsS0FIRDs7QUFJQSxXQUFPUyxHQUFQO0FBQ0Q7O0FBdkZnQjtBQTBGbkIsZUFBZVAsS0FBZiIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGZpbGUgTWFuYWdlcyBhc3luY2hyb25vdXMgbWV0aG9kIHJlc3BvbnNlIGNhY2hlXG4gKiBAYXV0aG9yIFNoaW5pY2hpIFRvbWl0YSA8c2hpbmljaGkudG9taXRhQGdtYWlsLmNvbT5cbiAqL1xuaW1wb3J0IHsgRXZlbnRFbWl0dGVyIH0gZnJvbSAnZXZlbnRzJztcblxuLyoqXG4gKiB0eXBlIGRlZlxuICovXG5leHBvcnQgdHlwZSBDYWNoaW5nT3B0aW9ucyA9IHtcbiAga2V5Pzogc3RyaW5nIHwgKCguLi5hcmdzOiBhbnlbXSkgPT4gc3RyaW5nKTtcbiAgbmFtZXNwYWNlPzogc3RyaW5nO1xuICBzdHJhdGVneTogJ05PQ0FDSEUnIHwgJ0hJVCcgfCAnSU1NRURJQVRFJztcbn07XG5cbnR5cGUgQ2FjaGVWYWx1ZTxUPiA9IHtcbiAgZXJyb3I/OiBFcnJvcjtcbiAgcmVzdWx0OiBUO1xufTtcblxuZXhwb3J0IHR5cGUgQ2FjaGVkRnVuY3Rpb248Rm4+ID0gRm4gJiB7IGNsZWFyOiAoLi4uYXJnczogYW55W10pID0+IHZvaWQgfTtcblxuLyoqXG4gKiBDbGFzcyBmb3IgbWFuYWdpbmcgY2FjaGUgZW50cnlcbiAqXG4gKiBAcHJpdmF0ZVxuICogQGNsYXNzXG4gKiBAY29uc3RydWN0b3JcbiAqIEB0ZW1wbGF0ZSBUXG4gKi9cbmNsYXNzIENhY2hlRW50cnk8VD4gZXh0ZW5kcyBFdmVudEVtaXR0ZXIge1xuICBfZmV0Y2hpbmc6IGJvb2xlYW4gPSBmYWxzZTtcbiAgX3ZhbHVlOiBDYWNoZVZhbHVlPFQ+IHwgdm9pZCA9IHVuZGVmaW5lZDtcblxuICAvKipcbiAgICogR2V0IHZhbHVlIGluIHRoZSBjYWNoZSBlbnRyeVxuICAgKlxuICAgKiBAcGFyYW0geygpID0+IFByb21pc2U8VD59IFtjYWxsYmFja10gLSBDYWxsYmFjayBmdW5jdGlvbiBjYWxsYmFja2VkIHRoZSBjYWNoZSBlbnRyeSB1cGRhdGVkXG4gICAqIEByZXR1cm5zIHtUfHVuZGVmaW5lZH1cbiAgICovXG4gIGdldChjYWxsYmFjaz86ICh2OiBUKSA9PiBhbnkpOiBDYWNoZVZhbHVlPFQ+IHwgdm9pZCB7XG4gICAgaWYgKGNhbGxiYWNrKSB7XG4gICAgICBjb25zdCBjYiA9IGNhbGxiYWNrO1xuICAgICAgdGhpcy5vbmNlKCd2YWx1ZScsICh2OiBUKSA9PiBjYih2KSk7XG4gICAgICBpZiAodHlwZW9mIHRoaXMuX3ZhbHVlICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICB0aGlzLmVtaXQoJ3ZhbHVlJywgdGhpcy5fdmFsdWUpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdGhpcy5fdmFsdWU7XG4gIH1cblxuICAvKipcbiAgICogU2V0IHZhbHVlIGluIHRoZSBjYWNoZSBlbnRyeVxuICAgKi9cbiAgc2V0KHZhbHVlOiBDYWNoZVZhbHVlPFQ+KSB7XG4gICAgdGhpcy5fdmFsdWUgPSB2YWx1ZTtcbiAgICB0aGlzLmVtaXQoJ3ZhbHVlJywgdGhpcy5fdmFsdWUpO1xuICB9XG5cbiAgLyoqXG4gICAqIENsZWFyIGNhY2hlZCB2YWx1ZVxuICAgKi9cbiAgY2xlYXIoKSB7XG4gICAgdGhpcy5fZmV0Y2hpbmcgPSBmYWxzZTtcbiAgICB0aGlzLl92YWx1ZSA9IHVuZGVmaW5lZDtcbiAgfVxufVxuXG4vKipcbiAqIGNyZWF0ZSBhbmQgcmV0dXJuIGNhY2hlIGtleSBmcm9tIG5hbWVzcGFjZSBhbmQgc2VyaWFsaXplZCBhcmd1bWVudHMuXG4gKiBAcHJpdmF0ZVxuICovXG5mdW5jdGlvbiBjcmVhdGVDYWNoZUtleShuYW1lc3BhY2U6IHN0cmluZyB8IHZvaWQsIGFyZ3M6IGFueVtdKTogc3RyaW5nIHtcbiAgcmV0dXJuIGAke25hbWVzcGFjZSB8fCAnJ30oJHtbLi4uYXJnc11cbiAgICAubWFwKChhKSA9PiBKU09OLnN0cmluZ2lmeShhKSlcbiAgICAuam9pbignLCcpfSlgO1xufVxuXG5mdW5jdGlvbiBnZW5lcmF0ZUtleVN0cmluZyhcbiAgb3B0aW9uczogQ2FjaGluZ09wdGlvbnMsXG4gIHNjb3BlOiBhbnksXG4gIGFyZ3M6IGFueVtdLFxuKTogc3RyaW5nIHtcbiAgcmV0dXJuIHR5cGVvZiBvcHRpb25zLmtleSA9PT0gJ3N0cmluZydcbiAgICA/IG9wdGlvbnMua2V5XG4gICAgOiB0eXBlb2Ygb3B0aW9ucy5rZXkgPT09ICdmdW5jdGlvbidcbiAgICA/IG9wdGlvbnMua2V5LmFwcGx5KHNjb3BlLCBhcmdzKVxuICAgIDogY3JlYXRlQ2FjaGVLZXkob3B0aW9ucy5uYW1lc3BhY2UsIGFyZ3MpO1xufVxuXG4vKipcbiAqIENhY2hpbmcgbWFuYWdlciBmb3IgYXN5bmMgbWV0aG9kc1xuICpcbiAqIEBjbGFzc1xuICogQGNvbnN0cnVjdG9yXG4gKi9cbmV4cG9ydCBjbGFzcyBDYWNoZSB7XG4gIHByaXZhdGUgX2VudHJpZXM6IHsgW2tleTogc3RyaW5nXTogQ2FjaGVFbnRyeTxhbnk+IH0gPSB7fTtcblxuICAvKipcbiAgICogcmV0cml2ZSBjYWNoZSBlbnRyeSwgb3IgY3JlYXRlIGlmIG5vdCBleGlzdHMuXG4gICAqXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBba2V5XSAtIEtleSBvZiBjYWNoZSBlbnRyeVxuICAgKiBAcmV0dXJucyB7Q2FjaGVFbnRyeX1cbiAgICovXG4gIGdldChrZXk6IHN0cmluZykge1xuICAgIGlmICh0aGlzLl9lbnRyaWVzW2tleV0pIHtcbiAgICAgIHJldHVybiB0aGlzLl9lbnRyaWVzW2tleV07XG4gICAgfVxuICAgIGNvbnN0IGVudHJ5ID0gbmV3IENhY2hlRW50cnkoKTtcbiAgICB0aGlzLl9lbnRyaWVzW2tleV0gPSBlbnRyeTtcbiAgICByZXR1cm4gZW50cnk7XG4gIH1cblxuICAvKipcbiAgICogY2xlYXIgY2FjaGUgZW50cmllcyBwcmVmaXggbWF0Y2hpbmcgZ2l2ZW4ga2V5XG4gICAqL1xuICBjbGVhcihrZXk/OiBzdHJpbmcpIHtcbiAgICBmb3IgKGNvbnN0IGsgb2YgT2JqZWN0LmtleXModGhpcy5fZW50cmllcykpIHtcbiAgICAgIGlmICgha2V5IHx8IGsuaW5kZXhPZihrZXkpID09PSAwKSB7XG4gICAgICAgIHRoaXMuX2VudHJpZXNba10uY2xlYXIoKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogRW5hYmxlIGNhY2hpbmcgZm9yIGFzeW5jIGNhbGwgZm4gdG8gbG9va3VwIHRoZSByZXNwb25zZSBjYWNoZSBmaXJzdCxcbiAgICogdGhlbiBpbnZva2Ugb3JpZ2luYWwgaWYgbm8gY2FjaGVkIHZhbHVlLlxuICAgKi9cbiAgY3JlYXRlQ2FjaGVkRnVuY3Rpb248Rm4gZXh0ZW5kcyBGdW5jdGlvbj4oXG4gICAgZm46IEZuLFxuICAgIHNjb3BlOiBhbnksXG4gICAgb3B0aW9uczogQ2FjaGluZ09wdGlvbnMgPSB7IHN0cmF0ZWd5OiAnTk9DQUNIRScgfSxcbiAgKTogQ2FjaGVkRnVuY3Rpb248Rm4+IHtcbiAgICBjb25zdCBzdHJhdGVneSA9IG9wdGlvbnMuc3RyYXRlZ3k7XG4gICAgY29uc3QgJGZuOiBhbnkgPSAoLi4uYXJnczogYW55W10pID0+IHtcbiAgICAgIGNvbnN0IGtleSA9IGdlbmVyYXRlS2V5U3RyaW5nKG9wdGlvbnMsIHNjb3BlLCBhcmdzKTtcbiAgICAgIGNvbnN0IGVudHJ5ID0gdGhpcy5nZXQoa2V5KTtcbiAgICAgIGNvbnN0IGV4ZWN1dGVGZXRjaCA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgZW50cnkuX2ZldGNoaW5nID0gdHJ1ZTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBmbi5hcHBseShzY29wZSB8fCB0aGlzLCBhcmdzKTtcbiAgICAgICAgICBlbnRyeS5zZXQoeyBlcnJvcjogdW5kZWZpbmVkLCByZXN1bHQgfSk7XG4gICAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICBlbnRyeS5zZXQoeyBlcnJvcjogZXJyb3IgYXMgRXJyb3IsIHJlc3VsdDogdW5kZWZpbmVkIH0pO1xuICAgICAgICAgIHRocm93IGVycm9yO1xuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgbGV0IHZhbHVlO1xuICAgICAgc3dpdGNoIChzdHJhdGVneSkge1xuICAgICAgICBjYXNlICdJTU1FRElBVEUnOlxuICAgICAgICAgIHZhbHVlID0gZW50cnkuZ2V0KCk7XG4gICAgICAgICAgaWYgKCF2YWx1ZSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdGdW5jdGlvbiBjYWxsIHJlc3VsdCBpcyBub3QgY2FjaGVkIHlldC4nKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKHZhbHVlLmVycm9yKSB7XG4gICAgICAgICAgICB0aHJvdyB2YWx1ZS5lcnJvcjtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHZhbHVlLnJlc3VsdDtcbiAgICAgICAgY2FzZSAnSElUJzpcbiAgICAgICAgICByZXR1cm4gKGFzeW5jICgpID0+IHtcbiAgICAgICAgICAgIGlmICghZW50cnkuX2ZldGNoaW5nKSB7XG4gICAgICAgICAgICAgIC8vIG9ubHkgd2hlbiBubyBvdGhlciBjbGllbnQgaXMgY2FsbGluZyBmdW5jdGlvblxuICAgICAgICAgICAgICBhd2FpdCBleGVjdXRlRmV0Y2goKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgICAgIGVudHJ5LmdldCgoeyBlcnJvciwgcmVzdWx0IH0pID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoZXJyb3IpIHJlamVjdChlcnJvcik7XG4gICAgICAgICAgICAgICAgZWxzZSByZXNvbHZlKHJlc3VsdCk7XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfSkoKTtcbiAgICAgICAgY2FzZSAnTk9DQUNIRSc6XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgcmV0dXJuIGV4ZWN1dGVGZXRjaCgpO1xuICAgICAgfVxuICAgIH07XG4gICAgJGZuLmNsZWFyID0gKC4uLmFyZ3M6IGFueVtdKSA9PiB7XG4gICAgICBjb25zdCBrZXkgPSBnZW5lcmF0ZUtleVN0cmluZyhvcHRpb25zLCBzY29wZSwgYXJncyk7XG4gICAgICB0aGlzLmNsZWFyKGtleSk7XG4gICAgfTtcbiAgICByZXR1cm4gJGZuIGFzIENhY2hlZEZ1bmN0aW9uPEZuPjtcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBDYWNoZTtcbiJdfQ==