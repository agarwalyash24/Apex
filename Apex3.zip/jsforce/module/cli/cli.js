import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import "core-js/modules/es.array.iterator";
import "core-js/modules/es.promise";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _reduceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/reduce";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _indexOfInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/index-of";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context2; _forEachInstanceProperty(_context2 = ownKeys(Object(source), true)).call(_context2, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context3; _forEachInstanceProperty(_context3 = ownKeys(Object(source))).call(_context3, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 * @file Command line interface for JSforce
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import http from 'http';
import url from 'url';
import crypto from 'crypto';
import openUrl from 'open';
import { Command } from 'commander';
import inquirer from 'inquirer';
import request from '../request';
import base64url from 'base64url';
import Repl from './repl';
import jsforce, { Connection, OAuth2 } from '..';
import version from '../VERSION';
const registry = jsforce.registry;

/**
 *
 */
export class Cli {
  constructor() {
    _defineProperty(this, "_repl", new Repl(this));

    _defineProperty(this, "_conn", new Connection());

    _defineProperty(this, "_connName", undefined);

    _defineProperty(this, "_outputEnabled", true);

    _defineProperty(this, "_defaultLoginUrl", undefined);
  }

  /**
   *
   */
  readCommand() {
    return new Command().option('-u, --username [username]', 'Salesforce username').option('-p, --password [password]', 'Salesforce password (and security token, if available)').option('-c, --connection [connection]', 'Connection name stored in connection registry').option('-l, --loginUrl [loginUrl]', 'Salesforce login url').option('--sandbox', 'Login to Salesforce sandbox').option('-e, --evalScript [evalScript]', 'Script to evaluate').version(version).parse(process.argv);
  }

  async start() {
    const program = this.readCommand();
    this._outputEnabled = !program.evalScript;

    try {
      await this.connect(program);

      if (program.evalScript) {
        this._repl.start({
          interactive: false,
          evalScript: program.evalScript
        });
      } else {
        this._repl.start();
      }
    } catch (err) {
      console.error(err);
      process.exit();
    }
  }

  getCurrentConnection() {
    return this._conn;
  }

  print(...args) {
    if (this._outputEnabled) {
      console.log(...args);
    }
  }

  saveCurrentConnection() {
    if (this._connName) {
      const conn = this._conn;
      const connName = this._connName;
      const connConfig = {
        oauth2: conn.oauth2 ? {
          clientId: conn.oauth2.clientId || undefined,
          clientSecret: conn.oauth2.clientSecret || undefined,
          redirectUri: conn.oauth2.redirectUri || undefined,
          loginUrl: conn.oauth2.loginUrl || undefined
        } : undefined,
        accessToken: conn.accessToken || undefined,
        instanceUrl: conn.instanceUrl || undefined,
        refreshToken: conn.refreshToken || undefined
      };
      registry.saveConnectionConfig(connName, connConfig);
    }
  }

  setLoginServer(loginServer) {
    if (!loginServer) {
      return;
    }

    if (loginServer === 'production') {
      this._defaultLoginUrl = 'https://login.salesforce.com';
    } else if (loginServer === 'sandbox') {
      this._defaultLoginUrl = 'https://test.salesforce.com';
    } else if (_indexOfInstanceProperty(loginServer).call(loginServer, 'https://') !== 0) {
      this._defaultLoginUrl = 'https://' + loginServer;
    } else {
      this._defaultLoginUrl = loginServer;
    }

    this.print(`Using "${this._defaultLoginUrl}" as default login URL.`);
  }
  /**
   *
   */


  async connect(options) {
    const loginServer = options.loginUrl ? options.loginUrl : options.sandbox ? 'sandbox' : null;
    this.setLoginServer(loginServer);
    this._connName = options.connection;
    let connConfig = await registry.getConnectionConfig(options.connection);
    let username = options.username;

    if (!connConfig) {
      connConfig = {};

      if (this._defaultLoginUrl) {
        connConfig.loginUrl = this._defaultLoginUrl;
      }

      username = username || options.connection;
    }

    this._conn = new Connection(connConfig);
    const password = options.password;

    if (username) {
      await this.startPasswordAuth(username, password);
      this.saveCurrentConnection();
    } else {
      if (this._connName && this._conn.accessToken) {
        this._conn.on('refresh', () => {
          this.print('Refreshing access token ... ');
          this.saveCurrentConnection();
        });

        try {
          const identity = await this._conn.identity();
          this.print(`Logged in as : ${identity.username}`);
        } catch (err) {
          if (err instanceof Error) {
            this.print(err.message);
          }

          if (this._conn.oauth2) {
            throw new Error('Please re-authorize connection.');
          } else {
            await this.startPasswordAuth(this._connName);
          }
        }
      }
    }
  }
  /**
   *
   */


  async startPasswordAuth(username, password) {
    try {
      await this.loginByPassword(username, password, 2);
    } catch (err) {
      if (err instanceof Error && err.message === 'canceled') {
        console.error('Password authentication canceled: Not logged in');
      } else {
        throw err;
      }
    }
  }
  /**
   *
   */


  async loginByPassword(username, password, retryCount) {
    if (password === '') {
      throw new Error('canceled');
    }

    if (password == null) {
      const pass = await this.promptPassword('Password: ');
      return this.loginByPassword(username, pass, retryCount);
    }

    try {
      const result = await this._conn.login(username, password);
      this.print(`Logged in as : ${username}`);
      return result;
    } catch (err) {
      if (err instanceof Error) {
        console.error(err.message);
      }

      if (retryCount > 0) {
        return this.loginByPassword(username, undefined, retryCount - 1);
      } else {
        throw new Error('canceled');
      }
    }
  }
  /**
   *
   */


  disconnect(connName) {
    const name = connName || this._connName;

    if (name && registry.getConnectionConfig(name)) {
      registry.removeConnectionConfig(name);
      this.print(`Disconnect connection '${name}'`);
    }

    this._connName = undefined;
    this._conn = new Connection();
  }
  /**
   *
   */


  async authorize(clientName) {
    const name = clientName || 'default';
    var oauth2Config = await registry.getClientConfig(name);

    if (!oauth2Config || !oauth2Config.clientId) {
      if (name === 'default' || name === 'sandbox') {
        this.print('No client information registered. Downloading JSforce default client information...');
        return this.downloadDefaultClientInfo(name);
      }

      throw new Error(`No OAuth2 client information registered : '${name}'. Please register client info first.`);
    }

    const oauth2 = new OAuth2(oauth2Config);
    const verifier = base64url.encode(crypto.randomBytes(32));
    const challenge = base64url.encode(crypto.createHash('sha256').update(verifier).digest());
    const state = base64url.encode(crypto.randomBytes(32));
    const authzUrl = oauth2.getAuthorizationUrl({
      code_challenge: challenge,
      state
    });
    this.print('Opening authorization page in browser...');
    this.print(`URL: ${authzUrl}`);
    this.openUrl(authzUrl);
    const params = await this.waitCallback(oauth2Config.redirectUri, state);

    if (!params.code) {
      throw new Error('No authorization code returned.');
    }

    if (params.state !== state) {
      throw new Error('Invalid state parameter returned.');
    }

    this._conn = new Connection({
      oauth2
    });
    this.print('Received authorization code. Please close the opened browser window.');
    await this._conn.authorize(params.code, {
      code_verifier: verifier
    });
    this.print('Authorized. Fetching user info...');
    const identity = await this._conn.identity();
    this.print(`Logged in as : ${identity.username}`);
    this._connName = identity.username;
    this.saveCurrentConnection();
  }
  /**
   *
   */


  async downloadDefaultClientInfo(clientName) {
    const configUrl = 'https://jsforce.github.io/client-config/default.json';
    const res = await new _Promise((resolve, reject) => {
      request({
        method: 'GET',
        url: configUrl
      }).on('complete', resolve).on('error', reject);
    });
    const clientConfig = JSON.parse(res.body);

    if (clientName === 'sandbox') {
      clientConfig.loginUrl = 'https://test.salesforce.com';
    }

    await registry.registerClientConfig(clientName, clientConfig);
    this.print('Client information downloaded successfully.');
    return this.authorize(clientName);
  }

  async waitCallback(serverUrl, state) {
    if (serverUrl && _indexOfInstanceProperty(serverUrl).call(serverUrl, 'http://localhost:') === 0) {
      return new _Promise((resolve, reject) => {
        const server = http.createServer((req, res) => {
          if (!req.url) {
            return;
          }

          const qparams = url.parse(req.url, true).query;
          res.writeHead(200, {
            'Content-Type': 'text/html'
          });
          res.write('<html><script>location.href="about:blank";</script></html>');
          res.end();

          if (qparams.error) {
            reject(new Error(qparams.error));
          } else {
            resolve(qparams);
          }

          server.close();
          req.connection.end();
          req.connection.destroy();
        });
        const port = Number(url.parse(serverUrl).port);
        server.listen(port, 'localhost');
      });
    } else {
      const code = await this.promptMessage('Copy & paste authz code passed in redirected URL: ');
      return {
        code: decodeURIComponent(code),
        state
      };
    }
  }
  /**
   *
   */


  async register(clientName, clientConfig) {
    var _context;

    const name = clientName || 'default';
    const prompts = {
      clientId: 'Input client ID : ',
      clientSecret: 'Input client secret (optional) : ',
      redirectUri: 'Input redirect URI : ',
      loginUrl: 'Input login URL (default is https://login.salesforce.com) : '
    };
    const registered = await registry.getClientConfig(name);

    if (registered) {
      const msg = `Client '${name}' is already registered. Are you sure you want to override ? [yN] : `;
      const ok = await this.promptConfirm(msg);

      if (!ok) {
        throw new Error('Registration canceled.');
      }
    }

    clientConfig = await _reduceInstanceProperty(_context = _Object$keys(prompts)).call(_context, async (promise, name) => {
      const cconfig = await promise;
      const promptName = name;
      const message = prompts[promptName];

      if (!cconfig[promptName]) {
        const value = await this.promptMessage(message);

        if (value) {
          return _objectSpread(_objectSpread({}, cconfig), {}, {
            [promptName]: value
          });
        }
      }

      return cconfig;
    }, _Promise.resolve(clientConfig));
    await registry.registerClientConfig(name, clientConfig);
    this.print('Client registered successfully.');
  }
  /**
   *
   */


  async listConnections() {
    const names = await registry.getConnectionNames();

    for (var i = 0; i < names.length; i++) {
      var name = names[i];
      this.print((name === this._connName ? '* ' : '  ') + name);
    }
  }
  /**
   *
   */


  async getConnectionNames() {
    return registry.getConnectionNames();
  }
  /**
   *
   */


  async getClientNames() {
    return registry.getClientNames();
  }
  /**
   *
   */


  async prompt(type, message) {
    this._repl.pause();

    const answer = await inquirer.prompt([{
      type,
      name: 'value',
      message
    }]);

    this._repl.resume();

    return answer.value;
  }
  /**
   *
   */


  async promptMessage(message) {
    return this.prompt('input', message);
  }

  async promptPassword(message) {
    return this.prompt('password', message);
  }
  /**
   *
   */


  async promptConfirm(message) {
    return this.prompt('confirm', message);
  }
  /**
   *
   */


  openUrl(url) {
    openUrl(url);
  }
  /**
   *
   */


  openUrlUsingSession(url) {
    let frontdoorUrl = `${this._conn.instanceUrl}/secur/frontdoor.jsp?sid=${this._conn.accessToken}`;

    if (url) {
      frontdoorUrl += '&retURL=' + encodeURIComponent(url);
    }

    this.openUrl(frontdoorUrl);
  }

}
/* ------------------------------------------------------------------------- */

const cli = new Cli();
export default cli;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9jbGkvY2xpLnRzIl0sIm5hbWVzIjpbImh0dHAiLCJ1cmwiLCJjcnlwdG8iLCJvcGVuVXJsIiwiQ29tbWFuZCIsImlucXVpcmVyIiwicmVxdWVzdCIsImJhc2U2NHVybCIsIlJlcGwiLCJqc2ZvcmNlIiwiQ29ubmVjdGlvbiIsIk9BdXRoMiIsInZlcnNpb24iLCJyZWdpc3RyeSIsIkNsaSIsInVuZGVmaW5lZCIsInJlYWRDb21tYW5kIiwib3B0aW9uIiwicGFyc2UiLCJwcm9jZXNzIiwiYXJndiIsInN0YXJ0IiwicHJvZ3JhbSIsIl9vdXRwdXRFbmFibGVkIiwiZXZhbFNjcmlwdCIsImNvbm5lY3QiLCJfcmVwbCIsImludGVyYWN0aXZlIiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwiZXhpdCIsImdldEN1cnJlbnRDb25uZWN0aW9uIiwiX2Nvbm4iLCJwcmludCIsImFyZ3MiLCJsb2ciLCJzYXZlQ3VycmVudENvbm5lY3Rpb24iLCJfY29ubk5hbWUiLCJjb25uIiwiY29ubk5hbWUiLCJjb25uQ29uZmlnIiwib2F1dGgyIiwiY2xpZW50SWQiLCJjbGllbnRTZWNyZXQiLCJyZWRpcmVjdFVyaSIsImxvZ2luVXJsIiwiYWNjZXNzVG9rZW4iLCJpbnN0YW5jZVVybCIsInJlZnJlc2hUb2tlbiIsInNhdmVDb25uZWN0aW9uQ29uZmlnIiwic2V0TG9naW5TZXJ2ZXIiLCJsb2dpblNlcnZlciIsIl9kZWZhdWx0TG9naW5VcmwiLCJvcHRpb25zIiwic2FuZGJveCIsImNvbm5lY3Rpb24iLCJnZXRDb25uZWN0aW9uQ29uZmlnIiwidXNlcm5hbWUiLCJwYXNzd29yZCIsInN0YXJ0UGFzc3dvcmRBdXRoIiwib24iLCJpZGVudGl0eSIsIkVycm9yIiwibWVzc2FnZSIsImxvZ2luQnlQYXNzd29yZCIsInJldHJ5Q291bnQiLCJwYXNzIiwicHJvbXB0UGFzc3dvcmQiLCJyZXN1bHQiLCJsb2dpbiIsImRpc2Nvbm5lY3QiLCJuYW1lIiwicmVtb3ZlQ29ubmVjdGlvbkNvbmZpZyIsImF1dGhvcml6ZSIsImNsaWVudE5hbWUiLCJvYXV0aDJDb25maWciLCJnZXRDbGllbnRDb25maWciLCJkb3dubG9hZERlZmF1bHRDbGllbnRJbmZvIiwidmVyaWZpZXIiLCJlbmNvZGUiLCJyYW5kb21CeXRlcyIsImNoYWxsZW5nZSIsImNyZWF0ZUhhc2giLCJ1cGRhdGUiLCJkaWdlc3QiLCJzdGF0ZSIsImF1dGh6VXJsIiwiZ2V0QXV0aG9yaXphdGlvblVybCIsImNvZGVfY2hhbGxlbmdlIiwicGFyYW1zIiwid2FpdENhbGxiYWNrIiwiY29kZSIsImNvZGVfdmVyaWZpZXIiLCJjb25maWdVcmwiLCJyZXMiLCJyZXNvbHZlIiwicmVqZWN0IiwibWV0aG9kIiwiY2xpZW50Q29uZmlnIiwiSlNPTiIsImJvZHkiLCJyZWdpc3RlckNsaWVudENvbmZpZyIsInNlcnZlclVybCIsInNlcnZlciIsImNyZWF0ZVNlcnZlciIsInJlcSIsInFwYXJhbXMiLCJxdWVyeSIsIndyaXRlSGVhZCIsIndyaXRlIiwiZW5kIiwiY2xvc2UiLCJkZXN0cm95IiwicG9ydCIsIk51bWJlciIsImxpc3RlbiIsInByb21wdE1lc3NhZ2UiLCJkZWNvZGVVUklDb21wb25lbnQiLCJyZWdpc3RlciIsInByb21wdHMiLCJyZWdpc3RlcmVkIiwibXNnIiwib2siLCJwcm9tcHRDb25maXJtIiwicHJvbWlzZSIsImNjb25maWciLCJwcm9tcHROYW1lIiwidmFsdWUiLCJsaXN0Q29ubmVjdGlvbnMiLCJuYW1lcyIsImdldENvbm5lY3Rpb25OYW1lcyIsImkiLCJsZW5ndGgiLCJnZXRDbGllbnROYW1lcyIsInByb21wdCIsInR5cGUiLCJwYXVzZSIsImFuc3dlciIsInJlc3VtZSIsIm9wZW5VcmxVc2luZ1Nlc3Npb24iLCJmcm9udGRvb3JVcmwiLCJlbmNvZGVVUklDb21wb25lbnQiLCJjbGkiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU9BLElBQVAsTUFBaUIsTUFBakI7QUFDQSxPQUFPQyxHQUFQLE1BQWdCLEtBQWhCO0FBQ0EsT0FBT0MsTUFBUCxNQUFtQixRQUFuQjtBQUNBLE9BQU9DLE9BQVAsTUFBb0IsTUFBcEI7QUFDQSxTQUFTQyxPQUFULFFBQXdCLFdBQXhCO0FBQ0EsT0FBT0MsUUFBUCxNQUFxQixVQUFyQjtBQUNBLE9BQU9DLE9BQVAsTUFBb0IsWUFBcEI7QUFDQSxPQUFPQyxTQUFQLE1BQXNCLFdBQXRCO0FBQ0EsT0FBT0MsSUFBUCxNQUFpQixRQUFqQjtBQUNBLE9BQU9DLE9BQVAsSUFBa0JDLFVBQWxCLEVBQThCQyxNQUE5QixRQUE0QyxJQUE1QztBQUNBLE9BQU9DLE9BQVAsTUFBb0IsWUFBcEI7QUFJQSxNQUFNQyxRQUFRLEdBQUdKLE9BQU8sQ0FBQ0ksUUFBekI7O0FBV0E7QUFDQTtBQUNBO0FBQ0EsT0FBTyxNQUFNQyxHQUFOLENBQVU7QUFBQTtBQUFBLG1DQUNELElBQUlOLElBQUosQ0FBUyxJQUFULENBREM7O0FBQUEsbUNBRUssSUFBSUUsVUFBSixFQUZMOztBQUFBLHVDQUdpQkssU0FIakI7O0FBQUEsNENBSVcsSUFKWDs7QUFBQSw4Q0FLd0JBLFNBTHhCO0FBQUE7O0FBT2Y7QUFDRjtBQUNBO0FBQ0VDLEVBQUFBLFdBQVcsR0FBZTtBQUN4QixXQUFPLElBQUlaLE9BQUosR0FDSmEsTUFESSxDQUNHLDJCQURILEVBQ2dDLHFCQURoQyxFQUVKQSxNQUZJLENBR0gsMkJBSEcsRUFJSCx3REFKRyxFQU1KQSxNQU5JLENBT0gsK0JBUEcsRUFRSCwrQ0FSRyxFQVVKQSxNQVZJLENBVUcsMkJBVkgsRUFVZ0Msc0JBVmhDLEVBV0pBLE1BWEksQ0FXRyxXQVhILEVBV2dCLDZCQVhoQixFQVlKQSxNQVpJLENBWUcsK0JBWkgsRUFZb0Msb0JBWnBDLEVBYUpMLE9BYkksQ0FhSUEsT0FiSixFQWNKTSxLQWRJLENBY0VDLE9BQU8sQ0FBQ0MsSUFkVixDQUFQO0FBZUQ7O0FBRUQsUUFBTUMsS0FBTixHQUFjO0FBQ1osVUFBTUMsT0FBTyxHQUFHLEtBQUtOLFdBQUwsRUFBaEI7QUFDQSxTQUFLTyxjQUFMLEdBQXNCLENBQUNELE9BQU8sQ0FBQ0UsVUFBL0I7O0FBQ0EsUUFBSTtBQUNGLFlBQU0sS0FBS0MsT0FBTCxDQUFhSCxPQUFiLENBQU47O0FBQ0EsVUFBSUEsT0FBTyxDQUFDRSxVQUFaLEVBQXdCO0FBQ3RCLGFBQUtFLEtBQUwsQ0FBV0wsS0FBWCxDQUFpQjtBQUNmTSxVQUFBQSxXQUFXLEVBQUUsS0FERTtBQUVmSCxVQUFBQSxVQUFVLEVBQUVGLE9BQU8sQ0FBQ0U7QUFGTCxTQUFqQjtBQUlELE9BTEQsTUFLTztBQUNMLGFBQUtFLEtBQUwsQ0FBV0wsS0FBWDtBQUNEO0FBQ0YsS0FWRCxDQVVFLE9BQU9PLEdBQVAsRUFBWTtBQUNaQyxNQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBY0YsR0FBZDtBQUNBVCxNQUFBQSxPQUFPLENBQUNZLElBQVI7QUFDRDtBQUNGOztBQUVEQyxFQUFBQSxvQkFBb0IsR0FBRztBQUNyQixXQUFPLEtBQUtDLEtBQVo7QUFDRDs7QUFFREMsRUFBQUEsS0FBSyxDQUFDLEdBQUdDLElBQUosRUFBaUI7QUFDcEIsUUFBSSxLQUFLWixjQUFULEVBQXlCO0FBQ3ZCTSxNQUFBQSxPQUFPLENBQUNPLEdBQVIsQ0FBWSxHQUFHRCxJQUFmO0FBQ0Q7QUFDRjs7QUFFREUsRUFBQUEscUJBQXFCLEdBQUc7QUFDdEIsUUFBSSxLQUFLQyxTQUFULEVBQW9CO0FBQ2xCLFlBQU1DLElBQUksR0FBRyxLQUFLTixLQUFsQjtBQUNBLFlBQU1PLFFBQVEsR0FBRyxLQUFLRixTQUF0QjtBQUNBLFlBQU1HLFVBQVUsR0FBRztBQUNqQkMsUUFBQUEsTUFBTSxFQUFFSCxJQUFJLENBQUNHLE1BQUwsR0FDSjtBQUNFQyxVQUFBQSxRQUFRLEVBQUVKLElBQUksQ0FBQ0csTUFBTCxDQUFZQyxRQUFaLElBQXdCNUIsU0FEcEM7QUFFRTZCLFVBQUFBLFlBQVksRUFBRUwsSUFBSSxDQUFDRyxNQUFMLENBQVlFLFlBQVosSUFBNEI3QixTQUY1QztBQUdFOEIsVUFBQUEsV0FBVyxFQUFFTixJQUFJLENBQUNHLE1BQUwsQ0FBWUcsV0FBWixJQUEyQjlCLFNBSDFDO0FBSUUrQixVQUFBQSxRQUFRLEVBQUVQLElBQUksQ0FBQ0csTUFBTCxDQUFZSSxRQUFaLElBQXdCL0I7QUFKcEMsU0FESSxHQU9KQSxTQVJhO0FBU2pCZ0MsUUFBQUEsV0FBVyxFQUFFUixJQUFJLENBQUNRLFdBQUwsSUFBb0JoQyxTQVRoQjtBQVVqQmlDLFFBQUFBLFdBQVcsRUFBRVQsSUFBSSxDQUFDUyxXQUFMLElBQW9CakMsU0FWaEI7QUFXakJrQyxRQUFBQSxZQUFZLEVBQUVWLElBQUksQ0FBQ1UsWUFBTCxJQUFxQmxDO0FBWGxCLE9BQW5CO0FBYUFGLE1BQUFBLFFBQVEsQ0FBQ3FDLG9CQUFULENBQThCVixRQUE5QixFQUF3Q0MsVUFBeEM7QUFDRDtBQUNGOztBQUVEVSxFQUFBQSxjQUFjLENBQUNDLFdBQUQsRUFBZ0M7QUFDNUMsUUFBSSxDQUFDQSxXQUFMLEVBQWtCO0FBQ2hCO0FBQ0Q7O0FBQ0QsUUFBSUEsV0FBVyxLQUFLLFlBQXBCLEVBQWtDO0FBQ2hDLFdBQUtDLGdCQUFMLEdBQXdCLDhCQUF4QjtBQUNELEtBRkQsTUFFTyxJQUFJRCxXQUFXLEtBQUssU0FBcEIsRUFBK0I7QUFDcEMsV0FBS0MsZ0JBQUwsR0FBd0IsNkJBQXhCO0FBQ0QsS0FGTSxNQUVBLElBQUkseUJBQUFELFdBQVcsTUFBWCxDQUFBQSxXQUFXLEVBQVMsVUFBVCxDQUFYLEtBQW9DLENBQXhDLEVBQTJDO0FBQ2hELFdBQUtDLGdCQUFMLEdBQXdCLGFBQWFELFdBQXJDO0FBQ0QsS0FGTSxNQUVBO0FBQ0wsV0FBS0MsZ0JBQUwsR0FBd0JELFdBQXhCO0FBQ0Q7O0FBQ0QsU0FBS2xCLEtBQUwsQ0FBWSxVQUFTLEtBQUttQixnQkFBaUIseUJBQTNDO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFLFFBQU01QixPQUFOLENBQWM2QixPQUFkLEVBTUc7QUFDRCxVQUFNRixXQUFXLEdBQUdFLE9BQU8sQ0FBQ1IsUUFBUixHQUNoQlEsT0FBTyxDQUFDUixRQURRLEdBRWhCUSxPQUFPLENBQUNDLE9BQVIsR0FDQSxTQURBLEdBRUEsSUFKSjtBQUtBLFNBQUtKLGNBQUwsQ0FBb0JDLFdBQXBCO0FBQ0EsU0FBS2QsU0FBTCxHQUFpQmdCLE9BQU8sQ0FBQ0UsVUFBekI7QUFDQSxRQUFJZixVQUFVLEdBQUcsTUFBTTVCLFFBQVEsQ0FBQzRDLG1CQUFULENBQTZCSCxPQUFPLENBQUNFLFVBQXJDLENBQXZCO0FBQ0EsUUFBSUUsUUFBUSxHQUFHSixPQUFPLENBQUNJLFFBQXZCOztBQUNBLFFBQUksQ0FBQ2pCLFVBQUwsRUFBaUI7QUFDZkEsTUFBQUEsVUFBVSxHQUFHLEVBQWI7O0FBQ0EsVUFBSSxLQUFLWSxnQkFBVCxFQUEyQjtBQUN6QlosUUFBQUEsVUFBVSxDQUFDSyxRQUFYLEdBQXNCLEtBQUtPLGdCQUEzQjtBQUNEOztBQUNESyxNQUFBQSxRQUFRLEdBQUdBLFFBQVEsSUFBSUosT0FBTyxDQUFDRSxVQUEvQjtBQUNEOztBQUNELFNBQUt2QixLQUFMLEdBQWEsSUFBSXZCLFVBQUosQ0FBZStCLFVBQWYsQ0FBYjtBQUNBLFVBQU1rQixRQUFRLEdBQUdMLE9BQU8sQ0FBQ0ssUUFBekI7O0FBQ0EsUUFBSUQsUUFBSixFQUFjO0FBQ1osWUFBTSxLQUFLRSxpQkFBTCxDQUF1QkYsUUFBdkIsRUFBaUNDLFFBQWpDLENBQU47QUFDQSxXQUFLdEIscUJBQUw7QUFDRCxLQUhELE1BR087QUFDTCxVQUFJLEtBQUtDLFNBQUwsSUFBa0IsS0FBS0wsS0FBTCxDQUFXYyxXQUFqQyxFQUE4QztBQUM1QyxhQUFLZCxLQUFMLENBQVc0QixFQUFYLENBQWMsU0FBZCxFQUF5QixNQUFNO0FBQzdCLGVBQUszQixLQUFMLENBQVcsOEJBQVg7QUFDQSxlQUFLRyxxQkFBTDtBQUNELFNBSEQ7O0FBSUEsWUFBSTtBQUNGLGdCQUFNeUIsUUFBUSxHQUFHLE1BQU0sS0FBSzdCLEtBQUwsQ0FBVzZCLFFBQVgsRUFBdkI7QUFDQSxlQUFLNUIsS0FBTCxDQUFZLGtCQUFpQjRCLFFBQVEsQ0FBQ0osUUFBUyxFQUEvQztBQUNELFNBSEQsQ0FHRSxPQUFPOUIsR0FBUCxFQUFZO0FBQ1osY0FBSUEsR0FBRyxZQUFZbUMsS0FBbkIsRUFBMEI7QUFDeEIsaUJBQUs3QixLQUFMLENBQVdOLEdBQUcsQ0FBQ29DLE9BQWY7QUFDRDs7QUFDRCxjQUFJLEtBQUsvQixLQUFMLENBQVdTLE1BQWYsRUFBdUI7QUFDckIsa0JBQU0sSUFBSXFCLEtBQUosQ0FBVSxpQ0FBVixDQUFOO0FBQ0QsV0FGRCxNQUVPO0FBQ0wsa0JBQU0sS0FBS0gsaUJBQUwsQ0FBdUIsS0FBS3RCLFNBQTVCLENBQU47QUFDRDtBQUNGO0FBQ0Y7QUFDRjtBQUNGO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRSxRQUFNc0IsaUJBQU4sQ0FBd0JGLFFBQXhCLEVBQTBDQyxRQUExQyxFQUE2RDtBQUMzRCxRQUFJO0FBQ0YsWUFBTSxLQUFLTSxlQUFMLENBQXFCUCxRQUFyQixFQUErQkMsUUFBL0IsRUFBeUMsQ0FBekMsQ0FBTjtBQUNELEtBRkQsQ0FFRSxPQUFPL0IsR0FBUCxFQUFZO0FBQ1osVUFBSUEsR0FBRyxZQUFZbUMsS0FBZixJQUF3Qm5DLEdBQUcsQ0FBQ29DLE9BQUosS0FBZ0IsVUFBNUMsRUFBd0Q7QUFDdERuQyxRQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYyxpREFBZDtBQUNELE9BRkQsTUFFTztBQUNMLGNBQU1GLEdBQU47QUFDRDtBQUNGO0FBQ0Y7QUFFRDtBQUNGO0FBQ0E7OztBQUNFLFFBQU1xQyxlQUFOLENBQ0VQLFFBREYsRUFFRUMsUUFGRixFQUdFTyxVQUhGLEVBSTJCO0FBQ3pCLFFBQUlQLFFBQVEsS0FBSyxFQUFqQixFQUFxQjtBQUNuQixZQUFNLElBQUlJLEtBQUosQ0FBVSxVQUFWLENBQU47QUFDRDs7QUFDRCxRQUFJSixRQUFRLElBQUksSUFBaEIsRUFBc0I7QUFDcEIsWUFBTVEsSUFBSSxHQUFHLE1BQU0sS0FBS0MsY0FBTCxDQUFvQixZQUFwQixDQUFuQjtBQUNBLGFBQU8sS0FBS0gsZUFBTCxDQUFxQlAsUUFBckIsRUFBK0JTLElBQS9CLEVBQXFDRCxVQUFyQyxDQUFQO0FBQ0Q7O0FBQ0QsUUFBSTtBQUNGLFlBQU1HLE1BQU0sR0FBRyxNQUFNLEtBQUtwQyxLQUFMLENBQVdxQyxLQUFYLENBQWlCWixRQUFqQixFQUEyQkMsUUFBM0IsQ0FBckI7QUFDQSxXQUFLekIsS0FBTCxDQUFZLGtCQUFpQndCLFFBQVMsRUFBdEM7QUFDQSxhQUFPVyxNQUFQO0FBQ0QsS0FKRCxDQUlFLE9BQU96QyxHQUFQLEVBQVk7QUFDWixVQUFJQSxHQUFHLFlBQVltQyxLQUFuQixFQUEwQjtBQUN4QmxDLFFBQUFBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjRixHQUFHLENBQUNvQyxPQUFsQjtBQUNEOztBQUNELFVBQUlFLFVBQVUsR0FBRyxDQUFqQixFQUFvQjtBQUNsQixlQUFPLEtBQUtELGVBQUwsQ0FBcUJQLFFBQXJCLEVBQStCM0MsU0FBL0IsRUFBMENtRCxVQUFVLEdBQUcsQ0FBdkQsQ0FBUDtBQUNELE9BRkQsTUFFTztBQUNMLGNBQU0sSUFBSUgsS0FBSixDQUFVLFVBQVYsQ0FBTjtBQUNEO0FBQ0Y7QUFDRjtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0VRLEVBQUFBLFVBQVUsQ0FBQy9CLFFBQUQsRUFBb0I7QUFDNUIsVUFBTWdDLElBQUksR0FBR2hDLFFBQVEsSUFBSSxLQUFLRixTQUE5Qjs7QUFDQSxRQUFJa0MsSUFBSSxJQUFJM0QsUUFBUSxDQUFDNEMsbUJBQVQsQ0FBNkJlLElBQTdCLENBQVosRUFBZ0Q7QUFDOUMzRCxNQUFBQSxRQUFRLENBQUM0RCxzQkFBVCxDQUFnQ0QsSUFBaEM7QUFDQSxXQUFLdEMsS0FBTCxDQUFZLDBCQUF5QnNDLElBQUssR0FBMUM7QUFDRDs7QUFDRCxTQUFLbEMsU0FBTCxHQUFpQnZCLFNBQWpCO0FBQ0EsU0FBS2tCLEtBQUwsR0FBYSxJQUFJdkIsVUFBSixFQUFiO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFLFFBQU1nRSxTQUFOLENBQWdCQyxVQUFoQixFQUFvQztBQUNsQyxVQUFNSCxJQUFJLEdBQUdHLFVBQVUsSUFBSSxTQUEzQjtBQUNBLFFBQUlDLFlBQVksR0FBRyxNQUFNL0QsUUFBUSxDQUFDZ0UsZUFBVCxDQUF5QkwsSUFBekIsQ0FBekI7O0FBQ0EsUUFBSSxDQUFDSSxZQUFELElBQWlCLENBQUNBLFlBQVksQ0FBQ2pDLFFBQW5DLEVBQTZDO0FBQzNDLFVBQUk2QixJQUFJLEtBQUssU0FBVCxJQUFzQkEsSUFBSSxLQUFLLFNBQW5DLEVBQThDO0FBQzVDLGFBQUt0QyxLQUFMLENBQ0UscUZBREY7QUFHQSxlQUFPLEtBQUs0Qyx5QkFBTCxDQUErQk4sSUFBL0IsQ0FBUDtBQUNEOztBQUNELFlBQU0sSUFBSVQsS0FBSixDQUNILDhDQUE2Q1MsSUFBSyx1Q0FEL0MsQ0FBTjtBQUdEOztBQUNELFVBQU05QixNQUFNLEdBQUcsSUFBSS9CLE1BQUosQ0FBV2lFLFlBQVgsQ0FBZjtBQUNBLFVBQU1HLFFBQVEsR0FBR3hFLFNBQVMsQ0FBQ3lFLE1BQVYsQ0FBaUI5RSxNQUFNLENBQUMrRSxXQUFQLENBQW1CLEVBQW5CLENBQWpCLENBQWpCO0FBQ0EsVUFBTUMsU0FBUyxHQUFHM0UsU0FBUyxDQUFDeUUsTUFBVixDQUNoQjlFLE1BQU0sQ0FBQ2lGLFVBQVAsQ0FBa0IsUUFBbEIsRUFBNEJDLE1BQTVCLENBQW1DTCxRQUFuQyxFQUE2Q00sTUFBN0MsRUFEZ0IsQ0FBbEI7QUFHQSxVQUFNQyxLQUFLLEdBQUcvRSxTQUFTLENBQUN5RSxNQUFWLENBQWlCOUUsTUFBTSxDQUFDK0UsV0FBUCxDQUFtQixFQUFuQixDQUFqQixDQUFkO0FBQ0EsVUFBTU0sUUFBUSxHQUFHN0MsTUFBTSxDQUFDOEMsbUJBQVAsQ0FBMkI7QUFDMUNDLE1BQUFBLGNBQWMsRUFBRVAsU0FEMEI7QUFFMUNJLE1BQUFBO0FBRjBDLEtBQTNCLENBQWpCO0FBSUEsU0FBS3BELEtBQUwsQ0FBVywwQ0FBWDtBQUNBLFNBQUtBLEtBQUwsQ0FBWSxRQUFPcUQsUUFBUyxFQUE1QjtBQUNBLFNBQUtwRixPQUFMLENBQWFvRixRQUFiO0FBQ0EsVUFBTUcsTUFBTSxHQUFHLE1BQU0sS0FBS0MsWUFBTCxDQUFrQmYsWUFBWSxDQUFDL0IsV0FBL0IsRUFBNEN5QyxLQUE1QyxDQUFyQjs7QUFDQSxRQUFJLENBQUNJLE1BQU0sQ0FBQ0UsSUFBWixFQUFrQjtBQUNoQixZQUFNLElBQUk3QixLQUFKLENBQVUsaUNBQVYsQ0FBTjtBQUNEOztBQUNELFFBQUkyQixNQUFNLENBQUNKLEtBQVAsS0FBaUJBLEtBQXJCLEVBQTRCO0FBQzFCLFlBQU0sSUFBSXZCLEtBQUosQ0FBVSxtQ0FBVixDQUFOO0FBQ0Q7O0FBQ0QsU0FBSzlCLEtBQUwsR0FBYSxJQUFJdkIsVUFBSixDQUFlO0FBQUVnQyxNQUFBQTtBQUFGLEtBQWYsQ0FBYjtBQUNBLFNBQUtSLEtBQUwsQ0FDRSxzRUFERjtBQUdBLFVBQU0sS0FBS0QsS0FBTCxDQUFXeUMsU0FBWCxDQUFxQmdCLE1BQU0sQ0FBQ0UsSUFBNUIsRUFBa0M7QUFBRUMsTUFBQUEsYUFBYSxFQUFFZDtBQUFqQixLQUFsQyxDQUFOO0FBQ0EsU0FBSzdDLEtBQUwsQ0FBVyxtQ0FBWDtBQUNBLFVBQU00QixRQUFRLEdBQUcsTUFBTSxLQUFLN0IsS0FBTCxDQUFXNkIsUUFBWCxFQUF2QjtBQUNBLFNBQUs1QixLQUFMLENBQVksa0JBQWlCNEIsUUFBUSxDQUFDSixRQUFTLEVBQS9DO0FBQ0EsU0FBS3BCLFNBQUwsR0FBaUJ3QixRQUFRLENBQUNKLFFBQTFCO0FBQ0EsU0FBS3JCLHFCQUFMO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFLFFBQU15Qyx5QkFBTixDQUFnQ0gsVUFBaEMsRUFBbUU7QUFDakUsVUFBTW1CLFNBQVMsR0FBRyxzREFBbEI7QUFDQSxVQUFNQyxHQUFxQixHQUFHLE1BQU0sYUFBWSxDQUFDQyxPQUFELEVBQVVDLE1BQVYsS0FBcUI7QUFDbkUzRixNQUFBQSxPQUFPLENBQUM7QUFBRTRGLFFBQUFBLE1BQU0sRUFBRSxLQUFWO0FBQWlCakcsUUFBQUEsR0FBRyxFQUFFNkY7QUFBdEIsT0FBRCxDQUFQLENBQ0dqQyxFQURILENBQ00sVUFETixFQUNrQm1DLE9BRGxCLEVBRUduQyxFQUZILENBRU0sT0FGTixFQUVlb0MsTUFGZjtBQUdELEtBSm1DLENBQXBDO0FBS0EsVUFBTUUsWUFBWSxHQUFHQyxJQUFJLENBQUNsRixLQUFMLENBQVc2RSxHQUFHLENBQUNNLElBQWYsQ0FBckI7O0FBQ0EsUUFBSTFCLFVBQVUsS0FBSyxTQUFuQixFQUE4QjtBQUM1QndCLE1BQUFBLFlBQVksQ0FBQ3JELFFBQWIsR0FBd0IsNkJBQXhCO0FBQ0Q7O0FBQ0QsVUFBTWpDLFFBQVEsQ0FBQ3lGLG9CQUFULENBQThCM0IsVUFBOUIsRUFBMEN3QixZQUExQyxDQUFOO0FBQ0EsU0FBS2pFLEtBQUwsQ0FBVyw2Q0FBWDtBQUNBLFdBQU8sS0FBS3dDLFNBQUwsQ0FBZUMsVUFBZixDQUFQO0FBQ0Q7O0FBRUQsUUFBTWdCLFlBQU4sQ0FDRVksU0FERixFQUVFakIsS0FGRixFQUc0QztBQUMxQyxRQUFJaUIsU0FBUyxJQUFJLHlCQUFBQSxTQUFTLE1BQVQsQ0FBQUEsU0FBUyxFQUFTLG1CQUFULENBQVQsS0FBMkMsQ0FBNUQsRUFBK0Q7QUFDN0QsYUFBTyxhQUFZLENBQUNQLE9BQUQsRUFBVUMsTUFBVixLQUFxQjtBQUN0QyxjQUFNTyxNQUFNLEdBQUd4RyxJQUFJLENBQUN5RyxZQUFMLENBQWtCLENBQUNDLEdBQUQsRUFBTVgsR0FBTixLQUFjO0FBQzdDLGNBQUksQ0FBQ1csR0FBRyxDQUFDekcsR0FBVCxFQUFjO0FBQ1o7QUFDRDs7QUFDRCxnQkFBTTBHLE9BQU8sR0FBRzFHLEdBQUcsQ0FBQ2lCLEtBQUosQ0FBVXdGLEdBQUcsQ0FBQ3pHLEdBQWQsRUFBbUIsSUFBbkIsRUFBeUIyRyxLQUF6QztBQUNBYixVQUFBQSxHQUFHLENBQUNjLFNBQUosQ0FBYyxHQUFkLEVBQW1CO0FBQUUsNEJBQWdCO0FBQWxCLFdBQW5CO0FBQ0FkLFVBQUFBLEdBQUcsQ0FBQ2UsS0FBSixDQUNFLDREQURGO0FBR0FmLFVBQUFBLEdBQUcsQ0FBQ2dCLEdBQUo7O0FBQ0EsY0FBSUosT0FBTyxDQUFDN0UsS0FBWixFQUFtQjtBQUNqQm1FLFlBQUFBLE1BQU0sQ0FBQyxJQUFJbEMsS0FBSixDQUFVNEMsT0FBTyxDQUFDN0UsS0FBbEIsQ0FBRCxDQUFOO0FBQ0QsV0FGRCxNQUVPO0FBQ0xrRSxZQUFBQSxPQUFPLENBQUNXLE9BQUQsQ0FBUDtBQUNEOztBQUNESCxVQUFBQSxNQUFNLENBQUNRLEtBQVA7QUFDQU4sVUFBQUEsR0FBRyxDQUFDbEQsVUFBSixDQUFldUQsR0FBZjtBQUNBTCxVQUFBQSxHQUFHLENBQUNsRCxVQUFKLENBQWV5RCxPQUFmO0FBQ0QsU0FsQmMsQ0FBZjtBQW1CQSxjQUFNQyxJQUFJLEdBQUdDLE1BQU0sQ0FBQ2xILEdBQUcsQ0FBQ2lCLEtBQUosQ0FBVXFGLFNBQVYsRUFBcUJXLElBQXRCLENBQW5CO0FBQ0FWLFFBQUFBLE1BQU0sQ0FBQ1ksTUFBUCxDQUFjRixJQUFkLEVBQW9CLFdBQXBCO0FBQ0QsT0F0Qk0sQ0FBUDtBQXVCRCxLQXhCRCxNQXdCTztBQUNMLFlBQU10QixJQUFJLEdBQUcsTUFBTSxLQUFLeUIsYUFBTCxDQUNqQixvREFEaUIsQ0FBbkI7QUFHQSxhQUFPO0FBQUV6QixRQUFBQSxJQUFJLEVBQUUwQixrQkFBa0IsQ0FBQzFCLElBQUQsQ0FBMUI7QUFBa0NOLFFBQUFBO0FBQWxDLE9BQVA7QUFDRDtBQUNGO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRSxRQUFNaUMsUUFBTixDQUFlNUMsVUFBZixFQUErQ3dCLFlBQS9DLEVBQTJFO0FBQUE7O0FBQ3pFLFVBQU0zQixJQUFJLEdBQUdHLFVBQVUsSUFBSSxTQUEzQjtBQUNBLFVBQU02QyxPQUFPLEdBQUc7QUFDZDdFLE1BQUFBLFFBQVEsRUFBRSxvQkFESTtBQUVkQyxNQUFBQSxZQUFZLEVBQUUsbUNBRkE7QUFHZEMsTUFBQUEsV0FBVyxFQUFFLHVCQUhDO0FBSWRDLE1BQUFBLFFBQVEsRUFBRTtBQUpJLEtBQWhCO0FBTUEsVUFBTTJFLFVBQVUsR0FBRyxNQUFNNUcsUUFBUSxDQUFDZ0UsZUFBVCxDQUF5QkwsSUFBekIsQ0FBekI7O0FBQ0EsUUFBSWlELFVBQUosRUFBZ0I7QUFDZCxZQUFNQyxHQUFHLEdBQUksV0FBVWxELElBQUssc0VBQTVCO0FBQ0EsWUFBTW1ELEVBQUUsR0FBRyxNQUFNLEtBQUtDLGFBQUwsQ0FBbUJGLEdBQW5CLENBQWpCOztBQUNBLFVBQUksQ0FBQ0MsRUFBTCxFQUFTO0FBQ1AsY0FBTSxJQUFJNUQsS0FBSixDQUFVLHdCQUFWLENBQU47QUFDRDtBQUNGOztBQUNEb0MsSUFBQUEsWUFBWSxHQUFHLE1BQU0sZ0RBQVlxQixPQUFaLGtCQUE0QixPQUFPSyxPQUFQLEVBQWdCckQsSUFBaEIsS0FBeUI7QUFDeEUsWUFBTXNELE9BQU8sR0FBRyxNQUFNRCxPQUF0QjtBQUNBLFlBQU1FLFVBQVUsR0FBR3ZELElBQW5CO0FBQ0EsWUFBTVIsT0FBTyxHQUFHd0QsT0FBTyxDQUFDTyxVQUFELENBQXZCOztBQUNBLFVBQUksQ0FBQ0QsT0FBTyxDQUFDQyxVQUFELENBQVosRUFBMEI7QUFDeEIsY0FBTUMsS0FBSyxHQUFHLE1BQU0sS0FBS1gsYUFBTCxDQUFtQnJELE9BQW5CLENBQXBCOztBQUNBLFlBQUlnRSxLQUFKLEVBQVc7QUFDVCxpREFDS0YsT0FETDtBQUVFLGFBQUNDLFVBQUQsR0FBY0M7QUFGaEI7QUFJRDtBQUNGOztBQUNELGFBQU9GLE9BQVA7QUFDRCxLQWRvQixFQWNsQixTQUFROUIsT0FBUixDQUFnQkcsWUFBaEIsQ0Fka0IsQ0FBckI7QUFlQSxVQUFNdEYsUUFBUSxDQUFDeUYsb0JBQVQsQ0FBOEI5QixJQUE5QixFQUFvQzJCLFlBQXBDLENBQU47QUFDQSxTQUFLakUsS0FBTCxDQUFXLGlDQUFYO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFLFFBQU0rRixlQUFOLEdBQXdCO0FBQ3RCLFVBQU1DLEtBQUssR0FBRyxNQUFNckgsUUFBUSxDQUFDc0gsa0JBQVQsRUFBcEI7O0FBQ0EsU0FBSyxJQUFJQyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHRixLQUFLLENBQUNHLE1BQTFCLEVBQWtDRCxDQUFDLEVBQW5DLEVBQXVDO0FBQ3JDLFVBQUk1RCxJQUFJLEdBQUcwRCxLQUFLLENBQUNFLENBQUQsQ0FBaEI7QUFDQSxXQUFLbEcsS0FBTCxDQUFXLENBQUNzQyxJQUFJLEtBQUssS0FBS2xDLFNBQWQsR0FBMEIsSUFBMUIsR0FBaUMsSUFBbEMsSUFBMENrQyxJQUFyRDtBQUNEO0FBQ0Y7QUFFRDtBQUNGO0FBQ0E7OztBQUNFLFFBQU0yRCxrQkFBTixHQUEyQjtBQUN6QixXQUFPdEgsUUFBUSxDQUFDc0gsa0JBQVQsRUFBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRSxRQUFNRyxjQUFOLEdBQXVCO0FBQ3JCLFdBQU96SCxRQUFRLENBQUN5SCxjQUFULEVBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBQ0UsUUFBTUMsTUFBTixDQUFhQyxJQUFiLEVBQTJCeEUsT0FBM0IsRUFBNEM7QUFDMUMsU0FBS3RDLEtBQUwsQ0FBVytHLEtBQVg7O0FBQ0EsVUFBTUMsTUFBeUIsR0FBRyxNQUFNckksUUFBUSxDQUFDa0ksTUFBVCxDQUFnQixDQUN0RDtBQUNFQyxNQUFBQSxJQURGO0FBRUVoRSxNQUFBQSxJQUFJLEVBQUUsT0FGUjtBQUdFUixNQUFBQTtBQUhGLEtBRHNELENBQWhCLENBQXhDOztBQU9BLFNBQUt0QyxLQUFMLENBQVdpSCxNQUFYOztBQUNBLFdBQU9ELE1BQU0sQ0FBQ1YsS0FBZDtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRSxRQUFNWCxhQUFOLENBQW9CckQsT0FBcEIsRUFBcUM7QUFDbkMsV0FBTyxLQUFLdUUsTUFBTCxDQUFZLE9BQVosRUFBcUJ2RSxPQUFyQixDQUFQO0FBQ0Q7O0FBRUQsUUFBTUksY0FBTixDQUFxQkosT0FBckIsRUFBc0M7QUFDcEMsV0FBTyxLQUFLdUUsTUFBTCxDQUFZLFVBQVosRUFBd0J2RSxPQUF4QixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFLFFBQU00RCxhQUFOLENBQW9CNUQsT0FBcEIsRUFBcUM7QUFDbkMsV0FBTyxLQUFLdUUsTUFBTCxDQUFZLFNBQVosRUFBdUJ2RSxPQUF2QixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFN0QsRUFBQUEsT0FBTyxDQUFDRixHQUFELEVBQWM7QUFDbkJFLElBQUFBLE9BQU8sQ0FBQ0YsR0FBRCxDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFMkksRUFBQUEsbUJBQW1CLENBQUMzSSxHQUFELEVBQWU7QUFDaEMsUUFBSTRJLFlBQVksR0FBSSxHQUFFLEtBQUs1RyxLQUFMLENBQVdlLFdBQVksNEJBQTJCLEtBQUtmLEtBQUwsQ0FBV2MsV0FBWSxFQUEvRjs7QUFDQSxRQUFJOUMsR0FBSixFQUFTO0FBQ1A0SSxNQUFBQSxZQUFZLElBQUksYUFBYUMsa0JBQWtCLENBQUM3SSxHQUFELENBQS9DO0FBQ0Q7O0FBQ0QsU0FBS0UsT0FBTCxDQUFhMEksWUFBYjtBQUNEOztBQXhhYztBQTJhakI7O0FBRUEsTUFBTUUsR0FBRyxHQUFHLElBQUlqSSxHQUFKLEVBQVo7QUFFQSxlQUFlaUksR0FBZiIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGZpbGUgQ29tbWFuZCBsaW5lIGludGVyZmFjZSBmb3IgSlNmb3JjZVxuICogQGF1dGhvciBTaGluaWNoaSBUb21pdGEgPHNoaW5pY2hpLnRvbWl0YUBnbWFpbC5jb20+XG4gKi9cbmltcG9ydCBodHRwIGZyb20gJ2h0dHAnO1xuaW1wb3J0IHVybCBmcm9tICd1cmwnO1xuaW1wb3J0IGNyeXB0byBmcm9tICdjcnlwdG8nO1xuaW1wb3J0IG9wZW5VcmwgZnJvbSAnb3Blbic7XG5pbXBvcnQgeyBDb21tYW5kIH0gZnJvbSAnY29tbWFuZGVyJztcbmltcG9ydCBpbnF1aXJlciBmcm9tICdpbnF1aXJlcic7XG5pbXBvcnQgcmVxdWVzdCBmcm9tICcuLi9yZXF1ZXN0JztcbmltcG9ydCBiYXNlNjR1cmwgZnJvbSAnYmFzZTY0dXJsJztcbmltcG9ydCBSZXBsIGZyb20gJy4vcmVwbCc7XG5pbXBvcnQganNmb3JjZSwgeyBDb25uZWN0aW9uLCBPQXV0aDIgfSBmcm9tICcuLic7XG5pbXBvcnQgdmVyc2lvbiBmcm9tICcuLi9WRVJTSU9OJztcbmltcG9ydCB7IE9wdGlvbmFsIH0gZnJvbSAnLi4vdHlwZXMnO1xuaW1wb3J0IHsgQ2xpZW50Q29uZmlnIH0gZnJvbSAnLi4vcmVnaXN0cnkvdHlwZXMnO1xuXG5jb25zdCByZWdpc3RyeSA9IGpzZm9yY2UucmVnaXN0cnk7XG5cbmludGVyZmFjZSBDbGlDb21tYW5kIGV4dGVuZHMgQ29tbWFuZCB7XG4gIGNvbm5lY3Rpb24/OiBzdHJpbmc7XG4gIHVzZXJuYW1lPzogc3RyaW5nO1xuICBwYXNzd29yZD86IHN0cmluZztcbiAgbG9naW5Vcmw/OiBzdHJpbmc7XG4gIHNhbmRib3g/OiBib29sZWFuO1xuICBldmFsU2NyaXB0Pzogc3RyaW5nO1xufVxuXG4vKipcbiAqXG4gKi9cbmV4cG9ydCBjbGFzcyBDbGkge1xuICBfcmVwbDogUmVwbCA9IG5ldyBSZXBsKHRoaXMpO1xuICBfY29ubjogQ29ubmVjdGlvbiA9IG5ldyBDb25uZWN0aW9uKCk7XG4gIF9jb25uTmFtZTogc3RyaW5nIHwgdW5kZWZpbmVkID0gdW5kZWZpbmVkO1xuICBfb3V0cHV0RW5hYmxlZDogYm9vbGVhbiA9IHRydWU7XG4gIF9kZWZhdWx0TG9naW5Vcmw6IHN0cmluZyB8IHVuZGVmaW5lZCA9IHVuZGVmaW5lZDtcblxuICAvKipcbiAgICpcbiAgICovXG4gIHJlYWRDb21tYW5kKCk6IENsaUNvbW1hbmQge1xuICAgIHJldHVybiBuZXcgQ29tbWFuZCgpXG4gICAgICAub3B0aW9uKCctdSwgLS11c2VybmFtZSBbdXNlcm5hbWVdJywgJ1NhbGVzZm9yY2UgdXNlcm5hbWUnKVxuICAgICAgLm9wdGlvbihcbiAgICAgICAgJy1wLCAtLXBhc3N3b3JkIFtwYXNzd29yZF0nLFxuICAgICAgICAnU2FsZXNmb3JjZSBwYXNzd29yZCAoYW5kIHNlY3VyaXR5IHRva2VuLCBpZiBhdmFpbGFibGUpJyxcbiAgICAgIClcbiAgICAgIC5vcHRpb24oXG4gICAgICAgICctYywgLS1jb25uZWN0aW9uIFtjb25uZWN0aW9uXScsXG4gICAgICAgICdDb25uZWN0aW9uIG5hbWUgc3RvcmVkIGluIGNvbm5lY3Rpb24gcmVnaXN0cnknLFxuICAgICAgKVxuICAgICAgLm9wdGlvbignLWwsIC0tbG9naW5VcmwgW2xvZ2luVXJsXScsICdTYWxlc2ZvcmNlIGxvZ2luIHVybCcpXG4gICAgICAub3B0aW9uKCctLXNhbmRib3gnLCAnTG9naW4gdG8gU2FsZXNmb3JjZSBzYW5kYm94JylcbiAgICAgIC5vcHRpb24oJy1lLCAtLWV2YWxTY3JpcHQgW2V2YWxTY3JpcHRdJywgJ1NjcmlwdCB0byBldmFsdWF0ZScpXG4gICAgICAudmVyc2lvbih2ZXJzaW9uKVxuICAgICAgLnBhcnNlKHByb2Nlc3MuYXJndik7XG4gIH1cblxuICBhc3luYyBzdGFydCgpIHtcbiAgICBjb25zdCBwcm9ncmFtID0gdGhpcy5yZWFkQ29tbWFuZCgpO1xuICAgIHRoaXMuX291dHB1dEVuYWJsZWQgPSAhcHJvZ3JhbS5ldmFsU2NyaXB0O1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCB0aGlzLmNvbm5lY3QocHJvZ3JhbSk7XG4gICAgICBpZiAocHJvZ3JhbS5ldmFsU2NyaXB0KSB7XG4gICAgICAgIHRoaXMuX3JlcGwuc3RhcnQoe1xuICAgICAgICAgIGludGVyYWN0aXZlOiBmYWxzZSxcbiAgICAgICAgICBldmFsU2NyaXB0OiBwcm9ncmFtLmV2YWxTY3JpcHQsXG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5fcmVwbC5zdGFydCgpO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xuICAgICAgcHJvY2Vzcy5leGl0KCk7XG4gICAgfVxuICB9XG5cbiAgZ2V0Q3VycmVudENvbm5lY3Rpb24oKSB7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm47XG4gIH1cblxuICBwcmludCguLi5hcmdzOiBhbnlbXSkge1xuICAgIGlmICh0aGlzLl9vdXRwdXRFbmFibGVkKSB7XG4gICAgICBjb25zb2xlLmxvZyguLi5hcmdzKTtcbiAgICB9XG4gIH1cblxuICBzYXZlQ3VycmVudENvbm5lY3Rpb24oKSB7XG4gICAgaWYgKHRoaXMuX2Nvbm5OYW1lKSB7XG4gICAgICBjb25zdCBjb25uID0gdGhpcy5fY29ubjtcbiAgICAgIGNvbnN0IGNvbm5OYW1lID0gdGhpcy5fY29ubk5hbWU7XG4gICAgICBjb25zdCBjb25uQ29uZmlnID0ge1xuICAgICAgICBvYXV0aDI6IGNvbm4ub2F1dGgyXG4gICAgICAgICAgPyB7XG4gICAgICAgICAgICAgIGNsaWVudElkOiBjb25uLm9hdXRoMi5jbGllbnRJZCB8fCB1bmRlZmluZWQsXG4gICAgICAgICAgICAgIGNsaWVudFNlY3JldDogY29ubi5vYXV0aDIuY2xpZW50U2VjcmV0IHx8IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgcmVkaXJlY3RVcmk6IGNvbm4ub2F1dGgyLnJlZGlyZWN0VXJpIHx8IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgbG9naW5Vcmw6IGNvbm4ub2F1dGgyLmxvZ2luVXJsIHx8IHVuZGVmaW5lZCxcbiAgICAgICAgICAgIH1cbiAgICAgICAgICA6IHVuZGVmaW5lZCxcbiAgICAgICAgYWNjZXNzVG9rZW46IGNvbm4uYWNjZXNzVG9rZW4gfHwgdW5kZWZpbmVkLFxuICAgICAgICBpbnN0YW5jZVVybDogY29ubi5pbnN0YW5jZVVybCB8fCB1bmRlZmluZWQsXG4gICAgICAgIHJlZnJlc2hUb2tlbjogY29ubi5yZWZyZXNoVG9rZW4gfHwgdW5kZWZpbmVkLFxuICAgICAgfTtcbiAgICAgIHJlZ2lzdHJ5LnNhdmVDb25uZWN0aW9uQ29uZmlnKGNvbm5OYW1lLCBjb25uQ29uZmlnKTtcbiAgICB9XG4gIH1cblxuICBzZXRMb2dpblNlcnZlcihsb2dpblNlcnZlcjogT3B0aW9uYWw8c3RyaW5nPikge1xuICAgIGlmICghbG9naW5TZXJ2ZXIpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKGxvZ2luU2VydmVyID09PSAncHJvZHVjdGlvbicpIHtcbiAgICAgIHRoaXMuX2RlZmF1bHRMb2dpblVybCA9ICdodHRwczovL2xvZ2luLnNhbGVzZm9yY2UuY29tJztcbiAgICB9IGVsc2UgaWYgKGxvZ2luU2VydmVyID09PSAnc2FuZGJveCcpIHtcbiAgICAgIHRoaXMuX2RlZmF1bHRMb2dpblVybCA9ICdodHRwczovL3Rlc3Quc2FsZXNmb3JjZS5jb20nO1xuICAgIH0gZWxzZSBpZiAobG9naW5TZXJ2ZXIuaW5kZXhPZignaHR0cHM6Ly8nKSAhPT0gMCkge1xuICAgICAgdGhpcy5fZGVmYXVsdExvZ2luVXJsID0gJ2h0dHBzOi8vJyArIGxvZ2luU2VydmVyO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLl9kZWZhdWx0TG9naW5VcmwgPSBsb2dpblNlcnZlcjtcbiAgICB9XG4gICAgdGhpcy5wcmludChgVXNpbmcgXCIke3RoaXMuX2RlZmF1bHRMb2dpblVybH1cIiBhcyBkZWZhdWx0IGxvZ2luIFVSTC5gKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgY29ubmVjdChvcHRpb25zOiB7XG4gICAgdXNlcm5hbWU/OiBzdHJpbmc7XG4gICAgcGFzc3dvcmQ/OiBzdHJpbmc7XG4gICAgY29ubmVjdGlvbj86IHN0cmluZztcbiAgICBsb2dpblVybD86IHN0cmluZztcbiAgICBzYW5kYm94PzogYm9vbGVhbjtcbiAgfSkge1xuICAgIGNvbnN0IGxvZ2luU2VydmVyID0gb3B0aW9ucy5sb2dpblVybFxuICAgICAgPyBvcHRpb25zLmxvZ2luVXJsXG4gICAgICA6IG9wdGlvbnMuc2FuZGJveFxuICAgICAgPyAnc2FuZGJveCdcbiAgICAgIDogbnVsbDtcbiAgICB0aGlzLnNldExvZ2luU2VydmVyKGxvZ2luU2VydmVyKTtcbiAgICB0aGlzLl9jb25uTmFtZSA9IG9wdGlvbnMuY29ubmVjdGlvbjtcbiAgICBsZXQgY29ubkNvbmZpZyA9IGF3YWl0IHJlZ2lzdHJ5LmdldENvbm5lY3Rpb25Db25maWcob3B0aW9ucy5jb25uZWN0aW9uKTtcbiAgICBsZXQgdXNlcm5hbWUgPSBvcHRpb25zLnVzZXJuYW1lO1xuICAgIGlmICghY29ubkNvbmZpZykge1xuICAgICAgY29ubkNvbmZpZyA9IHt9O1xuICAgICAgaWYgKHRoaXMuX2RlZmF1bHRMb2dpblVybCkge1xuICAgICAgICBjb25uQ29uZmlnLmxvZ2luVXJsID0gdGhpcy5fZGVmYXVsdExvZ2luVXJsO1xuICAgICAgfVxuICAgICAgdXNlcm5hbWUgPSB1c2VybmFtZSB8fCBvcHRpb25zLmNvbm5lY3Rpb247XG4gICAgfVxuICAgIHRoaXMuX2Nvbm4gPSBuZXcgQ29ubmVjdGlvbihjb25uQ29uZmlnKTtcbiAgICBjb25zdCBwYXNzd29yZCA9IG9wdGlvbnMucGFzc3dvcmQ7XG4gICAgaWYgKHVzZXJuYW1lKSB7XG4gICAgICBhd2FpdCB0aGlzLnN0YXJ0UGFzc3dvcmRBdXRoKHVzZXJuYW1lLCBwYXNzd29yZCk7XG4gICAgICB0aGlzLnNhdmVDdXJyZW50Q29ubmVjdGlvbigpO1xuICAgIH0gZWxzZSB7XG4gICAgICBpZiAodGhpcy5fY29ubk5hbWUgJiYgdGhpcy5fY29ubi5hY2Nlc3NUb2tlbikge1xuICAgICAgICB0aGlzLl9jb25uLm9uKCdyZWZyZXNoJywgKCkgPT4ge1xuICAgICAgICAgIHRoaXMucHJpbnQoJ1JlZnJlc2hpbmcgYWNjZXNzIHRva2VuIC4uLiAnKTtcbiAgICAgICAgICB0aGlzLnNhdmVDdXJyZW50Q29ubmVjdGlvbigpO1xuICAgICAgICB9KTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCBpZGVudGl0eSA9IGF3YWl0IHRoaXMuX2Nvbm4uaWRlbnRpdHkoKTtcbiAgICAgICAgICB0aGlzLnByaW50KGBMb2dnZWQgaW4gYXMgOiAke2lkZW50aXR5LnVzZXJuYW1lfWApO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICBpZiAoZXJyIGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICAgICAgICAgIHRoaXMucHJpbnQoZXJyLm1lc3NhZ2UpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAodGhpcy5fY29ubi5vYXV0aDIpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignUGxlYXNlIHJlLWF1dGhvcml6ZSBjb25uZWN0aW9uLicpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBhd2FpdCB0aGlzLnN0YXJ0UGFzc3dvcmRBdXRoKHRoaXMuX2Nvbm5OYW1lKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIGFzeW5jIHN0YXJ0UGFzc3dvcmRBdXRoKHVzZXJuYW1lOiBzdHJpbmcsIHBhc3N3b3JkPzogc3RyaW5nKSB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHRoaXMubG9naW5CeVBhc3N3b3JkKHVzZXJuYW1lLCBwYXNzd29yZCwgMik7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBpZiAoZXJyIGluc3RhbmNlb2YgRXJyb3IgJiYgZXJyLm1lc3NhZ2UgPT09ICdjYW5jZWxlZCcpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcignUGFzc3dvcmQgYXV0aGVudGljYXRpb24gY2FuY2VsZWQ6IE5vdCBsb2dnZWQgaW4nKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRocm93IGVycjtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIGFzeW5jIGxvZ2luQnlQYXNzd29yZChcbiAgICB1c2VybmFtZTogc3RyaW5nLFxuICAgIHBhc3N3b3JkOiBzdHJpbmcgfCB1bmRlZmluZWQsXG4gICAgcmV0cnlDb3VudDogbnVtYmVyLFxuICApOiBQcm9taXNlPHsgaWQ6IHN0cmluZyB9PiB7XG4gICAgaWYgKHBhc3N3b3JkID09PSAnJykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdjYW5jZWxlZCcpO1xuICAgIH1cbiAgICBpZiAocGFzc3dvcmQgPT0gbnVsbCkge1xuICAgICAgY29uc3QgcGFzcyA9IGF3YWl0IHRoaXMucHJvbXB0UGFzc3dvcmQoJ1Bhc3N3b3JkOiAnKTtcbiAgICAgIHJldHVybiB0aGlzLmxvZ2luQnlQYXNzd29yZCh1c2VybmFtZSwgcGFzcywgcmV0cnlDb3VudCk7XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB0aGlzLl9jb25uLmxvZ2luKHVzZXJuYW1lLCBwYXNzd29yZCk7XG4gICAgICB0aGlzLnByaW50KGBMb2dnZWQgaW4gYXMgOiAke3VzZXJuYW1lfWApO1xuICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGVyci5tZXNzYWdlKTtcbiAgICAgIH1cbiAgICAgIGlmIChyZXRyeUNvdW50ID4gMCkge1xuICAgICAgICByZXR1cm4gdGhpcy5sb2dpbkJ5UGFzc3dvcmQodXNlcm5hbWUsIHVuZGVmaW5lZCwgcmV0cnlDb3VudCAtIDEpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdjYW5jZWxlZCcpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgZGlzY29ubmVjdChjb25uTmFtZT86IHN0cmluZykge1xuICAgIGNvbnN0IG5hbWUgPSBjb25uTmFtZSB8fCB0aGlzLl9jb25uTmFtZTtcbiAgICBpZiAobmFtZSAmJiByZWdpc3RyeS5nZXRDb25uZWN0aW9uQ29uZmlnKG5hbWUpKSB7XG4gICAgICByZWdpc3RyeS5yZW1vdmVDb25uZWN0aW9uQ29uZmlnKG5hbWUpO1xuICAgICAgdGhpcy5wcmludChgRGlzY29ubmVjdCBjb25uZWN0aW9uICcke25hbWV9J2ApO1xuICAgIH1cbiAgICB0aGlzLl9jb25uTmFtZSA9IHVuZGVmaW5lZDtcbiAgICB0aGlzLl9jb25uID0gbmV3IENvbm5lY3Rpb24oKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgYXV0aG9yaXplKGNsaWVudE5hbWU6IHN0cmluZykge1xuICAgIGNvbnN0IG5hbWUgPSBjbGllbnROYW1lIHx8ICdkZWZhdWx0JztcbiAgICB2YXIgb2F1dGgyQ29uZmlnID0gYXdhaXQgcmVnaXN0cnkuZ2V0Q2xpZW50Q29uZmlnKG5hbWUpO1xuICAgIGlmICghb2F1dGgyQ29uZmlnIHx8ICFvYXV0aDJDb25maWcuY2xpZW50SWQpIHtcbiAgICAgIGlmIChuYW1lID09PSAnZGVmYXVsdCcgfHwgbmFtZSA9PT0gJ3NhbmRib3gnKSB7XG4gICAgICAgIHRoaXMucHJpbnQoXG4gICAgICAgICAgJ05vIGNsaWVudCBpbmZvcm1hdGlvbiByZWdpc3RlcmVkLiBEb3dubG9hZGluZyBKU2ZvcmNlIGRlZmF1bHQgY2xpZW50IGluZm9ybWF0aW9uLi4uJyxcbiAgICAgICAgKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuZG93bmxvYWREZWZhdWx0Q2xpZW50SW5mbyhuYW1lKTtcbiAgICAgIH1cbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgYE5vIE9BdXRoMiBjbGllbnQgaW5mb3JtYXRpb24gcmVnaXN0ZXJlZCA6ICcke25hbWV9Jy4gUGxlYXNlIHJlZ2lzdGVyIGNsaWVudCBpbmZvIGZpcnN0LmAsXG4gICAgICApO1xuICAgIH1cbiAgICBjb25zdCBvYXV0aDIgPSBuZXcgT0F1dGgyKG9hdXRoMkNvbmZpZyk7XG4gICAgY29uc3QgdmVyaWZpZXIgPSBiYXNlNjR1cmwuZW5jb2RlKGNyeXB0by5yYW5kb21CeXRlcygzMikpO1xuICAgIGNvbnN0IGNoYWxsZW5nZSA9IGJhc2U2NHVybC5lbmNvZGUoXG4gICAgICBjcnlwdG8uY3JlYXRlSGFzaCgnc2hhMjU2JykudXBkYXRlKHZlcmlmaWVyKS5kaWdlc3QoKSxcbiAgICApO1xuICAgIGNvbnN0IHN0YXRlID0gYmFzZTY0dXJsLmVuY29kZShjcnlwdG8ucmFuZG9tQnl0ZXMoMzIpKTtcbiAgICBjb25zdCBhdXRoelVybCA9IG9hdXRoMi5nZXRBdXRob3JpemF0aW9uVXJsKHtcbiAgICAgIGNvZGVfY2hhbGxlbmdlOiBjaGFsbGVuZ2UsXG4gICAgICBzdGF0ZSxcbiAgICB9KTtcbiAgICB0aGlzLnByaW50KCdPcGVuaW5nIGF1dGhvcml6YXRpb24gcGFnZSBpbiBicm93c2VyLi4uJyk7XG4gICAgdGhpcy5wcmludChgVVJMOiAke2F1dGh6VXJsfWApO1xuICAgIHRoaXMub3BlblVybChhdXRoelVybCk7XG4gICAgY29uc3QgcGFyYW1zID0gYXdhaXQgdGhpcy53YWl0Q2FsbGJhY2sob2F1dGgyQ29uZmlnLnJlZGlyZWN0VXJpLCBzdGF0ZSk7XG4gICAgaWYgKCFwYXJhbXMuY29kZSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdObyBhdXRob3JpemF0aW9uIGNvZGUgcmV0dXJuZWQuJyk7XG4gICAgfVxuICAgIGlmIChwYXJhbXMuc3RhdGUgIT09IHN0YXRlKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ludmFsaWQgc3RhdGUgcGFyYW1ldGVyIHJldHVybmVkLicpO1xuICAgIH1cbiAgICB0aGlzLl9jb25uID0gbmV3IENvbm5lY3Rpb24oeyBvYXV0aDIgfSk7XG4gICAgdGhpcy5wcmludChcbiAgICAgICdSZWNlaXZlZCBhdXRob3JpemF0aW9uIGNvZGUuIFBsZWFzZSBjbG9zZSB0aGUgb3BlbmVkIGJyb3dzZXIgd2luZG93LicsXG4gICAgKTtcbiAgICBhd2FpdCB0aGlzLl9jb25uLmF1dGhvcml6ZShwYXJhbXMuY29kZSwgeyBjb2RlX3ZlcmlmaWVyOiB2ZXJpZmllciB9KTtcbiAgICB0aGlzLnByaW50KCdBdXRob3JpemVkLiBGZXRjaGluZyB1c2VyIGluZm8uLi4nKTtcbiAgICBjb25zdCBpZGVudGl0eSA9IGF3YWl0IHRoaXMuX2Nvbm4uaWRlbnRpdHkoKTtcbiAgICB0aGlzLnByaW50KGBMb2dnZWQgaW4gYXMgOiAke2lkZW50aXR5LnVzZXJuYW1lfWApO1xuICAgIHRoaXMuX2Nvbm5OYW1lID0gaWRlbnRpdHkudXNlcm5hbWU7XG4gICAgdGhpcy5zYXZlQ3VycmVudENvbm5lY3Rpb24oKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgZG93bmxvYWREZWZhdWx0Q2xpZW50SW5mbyhjbGllbnROYW1lOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBjb25maWdVcmwgPSAnaHR0cHM6Ly9qc2ZvcmNlLmdpdGh1Yi5pby9jbGllbnQtY29uZmlnL2RlZmF1bHQuanNvbic7XG4gICAgY29uc3QgcmVzOiB7IGJvZHk6IHN0cmluZyB9ID0gYXdhaXQgbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgcmVxdWVzdCh7IG1ldGhvZDogJ0dFVCcsIHVybDogY29uZmlnVXJsIH0pXG4gICAgICAgIC5vbignY29tcGxldGUnLCByZXNvbHZlKVxuICAgICAgICAub24oJ2Vycm9yJywgcmVqZWN0KTtcbiAgICB9KTtcbiAgICBjb25zdCBjbGllbnRDb25maWcgPSBKU09OLnBhcnNlKHJlcy5ib2R5KTtcbiAgICBpZiAoY2xpZW50TmFtZSA9PT0gJ3NhbmRib3gnKSB7XG4gICAgICBjbGllbnRDb25maWcubG9naW5VcmwgPSAnaHR0cHM6Ly90ZXN0LnNhbGVzZm9yY2UuY29tJztcbiAgICB9XG4gICAgYXdhaXQgcmVnaXN0cnkucmVnaXN0ZXJDbGllbnRDb25maWcoY2xpZW50TmFtZSwgY2xpZW50Q29uZmlnKTtcbiAgICB0aGlzLnByaW50KCdDbGllbnQgaW5mb3JtYXRpb24gZG93bmxvYWRlZCBzdWNjZXNzZnVsbHkuJyk7XG4gICAgcmV0dXJuIHRoaXMuYXV0aG9yaXplKGNsaWVudE5hbWUpO1xuICB9XG5cbiAgYXN5bmMgd2FpdENhbGxiYWNrKFxuICAgIHNlcnZlclVybDogc3RyaW5nIHwgdW5kZWZpbmVkLFxuICAgIHN0YXRlOiBzdHJpbmcsXG4gICk6IFByb21pc2U8eyBjb2RlOiBzdHJpbmc7IHN0YXRlOiBzdHJpbmcgfT4ge1xuICAgIGlmIChzZXJ2ZXJVcmwgJiYgc2VydmVyVXJsLmluZGV4T2YoJ2h0dHA6Ly9sb2NhbGhvc3Q6JykgPT09IDApIHtcbiAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgIGNvbnN0IHNlcnZlciA9IGh0dHAuY3JlYXRlU2VydmVyKChyZXEsIHJlcykgPT4ge1xuICAgICAgICAgIGlmICghcmVxLnVybCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCBxcGFyYW1zID0gdXJsLnBhcnNlKHJlcS51cmwsIHRydWUpLnF1ZXJ5O1xuICAgICAgICAgIHJlcy53cml0ZUhlYWQoMjAwLCB7ICdDb250ZW50LVR5cGUnOiAndGV4dC9odG1sJyB9KTtcbiAgICAgICAgICByZXMud3JpdGUoXG4gICAgICAgICAgICAnPGh0bWw+PHNjcmlwdD5sb2NhdGlvbi5ocmVmPVwiYWJvdXQ6YmxhbmtcIjs8L3NjcmlwdD48L2h0bWw+JyxcbiAgICAgICAgICApO1xuICAgICAgICAgIHJlcy5lbmQoKTtcbiAgICAgICAgICBpZiAocXBhcmFtcy5lcnJvcikge1xuICAgICAgICAgICAgcmVqZWN0KG5ldyBFcnJvcihxcGFyYW1zLmVycm9yIGFzIHN0cmluZykpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXNvbHZlKHFwYXJhbXMgYXMgeyBjb2RlOiBzdHJpbmc7IHN0YXRlOiBzdHJpbmcgfSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHNlcnZlci5jbG9zZSgpO1xuICAgICAgICAgIHJlcS5jb25uZWN0aW9uLmVuZCgpO1xuICAgICAgICAgIHJlcS5jb25uZWN0aW9uLmRlc3Ryb3koKTtcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IHBvcnQgPSBOdW1iZXIodXJsLnBhcnNlKHNlcnZlclVybCkucG9ydCk7XG4gICAgICAgIHNlcnZlci5saXN0ZW4ocG9ydCwgJ2xvY2FsaG9zdCcpO1xuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IGNvZGUgPSBhd2FpdCB0aGlzLnByb21wdE1lc3NhZ2UoXG4gICAgICAgICdDb3B5ICYgcGFzdGUgYXV0aHogY29kZSBwYXNzZWQgaW4gcmVkaXJlY3RlZCBVUkw6ICcsXG4gICAgICApO1xuICAgICAgcmV0dXJuIHsgY29kZTogZGVjb2RlVVJJQ29tcG9uZW50KGNvZGUpLCBzdGF0ZSB9O1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgcmVnaXN0ZXIoY2xpZW50TmFtZTogc3RyaW5nIHwgdW5kZWZpbmVkLCBjbGllbnRDb25maWc6IENsaWVudENvbmZpZykge1xuICAgIGNvbnN0IG5hbWUgPSBjbGllbnROYW1lIHx8ICdkZWZhdWx0JztcbiAgICBjb25zdCBwcm9tcHRzID0ge1xuICAgICAgY2xpZW50SWQ6ICdJbnB1dCBjbGllbnQgSUQgOiAnLFxuICAgICAgY2xpZW50U2VjcmV0OiAnSW5wdXQgY2xpZW50IHNlY3JldCAob3B0aW9uYWwpIDogJyxcbiAgICAgIHJlZGlyZWN0VXJpOiAnSW5wdXQgcmVkaXJlY3QgVVJJIDogJyxcbiAgICAgIGxvZ2luVXJsOiAnSW5wdXQgbG9naW4gVVJMIChkZWZhdWx0IGlzIGh0dHBzOi8vbG9naW4uc2FsZXNmb3JjZS5jb20pIDogJyxcbiAgICB9O1xuICAgIGNvbnN0IHJlZ2lzdGVyZWQgPSBhd2FpdCByZWdpc3RyeS5nZXRDbGllbnRDb25maWcobmFtZSk7XG4gICAgaWYgKHJlZ2lzdGVyZWQpIHtcbiAgICAgIGNvbnN0IG1zZyA9IGBDbGllbnQgJyR7bmFtZX0nIGlzIGFscmVhZHkgcmVnaXN0ZXJlZC4gQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIG92ZXJyaWRlID8gW3lOXSA6IGA7XG4gICAgICBjb25zdCBvayA9IGF3YWl0IHRoaXMucHJvbXB0Q29uZmlybShtc2cpO1xuICAgICAgaWYgKCFvaykge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1JlZ2lzdHJhdGlvbiBjYW5jZWxlZC4nKTtcbiAgICAgIH1cbiAgICB9XG4gICAgY2xpZW50Q29uZmlnID0gYXdhaXQgT2JqZWN0LmtleXMocHJvbXB0cykucmVkdWNlKGFzeW5jIChwcm9taXNlLCBuYW1lKSA9PiB7XG4gICAgICBjb25zdCBjY29uZmlnID0gYXdhaXQgcHJvbWlzZTtcbiAgICAgIGNvbnN0IHByb21wdE5hbWUgPSBuYW1lIGFzIGtleW9mIHR5cGVvZiBwcm9tcHRzO1xuICAgICAgY29uc3QgbWVzc2FnZSA9IHByb21wdHNbcHJvbXB0TmFtZV07XG4gICAgICBpZiAoIWNjb25maWdbcHJvbXB0TmFtZV0pIHtcbiAgICAgICAgY29uc3QgdmFsdWUgPSBhd2FpdCB0aGlzLnByb21wdE1lc3NhZ2UobWVzc2FnZSk7XG4gICAgICAgIGlmICh2YWx1ZSkge1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAuLi5jY29uZmlnLFxuICAgICAgICAgICAgW3Byb21wdE5hbWVdOiB2YWx1ZSxcbiAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gY2NvbmZpZztcbiAgICB9LCBQcm9taXNlLnJlc29sdmUoY2xpZW50Q29uZmlnKSk7XG4gICAgYXdhaXQgcmVnaXN0cnkucmVnaXN0ZXJDbGllbnRDb25maWcobmFtZSwgY2xpZW50Q29uZmlnKTtcbiAgICB0aGlzLnByaW50KCdDbGllbnQgcmVnaXN0ZXJlZCBzdWNjZXNzZnVsbHkuJyk7XG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIGFzeW5jIGxpc3RDb25uZWN0aW9ucygpIHtcbiAgICBjb25zdCBuYW1lcyA9IGF3YWl0IHJlZ2lzdHJ5LmdldENvbm5lY3Rpb25OYW1lcygpO1xuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbmFtZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgIHZhciBuYW1lID0gbmFtZXNbaV07XG4gICAgICB0aGlzLnByaW50KChuYW1lID09PSB0aGlzLl9jb25uTmFtZSA/ICcqICcgOiAnICAnKSArIG5hbWUpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgZ2V0Q29ubmVjdGlvbk5hbWVzKCkge1xuICAgIHJldHVybiByZWdpc3RyeS5nZXRDb25uZWN0aW9uTmFtZXMoKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgZ2V0Q2xpZW50TmFtZXMoKSB7XG4gICAgcmV0dXJuIHJlZ2lzdHJ5LmdldENsaWVudE5hbWVzKCk7XG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIGFzeW5jIHByb21wdCh0eXBlOiBzdHJpbmcsIG1lc3NhZ2U6IHN0cmluZykge1xuICAgIHRoaXMuX3JlcGwucGF1c2UoKTtcbiAgICBjb25zdCBhbnN3ZXI6IHsgdmFsdWU6IHN0cmluZyB9ID0gYXdhaXQgaW5xdWlyZXIucHJvbXB0KFtcbiAgICAgIHtcbiAgICAgICAgdHlwZSxcbiAgICAgICAgbmFtZTogJ3ZhbHVlJyxcbiAgICAgICAgbWVzc2FnZSxcbiAgICAgIH0sXG4gICAgXSk7XG4gICAgdGhpcy5fcmVwbC5yZXN1bWUoKTtcbiAgICByZXR1cm4gYW5zd2VyLnZhbHVlO1xuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBhc3luYyBwcm9tcHRNZXNzYWdlKG1lc3NhZ2U6IHN0cmluZykge1xuICAgIHJldHVybiB0aGlzLnByb21wdCgnaW5wdXQnLCBtZXNzYWdlKTtcbiAgfVxuXG4gIGFzeW5jIHByb21wdFBhc3N3b3JkKG1lc3NhZ2U6IHN0cmluZykge1xuICAgIHJldHVybiB0aGlzLnByb21wdCgncGFzc3dvcmQnLCBtZXNzYWdlKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgcHJvbXB0Q29uZmlybShtZXNzYWdlOiBzdHJpbmcpIHtcbiAgICByZXR1cm4gdGhpcy5wcm9tcHQoJ2NvbmZpcm0nLCBtZXNzYWdlKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgb3BlblVybCh1cmw6IHN0cmluZykge1xuICAgIG9wZW5VcmwodXJsKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgb3BlblVybFVzaW5nU2Vzc2lvbih1cmw/OiBzdHJpbmcpIHtcbiAgICBsZXQgZnJvbnRkb29yVXJsID0gYCR7dGhpcy5fY29ubi5pbnN0YW5jZVVybH0vc2VjdXIvZnJvbnRkb29yLmpzcD9zaWQ9JHt0aGlzLl9jb25uLmFjY2Vzc1Rva2VufWA7XG4gICAgaWYgKHVybCkge1xuICAgICAgZnJvbnRkb29yVXJsICs9ICcmcmV0VVJMPScgKyBlbmNvZGVVUklDb21wb25lbnQodXJsKTtcbiAgICB9XG4gICAgdGhpcy5vcGVuVXJsKGZyb250ZG9vclVybCk7XG4gIH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5jb25zdCBjbGkgPSBuZXcgQ2xpKCk7XG5cbmV4cG9ydCBkZWZhdWx0IGNsaTtcbiJdfQ==