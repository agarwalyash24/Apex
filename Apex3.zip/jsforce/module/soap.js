import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import "core-js/modules/es.array.iterator";
import "core-js/modules/es.promise";
import "core-js/modules/es.string.replace";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _reduceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/reduce";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context3; _forEachInstanceProperty(_context3 = ownKeys(Object(source), true)).call(_context3, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context4; _forEachInstanceProperty(_context4 = ownKeys(Object(source))).call(_context4, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 * @file Manages method call to SOAP endpoint
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import HttpApi from './http-api';
import { isMapObject, isObject } from './util/function';
/**
 *
 */

function getPropsSchema(schema, schemaDict) {
  if (schema.extends && schemaDict[schema.extends]) {
    const extendSchema = schemaDict[schema.extends];
    return _objectSpread(_objectSpread({}, getPropsSchema(extendSchema, schemaDict)), schema.props);
  }

  return schema.props;
}

function isNillValue(value) {
  return value == null || isMapObject(value) && isMapObject(value.$) && value.$['xsi:nil'] === 'true';
}
/**
 *
 */


export function castTypeUsingSchema(value, schema, schemaDict = {}) {
  if (_Array$isArray(schema)) {
    var _context;

    const nillable = schema.length === 2 && schema[0] === '?';
    const schema_ = nillable ? schema[1] : schema[0];

    if (value == null) {
      return nillable ? null : [];
    }

    return _mapInstanceProperty(_context = _Array$isArray(value) ? value : [value]).call(_context, v => castTypeUsingSchema(v, schema_, schemaDict));
  } else if (isMapObject(schema)) {
    var _context2;

    // if schema is Schema Definition, not schema element
    if ('type' in schema && 'props' in schema && isMapObject(schema.props)) {
      const props = getPropsSchema(schema, schemaDict);
      return castTypeUsingSchema(value, props, schemaDict);
    }

    const nillable = ('?' in schema);
    const schema_ = '?' in schema ? schema['?'] : schema;

    if (nillable && isNillValue(value)) {
      return null;
    }

    const obj = isMapObject(value) ? value : {};
    return _reduceInstanceProperty(_context2 = _Object$keys(schema_)).call(_context2, (o, k) => {
      const s = schema_[k];
      const v = obj[k];
      const nillable = _Array$isArray(s) && s.length === 2 && s[0] === '?' || isMapObject(s) && '?' in s || typeof s === 'string' && s[0] === '?';

      if (typeof v === 'undefined' && nillable) {
        return o;
      }

      return _objectSpread(_objectSpread({}, o), {}, {
        [k]: castTypeUsingSchema(v, s, schemaDict)
      });
    }, obj);
  } else {
    const nillable = typeof schema === 'string' && schema[0] === '?';
    const type = typeof schema === 'string' ? nillable ? schema.substring(1) : schema : 'any';

    switch (type) {
      case 'string':
        return isNillValue(value) ? nillable ? null : '' : String(value);

      case 'number':
        return isNillValue(value) ? nillable ? null : 0 : Number(value);

      case 'boolean':
        return isNillValue(value) ? nillable ? null : false : value === 'true';

      case 'null':
        return null;

      default:
        {
          if (schemaDict[type]) {
            const cvalue = castTypeUsingSchema(value, schemaDict[type], schemaDict);
            const isEmpty = isMapObject(cvalue) && _Object$keys(cvalue).length === 0;
            return isEmpty && nillable ? null : cvalue;
          }

          return value;
        }
    }
  }
}
/**
 * @private
 */

function lookupValue(obj, propRegExps) {
  const regexp = propRegExps.shift();

  if (!regexp) {
    return obj;
  }

  if (isMapObject(obj)) {
    for (const prop of _Object$keys(obj)) {
      if (regexp.test(prop)) {
        return lookupValue(obj[prop], propRegExps);
      }
    }

    return null;
  }
}
/**
 * @private
 */


function toXML(name, value) {
  if (isObject(name)) {
    value = name;
    name = null;
  }

  if (_Array$isArray(value)) {
    return _mapInstanceProperty(value).call(value, v => toXML(name, v)).join('');
  } else {
    const attrs = [];
    const elems = [];

    if (isMapObject(value)) {
      for (const k of _Object$keys(value)) {
        const v = value[k];

        if (k[0] === '@') {
          const kk = k.substring(1);
          attrs.push(kk + '="' + v + '"');
        } else {
          elems.push(toXML(k, v));
        }
      }

      value = elems.join('');
    } else {
      value = String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
    }

    const startTag = name ? '<' + name + (attrs.length > 0 ? ' ' + attrs.join(' ') : '') + '>' : '';
    const endTag = name ? '</' + name + '>' : '';
    return startTag + value + endTag;
  }
}
/**
 *
 */


/**
 * Class for SOAP endpoint of Salesforce
 *
 * @protected
 * @class
 * @constructor
 * @param {Connection} conn - Connection instance
 * @param {Object} options - SOAP endpoint setting options
 * @param {String} options.endpointUrl - SOAP endpoint URL
 * @param {String} [options.xmlns] - XML namespace for method call (default is "urn:partner.soap.sforce.com")
 */
export class SOAP extends HttpApi {
  constructor(conn, options) {
    super(conn, options);

    _defineProperty(this, "_endpointUrl", void 0);

    _defineProperty(this, "_xmlns", void 0);

    this._endpointUrl = options.endpointUrl;
    this._xmlns = options.xmlns || 'urn:partner.soap.sforce.com';
  }
  /**
   * Invoke SOAP call using method and arguments
   */


  async invoke(method, args, schema, schemaDict) {
    const res = await this.request({
      method: 'POST',
      url: this._endpointUrl,
      headers: {
        'Content-Type': 'text/xml',
        SOAPAction: '""'
      },
      _message: {
        [method]: args
      }
    });
    return schema ? castTypeUsingSchema(res, schema, schemaDict) : res;
  }
  /** @override */


  beforeSend(request) {
    request.body = this._createEnvelope(request._message);
  }
  /** @override **/


  isSessionExpired(response) {
    return response.statusCode === 500 && /<faultcode>[a-zA-Z]+:INVALID_SESSION_ID<\/faultcode>/.test(response.body);
  }
  /** @override **/


  parseError(body) {
    const error = lookupValue(body, [/:Envelope$/, /:Body$/, /:Fault$/]);
    return {
      errorCode: error.faultcode,
      message: error.faultstring
    };
  }
  /** @override **/


  async getResponseBody(response) {
    const body = await super.getResponseBody(response);
    return lookupValue(body, [/:Envelope$/, /:Body$/, /.+/]);
  }
  /**
   * @private
   */


  _createEnvelope(message) {
    const header = {};
    const conn = this._conn;

    if (conn.accessToken) {
      header.SessionHeader = {
        sessionId: conn.accessToken
      };
    }

    if (conn._callOptions) {
      header.CallOptions = conn._callOptions;
    }

    return ['<?xml version="1.0" encoding="UTF-8"?>', '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"', ' xmlns:xsd="http://www.w3.org/2001/XMLSchema"', ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">', '<soapenv:Header xmlns="' + this._xmlns + '">', toXML(header), '</soapenv:Header>', '<soapenv:Body xmlns="' + this._xmlns + '">', toXML(message), '</soapenv:Body>', '</soapenv:Envelope>'].join('');
  }

}
export default SOAP;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9zb2FwLnRzIl0sIm5hbWVzIjpbIkh0dHBBcGkiLCJpc01hcE9iamVjdCIsImlzT2JqZWN0IiwiZ2V0UHJvcHNTY2hlbWEiLCJzY2hlbWEiLCJzY2hlbWFEaWN0IiwiZXh0ZW5kcyIsImV4dGVuZFNjaGVtYSIsInByb3BzIiwiaXNOaWxsVmFsdWUiLCJ2YWx1ZSIsIiQiLCJjYXN0VHlwZVVzaW5nU2NoZW1hIiwibmlsbGFibGUiLCJsZW5ndGgiLCJzY2hlbWFfIiwidiIsIm9iaiIsIm8iLCJrIiwicyIsInR5cGUiLCJzdWJzdHJpbmciLCJTdHJpbmciLCJOdW1iZXIiLCJjdmFsdWUiLCJpc0VtcHR5IiwibG9va3VwVmFsdWUiLCJwcm9wUmVnRXhwcyIsInJlZ2V4cCIsInNoaWZ0IiwicHJvcCIsInRlc3QiLCJ0b1hNTCIsIm5hbWUiLCJqb2luIiwiYXR0cnMiLCJlbGVtcyIsImtrIiwicHVzaCIsInJlcGxhY2UiLCJzdGFydFRhZyIsImVuZFRhZyIsIlNPQVAiLCJjb25zdHJ1Y3RvciIsImNvbm4iLCJvcHRpb25zIiwiX2VuZHBvaW50VXJsIiwiZW5kcG9pbnRVcmwiLCJfeG1sbnMiLCJ4bWxucyIsImludm9rZSIsIm1ldGhvZCIsImFyZ3MiLCJyZXMiLCJyZXF1ZXN0IiwidXJsIiwiaGVhZGVycyIsIlNPQVBBY3Rpb24iLCJfbWVzc2FnZSIsImJlZm9yZVNlbmQiLCJib2R5IiwiX2NyZWF0ZUVudmVsb3BlIiwiaXNTZXNzaW9uRXhwaXJlZCIsInJlc3BvbnNlIiwic3RhdHVzQ29kZSIsInBhcnNlRXJyb3IiLCJlcnJvciIsImVycm9yQ29kZSIsImZhdWx0Y29kZSIsIm1lc3NhZ2UiLCJmYXVsdHN0cmluZyIsImdldFJlc3BvbnNlQm9keSIsImhlYWRlciIsIl9jb25uIiwiYWNjZXNzVG9rZW4iLCJTZXNzaW9uSGVhZGVyIiwic2Vzc2lvbklkIiwiX2NhbGxPcHRpb25zIiwiQ2FsbE9wdGlvbnMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPQSxPQUFQLE1BQW9CLFlBQXBCO0FBU0EsU0FBU0MsV0FBVCxFQUFzQkMsUUFBdEIsUUFBc0MsaUJBQXRDO0FBRUE7QUFDQTtBQUNBOztBQUNBLFNBQVNDLGNBQVQsQ0FDRUMsTUFERixFQUVFQyxVQUZGLEVBRzBCO0FBQ3hCLE1BQUlELE1BQU0sQ0FBQ0UsT0FBUCxJQUFrQkQsVUFBVSxDQUFDRCxNQUFNLENBQUNFLE9BQVIsQ0FBaEMsRUFBa0Q7QUFDaEQsVUFBTUMsWUFBWSxHQUFHRixVQUFVLENBQUNELE1BQU0sQ0FBQ0UsT0FBUixDQUEvQjtBQUNBLDJDQUNLSCxjQUFjLENBQUNJLFlBQUQsRUFBZUYsVUFBZixDQURuQixHQUVLRCxNQUFNLENBQUNJLEtBRlo7QUFJRDs7QUFDRCxTQUFPSixNQUFNLENBQUNJLEtBQWQ7QUFDRDs7QUFFRCxTQUFTQyxXQUFULENBQXFCQyxLQUFyQixFQUFxQztBQUNuQyxTQUNFQSxLQUFLLElBQUksSUFBVCxJQUNDVCxXQUFXLENBQUNTLEtBQUQsQ0FBWCxJQUNDVCxXQUFXLENBQUNTLEtBQUssQ0FBQ0MsQ0FBUCxDQURaLElBRUNELEtBQUssQ0FBQ0MsQ0FBTixDQUFRLFNBQVIsTUFBdUIsTUFKM0I7QUFNRDtBQUVEO0FBQ0E7QUFDQTs7O0FBQ0EsT0FBTyxTQUFTQyxtQkFBVCxDQUNMRixLQURLLEVBRUxOLE1BRkssRUFHTEMsVUFBNkMsR0FBRyxFQUgzQyxFQUlBO0FBQ0wsTUFBSSxlQUFjRCxNQUFkLENBQUosRUFBMkI7QUFBQTs7QUFDekIsVUFBTVMsUUFBUSxHQUFHVCxNQUFNLENBQUNVLE1BQVAsS0FBa0IsQ0FBbEIsSUFBdUJWLE1BQU0sQ0FBQyxDQUFELENBQU4sS0FBYyxHQUF0RDtBQUNBLFVBQU1XLE9BQU8sR0FBR0YsUUFBUSxHQUFHVCxNQUFNLENBQUMsQ0FBRCxDQUFULEdBQWVBLE1BQU0sQ0FBQyxDQUFELENBQTdDOztBQUNBLFFBQUlNLEtBQUssSUFBSSxJQUFiLEVBQW1CO0FBQ2pCLGFBQU9HLFFBQVEsR0FBRyxJQUFILEdBQVUsRUFBekI7QUFDRDs7QUFDRCxXQUFPLGdDQUFDLGVBQWNILEtBQWQsSUFBdUJBLEtBQXZCLEdBQStCLENBQUNBLEtBQUQsQ0FBaEMsaUJBQThDTSxDQUFELElBQ2xESixtQkFBbUIsQ0FBQ0ksQ0FBRCxFQUFJRCxPQUFKLEVBQWFWLFVBQWIsQ0FEZCxDQUFQO0FBR0QsR0FURCxNQVNPLElBQUlKLFdBQVcsQ0FBQ0csTUFBRCxDQUFmLEVBQXlCO0FBQUE7O0FBQzlCO0FBQ0EsUUFBSSxVQUFVQSxNQUFWLElBQW9CLFdBQVdBLE1BQS9CLElBQXlDSCxXQUFXLENBQUNHLE1BQU0sQ0FBQ0ksS0FBUixDQUF4RCxFQUF3RTtBQUN0RSxZQUFNQSxLQUFLLEdBQUdMLGNBQWMsQ0FBQ0MsTUFBRCxFQUEwQkMsVUFBMUIsQ0FBNUI7QUFDQSxhQUFPTyxtQkFBbUIsQ0FBQ0YsS0FBRCxFQUFRRixLQUFSLEVBQWVILFVBQWYsQ0FBMUI7QUFDRDs7QUFDRCxVQUFNUSxRQUFRLElBQUcsT0FBT1QsTUFBVixDQUFkO0FBQ0EsVUFBTVcsT0FBTyxHQUNYLE9BQU9YLE1BQVAsR0FBaUJBLE1BQU0sQ0FBQyxHQUFELENBQXZCLEdBQTBEQSxNQUQ1RDs7QUFFQSxRQUFJUyxRQUFRLElBQUlKLFdBQVcsQ0FBQ0MsS0FBRCxDQUEzQixFQUFvQztBQUNsQyxhQUFPLElBQVA7QUFDRDs7QUFDRCxVQUFNTyxHQUFHLEdBQUdoQixXQUFXLENBQUNTLEtBQUQsQ0FBWCxHQUFxQkEsS0FBckIsR0FBNkIsRUFBekM7QUFDQSxXQUFPLGlEQUFZSyxPQUFaLG1CQUE0QixDQUFDRyxDQUFELEVBQUlDLENBQUosS0FBVTtBQUMzQyxZQUFNQyxDQUFDLEdBQUdMLE9BQU8sQ0FBQ0ksQ0FBRCxDQUFqQjtBQUNBLFlBQU1ILENBQUMsR0FBR0MsR0FBRyxDQUFDRSxDQUFELENBQWI7QUFDQSxZQUFNTixRQUFRLEdBQ1gsZUFBY08sQ0FBZCxLQUFvQkEsQ0FBQyxDQUFDTixNQUFGLEtBQWEsQ0FBakMsSUFBc0NNLENBQUMsQ0FBQyxDQUFELENBQUQsS0FBUyxHQUFoRCxJQUNDbkIsV0FBVyxDQUFDbUIsQ0FBRCxDQUFYLElBQWtCLE9BQU9BLENBRDFCLElBRUMsT0FBT0EsQ0FBUCxLQUFhLFFBQWIsSUFBeUJBLENBQUMsQ0FBQyxDQUFELENBQUQsS0FBUyxHQUhyQzs7QUFJQSxVQUFJLE9BQU9KLENBQVAsS0FBYSxXQUFiLElBQTRCSCxRQUFoQyxFQUEwQztBQUN4QyxlQUFPSyxDQUFQO0FBQ0Q7O0FBQ0QsNkNBQ0tBLENBREw7QUFFRSxTQUFDQyxDQUFELEdBQUtQLG1CQUFtQixDQUFDSSxDQUFELEVBQUlJLENBQUosRUFBT2YsVUFBUDtBQUYxQjtBQUlELEtBZE0sRUFjSlksR0FkSSxDQUFQO0FBZUQsR0E1Qk0sTUE0QkE7QUFDTCxVQUFNSixRQUFRLEdBQUcsT0FBT1QsTUFBUCxLQUFrQixRQUFsQixJQUE4QkEsTUFBTSxDQUFDLENBQUQsQ0FBTixLQUFjLEdBQTdEO0FBQ0EsVUFBTWlCLElBQUksR0FDUixPQUFPakIsTUFBUCxLQUFrQixRQUFsQixHQUNJUyxRQUFRLEdBQ05ULE1BQU0sQ0FBQ2tCLFNBQVAsQ0FBaUIsQ0FBakIsQ0FETSxHQUVObEIsTUFITixHQUlJLEtBTE47O0FBTUEsWUFBUWlCLElBQVI7QUFDRSxXQUFLLFFBQUw7QUFDRSxlQUFPWixXQUFXLENBQUNDLEtBQUQsQ0FBWCxHQUFzQkcsUUFBUSxHQUFHLElBQUgsR0FBVSxFQUF4QyxHQUE4Q1UsTUFBTSxDQUFDYixLQUFELENBQTNEOztBQUNGLFdBQUssUUFBTDtBQUNFLGVBQU9ELFdBQVcsQ0FBQ0MsS0FBRCxDQUFYLEdBQXNCRyxRQUFRLEdBQUcsSUFBSCxHQUFVLENBQXhDLEdBQTZDVyxNQUFNLENBQUNkLEtBQUQsQ0FBMUQ7O0FBQ0YsV0FBSyxTQUFMO0FBQ0UsZUFBT0QsV0FBVyxDQUFDQyxLQUFELENBQVgsR0FDSEcsUUFBUSxHQUNOLElBRE0sR0FFTixLQUhDLEdBSUhILEtBQUssS0FBSyxNQUpkOztBQUtGLFdBQUssTUFBTDtBQUNFLGVBQU8sSUFBUDs7QUFDRjtBQUFTO0FBQ1AsY0FBSUwsVUFBVSxDQUFDZ0IsSUFBRCxDQUFkLEVBQXNCO0FBQ3BCLGtCQUFNSSxNQUFNLEdBQUdiLG1CQUFtQixDQUNoQ0YsS0FEZ0MsRUFFaENMLFVBQVUsQ0FBQ2dCLElBQUQsQ0FGc0IsRUFHaENoQixVQUhnQyxDQUFsQztBQUtBLGtCQUFNcUIsT0FBTyxHQUNYekIsV0FBVyxDQUFDd0IsTUFBRCxDQUFYLElBQXVCLGFBQVlBLE1BQVosRUFBb0JYLE1BQXBCLEtBQStCLENBRHhEO0FBRUEsbUJBQU9ZLE9BQU8sSUFBSWIsUUFBWCxHQUFzQixJQUF0QixHQUE2QlksTUFBcEM7QUFDRDs7QUFDRCxpQkFBT2YsS0FBUDtBQUNEO0FBekJIO0FBMkJEO0FBQ0Y7QUFFRDtBQUNBO0FBQ0E7O0FBQ0EsU0FBU2lCLFdBQVQsQ0FBcUJWLEdBQXJCLEVBQW1DVyxXQUFuQyxFQUFtRTtBQUNqRSxRQUFNQyxNQUFNLEdBQUdELFdBQVcsQ0FBQ0UsS0FBWixFQUFmOztBQUNBLE1BQUksQ0FBQ0QsTUFBTCxFQUFhO0FBQ1gsV0FBT1osR0FBUDtBQUNEOztBQUNELE1BQUloQixXQUFXLENBQUNnQixHQUFELENBQWYsRUFBc0I7QUFDcEIsU0FBSyxNQUFNYyxJQUFYLElBQW1CLGFBQVlkLEdBQVosQ0FBbkIsRUFBcUM7QUFDbkMsVUFBSVksTUFBTSxDQUFDRyxJQUFQLENBQVlELElBQVosQ0FBSixFQUF1QjtBQUNyQixlQUFPSixXQUFXLENBQUNWLEdBQUcsQ0FBQ2MsSUFBRCxDQUFKLEVBQVlILFdBQVosQ0FBbEI7QUFDRDtBQUNGOztBQUNELFdBQU8sSUFBUDtBQUNEO0FBQ0Y7QUFFRDtBQUNBO0FBQ0E7OztBQUNBLFNBQVNLLEtBQVQsQ0FBZUMsSUFBZixFQUE2Q3hCLEtBQTdDLEVBQWtFO0FBQ2hFLE1BQUlSLFFBQVEsQ0FBQ2dDLElBQUQsQ0FBWixFQUFvQjtBQUNsQnhCLElBQUFBLEtBQUssR0FBR3dCLElBQVI7QUFDQUEsSUFBQUEsSUFBSSxHQUFHLElBQVA7QUFDRDs7QUFDRCxNQUFJLGVBQWN4QixLQUFkLENBQUosRUFBMEI7QUFDeEIsV0FBTyxxQkFBQUEsS0FBSyxNQUFMLENBQUFBLEtBQUssRUFBTU0sQ0FBRCxJQUFPaUIsS0FBSyxDQUFDQyxJQUFELEVBQU9sQixDQUFQLENBQWpCLENBQUwsQ0FBaUNtQixJQUFqQyxDQUFzQyxFQUF0QyxDQUFQO0FBQ0QsR0FGRCxNQUVPO0FBQ0wsVUFBTUMsS0FBSyxHQUFHLEVBQWQ7QUFDQSxVQUFNQyxLQUFLLEdBQUcsRUFBZDs7QUFDQSxRQUFJcEMsV0FBVyxDQUFDUyxLQUFELENBQWYsRUFBd0I7QUFDdEIsV0FBSyxNQUFNUyxDQUFYLElBQWdCLGFBQVlULEtBQVosQ0FBaEIsRUFBb0M7QUFDbEMsY0FBTU0sQ0FBQyxHQUFHTixLQUFLLENBQUNTLENBQUQsQ0FBZjs7QUFDQSxZQUFJQSxDQUFDLENBQUMsQ0FBRCxDQUFELEtBQVMsR0FBYixFQUFrQjtBQUNoQixnQkFBTW1CLEVBQUUsR0FBR25CLENBQUMsQ0FBQ0csU0FBRixDQUFZLENBQVosQ0FBWDtBQUNBYyxVQUFBQSxLQUFLLENBQUNHLElBQU4sQ0FBV0QsRUFBRSxHQUFHLElBQUwsR0FBWXRCLENBQVosR0FBZ0IsR0FBM0I7QUFDRCxTQUhELE1BR087QUFDTHFCLFVBQUFBLEtBQUssQ0FBQ0UsSUFBTixDQUFXTixLQUFLLENBQUNkLENBQUQsRUFBSUgsQ0FBSixDQUFoQjtBQUNEO0FBQ0Y7O0FBQ0ROLE1BQUFBLEtBQUssR0FBRzJCLEtBQUssQ0FBQ0YsSUFBTixDQUFXLEVBQVgsQ0FBUjtBQUNELEtBWEQsTUFXTztBQUNMekIsTUFBQUEsS0FBSyxHQUFHYSxNQUFNLENBQUNiLEtBQUQsQ0FBTixDQUNMOEIsT0FESyxDQUNHLElBREgsRUFDUyxPQURULEVBRUxBLE9BRkssQ0FFRyxJQUZILEVBRVMsTUFGVCxFQUdMQSxPQUhLLENBR0csSUFISCxFQUdTLE1BSFQsRUFJTEEsT0FKSyxDQUlHLElBSkgsRUFJUyxRQUpULEVBS0xBLE9BTEssQ0FLRyxJQUxILEVBS1MsUUFMVCxDQUFSO0FBTUQ7O0FBQ0QsVUFBTUMsUUFBUSxHQUFHUCxJQUFJLEdBQ2pCLE1BQU1BLElBQU4sSUFBY0UsS0FBSyxDQUFDdEIsTUFBTixHQUFlLENBQWYsR0FBbUIsTUFBTXNCLEtBQUssQ0FBQ0QsSUFBTixDQUFXLEdBQVgsQ0FBekIsR0FBMkMsRUFBekQsSUFBK0QsR0FEOUMsR0FFakIsRUFGSjtBQUdBLFVBQU1PLE1BQU0sR0FBR1IsSUFBSSxHQUFHLE9BQU9BLElBQVAsR0FBYyxHQUFqQixHQUF1QixFQUExQztBQUNBLFdBQU9PLFFBQVEsR0FBRy9CLEtBQVgsR0FBbUJnQyxNQUExQjtBQUNEO0FBQ0Y7QUFFRDtBQUNBO0FBQ0E7OztBQU1BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPLE1BQU1DLElBQU4sU0FBcUMzQyxPQUFyQyxDQUFnRDtBQUlyRDRDLEVBQUFBLFdBQVcsQ0FBQ0MsSUFBRCxFQUFzQkMsT0FBdEIsRUFBNEM7QUFDckQsVUFBTUQsSUFBTixFQUFZQyxPQUFaOztBQURxRDs7QUFBQTs7QUFFckQsU0FBS0MsWUFBTCxHQUFvQkQsT0FBTyxDQUFDRSxXQUE1QjtBQUNBLFNBQUtDLE1BQUwsR0FBY0gsT0FBTyxDQUFDSSxLQUFSLElBQWlCLDZCQUEvQjtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRSxRQUFNQyxNQUFOLENBQ0VDLE1BREYsRUFFRUMsSUFGRixFQUdFakQsTUFIRixFQUlFQyxVQUpGLEVBS0U7QUFDQSxVQUFNaUQsR0FBRyxHQUFHLE1BQU0sS0FBS0MsT0FBTCxDQUFhO0FBQzdCSCxNQUFBQSxNQUFNLEVBQUUsTUFEcUI7QUFFN0JJLE1BQUFBLEdBQUcsRUFBRSxLQUFLVCxZQUZtQjtBQUc3QlUsTUFBQUEsT0FBTyxFQUFFO0FBQ1Asd0JBQWdCLFVBRFQ7QUFFUEMsUUFBQUEsVUFBVSxFQUFFO0FBRkwsT0FIb0I7QUFPN0JDLE1BQUFBLFFBQVEsRUFBRTtBQUFFLFNBQUNQLE1BQUQsR0FBVUM7QUFBWjtBQVBtQixLQUFiLENBQWxCO0FBU0EsV0FBT2pELE1BQU0sR0FBR1EsbUJBQW1CLENBQUMwQyxHQUFELEVBQU1sRCxNQUFOLEVBQWNDLFVBQWQsQ0FBdEIsR0FBa0RpRCxHQUEvRDtBQUNEO0FBRUQ7OztBQUNBTSxFQUFBQSxVQUFVLENBQUNMLE9BQUQsRUFBOEM7QUFDdERBLElBQUFBLE9BQU8sQ0FBQ00sSUFBUixHQUFlLEtBQUtDLGVBQUwsQ0FBcUJQLE9BQU8sQ0FBQ0ksUUFBN0IsQ0FBZjtBQUNEO0FBRUQ7OztBQUNBSSxFQUFBQSxnQkFBZ0IsQ0FBQ0MsUUFBRCxFQUF5QjtBQUN2QyxXQUNFQSxRQUFRLENBQUNDLFVBQVQsS0FBd0IsR0FBeEIsSUFDQSx1REFBdURqQyxJQUF2RCxDQUE0RGdDLFFBQVEsQ0FBQ0gsSUFBckUsQ0FGRjtBQUlEO0FBRUQ7OztBQUNBSyxFQUFBQSxVQUFVLENBQUNMLElBQUQsRUFBZTtBQUN2QixVQUFNTSxLQUFLLEdBQUd4QyxXQUFXLENBQUNrQyxJQUFELEVBQU8sQ0FBQyxZQUFELEVBQWUsUUFBZixFQUF5QixTQUF6QixDQUFQLENBQXpCO0FBR0EsV0FBTztBQUNMTyxNQUFBQSxTQUFTLEVBQUVELEtBQUssQ0FBQ0UsU0FEWjtBQUVMQyxNQUFBQSxPQUFPLEVBQUVILEtBQUssQ0FBQ0k7QUFGVixLQUFQO0FBSUQ7QUFFRDs7O0FBQ0EsUUFBTUMsZUFBTixDQUFzQlIsUUFBdEIsRUFBOEM7QUFDNUMsVUFBTUgsSUFBSSxHQUFHLE1BQU0sTUFBTVcsZUFBTixDQUFzQlIsUUFBdEIsQ0FBbkI7QUFDQSxXQUFPckMsV0FBVyxDQUFDa0MsSUFBRCxFQUFPLENBQUMsWUFBRCxFQUFlLFFBQWYsRUFBeUIsSUFBekIsQ0FBUCxDQUFsQjtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRUMsRUFBQUEsZUFBZSxDQUFDUSxPQUFELEVBQWtCO0FBQy9CLFVBQU1HLE1BQStCLEdBQUcsRUFBeEM7QUFDQSxVQUFNNUIsSUFBSSxHQUFHLEtBQUs2QixLQUFsQjs7QUFDQSxRQUFJN0IsSUFBSSxDQUFDOEIsV0FBVCxFQUFzQjtBQUNwQkYsTUFBQUEsTUFBTSxDQUFDRyxhQUFQLEdBQXVCO0FBQUVDLFFBQUFBLFNBQVMsRUFBRWhDLElBQUksQ0FBQzhCO0FBQWxCLE9BQXZCO0FBQ0Q7O0FBQ0QsUUFBSTlCLElBQUksQ0FBQ2lDLFlBQVQsRUFBdUI7QUFDckJMLE1BQUFBLE1BQU0sQ0FBQ00sV0FBUCxHQUFxQmxDLElBQUksQ0FBQ2lDLFlBQTFCO0FBQ0Q7O0FBQ0QsV0FBTyxDQUNMLHdDQURLLEVBRUwsNkVBRkssRUFHTCwrQ0FISyxFQUlMLHlEQUpLLEVBS0wsNEJBQTRCLEtBQUs3QixNQUFqQyxHQUEwQyxJQUxyQyxFQU1MaEIsS0FBSyxDQUFDd0MsTUFBRCxDQU5BLEVBT0wsbUJBUEssRUFRTCwwQkFBMEIsS0FBS3hCLE1BQS9CLEdBQXdDLElBUm5DLEVBU0xoQixLQUFLLENBQUNxQyxPQUFELENBVEEsRUFVTCxpQkFWSyxFQVdMLHFCQVhLLEVBWUxuQyxJQVpLLENBWUEsRUFaQSxDQUFQO0FBYUQ7O0FBdEZvRDtBQXlGdkQsZUFBZVEsSUFBZiIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGZpbGUgTWFuYWdlcyBtZXRob2QgY2FsbCB0byBTT0FQIGVuZHBvaW50XG4gKiBAYXV0aG9yIFNoaW5pY2hpIFRvbWl0YSA8c2hpbmljaGkudG9taXRhQGdtYWlsLmNvbT5cbiAqL1xuaW1wb3J0IEh0dHBBcGkgZnJvbSAnLi9odHRwLWFwaSc7XG5pbXBvcnQgQ29ubmVjdGlvbiBmcm9tICcuL2Nvbm5lY3Rpb24nO1xuaW1wb3J0IHtcbiAgU2NoZW1hLFxuICBIdHRwUmVzcG9uc2UsXG4gIEh0dHBSZXF1ZXN0LFxuICBTb2FwU2NoZW1hLFxuICBTb2FwU2NoZW1hRGVmLFxufSBmcm9tICcuL3R5cGVzJztcbmltcG9ydCB7IGlzTWFwT2JqZWN0LCBpc09iamVjdCB9IGZyb20gJy4vdXRpbC9mdW5jdGlvbic7XG5cbi8qKlxuICpcbiAqL1xuZnVuY3Rpb24gZ2V0UHJvcHNTY2hlbWEoXG4gIHNjaGVtYTogU29hcFNjaGVtYURlZixcbiAgc2NoZW1hRGljdDogeyBbbmFtZTogc3RyaW5nXTogU29hcFNjaGVtYURlZiB9LFxuKTogU29hcFNjaGVtYURlZlsncHJvcHMnXSB7XG4gIGlmIChzY2hlbWEuZXh0ZW5kcyAmJiBzY2hlbWFEaWN0W3NjaGVtYS5leHRlbmRzXSkge1xuICAgIGNvbnN0IGV4dGVuZFNjaGVtYSA9IHNjaGVtYURpY3Rbc2NoZW1hLmV4dGVuZHNdO1xuICAgIHJldHVybiB7XG4gICAgICAuLi5nZXRQcm9wc1NjaGVtYShleHRlbmRTY2hlbWEsIHNjaGVtYURpY3QpLFxuICAgICAgLi4uc2NoZW1hLnByb3BzLFxuICAgIH07XG4gIH1cbiAgcmV0dXJuIHNjaGVtYS5wcm9wcztcbn1cblxuZnVuY3Rpb24gaXNOaWxsVmFsdWUodmFsdWU6IHVua25vd24pIHtcbiAgcmV0dXJuIChcbiAgICB2YWx1ZSA9PSBudWxsIHx8XG4gICAgKGlzTWFwT2JqZWN0KHZhbHVlKSAmJlxuICAgICAgaXNNYXBPYmplY3QodmFsdWUuJCkgJiZcbiAgICAgIHZhbHVlLiRbJ3hzaTpuaWwnXSA9PT0gJ3RydWUnKVxuICApO1xufVxuXG4vKipcbiAqXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjYXN0VHlwZVVzaW5nU2NoZW1hKFxuICB2YWx1ZTogdW5rbm93bixcbiAgc2NoZW1hPzogU29hcFNjaGVtYSB8IFNvYXBTY2hlbWFEZWYsXG4gIHNjaGVtYURpY3Q6IHsgW25hbWU6IHN0cmluZ106IFNvYXBTY2hlbWFEZWYgfSA9IHt9LFxuKTogYW55IHtcbiAgaWYgKEFycmF5LmlzQXJyYXkoc2NoZW1hKSkge1xuICAgIGNvbnN0IG5pbGxhYmxlID0gc2NoZW1hLmxlbmd0aCA9PT0gMiAmJiBzY2hlbWFbMF0gPT09ICc/JztcbiAgICBjb25zdCBzY2hlbWFfID0gbmlsbGFibGUgPyBzY2hlbWFbMV0gOiBzY2hlbWFbMF07XG4gICAgaWYgKHZhbHVlID09IG51bGwpIHtcbiAgICAgIHJldHVybiBuaWxsYWJsZSA/IG51bGwgOiBbXTtcbiAgICB9XG4gICAgcmV0dXJuIChBcnJheS5pc0FycmF5KHZhbHVlKSA/IHZhbHVlIDogW3ZhbHVlXSkubWFwKCh2KSA9PlxuICAgICAgY2FzdFR5cGVVc2luZ1NjaGVtYSh2LCBzY2hlbWFfLCBzY2hlbWFEaWN0KSxcbiAgICApO1xuICB9IGVsc2UgaWYgKGlzTWFwT2JqZWN0KHNjaGVtYSkpIHtcbiAgICAvLyBpZiBzY2hlbWEgaXMgU2NoZW1hIERlZmluaXRpb24sIG5vdCBzY2hlbWEgZWxlbWVudFxuICAgIGlmICgndHlwZScgaW4gc2NoZW1hICYmICdwcm9wcycgaW4gc2NoZW1hICYmIGlzTWFwT2JqZWN0KHNjaGVtYS5wcm9wcykpIHtcbiAgICAgIGNvbnN0IHByb3BzID0gZ2V0UHJvcHNTY2hlbWEoc2NoZW1hIGFzIFNvYXBTY2hlbWFEZWYsIHNjaGVtYURpY3QpO1xuICAgICAgcmV0dXJuIGNhc3RUeXBlVXNpbmdTY2hlbWEodmFsdWUsIHByb3BzLCBzY2hlbWFEaWN0KTtcbiAgICB9XG4gICAgY29uc3QgbmlsbGFibGUgPSAnPycgaW4gc2NoZW1hO1xuICAgIGNvbnN0IHNjaGVtYV8gPVxuICAgICAgJz8nIGluIHNjaGVtYSA/IChzY2hlbWFbJz8nXSBhcyB7IFtrZXk6IHN0cmluZ106IGFueSB9KSA6IHNjaGVtYTtcbiAgICBpZiAobmlsbGFibGUgJiYgaXNOaWxsVmFsdWUodmFsdWUpKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgY29uc3Qgb2JqID0gaXNNYXBPYmplY3QodmFsdWUpID8gdmFsdWUgOiB7fTtcbiAgICByZXR1cm4gT2JqZWN0LmtleXMoc2NoZW1hXykucmVkdWNlKChvLCBrKSA9PiB7XG4gICAgICBjb25zdCBzID0gc2NoZW1hX1trXTtcbiAgICAgIGNvbnN0IHYgPSBvYmpba107XG4gICAgICBjb25zdCBuaWxsYWJsZSA9XG4gICAgICAgIChBcnJheS5pc0FycmF5KHMpICYmIHMubGVuZ3RoID09PSAyICYmIHNbMF0gPT09ICc/JykgfHxcbiAgICAgICAgKGlzTWFwT2JqZWN0KHMpICYmICc/JyBpbiBzKSB8fFxuICAgICAgICAodHlwZW9mIHMgPT09ICdzdHJpbmcnICYmIHNbMF0gPT09ICc/Jyk7XG4gICAgICBpZiAodHlwZW9mIHYgPT09ICd1bmRlZmluZWQnICYmIG5pbGxhYmxlKSB7XG4gICAgICAgIHJldHVybiBvO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgLi4ubyxcbiAgICAgICAgW2tdOiBjYXN0VHlwZVVzaW5nU2NoZW1hKHYsIHMsIHNjaGVtYURpY3QpLFxuICAgICAgfTtcbiAgICB9LCBvYmopO1xuICB9IGVsc2Uge1xuICAgIGNvbnN0IG5pbGxhYmxlID0gdHlwZW9mIHNjaGVtYSA9PT0gJ3N0cmluZycgJiYgc2NoZW1hWzBdID09PSAnPyc7XG4gICAgY29uc3QgdHlwZSA9XG4gICAgICB0eXBlb2Ygc2NoZW1hID09PSAnc3RyaW5nJ1xuICAgICAgICA/IG5pbGxhYmxlXG4gICAgICAgICAgPyBzY2hlbWEuc3Vic3RyaW5nKDEpXG4gICAgICAgICAgOiBzY2hlbWFcbiAgICAgICAgOiAnYW55JztcbiAgICBzd2l0Y2ggKHR5cGUpIHtcbiAgICAgIGNhc2UgJ3N0cmluZyc6XG4gICAgICAgIHJldHVybiBpc05pbGxWYWx1ZSh2YWx1ZSkgPyAobmlsbGFibGUgPyBudWxsIDogJycpIDogU3RyaW5nKHZhbHVlKTtcbiAgICAgIGNhc2UgJ251bWJlcic6XG4gICAgICAgIHJldHVybiBpc05pbGxWYWx1ZSh2YWx1ZSkgPyAobmlsbGFibGUgPyBudWxsIDogMCkgOiBOdW1iZXIodmFsdWUpO1xuICAgICAgY2FzZSAnYm9vbGVhbic6XG4gICAgICAgIHJldHVybiBpc05pbGxWYWx1ZSh2YWx1ZSlcbiAgICAgICAgICA/IG5pbGxhYmxlXG4gICAgICAgICAgICA/IG51bGxcbiAgICAgICAgICAgIDogZmFsc2VcbiAgICAgICAgICA6IHZhbHVlID09PSAndHJ1ZSc7XG4gICAgICBjYXNlICdudWxsJzpcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICBkZWZhdWx0OiB7XG4gICAgICAgIGlmIChzY2hlbWFEaWN0W3R5cGVdKSB7XG4gICAgICAgICAgY29uc3QgY3ZhbHVlID0gY2FzdFR5cGVVc2luZ1NjaGVtYShcbiAgICAgICAgICAgIHZhbHVlLFxuICAgICAgICAgICAgc2NoZW1hRGljdFt0eXBlXSxcbiAgICAgICAgICAgIHNjaGVtYURpY3QsXG4gICAgICAgICAgKTtcbiAgICAgICAgICBjb25zdCBpc0VtcHR5ID1cbiAgICAgICAgICAgIGlzTWFwT2JqZWN0KGN2YWx1ZSkgJiYgT2JqZWN0LmtleXMoY3ZhbHVlKS5sZW5ndGggPT09IDA7XG4gICAgICAgICAgcmV0dXJuIGlzRW1wdHkgJiYgbmlsbGFibGUgPyBudWxsIDogY3ZhbHVlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB2YWx1ZSBhcyBhbnk7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cbi8qKlxuICogQHByaXZhdGVcbiAqL1xuZnVuY3Rpb24gbG9va3VwVmFsdWUob2JqOiB1bmtub3duLCBwcm9wUmVnRXhwczogUmVnRXhwW10pOiB1bmtub3duIHtcbiAgY29uc3QgcmVnZXhwID0gcHJvcFJlZ0V4cHMuc2hpZnQoKTtcbiAgaWYgKCFyZWdleHApIHtcbiAgICByZXR1cm4gb2JqO1xuICB9XG4gIGlmIChpc01hcE9iamVjdChvYmopKSB7XG4gICAgZm9yIChjb25zdCBwcm9wIG9mIE9iamVjdC5rZXlzKG9iaikpIHtcbiAgICAgIGlmIChyZWdleHAudGVzdChwcm9wKSkge1xuICAgICAgICByZXR1cm4gbG9va3VwVmFsdWUob2JqW3Byb3BdLCBwcm9wUmVnRXhwcyk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9XG59XG5cbi8qKlxuICogQHByaXZhdGVcbiAqL1xuZnVuY3Rpb24gdG9YTUwobmFtZTogb2JqZWN0IHwgc3RyaW5nIHwgbnVsbCwgdmFsdWU/OiBhbnkpOiBzdHJpbmcge1xuICBpZiAoaXNPYmplY3QobmFtZSkpIHtcbiAgICB2YWx1ZSA9IG5hbWU7XG4gICAgbmFtZSA9IG51bGw7XG4gIH1cbiAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgcmV0dXJuIHZhbHVlLm1hcCgodikgPT4gdG9YTUwobmFtZSwgdikpLmpvaW4oJycpO1xuICB9IGVsc2Uge1xuICAgIGNvbnN0IGF0dHJzID0gW107XG4gICAgY29uc3QgZWxlbXMgPSBbXTtcbiAgICBpZiAoaXNNYXBPYmplY3QodmFsdWUpKSB7XG4gICAgICBmb3IgKGNvbnN0IGsgb2YgT2JqZWN0LmtleXModmFsdWUpKSB7XG4gICAgICAgIGNvbnN0IHYgPSB2YWx1ZVtrXTtcbiAgICAgICAgaWYgKGtbMF0gPT09ICdAJykge1xuICAgICAgICAgIGNvbnN0IGtrID0gay5zdWJzdHJpbmcoMSk7XG4gICAgICAgICAgYXR0cnMucHVzaChrayArICc9XCInICsgdiArICdcIicpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGVsZW1zLnB1c2godG9YTUwoaywgdikpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICB2YWx1ZSA9IGVsZW1zLmpvaW4oJycpO1xuICAgIH0gZWxzZSB7XG4gICAgICB2YWx1ZSA9IFN0cmluZyh2YWx1ZSlcbiAgICAgICAgLnJlcGxhY2UoLyYvZywgJyZhbXA7JylcbiAgICAgICAgLnJlcGxhY2UoLzwvZywgJyZsdDsnKVxuICAgICAgICAucmVwbGFjZSgvPi9nLCAnJmd0OycpXG4gICAgICAgIC5yZXBsYWNlKC9cIi9nLCAnJnF1b3Q7JylcbiAgICAgICAgLnJlcGxhY2UoLycvZywgJyZhcG9zOycpO1xuICAgIH1cbiAgICBjb25zdCBzdGFydFRhZyA9IG5hbWVcbiAgICAgID8gJzwnICsgbmFtZSArIChhdHRycy5sZW5ndGggPiAwID8gJyAnICsgYXR0cnMuam9pbignICcpIDogJycpICsgJz4nXG4gICAgICA6ICcnO1xuICAgIGNvbnN0IGVuZFRhZyA9IG5hbWUgPyAnPC8nICsgbmFtZSArICc+JyA6ICcnO1xuICAgIHJldHVybiBzdGFydFRhZyArIHZhbHVlICsgZW5kVGFnO1xuICB9XG59XG5cbi8qKlxuICpcbiAqL1xuZXhwb3J0IHR5cGUgU09BUE9wdGlvbnMgPSB7XG4gIGVuZHBvaW50VXJsOiBzdHJpbmc7XG4gIHhtbG5zPzogc3RyaW5nO1xufTtcblxuLyoqXG4gKiBDbGFzcyBmb3IgU09BUCBlbmRwb2ludCBvZiBTYWxlc2ZvcmNlXG4gKlxuICogQHByb3RlY3RlZFxuICogQGNsYXNzXG4gKiBAY29uc3RydWN0b3JcbiAqIEBwYXJhbSB7Q29ubmVjdGlvbn0gY29ubiAtIENvbm5lY3Rpb24gaW5zdGFuY2VcbiAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zIC0gU09BUCBlbmRwb2ludCBzZXR0aW5nIG9wdGlvbnNcbiAqIEBwYXJhbSB7U3RyaW5nfSBvcHRpb25zLmVuZHBvaW50VXJsIC0gU09BUCBlbmRwb2ludCBVUkxcbiAqIEBwYXJhbSB7U3RyaW5nfSBbb3B0aW9ucy54bWxuc10gLSBYTUwgbmFtZXNwYWNlIGZvciBtZXRob2QgY2FsbCAoZGVmYXVsdCBpcyBcInVybjpwYXJ0bmVyLnNvYXAuc2ZvcmNlLmNvbVwiKVxuICovXG5leHBvcnQgY2xhc3MgU09BUDxTIGV4dGVuZHMgU2NoZW1hPiBleHRlbmRzIEh0dHBBcGk8Uz4ge1xuICBfZW5kcG9pbnRVcmw6IHN0cmluZztcbiAgX3htbG5zOiBzdHJpbmc7XG5cbiAgY29uc3RydWN0b3IoY29ubjogQ29ubmVjdGlvbjxTPiwgb3B0aW9uczogU09BUE9wdGlvbnMpIHtcbiAgICBzdXBlcihjb25uLCBvcHRpb25zKTtcbiAgICB0aGlzLl9lbmRwb2ludFVybCA9IG9wdGlvbnMuZW5kcG9pbnRVcmw7XG4gICAgdGhpcy5feG1sbnMgPSBvcHRpb25zLnhtbG5zIHx8ICd1cm46cGFydG5lci5zb2FwLnNmb3JjZS5jb20nO1xuICB9XG5cbiAgLyoqXG4gICAqIEludm9rZSBTT0FQIGNhbGwgdXNpbmcgbWV0aG9kIGFuZCBhcmd1bWVudHNcbiAgICovXG4gIGFzeW5jIGludm9rZShcbiAgICBtZXRob2Q6IHN0cmluZyxcbiAgICBhcmdzOiBvYmplY3QsXG4gICAgc2NoZW1hPzogU29hcFNjaGVtYSB8IFNvYXBTY2hlbWFEZWYsXG4gICAgc2NoZW1hRGljdD86IHsgW25hbWU6IHN0cmluZ106IFNvYXBTY2hlbWFEZWYgfSxcbiAgKSB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5yZXF1ZXN0KHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgdXJsOiB0aGlzLl9lbmRwb2ludFVybCxcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICd0ZXh0L3htbCcsXG4gICAgICAgIFNPQVBBY3Rpb246ICdcIlwiJyxcbiAgICAgIH0sXG4gICAgICBfbWVzc2FnZTogeyBbbWV0aG9kXTogYXJncyB9LFxuICAgIH0gYXMgSHR0cFJlcXVlc3QpO1xuICAgIHJldHVybiBzY2hlbWEgPyBjYXN0VHlwZVVzaW5nU2NoZW1hKHJlcywgc2NoZW1hLCBzY2hlbWFEaWN0KSA6IHJlcztcbiAgfVxuXG4gIC8qKiBAb3ZlcnJpZGUgKi9cbiAgYmVmb3JlU2VuZChyZXF1ZXN0OiBIdHRwUmVxdWVzdCAmIHsgX21lc3NhZ2U6IG9iamVjdCB9KSB7XG4gICAgcmVxdWVzdC5ib2R5ID0gdGhpcy5fY3JlYXRlRW52ZWxvcGUocmVxdWVzdC5fbWVzc2FnZSk7XG4gIH1cblxuICAvKiogQG92ZXJyaWRlICoqL1xuICBpc1Nlc3Npb25FeHBpcmVkKHJlc3BvbnNlOiBIdHRwUmVzcG9uc2UpIHtcbiAgICByZXR1cm4gKFxuICAgICAgcmVzcG9uc2Uuc3RhdHVzQ29kZSA9PT0gNTAwICYmXG4gICAgICAvPGZhdWx0Y29kZT5bYS16QS1aXSs6SU5WQUxJRF9TRVNTSU9OX0lEPFxcL2ZhdWx0Y29kZT4vLnRlc3QocmVzcG9uc2UuYm9keSlcbiAgICApO1xuICB9XG5cbiAgLyoqIEBvdmVycmlkZSAqKi9cbiAgcGFyc2VFcnJvcihib2R5OiBzdHJpbmcpIHtcbiAgICBjb25zdCBlcnJvciA9IGxvb2t1cFZhbHVlKGJvZHksIFsvOkVudmVsb3BlJC8sIC86Qm9keSQvLCAvOkZhdWx0JC9dKSBhcyB7XG4gICAgICBbbmFtZTogc3RyaW5nXTogc3RyaW5nIHwgdW5kZWZpbmVkO1xuICAgIH07XG4gICAgcmV0dXJuIHtcbiAgICAgIGVycm9yQ29kZTogZXJyb3IuZmF1bHRjb2RlLFxuICAgICAgbWVzc2FnZTogZXJyb3IuZmF1bHRzdHJpbmcsXG4gICAgfTtcbiAgfVxuXG4gIC8qKiBAb3ZlcnJpZGUgKiovXG4gIGFzeW5jIGdldFJlc3BvbnNlQm9keShyZXNwb25zZTogSHR0cFJlc3BvbnNlKSB7XG4gICAgY29uc3QgYm9keSA9IGF3YWl0IHN1cGVyLmdldFJlc3BvbnNlQm9keShyZXNwb25zZSk7XG4gICAgcmV0dXJuIGxvb2t1cFZhbHVlKGJvZHksIFsvOkVudmVsb3BlJC8sIC86Qm9keSQvLCAvLisvXSk7XG4gIH1cblxuICAvKipcbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9jcmVhdGVFbnZlbG9wZShtZXNzYWdlOiBvYmplY3QpIHtcbiAgICBjb25zdCBoZWFkZXI6IHsgW25hbWU6IHN0cmluZ106IGFueSB9ID0ge307XG4gICAgY29uc3QgY29ubiA9IHRoaXMuX2Nvbm47XG4gICAgaWYgKGNvbm4uYWNjZXNzVG9rZW4pIHtcbiAgICAgIGhlYWRlci5TZXNzaW9uSGVhZGVyID0geyBzZXNzaW9uSWQ6IGNvbm4uYWNjZXNzVG9rZW4gfTtcbiAgICB9XG4gICAgaWYgKGNvbm4uX2NhbGxPcHRpb25zKSB7XG4gICAgICBoZWFkZXIuQ2FsbE9wdGlvbnMgPSBjb25uLl9jYWxsT3B0aW9ucztcbiAgICB9XG4gICAgcmV0dXJuIFtcbiAgICAgICc8P3htbCB2ZXJzaW9uPVwiMS4wXCIgZW5jb2Rpbmc9XCJVVEYtOFwiPz4nLFxuICAgICAgJzxzb2FwZW52OkVudmVsb3BlIHhtbG5zOnNvYXBlbnY9XCJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy9zb2FwL2VudmVsb3BlL1wiJyxcbiAgICAgICcgeG1sbnM6eHNkPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWFcIicsXG4gICAgICAnIHhtbG5zOnhzaT1cImh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hLWluc3RhbmNlXCI+JyxcbiAgICAgICc8c29hcGVudjpIZWFkZXIgeG1sbnM9XCInICsgdGhpcy5feG1sbnMgKyAnXCI+JyxcbiAgICAgIHRvWE1MKGhlYWRlciksXG4gICAgICAnPC9zb2FwZW52OkhlYWRlcj4nLFxuICAgICAgJzxzb2FwZW52OkJvZHkgeG1sbnM9XCInICsgdGhpcy5feG1sbnMgKyAnXCI+JyxcbiAgICAgIHRvWE1MKG1lc3NhZ2UpLFxuICAgICAgJzwvc29hcGVudjpCb2R5PicsXG4gICAgICAnPC9zb2FwZW52OkVudmVsb3BlPicsXG4gICAgXS5qb2luKCcnKTtcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBTT0FQO1xuIl19