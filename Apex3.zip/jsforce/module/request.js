import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import "core-js/modules/es.array.iterator";
import "core-js/modules/es.promise";
import _keysInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/keys";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime-corejs3/helpers/objectWithoutProperties";

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context2; _forEachInstanceProperty(_context2 = ownKeys(Object(source), true)).call(_context2, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context3; _forEachInstanceProperty(_context3 = ownKeys(Object(source))).call(_context3, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

import fetch from 'node-fetch';
import AbortController from 'abort-controller';
import createHttpsProxyAgent from 'https-proxy-agent';
import { createHttpRequestHandlerStreams, executeWithTimeout, isRedirect, performRedirectRequest } from './request-helper';

/**
 *
 */
let defaults = {};
/**
 *
 */

export function setDefaults(defaults_) {
  defaults = defaults_;
}
/**
 *
 */

async function startFetchRequest(request, options, input, output, emitter, counter = 0) {
  const {
    httpProxy,
    followRedirect
  } = options;
  const agent = httpProxy ? createHttpsProxyAgent(httpProxy) : undefined;

  const {
    url,
    body
  } = request,
        rrequest = _objectWithoutProperties(request, ["url", "body"]);

  const controller = new AbortController();
  let res;

  try {
    res = await executeWithTimeout(() => fetch(url, _objectSpread(_objectSpread(_objectSpread({}, rrequest), input && /^(post|put|patch)$/i.test(request.method) ? {
      body: input
    } : {}), {}, {
      redirect: 'manual',
      signal: controller.signal,
      agent
    })), options.timeout, () => controller.abort());
  } catch (err) {
    emitter.emit('error', err);
    return;
  }

  const headers = {};

  for (const headerName of _keysInstanceProperty(_context = res.headers).call(_context)) {
    var _context;

    headers[headerName.toLowerCase()] = res.headers.get(headerName);
  }

  const response = {
    statusCode: res.status,
    headers
  };

  if (followRedirect && isRedirect(response.statusCode)) {
    try {
      performRedirectRequest(request, response, followRedirect, counter, req => startFetchRequest(req, options, undefined, output, emitter, counter + 1));
    } catch (err) {
      emitter.emit('error', err);
    }

    return;
  }

  emitter.emit('response', response);
  res.body.pipe(output);
}
/**
 *
 */


export default function request(req, options_ = {}) {
  const options = _objectSpread(_objectSpread({}, defaults), options_);

  const {
    input,
    output,
    stream
  } = createHttpRequestHandlerStreams(req);
  startFetchRequest(req, options, input, output, stream);
  return stream;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9yZXF1ZXN0LnRzIl0sIm5hbWVzIjpbImZldGNoIiwiQWJvcnRDb250cm9sbGVyIiwiY3JlYXRlSHR0cHNQcm94eUFnZW50IiwiY3JlYXRlSHR0cFJlcXVlc3RIYW5kbGVyU3RyZWFtcyIsImV4ZWN1dGVXaXRoVGltZW91dCIsImlzUmVkaXJlY3QiLCJwZXJmb3JtUmVkaXJlY3RSZXF1ZXN0IiwiZGVmYXVsdHMiLCJzZXREZWZhdWx0cyIsImRlZmF1bHRzXyIsInN0YXJ0RmV0Y2hSZXF1ZXN0IiwicmVxdWVzdCIsIm9wdGlvbnMiLCJpbnB1dCIsIm91dHB1dCIsImVtaXR0ZXIiLCJjb3VudGVyIiwiaHR0cFByb3h5IiwiZm9sbG93UmVkaXJlY3QiLCJhZ2VudCIsInVuZGVmaW5lZCIsInVybCIsImJvZHkiLCJycmVxdWVzdCIsImNvbnRyb2xsZXIiLCJyZXMiLCJ0ZXN0IiwibWV0aG9kIiwicmVkaXJlY3QiLCJzaWduYWwiLCJ0aW1lb3V0IiwiYWJvcnQiLCJlcnIiLCJlbWl0IiwiaGVhZGVycyIsImhlYWRlck5hbWUiLCJ0b0xvd2VyQ2FzZSIsImdldCIsInJlc3BvbnNlIiwic3RhdHVzQ29kZSIsInN0YXR1cyIsInJlcSIsInBpcGUiLCJvcHRpb25zXyIsInN0cmVhbSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRUEsT0FBT0EsS0FBUCxNQUFrQixZQUFsQjtBQUNBLE9BQU9DLGVBQVAsTUFBNEIsa0JBQTVCO0FBQ0EsT0FBT0MscUJBQVAsTUFBa0MsbUJBQWxDO0FBQ0EsU0FDRUMsK0JBREYsRUFFRUMsa0JBRkYsRUFHRUMsVUFIRixFQUlFQyxzQkFKRixRQUtPLGtCQUxQOztBQVFBO0FBQ0E7QUFDQTtBQUNBLElBQUlDLFFBQTRCLEdBQUcsRUFBbkM7QUFFQTtBQUNBO0FBQ0E7O0FBQ0EsT0FBTyxTQUFTQyxXQUFULENBQXFCQyxTQUFyQixFQUFvRDtBQUN6REYsRUFBQUEsUUFBUSxHQUFHRSxTQUFYO0FBQ0Q7QUFFRDtBQUNBO0FBQ0E7O0FBQ0EsZUFBZUMsaUJBQWYsQ0FDRUMsT0FERixFQUVFQyxPQUZGLEVBR0VDLEtBSEYsRUFJRUMsTUFKRixFQUtFQyxPQUxGLEVBTUVDLE9BQWUsR0FBRyxDQU5wQixFQU9FO0FBQ0EsUUFBTTtBQUFFQyxJQUFBQSxTQUFGO0FBQWFDLElBQUFBO0FBQWIsTUFBZ0NOLE9BQXRDO0FBQ0EsUUFBTU8sS0FBSyxHQUFHRixTQUFTLEdBQUdmLHFCQUFxQixDQUFDZSxTQUFELENBQXhCLEdBQXNDRyxTQUE3RDs7QUFDQSxRQUFNO0FBQUVDLElBQUFBLEdBQUY7QUFBT0MsSUFBQUE7QUFBUCxNQUE2QlgsT0FBbkM7QUFBQSxRQUFzQlksUUFBdEIsNEJBQW1DWixPQUFuQzs7QUFDQSxRQUFNYSxVQUFVLEdBQUcsSUFBSXZCLGVBQUosRUFBbkI7QUFDQSxNQUFJd0IsR0FBSjs7QUFDQSxNQUFJO0FBQ0ZBLElBQUFBLEdBQUcsR0FBRyxNQUFNckIsa0JBQWtCLENBQzVCLE1BQ0VKLEtBQUssQ0FBQ3FCLEdBQUQsZ0RBQ0FFLFFBREEsR0FFQ1YsS0FBSyxJQUFJLHNCQUFzQmEsSUFBdEIsQ0FBMkJmLE9BQU8sQ0FBQ2dCLE1BQW5DLENBQVQsR0FDQTtBQUFFTCxNQUFBQSxJQUFJLEVBQUVUO0FBQVIsS0FEQSxHQUVBLEVBSkQ7QUFLSGUsTUFBQUEsUUFBUSxFQUFFLFFBTFA7QUFNSEMsTUFBQUEsTUFBTSxFQUFFTCxVQUFVLENBQUNLLE1BTmhCO0FBT0hWLE1BQUFBO0FBUEcsT0FGcUIsRUFXNUJQLE9BQU8sQ0FBQ2tCLE9BWG9CLEVBWTVCLE1BQU1OLFVBQVUsQ0FBQ08sS0FBWCxFQVpzQixDQUE5QjtBQWNELEdBZkQsQ0FlRSxPQUFPQyxHQUFQLEVBQVk7QUFDWmpCLElBQUFBLE9BQU8sQ0FBQ2tCLElBQVIsQ0FBYSxPQUFiLEVBQXNCRCxHQUF0QjtBQUNBO0FBQ0Q7O0FBQ0QsUUFBTUUsT0FBK0IsR0FBRyxFQUF4Qzs7QUFDQSxPQUFLLE1BQU1DLFVBQVgsSUFBeUIsaUNBQUFWLEdBQUcsQ0FBQ1MsT0FBSixnQkFBekIsRUFBNkM7QUFBQTs7QUFDM0NBLElBQUFBLE9BQU8sQ0FBQ0MsVUFBVSxDQUFDQyxXQUFYLEVBQUQsQ0FBUCxHQUFvQ1gsR0FBRyxDQUFDUyxPQUFKLENBQVlHLEdBQVosQ0FBZ0JGLFVBQWhCLENBQXBDO0FBQ0Q7O0FBQ0QsUUFBTUcsUUFBUSxHQUFHO0FBQ2ZDLElBQUFBLFVBQVUsRUFBRWQsR0FBRyxDQUFDZSxNQUREO0FBRWZOLElBQUFBO0FBRmUsR0FBakI7O0FBSUEsTUFBSWhCLGNBQWMsSUFBSWIsVUFBVSxDQUFDaUMsUUFBUSxDQUFDQyxVQUFWLENBQWhDLEVBQXVEO0FBQ3JELFFBQUk7QUFDRmpDLE1BQUFBLHNCQUFzQixDQUNwQkssT0FEb0IsRUFFcEIyQixRQUZvQixFQUdwQnBCLGNBSG9CLEVBSXBCRixPQUpvQixFQUtuQnlCLEdBQUQsSUFDRS9CLGlCQUFpQixDQUNmK0IsR0FEZSxFQUVmN0IsT0FGZSxFQUdmUSxTQUhlLEVBSWZOLE1BSmUsRUFLZkMsT0FMZSxFQU1mQyxPQUFPLEdBQUcsQ0FOSyxDQU5DLENBQXRCO0FBZUQsS0FoQkQsQ0FnQkUsT0FBT2dCLEdBQVAsRUFBWTtBQUNaakIsTUFBQUEsT0FBTyxDQUFDa0IsSUFBUixDQUFhLE9BQWIsRUFBc0JELEdBQXRCO0FBQ0Q7O0FBQ0Q7QUFDRDs7QUFDRGpCLEVBQUFBLE9BQU8sQ0FBQ2tCLElBQVIsQ0FBYSxVQUFiLEVBQXlCSyxRQUF6QjtBQUNBYixFQUFBQSxHQUFHLENBQUNILElBQUosQ0FBU29CLElBQVQsQ0FBYzVCLE1BQWQ7QUFDRDtBQUVEO0FBQ0E7QUFDQTs7O0FBQ0EsZUFBZSxTQUFTSCxPQUFULENBQ2I4QixHQURhLEVBRWJFLFFBQTRCLEdBQUcsRUFGbEIsRUFHTDtBQUNSLFFBQU0vQixPQUFPLG1DQUFRTCxRQUFSLEdBQXFCb0MsUUFBckIsQ0FBYjs7QUFDQSxRQUFNO0FBQUU5QixJQUFBQSxLQUFGO0FBQVNDLElBQUFBLE1BQVQ7QUFBaUI4QixJQUFBQTtBQUFqQixNQUE0QnpDLCtCQUErQixDQUFDc0MsR0FBRCxDQUFqRTtBQUNBL0IsRUFBQUEsaUJBQWlCLENBQUMrQixHQUFELEVBQU03QixPQUFOLEVBQWVDLEtBQWYsRUFBc0JDLE1BQXRCLEVBQThCOEIsTUFBOUIsQ0FBakI7QUFDQSxTQUFPQSxNQUFQO0FBQ0QiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBFdmVudEVtaXR0ZXIgfSBmcm9tICdldmVudHMnO1xuaW1wb3J0IHsgRHVwbGV4LCBSZWFkYWJsZSwgV3JpdGFibGUgfSBmcm9tICdzdHJlYW0nO1xuaW1wb3J0IGZldGNoIGZyb20gJ25vZGUtZmV0Y2gnO1xuaW1wb3J0IEFib3J0Q29udHJvbGxlciBmcm9tICdhYm9ydC1jb250cm9sbGVyJztcbmltcG9ydCBjcmVhdGVIdHRwc1Byb3h5QWdlbnQgZnJvbSAnaHR0cHMtcHJveHktYWdlbnQnO1xuaW1wb3J0IHtcbiAgY3JlYXRlSHR0cFJlcXVlc3RIYW5kbGVyU3RyZWFtcyxcbiAgZXhlY3V0ZVdpdGhUaW1lb3V0LFxuICBpc1JlZGlyZWN0LFxuICBwZXJmb3JtUmVkaXJlY3RSZXF1ZXN0LFxufSBmcm9tICcuL3JlcXVlc3QtaGVscGVyJztcbmltcG9ydCB7IEh0dHBSZXF1ZXN0LCBIdHRwUmVxdWVzdE9wdGlvbnMgfSBmcm9tICcuL3R5cGVzJztcblxuLyoqXG4gKlxuICovXG5sZXQgZGVmYXVsdHM6IEh0dHBSZXF1ZXN0T3B0aW9ucyA9IHt9O1xuXG4vKipcbiAqXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzZXREZWZhdWx0cyhkZWZhdWx0c186IEh0dHBSZXF1ZXN0T3B0aW9ucykge1xuICBkZWZhdWx0cyA9IGRlZmF1bHRzXztcbn1cblxuLyoqXG4gKlxuICovXG5hc3luYyBmdW5jdGlvbiBzdGFydEZldGNoUmVxdWVzdChcbiAgcmVxdWVzdDogSHR0cFJlcXVlc3QsXG4gIG9wdGlvbnM6IEh0dHBSZXF1ZXN0T3B0aW9ucyxcbiAgaW5wdXQ6IFJlYWRhYmxlIHwgdW5kZWZpbmVkLFxuICBvdXRwdXQ6IFdyaXRhYmxlLFxuICBlbWl0dGVyOiBFdmVudEVtaXR0ZXIsXG4gIGNvdW50ZXI6IG51bWJlciA9IDAsXG4pIHtcbiAgY29uc3QgeyBodHRwUHJveHksIGZvbGxvd1JlZGlyZWN0IH0gPSBvcHRpb25zO1xuICBjb25zdCBhZ2VudCA9IGh0dHBQcm94eSA/IGNyZWF0ZUh0dHBzUHJveHlBZ2VudChodHRwUHJveHkpIDogdW5kZWZpbmVkO1xuICBjb25zdCB7IHVybCwgYm9keSwgLi4ucnJlcXVlc3QgfSA9IHJlcXVlc3Q7XG4gIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gIGxldCByZXM7XG4gIHRyeSB7XG4gICAgcmVzID0gYXdhaXQgZXhlY3V0ZVdpdGhUaW1lb3V0KFxuICAgICAgKCkgPT5cbiAgICAgICAgZmV0Y2godXJsLCB7XG4gICAgICAgICAgLi4ucnJlcXVlc3QsXG4gICAgICAgICAgLi4uKGlucHV0ICYmIC9eKHBvc3R8cHV0fHBhdGNoKSQvaS50ZXN0KHJlcXVlc3QubWV0aG9kKVxuICAgICAgICAgICAgPyB7IGJvZHk6IGlucHV0IH1cbiAgICAgICAgICAgIDoge30pLFxuICAgICAgICAgIHJlZGlyZWN0OiAnbWFudWFsJyxcbiAgICAgICAgICBzaWduYWw6IGNvbnRyb2xsZXIuc2lnbmFsLFxuICAgICAgICAgIGFnZW50LFxuICAgICAgICB9KSxcbiAgICAgIG9wdGlvbnMudGltZW91dCxcbiAgICAgICgpID0+IGNvbnRyb2xsZXIuYWJvcnQoKSxcbiAgICApO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBlbWl0dGVyLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgaGVhZGVyczogeyBba2V5OiBzdHJpbmddOiBhbnkgfSA9IHt9O1xuICBmb3IgKGNvbnN0IGhlYWRlck5hbWUgb2YgcmVzLmhlYWRlcnMua2V5cygpKSB7XG4gICAgaGVhZGVyc1toZWFkZXJOYW1lLnRvTG93ZXJDYXNlKCldID0gcmVzLmhlYWRlcnMuZ2V0KGhlYWRlck5hbWUpO1xuICB9XG4gIGNvbnN0IHJlc3BvbnNlID0ge1xuICAgIHN0YXR1c0NvZGU6IHJlcy5zdGF0dXMsXG4gICAgaGVhZGVycyxcbiAgfTtcbiAgaWYgKGZvbGxvd1JlZGlyZWN0ICYmIGlzUmVkaXJlY3QocmVzcG9uc2Uuc3RhdHVzQ29kZSkpIHtcbiAgICB0cnkge1xuICAgICAgcGVyZm9ybVJlZGlyZWN0UmVxdWVzdChcbiAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgcmVzcG9uc2UsXG4gICAgICAgIGZvbGxvd1JlZGlyZWN0LFxuICAgICAgICBjb3VudGVyLFxuICAgICAgICAocmVxKSA9PlxuICAgICAgICAgIHN0YXJ0RmV0Y2hSZXF1ZXN0KFxuICAgICAgICAgICAgcmVxLFxuICAgICAgICAgICAgb3B0aW9ucyxcbiAgICAgICAgICAgIHVuZGVmaW5lZCxcbiAgICAgICAgICAgIG91dHB1dCxcbiAgICAgICAgICAgIGVtaXR0ZXIsXG4gICAgICAgICAgICBjb3VudGVyICsgMSxcbiAgICAgICAgICApLFxuICAgICAgKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGVtaXR0ZXIuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgIH1cbiAgICByZXR1cm47XG4gIH1cbiAgZW1pdHRlci5lbWl0KCdyZXNwb25zZScsIHJlc3BvbnNlKTtcbiAgcmVzLmJvZHkucGlwZShvdXRwdXQpO1xufVxuXG4vKipcbiAqXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIHJlcXVlc3QoXG4gIHJlcTogSHR0cFJlcXVlc3QsXG4gIG9wdGlvbnNfOiBIdHRwUmVxdWVzdE9wdGlvbnMgPSB7fSxcbik6IER1cGxleCB7XG4gIGNvbnN0IG9wdGlvbnMgPSB7IC4uLmRlZmF1bHRzLCAuLi5vcHRpb25zXyB9O1xuICBjb25zdCB7IGlucHV0LCBvdXRwdXQsIHN0cmVhbSB9ID0gY3JlYXRlSHR0cFJlcXVlc3RIYW5kbGVyU3RyZWFtcyhyZXEpO1xuICBzdGFydEZldGNoUmVxdWVzdChyZXEsIG9wdGlvbnMsIGlucHV0LCBvdXRwdXQsIHN0cmVhbSk7XG4gIHJldHVybiBzdHJlYW07XG59XG4iXX0=