import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import "core-js/modules/es.array.iterator";
import "core-js/modules/es.string.replace";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _objectWithoutProperties from "@babel/runtime-corejs3/helpers/objectWithoutProperties";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _reduceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/reduce";

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context3; _forEachInstanceProperty(_context3 = ownKeys(Object(source), true)).call(_context3, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context4; _forEachInstanceProperty(_context4 = ownKeys(Object(source))).call(_context4, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 * @file Represents stream that handles Salesforce record as stream data
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { Transform, PassThrough } from 'stream';
import { serializeCSVStream, parseCSVStream } from './csv';
import { concatStreamsAsDuplex } from './util/stream';
/**
 * type defs
 */

/**
 * @private
 */
function evalMapping(value, mapping) {
  if (typeof value === 'string') {
    const m = /^\$\{(\w+)\}$/.exec(value);

    if (m) {
      return mapping[m[1]];
    }

    return value.replace(/\$\{(\w+)\}/g, ($0, prop) => {
      const v = mapping[prop];
      return typeof v === 'undefined' || v === null ? '' : String(v);
    });
  }

  return value;
}
/**
 * @private
 */


function convertRecordForSerialization(record, options = {}) {
  var _context;

  return _reduceInstanceProperty(_context = _Object$keys(record)).call(_context, (rec, key) => {
    const value = rec[key];
    let urec;

    if (key === 'attributes') {
      // 'attributes' prop will be ignored
      urec = _objectSpread({}, rec);
      delete urec[key];
      return urec;
    } else if (options.nullValue && value === null) {
      return _objectSpread(_objectSpread({}, rec), {}, {
        [key]: options.nullValue
      });
    } else if (value !== null && typeof value === 'object') {
      var _context2;

      const precord = convertRecordForSerialization(value, options);
      return _reduceInstanceProperty(_context2 = _Object$keys(precord)).call(_context2, (prec, pkey) => {
        prec[`${key}.${pkey}`] = precord[pkey]; // eslint-disable-line no-param-reassign

        return prec;
      }, _objectSpread({}, rec));
    }

    return rec;
  }, record);
}
/**
 * @private
 */


function createPipelineStream(s1, s2) {
  s1.pipe(s2);
  return concatStreamsAsDuplex(s1, s2, {
    writableObjectMode: true
  });
}

/**
 * @private
 */
const CSVStreamConverter = {
  serialize(options = {}) {
    const {
      nullValue
    } = options,
          csvOpts = _objectWithoutProperties(options, ["nullValue"]);

    return createPipelineStream( // eslint-disable-next-line no-use-before-define
    _mapInstanceProperty(RecordStream).call(RecordStream, record => convertRecordForSerialization(record, options)), serializeCSVStream(csvOpts));
  },

  parse(options = {}) {
    return parseCSVStream(options);
  }

};
/**
 * @private
 */

const DataStreamConverters = {
  csv: CSVStreamConverter
};
/**
 * Class for Record Stream
 *
 * @class
 * @constructor
 * @extends stream.Transform
 */

export class RecordStream extends PassThrough {
  /**
   *
   */
  constructor() {
    super({
      objectMode: true
    });

    _defineProperty(this, "addListener", this.on);
  }
  /**
   * Get record stream of queried records applying the given mapping function
   */


  map(fn) {
    return this.pipe(_mapInstanceProperty(RecordStream).call(RecordStream, fn));
  }
  /**
   * Get record stream of queried records, applying the given filter function
   */


  filter(fn) {
    return this.pipe(_filterInstanceProperty(RecordStream).call(RecordStream, fn));
  }
  /* @override */


  on(ev, fn) {
    return super.on(ev === 'record' ? 'data' : ev, fn);
  }
  /* @override */


  /* --------------------------------------------------- */

  /**
   * Create a record stream which maps records and pass them to downstream
   */
  static map(fn) {
    const mapStream = new Transform({
      objectMode: true,

      transform(record, enc, callback) {
        const rec = fn(record) || record; // if not returned record, use same record

        mapStream.push(rec);
        callback();
      }

    });
    return mapStream;
  }
  /**
   * Create mapping stream using given record template
   */


  static recordMapStream(record, noeval) {
    return _mapInstanceProperty(RecordStream).call(RecordStream, rec => {
      const mapped = {
        Id: rec.Id
      };

      for (const prop of _Object$keys(record)) {
        mapped[prop] = noeval ? record[prop] : evalMapping(record[prop], rec);
      }

      return mapped;
    });
  }
  /**
   * Create a record stream which filters records and pass them to downstream
   *
   * @param {RecordFilterFunction} fn - Record filtering function
   * @returns {RecordStream.Serializable}
   */


  static filter(fn) {
    const filterStream = new Transform({
      objectMode: true,

      transform(record, enc, callback) {
        if (fn(record)) {
          filterStream.push(record);
        }

        callback();
      }

    });
    return filterStream;
  }

}
/**
 * @class RecordStream.Serializable
 * @extends {RecordStream}
 */

export class Serializable extends RecordStream {
  constructor(...args) {
    super(...args);

    _defineProperty(this, "_dataStreams", {});
  }

  /**
   * Get readable data stream which emits serialized record data
   */
  stream(type = 'csv', options = {}) {
    if (this._dataStreams[type]) {
      return this._dataStreams[type];
    }

    const converter = DataStreamConverters[type];

    if (!converter) {
      throw new Error(`Converting [${type}] data stream is not supported.`);
    }

    const dataStream = new PassThrough();
    this.pipe(converter.serialize(options)).pipe(dataStream);
    this._dataStreams[type] = dataStream;
    return dataStream;
  }

}
/**
 * @class RecordStream.Parsable
 * @extends {RecordStream}
 */

export class Parsable extends RecordStream {
  constructor(...args) {
    super(...args);

    _defineProperty(this, "_dataStreams", {});

    _defineProperty(this, "_execParse", false);

    _defineProperty(this, "_incomings", []);

    _defineProperty(this, "addListener", this.on);
  }

  /**
   * Get writable data stream which accepts serialized record data
   */
  stream(type = 'csv', options = {}) {
    if (this._dataStreams[type]) {
      return this._dataStreams[type];
    }

    const converter = DataStreamConverters[type];

    if (!converter) {
      throw new Error(`Converting [${type}] data stream is not supported.`);
    }

    const dataStream = new PassThrough();
    const parserStream = converter.parse(options);
    parserStream.on('error', err => this.emit('error', err));
    parserStream.pipe(this).pipe(new PassThrough({
      objectMode: true,
      highWaterMark: 500 * 1000
    }));

    if (this._execParse) {
      dataStream.pipe(parserStream);
    } else {
      this._incomings.push([dataStream, parserStream]);
    }

    this._dataStreams[type] = dataStream;
    return dataStream;
  }
  /* @override */


  on(ev, fn) {
    if (ev === 'readable' || ev === 'record') {
      if (!this._execParse) {
        this._execParse = true;

        for (const [dataStream, parserStream] of this._incomings) {
          dataStream.pipe(parserStream);
        }
      }
    }

    return super.on(ev, fn);
  }
  /* @override */


}
export default RecordStream;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9yZWNvcmQtc3RyZWFtLnRzIl0sIm5hbWVzIjpbIlRyYW5zZm9ybSIsIlBhc3NUaHJvdWdoIiwic2VyaWFsaXplQ1NWU3RyZWFtIiwicGFyc2VDU1ZTdHJlYW0iLCJjb25jYXRTdHJlYW1zQXNEdXBsZXgiLCJldmFsTWFwcGluZyIsInZhbHVlIiwibWFwcGluZyIsIm0iLCJleGVjIiwicmVwbGFjZSIsIiQwIiwicHJvcCIsInYiLCJTdHJpbmciLCJjb252ZXJ0UmVjb3JkRm9yU2VyaWFsaXphdGlvbiIsInJlY29yZCIsIm9wdGlvbnMiLCJyZWMiLCJrZXkiLCJ1cmVjIiwibnVsbFZhbHVlIiwicHJlY29yZCIsInByZWMiLCJwa2V5IiwiY3JlYXRlUGlwZWxpbmVTdHJlYW0iLCJzMSIsInMyIiwicGlwZSIsIndyaXRhYmxlT2JqZWN0TW9kZSIsIkNTVlN0cmVhbUNvbnZlcnRlciIsInNlcmlhbGl6ZSIsImNzdk9wdHMiLCJSZWNvcmRTdHJlYW0iLCJwYXJzZSIsIkRhdGFTdHJlYW1Db252ZXJ0ZXJzIiwiY3N2IiwiY29uc3RydWN0b3IiLCJvYmplY3RNb2RlIiwib24iLCJtYXAiLCJmbiIsImZpbHRlciIsImV2IiwibWFwU3RyZWFtIiwidHJhbnNmb3JtIiwiZW5jIiwiY2FsbGJhY2siLCJwdXNoIiwicmVjb3JkTWFwU3RyZWFtIiwibm9ldmFsIiwibWFwcGVkIiwiSWQiLCJmaWx0ZXJTdHJlYW0iLCJTZXJpYWxpemFibGUiLCJzdHJlYW0iLCJ0eXBlIiwiX2RhdGFTdHJlYW1zIiwiY29udmVydGVyIiwiRXJyb3IiLCJkYXRhU3RyZWFtIiwiUGFyc2FibGUiLCJwYXJzZXJTdHJlYW0iLCJlcnIiLCJlbWl0IiwiaGlnaFdhdGVyTWFyayIsIl9leGVjUGFyc2UiLCJfaW5jb21pbmdzIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFxQ0EsU0FBckMsRUFBZ0RDLFdBQWhELFFBQW1FLFFBQW5FO0FBRUEsU0FBU0Msa0JBQVQsRUFBNkJDLGNBQTdCLFFBQW1ELE9BQW5EO0FBQ0EsU0FBU0MscUJBQVQsUUFBc0MsZUFBdEM7QUFFQTtBQUNBO0FBQ0E7O0FBT0E7QUFDQTtBQUNBO0FBQ0EsU0FBU0MsV0FBVCxDQUFxQkMsS0FBckIsRUFBaUNDLE9BQWpDLEVBQXNFO0FBQ3BFLE1BQUksT0FBT0QsS0FBUCxLQUFpQixRQUFyQixFQUErQjtBQUM3QixVQUFNRSxDQUFDLEdBQUcsZ0JBQWdCQyxJQUFoQixDQUFxQkgsS0FBckIsQ0FBVjs7QUFDQSxRQUFJRSxDQUFKLEVBQU87QUFDTCxhQUFPRCxPQUFPLENBQUNDLENBQUMsQ0FBQyxDQUFELENBQUYsQ0FBZDtBQUNEOztBQUNELFdBQU9GLEtBQUssQ0FBQ0ksT0FBTixDQUFjLGNBQWQsRUFBOEIsQ0FBQ0MsRUFBRCxFQUFLQyxJQUFMLEtBQWM7QUFDakQsWUFBTUMsQ0FBQyxHQUFHTixPQUFPLENBQUNLLElBQUQsQ0FBakI7QUFDQSxhQUFPLE9BQU9DLENBQVAsS0FBYSxXQUFiLElBQTRCQSxDQUFDLEtBQUssSUFBbEMsR0FBeUMsRUFBekMsR0FBOENDLE1BQU0sQ0FBQ0QsQ0FBRCxDQUEzRDtBQUNELEtBSE0sQ0FBUDtBQUlEOztBQUNELFNBQU9QLEtBQVA7QUFDRDtBQUVEO0FBQ0E7QUFDQTs7O0FBQ0EsU0FBU1MsNkJBQVQsQ0FDRUMsTUFERixFQUVFQyxPQUFnQyxHQUFHLEVBRnJDLEVBR1U7QUFBQTs7QUFDUixTQUFPLGdEQUFZRCxNQUFaLGtCQUEyQixDQUFDRSxHQUFELEVBQWNDLEdBQWQsS0FBOEI7QUFDOUQsVUFBTWIsS0FBSyxHQUFJWSxHQUFELENBQWFDLEdBQWIsQ0FBZDtBQUNBLFFBQUlDLElBQUo7O0FBQ0EsUUFBSUQsR0FBRyxLQUFLLFlBQVosRUFBMEI7QUFDeEI7QUFDQUMsTUFBQUEsSUFBSSxxQkFBUUYsR0FBUixDQUFKO0FBQ0EsYUFBT0UsSUFBSSxDQUFDRCxHQUFELENBQVg7QUFDQSxhQUFPQyxJQUFQO0FBQ0QsS0FMRCxNQUtPLElBQUlILE9BQU8sQ0FBQ0ksU0FBUixJQUFxQmYsS0FBSyxLQUFLLElBQW5DLEVBQXlDO0FBQzlDLDZDQUFZWSxHQUFaO0FBQWlCLFNBQUNDLEdBQUQsR0FBT0YsT0FBTyxDQUFDSTtBQUFoQztBQUNELEtBRk0sTUFFQSxJQUFJZixLQUFLLEtBQUssSUFBVixJQUFrQixPQUFPQSxLQUFQLEtBQWlCLFFBQXZDLEVBQWlEO0FBQUE7O0FBQ3RELFlBQU1nQixPQUFPLEdBQUdQLDZCQUE2QixDQUFDVCxLQUFELEVBQVFXLE9BQVIsQ0FBN0M7QUFDQSxhQUFPLGlEQUFZSyxPQUFaLG1CQUNMLENBQUNDLElBQUQsRUFBZUMsSUFBZixLQUF3QjtBQUN0QkQsUUFBQUEsSUFBSSxDQUFFLEdBQUVKLEdBQUksSUFBR0ssSUFBSyxFQUFoQixDQUFKLEdBQXlCRixPQUFPLENBQUNFLElBQUQsQ0FBaEMsQ0FEc0IsQ0FDa0I7O0FBQ3hDLGVBQU9ELElBQVA7QUFDRCxPQUpJLG9CQUtBTCxHQUxBLEVBQVA7QUFPRDs7QUFDRCxXQUFPQSxHQUFQO0FBQ0QsR0FyQk0sRUFxQkpGLE1BckJJLENBQVA7QUFzQkQ7QUFFRDtBQUNBO0FBQ0E7OztBQUNBLFNBQVNTLG9CQUFULENBQThCQyxFQUE5QixFQUEwQ0MsRUFBMUMsRUFBc0Q7QUFDcERELEVBQUFBLEVBQUUsQ0FBQ0UsSUFBSCxDQUFRRCxFQUFSO0FBQ0EsU0FBT3ZCLHFCQUFxQixDQUFDc0IsRUFBRCxFQUFLQyxFQUFMLEVBQVM7QUFBRUUsSUFBQUEsa0JBQWtCLEVBQUU7QUFBdEIsR0FBVCxDQUE1QjtBQUNEOztBQU9EO0FBQ0E7QUFDQTtBQUNBLE1BQU1DLGtCQUFtQyxHQUFHO0FBQzFDQyxFQUFBQSxTQUFTLENBQUNkLE9BQW9DLEdBQUcsRUFBeEMsRUFBNEM7QUFDbkQsVUFBTTtBQUFFSSxNQUFBQTtBQUFGLFFBQTRCSixPQUFsQztBQUFBLFVBQXNCZSxPQUF0Qiw0QkFBa0NmLE9BQWxDOztBQUNBLFdBQU9RLG9CQUFvQixFQUN6QjtBQUNBLHlCQUFBUSxZQUFZLE1BQVosQ0FBQUEsWUFBWSxFQUFNakIsTUFBRCxJQUNmRCw2QkFBNkIsQ0FBQ0MsTUFBRCxFQUFTQyxPQUFULENBRG5CLENBRmEsRUFLekJmLGtCQUFrQixDQUFDOEIsT0FBRCxDQUxPLENBQTNCO0FBT0QsR0FWeUM7O0FBVzFDRSxFQUFBQSxLQUFLLENBQUNqQixPQUFnQyxHQUFHLEVBQXBDLEVBQXdDO0FBQzNDLFdBQU9kLGNBQWMsQ0FBQ2MsT0FBRCxDQUFyQjtBQUNEOztBQWJ5QyxDQUE1QztBQWdCQTtBQUNBO0FBQ0E7O0FBQ0EsTUFBTWtCLG9CQUF3RCxHQUFHO0FBQy9EQyxFQUFBQSxHQUFHLEVBQUVOO0FBRDBELENBQWpFO0FBSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EsT0FBTyxNQUFNRyxZQUFOLFNBQXNEaEMsV0FBdEQsQ0FBa0U7QUFDdkU7QUFDRjtBQUNBO0FBQ0VvQyxFQUFBQSxXQUFXLEdBQUc7QUFDWixVQUFNO0FBQUVDLE1BQUFBLFVBQVUsRUFBRTtBQUFkLEtBQU47O0FBRFkseUNBd0JBLEtBQUtDLEVBeEJMO0FBRWI7QUFFRDtBQUNGO0FBQ0E7OztBQUNFQyxFQUFBQSxHQUFHLENBQW9CQyxFQUFwQixFQUFrRDtBQUNuRCxXQUFPLEtBQUtiLElBQUwsQ0FBVSxxQkFBQUssWUFBWSxNQUFaLENBQUFBLFlBQVksRUFBWVEsRUFBWixDQUF0QixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFQyxFQUFBQSxNQUFNLENBQUNELEVBQUQsRUFBa0M7QUFDdEMsV0FBTyxLQUFLYixJQUFMLENBQVUsd0JBQUFLLFlBQVksTUFBWixDQUFBQSxZQUFZLEVBQVdRLEVBQVgsQ0FBdEIsQ0FBUDtBQUNEO0FBRUQ7OztBQUNBRixFQUFBQSxFQUFFLENBQUNJLEVBQUQsRUFBYUYsRUFBYixFQUEyQztBQUMzQyxXQUFPLE1BQU1GLEVBQU4sQ0FBU0ksRUFBRSxLQUFLLFFBQVAsR0FBa0IsTUFBbEIsR0FBMkJBLEVBQXBDLEVBQXdDRixFQUF4QyxDQUFQO0FBQ0Q7QUFFRDs7O0FBR0E7O0FBRUE7QUFDRjtBQUNBO0FBQ0UsU0FBT0QsR0FBUCxDQUNFQyxFQURGLEVBRUU7QUFDQSxVQUFNRyxTQUFTLEdBQUcsSUFBSTVDLFNBQUosQ0FBYztBQUM5QnNDLE1BQUFBLFVBQVUsRUFBRSxJQURrQjs7QUFFOUJPLE1BQUFBLFNBQVMsQ0FBQzdCLE1BQUQsRUFBUzhCLEdBQVQsRUFBY0MsUUFBZCxFQUF3QjtBQUMvQixjQUFNN0IsR0FBRyxHQUFHdUIsRUFBRSxDQUFDekIsTUFBRCxDQUFGLElBQWNBLE1BQTFCLENBRCtCLENBQ0c7O0FBQ2xDNEIsUUFBQUEsU0FBUyxDQUFDSSxJQUFWLENBQWU5QixHQUFmO0FBQ0E2QixRQUFBQSxRQUFRO0FBQ1Q7O0FBTjZCLEtBQWQsQ0FBbEI7QUFRQSxXQUFPSCxTQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7OztBQUNFLFNBQU9LLGVBQVAsQ0FHRWpDLE1BSEYsRUFHY2tDLE1BSGQsRUFHZ0M7QUFDOUIsV0FBTyxxQkFBQWpCLFlBQVksTUFBWixDQUFBQSxZQUFZLEVBQWNmLEdBQUQsSUFBUztBQUN2QyxZQUFNaUMsTUFBYyxHQUFHO0FBQUVDLFFBQUFBLEVBQUUsRUFBRWxDLEdBQUcsQ0FBQ2tDO0FBQVYsT0FBdkI7O0FBQ0EsV0FBSyxNQUFNeEMsSUFBWCxJQUFtQixhQUFZSSxNQUFaLENBQW5CLEVBQXdDO0FBQ3RDbUMsUUFBQUEsTUFBTSxDQUFDdkMsSUFBRCxDQUFOLEdBQWVzQyxNQUFNLEdBQUdsQyxNQUFNLENBQUNKLElBQUQsQ0FBVCxHQUFrQlAsV0FBVyxDQUFDVyxNQUFNLENBQUNKLElBQUQsQ0FBUCxFQUFlTSxHQUFmLENBQWxEO0FBQ0Q7O0FBQ0QsYUFBT2lDLE1BQVA7QUFDRCxLQU5rQixDQUFuQjtBQU9EO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRSxTQUFPVCxNQUFQLENBQTBDRCxFQUExQyxFQUE0RTtBQUMxRSxVQUFNWSxZQUFZLEdBQUcsSUFBSXJELFNBQUosQ0FBYztBQUNqQ3NDLE1BQUFBLFVBQVUsRUFBRSxJQURxQjs7QUFFakNPLE1BQUFBLFNBQVMsQ0FBQzdCLE1BQUQsRUFBUzhCLEdBQVQsRUFBY0MsUUFBZCxFQUF3QjtBQUMvQixZQUFJTixFQUFFLENBQUN6QixNQUFELENBQU4sRUFBZ0I7QUFDZHFDLFVBQUFBLFlBQVksQ0FBQ0wsSUFBYixDQUFrQmhDLE1BQWxCO0FBQ0Q7O0FBQ0QrQixRQUFBQSxRQUFRO0FBQ1Q7O0FBUGdDLEtBQWQsQ0FBckI7QUFTQSxXQUFPTSxZQUFQO0FBQ0Q7O0FBbEZzRTtBQXFGekU7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EsT0FBTyxNQUFNQyxZQUFOLFNBQXNEckIsWUFBdEQsQ0FBc0U7QUFBQTtBQUFBOztBQUFBLDBDQUNoQyxFQURnQztBQUFBOztBQUczRTtBQUNGO0FBQ0E7QUFDRXNCLEVBQUFBLE1BQU0sQ0FBQ0MsSUFBWSxHQUFHLEtBQWhCLEVBQXVCdkMsT0FBZSxHQUFHLEVBQXpDLEVBQXFEO0FBQ3pELFFBQUksS0FBS3dDLFlBQUwsQ0FBa0JELElBQWxCLENBQUosRUFBNkI7QUFDM0IsYUFBTyxLQUFLQyxZQUFMLENBQWtCRCxJQUFsQixDQUFQO0FBQ0Q7O0FBQ0QsVUFBTUUsU0FBb0MsR0FBR3ZCLG9CQUFvQixDQUFDcUIsSUFBRCxDQUFqRTs7QUFDQSxRQUFJLENBQUNFLFNBQUwsRUFBZ0I7QUFDZCxZQUFNLElBQUlDLEtBQUosQ0FBVyxlQUFjSCxJQUFLLGlDQUE5QixDQUFOO0FBQ0Q7O0FBQ0QsVUFBTUksVUFBVSxHQUFHLElBQUkzRCxXQUFKLEVBQW5CO0FBQ0EsU0FBSzJCLElBQUwsQ0FBVThCLFNBQVMsQ0FBQzNCLFNBQVYsQ0FBb0JkLE9BQXBCLENBQVYsRUFBd0NXLElBQXhDLENBQTZDZ0MsVUFBN0M7QUFDQSxTQUFLSCxZQUFMLENBQWtCRCxJQUFsQixJQUEwQkksVUFBMUI7QUFDQSxXQUFPQSxVQUFQO0FBQ0Q7O0FBbEIwRTtBQXFCN0U7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EsT0FBTyxNQUFNQyxRQUFOLFNBQWtENUIsWUFBbEQsQ0FBa0U7QUFBQTtBQUFBOztBQUFBLDBDQUM1QixFQUQ0Qjs7QUFBQSx3Q0FFakQsS0FGaUQ7O0FBQUEsd0NBRzdCLEVBSDZCOztBQUFBLHlDQTZDekQsS0FBS00sRUE3Q29EO0FBQUE7O0FBS3ZFO0FBQ0Y7QUFDQTtBQUNFZ0IsRUFBQUEsTUFBTSxDQUFDQyxJQUFZLEdBQUcsS0FBaEIsRUFBdUJ2QyxPQUFlLEdBQUcsRUFBekMsRUFBcUQ7QUFDekQsUUFBSSxLQUFLd0MsWUFBTCxDQUFrQkQsSUFBbEIsQ0FBSixFQUE2QjtBQUMzQixhQUFPLEtBQUtDLFlBQUwsQ0FBa0JELElBQWxCLENBQVA7QUFDRDs7QUFDRCxVQUFNRSxTQUFvQyxHQUFHdkIsb0JBQW9CLENBQUNxQixJQUFELENBQWpFOztBQUNBLFFBQUksQ0FBQ0UsU0FBTCxFQUFnQjtBQUNkLFlBQU0sSUFBSUMsS0FBSixDQUFXLGVBQWNILElBQUssaUNBQTlCLENBQU47QUFDRDs7QUFDRCxVQUFNSSxVQUFVLEdBQUcsSUFBSTNELFdBQUosRUFBbkI7QUFDQSxVQUFNNkQsWUFBWSxHQUFHSixTQUFTLENBQUN4QixLQUFWLENBQWdCakIsT0FBaEIsQ0FBckI7QUFDQTZDLElBQUFBLFlBQVksQ0FBQ3ZCLEVBQWIsQ0FBZ0IsT0FBaEIsRUFBMEJ3QixHQUFELElBQVMsS0FBS0MsSUFBTCxDQUFVLE9BQVYsRUFBbUJELEdBQW5CLENBQWxDO0FBQ0FELElBQUFBLFlBQVksQ0FDVGxDLElBREgsQ0FDUSxJQURSLEVBRUdBLElBRkgsQ0FFUSxJQUFJM0IsV0FBSixDQUFnQjtBQUFFcUMsTUFBQUEsVUFBVSxFQUFFLElBQWQ7QUFBb0IyQixNQUFBQSxhQUFhLEVBQUUsTUFBTTtBQUF6QyxLQUFoQixDQUZSOztBQUdBLFFBQUksS0FBS0MsVUFBVCxFQUFxQjtBQUNuQk4sTUFBQUEsVUFBVSxDQUFDaEMsSUFBWCxDQUFnQmtDLFlBQWhCO0FBQ0QsS0FGRCxNQUVPO0FBQ0wsV0FBS0ssVUFBTCxDQUFnQm5CLElBQWhCLENBQXFCLENBQUNZLFVBQUQsRUFBYUUsWUFBYixDQUFyQjtBQUNEOztBQUNELFNBQUtMLFlBQUwsQ0FBa0JELElBQWxCLElBQTBCSSxVQUExQjtBQUNBLFdBQU9BLFVBQVA7QUFDRDtBQUVEOzs7QUFDQXJCLEVBQUFBLEVBQUUsQ0FBQ0ksRUFBRCxFQUFhRixFQUFiLEVBQTJDO0FBQzNDLFFBQUlFLEVBQUUsS0FBSyxVQUFQLElBQXFCQSxFQUFFLEtBQUssUUFBaEMsRUFBMEM7QUFDeEMsVUFBSSxDQUFDLEtBQUt1QixVQUFWLEVBQXNCO0FBQ3BCLGFBQUtBLFVBQUwsR0FBa0IsSUFBbEI7O0FBQ0EsYUFBSyxNQUFNLENBQUNOLFVBQUQsRUFBYUUsWUFBYixDQUFYLElBQXlDLEtBQUtLLFVBQTlDLEVBQTBEO0FBQ3hEUCxVQUFBQSxVQUFVLENBQUNoQyxJQUFYLENBQWdCa0MsWUFBaEI7QUFDRDtBQUNGO0FBQ0Y7O0FBQ0QsV0FBTyxNQUFNdkIsRUFBTixDQUFTSSxFQUFULEVBQWFGLEVBQWIsQ0FBUDtBQUNEO0FBRUQ7OztBQTVDdUU7QUFnRHpFLGVBQWVSLFlBQWYiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBmaWxlIFJlcHJlc2VudHMgc3RyZWFtIHRoYXQgaGFuZGxlcyBTYWxlc2ZvcmNlIHJlY29yZCBhcyBzdHJlYW0gZGF0YVxuICogQGF1dGhvciBTaGluaWNoaSBUb21pdGEgPHNoaW5pY2hpLnRvbWl0YUBnbWFpbC5jb20+XG4gKi9cbmltcG9ydCB7IFJlYWRhYmxlLCBXcml0YWJsZSwgRHVwbGV4LCBUcmFuc2Zvcm0sIFBhc3NUaHJvdWdoIH0gZnJvbSAnc3RyZWFtJztcbmltcG9ydCB7IFJlY29yZCwgT3B0aW9uYWwgfSBmcm9tICcuL3R5cGVzJztcbmltcG9ydCB7IHNlcmlhbGl6ZUNTVlN0cmVhbSwgcGFyc2VDU1ZTdHJlYW0gfSBmcm9tICcuL2Nzdic7XG5pbXBvcnQgeyBjb25jYXRTdHJlYW1zQXNEdXBsZXggfSBmcm9tICcuL3V0aWwvc3RyZWFtJztcblxuLyoqXG4gKiB0eXBlIGRlZnNcbiAqL1xuZXhwb3J0IHR5cGUgUmVjb3JkU3RyZWFtU2VyaWFsaXplT3B0aW9uID0ge1xuICBudWxsVmFsdWU/OiBhbnk7XG59O1xuXG5leHBvcnQgdHlwZSBSZWNvcmRTdHJlYW1QYXJzZU9wdGlvbiA9IHt9O1xuXG4vKipcbiAqIEBwcml2YXRlXG4gKi9cbmZ1bmN0aW9uIGV2YWxNYXBwaW5nKHZhbHVlOiBhbnksIG1hcHBpbmc6IHsgW3Byb3A6IHN0cmluZ106IHN0cmluZyB9KSB7XG4gIGlmICh0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnKSB7XG4gICAgY29uc3QgbSA9IC9eXFwkXFx7KFxcdyspXFx9JC8uZXhlYyh2YWx1ZSk7XG4gICAgaWYgKG0pIHtcbiAgICAgIHJldHVybiBtYXBwaW5nW21bMV1dO1xuICAgIH1cbiAgICByZXR1cm4gdmFsdWUucmVwbGFjZSgvXFwkXFx7KFxcdyspXFx9L2csICgkMCwgcHJvcCkgPT4ge1xuICAgICAgY29uc3QgdiA9IG1hcHBpbmdbcHJvcF07XG4gICAgICByZXR1cm4gdHlwZW9mIHYgPT09ICd1bmRlZmluZWQnIHx8IHYgPT09IG51bGwgPyAnJyA6IFN0cmluZyh2KTtcbiAgICB9KTtcbiAgfVxuICByZXR1cm4gdmFsdWU7XG59XG5cbi8qKlxuICogQHByaXZhdGVcbiAqL1xuZnVuY3Rpb24gY29udmVydFJlY29yZEZvclNlcmlhbGl6YXRpb24oXG4gIHJlY29yZDogUmVjb3JkLFxuICBvcHRpb25zOiB7IG51bGxWYWx1ZT86IGJvb2xlYW4gfSA9IHt9LFxuKTogUmVjb3JkIHtcbiAgcmV0dXJuIE9iamVjdC5rZXlzKHJlY29yZCkucmVkdWNlKChyZWM6IFJlY29yZCwga2V5OiBzdHJpbmcpID0+IHtcbiAgICBjb25zdCB2YWx1ZSA9IChyZWMgYXMgYW55KVtrZXldO1xuICAgIGxldCB1cmVjOiBSZWNvcmQ7XG4gICAgaWYgKGtleSA9PT0gJ2F0dHJpYnV0ZXMnKSB7XG4gICAgICAvLyAnYXR0cmlidXRlcycgcHJvcCB3aWxsIGJlIGlnbm9yZWRcbiAgICAgIHVyZWMgPSB7IC4uLnJlYyB9O1xuICAgICAgZGVsZXRlIHVyZWNba2V5XTtcbiAgICAgIHJldHVybiB1cmVjO1xuICAgIH0gZWxzZSBpZiAob3B0aW9ucy5udWxsVmFsdWUgJiYgdmFsdWUgPT09IG51bGwpIHtcbiAgICAgIHJldHVybiB7IC4uLnJlYywgW2tleV06IG9wdGlvbnMubnVsbFZhbHVlIH0gYXMgUmVjb3JkO1xuICAgIH0gZWxzZSBpZiAodmFsdWUgIT09IG51bGwgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0Jykge1xuICAgICAgY29uc3QgcHJlY29yZCA9IGNvbnZlcnRSZWNvcmRGb3JTZXJpYWxpemF0aW9uKHZhbHVlLCBvcHRpb25zKTtcbiAgICAgIHJldHVybiBPYmplY3Qua2V5cyhwcmVjb3JkKS5yZWR1Y2UoXG4gICAgICAgIChwcmVjOiBSZWNvcmQsIHBrZXkpID0+IHtcbiAgICAgICAgICBwcmVjW2Ake2tleX0uJHtwa2V5fWBdID0gcHJlY29yZFtwa2V5XTsgLy8gZXNsaW50LWRpc2FibGUtbGluZSBuby1wYXJhbS1yZWFzc2lnblxuICAgICAgICAgIHJldHVybiBwcmVjO1xuICAgICAgICB9LFxuICAgICAgICB7IC4uLnJlYyB9LFxuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIHJlYztcbiAgfSwgcmVjb3JkKTtcbn1cblxuLyoqXG4gKiBAcHJpdmF0ZVxuICovXG5mdW5jdGlvbiBjcmVhdGVQaXBlbGluZVN0cmVhbShzMTogRHVwbGV4LCBzMjogRHVwbGV4KSB7XG4gIHMxLnBpcGUoczIpO1xuICByZXR1cm4gY29uY2F0U3RyZWFtc0FzRHVwbGV4KHMxLCBzMiwgeyB3cml0YWJsZU9iamVjdE1vZGU6IHRydWUgfSk7XG59XG5cbnR5cGUgU3RyZWFtQ29udmVydGVyID0ge1xuICBzZXJpYWxpemU6IChvcHRpb25zPzogUmVjb3JkU3RyZWFtU2VyaWFsaXplT3B0aW9uKSA9PiBEdXBsZXg7XG4gIHBhcnNlOiAob3B0aW9ucz86IFJlY29yZFN0cmVhbVBhcnNlT3B0aW9uKSA9PiBEdXBsZXg7XG59O1xuXG4vKipcbiAqIEBwcml2YXRlXG4gKi9cbmNvbnN0IENTVlN0cmVhbUNvbnZlcnRlcjogU3RyZWFtQ29udmVydGVyID0ge1xuICBzZXJpYWxpemUob3B0aW9uczogUmVjb3JkU3RyZWFtU2VyaWFsaXplT3B0aW9uID0ge30pIHtcbiAgICBjb25zdCB7IG51bGxWYWx1ZSwgLi4uY3N2T3B0cyB9ID0gb3B0aW9ucztcbiAgICByZXR1cm4gY3JlYXRlUGlwZWxpbmVTdHJlYW0oXG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tdXNlLWJlZm9yZS1kZWZpbmVcbiAgICAgIFJlY29yZFN0cmVhbS5tYXAoKHJlY29yZCkgPT5cbiAgICAgICAgY29udmVydFJlY29yZEZvclNlcmlhbGl6YXRpb24ocmVjb3JkLCBvcHRpb25zKSxcbiAgICAgICksXG4gICAgICBzZXJpYWxpemVDU1ZTdHJlYW0oY3N2T3B0cyksXG4gICAgKTtcbiAgfSxcbiAgcGFyc2Uob3B0aW9uczogUmVjb3JkU3RyZWFtUGFyc2VPcHRpb24gPSB7fSkge1xuICAgIHJldHVybiBwYXJzZUNTVlN0cmVhbShvcHRpb25zKTtcbiAgfSxcbn07XG5cbi8qKlxuICogQHByaXZhdGVcbiAqL1xuY29uc3QgRGF0YVN0cmVhbUNvbnZlcnRlcnM6IHsgW2tleTogc3RyaW5nXTogU3RyZWFtQ29udmVydGVyIH0gPSB7XG4gIGNzdjogQ1NWU3RyZWFtQ29udmVydGVyLFxufTtcblxuLyoqXG4gKiBDbGFzcyBmb3IgUmVjb3JkIFN0cmVhbVxuICpcbiAqIEBjbGFzc1xuICogQGNvbnN0cnVjdG9yXG4gKiBAZXh0ZW5kcyBzdHJlYW0uVHJhbnNmb3JtXG4gKi9cbmV4cG9ydCBjbGFzcyBSZWNvcmRTdHJlYW08UiBleHRlbmRzIFJlY29yZCA9IFJlY29yZD4gZXh0ZW5kcyBQYXNzVGhyb3VnaCB7XG4gIC8qKlxuICAgKlxuICAgKi9cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoeyBvYmplY3RNb2RlOiB0cnVlIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIEdldCByZWNvcmQgc3RyZWFtIG9mIHF1ZXJpZWQgcmVjb3JkcyBhcHBseWluZyB0aGUgZ2l2ZW4gbWFwcGluZyBmdW5jdGlvblxuICAgKi9cbiAgbWFwPFJSIGV4dGVuZHMgUmVjb3JkPihmbjogKHJlYzogUikgPT4gT3B0aW9uYWw8UlI+KSB7XG4gICAgcmV0dXJuIHRoaXMucGlwZShSZWNvcmRTdHJlYW0ubWFwPFIsIFJSPihmbikpO1xuICB9XG5cbiAgLyoqXG4gICAqIEdldCByZWNvcmQgc3RyZWFtIG9mIHF1ZXJpZWQgcmVjb3JkcywgYXBwbHlpbmcgdGhlIGdpdmVuIGZpbHRlciBmdW5jdGlvblxuICAgKi9cbiAgZmlsdGVyKGZuOiAocmVjOiBSKSA9PiBib29sZWFuKTogRHVwbGV4IHtcbiAgICByZXR1cm4gdGhpcy5waXBlKFJlY29yZFN0cmVhbS5maWx0ZXI8Uj4oZm4pKTtcbiAgfVxuXG4gIC8qIEBvdmVycmlkZSAqL1xuICBvbihldjogc3RyaW5nLCBmbjogKC4uLmFyZ3M6IGFueVtdKSA9PiB2b2lkKSB7XG4gICAgcmV0dXJuIHN1cGVyLm9uKGV2ID09PSAncmVjb3JkJyA/ICdkYXRhJyA6IGV2LCBmbik7XG4gIH1cblxuICAvKiBAb3ZlcnJpZGUgKi9cbiAgYWRkTGlzdGVuZXIgPSB0aGlzLm9uO1xuXG4gIC8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG4gIC8qKlxuICAgKiBDcmVhdGUgYSByZWNvcmQgc3RyZWFtIHdoaWNoIG1hcHMgcmVjb3JkcyBhbmQgcGFzcyB0aGVtIHRvIGRvd25zdHJlYW1cbiAgICovXG4gIHN0YXRpYyBtYXA8UjEgZXh0ZW5kcyBSZWNvcmQgPSBSZWNvcmQsIFIyIGV4dGVuZHMgUmVjb3JkID0gUmVjb3JkPihcbiAgICBmbjogKHJlYzogUjEpID0+IE9wdGlvbmFsPFIyPixcbiAgKSB7XG4gICAgY29uc3QgbWFwU3RyZWFtID0gbmV3IFRyYW5zZm9ybSh7XG4gICAgICBvYmplY3RNb2RlOiB0cnVlLFxuICAgICAgdHJhbnNmb3JtKHJlY29yZCwgZW5jLCBjYWxsYmFjaykge1xuICAgICAgICBjb25zdCByZWMgPSBmbihyZWNvcmQpIHx8IHJlY29yZDsgLy8gaWYgbm90IHJldHVybmVkIHJlY29yZCwgdXNlIHNhbWUgcmVjb3JkXG4gICAgICAgIG1hcFN0cmVhbS5wdXNoKHJlYyk7XG4gICAgICAgIGNhbGxiYWNrKCk7XG4gICAgICB9LFxuICAgIH0pO1xuICAgIHJldHVybiBtYXBTdHJlYW07XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlIG1hcHBpbmcgc3RyZWFtIHVzaW5nIGdpdmVuIHJlY29yZCB0ZW1wbGF0ZVxuICAgKi9cbiAgc3RhdGljIHJlY29yZE1hcFN0cmVhbTxcbiAgICBSMSBleHRlbmRzIFJlY29yZCA9IFJlY29yZCxcbiAgICBSMiBleHRlbmRzIFJlY29yZCA9IFJlY29yZFxuICA+KHJlY29yZDogUjIsIG5vZXZhbD86IGJvb2xlYW4pIHtcbiAgICByZXR1cm4gUmVjb3JkU3RyZWFtLm1hcDxSMSwgUjI+KChyZWMpID0+IHtcbiAgICAgIGNvbnN0IG1hcHBlZDogUmVjb3JkID0geyBJZDogcmVjLklkIH07XG4gICAgICBmb3IgKGNvbnN0IHByb3Agb2YgT2JqZWN0LmtleXMocmVjb3JkKSkge1xuICAgICAgICBtYXBwZWRbcHJvcF0gPSBub2V2YWwgPyByZWNvcmRbcHJvcF0gOiBldmFsTWFwcGluZyhyZWNvcmRbcHJvcF0sIHJlYyk7XG4gICAgICB9XG4gICAgICByZXR1cm4gbWFwcGVkIGFzIFIyO1xuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhIHJlY29yZCBzdHJlYW0gd2hpY2ggZmlsdGVycyByZWNvcmRzIGFuZCBwYXNzIHRoZW0gdG8gZG93bnN0cmVhbVxuICAgKlxuICAgKiBAcGFyYW0ge1JlY29yZEZpbHRlckZ1bmN0aW9ufSBmbiAtIFJlY29yZCBmaWx0ZXJpbmcgZnVuY3Rpb25cbiAgICogQHJldHVybnMge1JlY29yZFN0cmVhbS5TZXJpYWxpemFibGV9XG4gICAqL1xuICBzdGF0aWMgZmlsdGVyPFIxIGV4dGVuZHMgUmVjb3JkID0gUmVjb3JkPihmbjogKHJlYzogUjEpID0+IGJvb2xlYW4pOiBEdXBsZXgge1xuICAgIGNvbnN0IGZpbHRlclN0cmVhbSA9IG5ldyBUcmFuc2Zvcm0oe1xuICAgICAgb2JqZWN0TW9kZTogdHJ1ZSxcbiAgICAgIHRyYW5zZm9ybShyZWNvcmQsIGVuYywgY2FsbGJhY2spIHtcbiAgICAgICAgaWYgKGZuKHJlY29yZCkpIHtcbiAgICAgICAgICBmaWx0ZXJTdHJlYW0ucHVzaChyZWNvcmQpO1xuICAgICAgICB9XG4gICAgICAgIGNhbGxiYWNrKCk7XG4gICAgICB9LFxuICAgIH0pO1xuICAgIHJldHVybiBmaWx0ZXJTdHJlYW07XG4gIH1cbn1cblxuLyoqXG4gKiBAY2xhc3MgUmVjb3JkU3RyZWFtLlNlcmlhbGl6YWJsZVxuICogQGV4dGVuZHMge1JlY29yZFN0cmVhbX1cbiAqL1xuZXhwb3J0IGNsYXNzIFNlcmlhbGl6YWJsZTxSIGV4dGVuZHMgUmVjb3JkID0gUmVjb3JkPiBleHRlbmRzIFJlY29yZFN0cmVhbTxSPiB7XG4gIF9kYXRhU3RyZWFtczogeyBbdHlwZTogc3RyaW5nXTogRHVwbGV4IH0gPSB7fTtcblxuICAvKipcbiAgICogR2V0IHJlYWRhYmxlIGRhdGEgc3RyZWFtIHdoaWNoIGVtaXRzIHNlcmlhbGl6ZWQgcmVjb3JkIGRhdGFcbiAgICovXG4gIHN0cmVhbSh0eXBlOiBzdHJpbmcgPSAnY3N2Jywgb3B0aW9uczogT2JqZWN0ID0ge30pOiBEdXBsZXgge1xuICAgIGlmICh0aGlzLl9kYXRhU3RyZWFtc1t0eXBlXSkge1xuICAgICAgcmV0dXJuIHRoaXMuX2RhdGFTdHJlYW1zW3R5cGVdO1xuICAgIH1cbiAgICBjb25zdCBjb252ZXJ0ZXI6IE9wdGlvbmFsPFN0cmVhbUNvbnZlcnRlcj4gPSBEYXRhU3RyZWFtQ29udmVydGVyc1t0eXBlXTtcbiAgICBpZiAoIWNvbnZlcnRlcikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBDb252ZXJ0aW5nIFske3R5cGV9XSBkYXRhIHN0cmVhbSBpcyBub3Qgc3VwcG9ydGVkLmApO1xuICAgIH1cbiAgICBjb25zdCBkYXRhU3RyZWFtID0gbmV3IFBhc3NUaHJvdWdoKCk7XG4gICAgdGhpcy5waXBlKGNvbnZlcnRlci5zZXJpYWxpemUob3B0aW9ucykpLnBpcGUoZGF0YVN0cmVhbSk7XG4gICAgdGhpcy5fZGF0YVN0cmVhbXNbdHlwZV0gPSBkYXRhU3RyZWFtO1xuICAgIHJldHVybiBkYXRhU3RyZWFtO1xuICB9XG59XG5cbi8qKlxuICogQGNsYXNzIFJlY29yZFN0cmVhbS5QYXJzYWJsZVxuICogQGV4dGVuZHMge1JlY29yZFN0cmVhbX1cbiAqL1xuZXhwb3J0IGNsYXNzIFBhcnNhYmxlPFIgZXh0ZW5kcyBSZWNvcmQgPSBSZWNvcmQ+IGV4dGVuZHMgUmVjb3JkU3RyZWFtPFI+IHtcbiAgX2RhdGFTdHJlYW1zOiB7IFt0eXBlOiBzdHJpbmddOiBEdXBsZXggfSA9IHt9O1xuICBfZXhlY1BhcnNlOiBib29sZWFuID0gZmFsc2U7XG4gIF9pbmNvbWluZ3M6IEFycmF5PFtSZWFkYWJsZSwgV3JpdGFibGVdPiA9IFtdO1xuXG4gIC8qKlxuICAgKiBHZXQgd3JpdGFibGUgZGF0YSBzdHJlYW0gd2hpY2ggYWNjZXB0cyBzZXJpYWxpemVkIHJlY29yZCBkYXRhXG4gICAqL1xuICBzdHJlYW0odHlwZTogc3RyaW5nID0gJ2NzdicsIG9wdGlvbnM6IE9iamVjdCA9IHt9KTogRHVwbGV4IHtcbiAgICBpZiAodGhpcy5fZGF0YVN0cmVhbXNbdHlwZV0pIHtcbiAgICAgIHJldHVybiB0aGlzLl9kYXRhU3RyZWFtc1t0eXBlXTtcbiAgICB9XG4gICAgY29uc3QgY29udmVydGVyOiBPcHRpb25hbDxTdHJlYW1Db252ZXJ0ZXI+ID0gRGF0YVN0cmVhbUNvbnZlcnRlcnNbdHlwZV07XG4gICAgaWYgKCFjb252ZXJ0ZXIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihgQ29udmVydGluZyBbJHt0eXBlfV0gZGF0YSBzdHJlYW0gaXMgbm90IHN1cHBvcnRlZC5gKTtcbiAgICB9XG4gICAgY29uc3QgZGF0YVN0cmVhbSA9IG5ldyBQYXNzVGhyb3VnaCgpO1xuICAgIGNvbnN0IHBhcnNlclN0cmVhbSA9IGNvbnZlcnRlci5wYXJzZShvcHRpb25zKTtcbiAgICBwYXJzZXJTdHJlYW0ub24oJ2Vycm9yJywgKGVycikgPT4gdGhpcy5lbWl0KCdlcnJvcicsIGVycikpO1xuICAgIHBhcnNlclN0cmVhbVxuICAgICAgLnBpcGUodGhpcylcbiAgICAgIC5waXBlKG5ldyBQYXNzVGhyb3VnaCh7IG9iamVjdE1vZGU6IHRydWUsIGhpZ2hXYXRlck1hcms6IDUwMCAqIDEwMDAgfSkpO1xuICAgIGlmICh0aGlzLl9leGVjUGFyc2UpIHtcbiAgICAgIGRhdGFTdHJlYW0ucGlwZShwYXJzZXJTdHJlYW0pO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLl9pbmNvbWluZ3MucHVzaChbZGF0YVN0cmVhbSwgcGFyc2VyU3RyZWFtXSk7XG4gICAgfVxuICAgIHRoaXMuX2RhdGFTdHJlYW1zW3R5cGVdID0gZGF0YVN0cmVhbTtcbiAgICByZXR1cm4gZGF0YVN0cmVhbTtcbiAgfVxuXG4gIC8qIEBvdmVycmlkZSAqL1xuICBvbihldjogc3RyaW5nLCBmbjogKC4uLmFyZ3M6IGFueVtdKSA9PiB2b2lkKSB7XG4gICAgaWYgKGV2ID09PSAncmVhZGFibGUnIHx8IGV2ID09PSAncmVjb3JkJykge1xuICAgICAgaWYgKCF0aGlzLl9leGVjUGFyc2UpIHtcbiAgICAgICAgdGhpcy5fZXhlY1BhcnNlID0gdHJ1ZTtcbiAgICAgICAgZm9yIChjb25zdCBbZGF0YVN0cmVhbSwgcGFyc2VyU3RyZWFtXSBvZiB0aGlzLl9pbmNvbWluZ3MpIHtcbiAgICAgICAgICBkYXRhU3RyZWFtLnBpcGUocGFyc2VyU3RyZWFtKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gc3VwZXIub24oZXYsIGZuKTtcbiAgfVxuXG4gIC8qIEBvdmVycmlkZSAqL1xuICBhZGRMaXN0ZW5lciA9IHRoaXMub247XG59XG5cbmV4cG9ydCBkZWZhdWx0IFJlY29yZFN0cmVhbTtcbiJdfQ==