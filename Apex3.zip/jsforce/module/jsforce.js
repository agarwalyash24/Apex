import "core-js/modules/es.array.iterator";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import { EventEmitter } from 'events';
import VERSION from './VERSION';
import Connection from './connection';
import OAuth2 from './oauth2';
import SfDate from './date';
import registry from './registry';
import client, { BrowserClient } from './browser/client';
import { JwtOAuth2 } from './jwtOAuth2';
/**
 *
 */

class JSforce extends EventEmitter {
  constructor(...args) {
    super(...args);

    _defineProperty(this, "VERSION", VERSION);

    _defineProperty(this, "Connection", Connection);

    _defineProperty(this, "OAuth2", OAuth2);

    _defineProperty(this, "JwtOAuth2", JwtOAuth2);

    _defineProperty(this, "SfDate", SfDate);

    _defineProperty(this, "Date", SfDate);

    _defineProperty(this, "BrowserClient", BrowserClient);

    _defineProperty(this, "registry", registry);

    _defineProperty(this, "browser", client);
  }

}

export function registerModule(name, factory) {
  jsforce.on('connection:new', conn => {
    let obj = undefined;

    _Object$defineProperty(conn, name, {
      get() {
        var _obj;

        obj = (_obj = obj) !== null && _obj !== void 0 ? _obj : factory(conn);
        return obj;
      },

      enumerable: true,
      configurable: true
    });
  });
}
const jsforce = new JSforce();
export default jsforce;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9qc2ZvcmNlLnRzIl0sIm5hbWVzIjpbIkV2ZW50RW1pdHRlciIsIlZFUlNJT04iLCJDb25uZWN0aW9uIiwiT0F1dGgyIiwiU2ZEYXRlIiwicmVnaXN0cnkiLCJjbGllbnQiLCJCcm93c2VyQ2xpZW50IiwiSnd0T0F1dGgyIiwiSlNmb3JjZSIsInJlZ2lzdGVyTW9kdWxlIiwibmFtZSIsImZhY3RvcnkiLCJqc2ZvcmNlIiwib24iLCJjb25uIiwib2JqIiwidW5kZWZpbmVkIiwiZ2V0IiwiZW51bWVyYWJsZSIsImNvbmZpZ3VyYWJsZSJdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsU0FBU0EsWUFBVCxRQUE2QixRQUE3QjtBQUNBLE9BQU9DLE9BQVAsTUFBb0IsV0FBcEI7QUFDQSxPQUFPQyxVQUFQLE1BQXVCLGNBQXZCO0FBQ0EsT0FBT0MsTUFBUCxNQUFtQixVQUFuQjtBQUNBLE9BQU9DLE1BQVAsTUFBbUIsUUFBbkI7QUFDQSxPQUFPQyxRQUFQLE1BQW1DLFlBQW5DO0FBQ0EsT0FBT0MsTUFBUCxJQUFpQkMsYUFBakIsUUFBc0Msa0JBQXRDO0FBQ0EsU0FBU0MsU0FBVCxRQUEwQixhQUExQjtBQUVBO0FBQ0E7QUFDQTs7QUFDQSxNQUFNQyxPQUFOLFNBQXNCVCxZQUF0QixDQUFtQztBQUFBO0FBQUE7O0FBQUEscUNBQ1BDLE9BRE87O0FBQUEsd0NBRURDLFVBRkM7O0FBQUEsb0NBR1RDLE1BSFM7O0FBQUEsdUNBSUhLLFNBSkc7O0FBQUEsb0NBS1RKLE1BTFM7O0FBQUEsa0NBTVhBLE1BTlc7O0FBQUEsMkNBT0tHLGFBUEw7O0FBQUEsc0NBUVpGLFFBUlk7O0FBQUEscUNBU1JDLE1BVFE7QUFBQTs7QUFBQTs7QUFZbkMsT0FBTyxTQUFTSSxjQUFULENBQ0xDLElBREssRUFFTEMsT0FGSyxFQUdMO0FBQ0FDLEVBQUFBLE9BQU8sQ0FBQ0MsRUFBUixDQUFXLGdCQUFYLEVBQThCQyxJQUFELElBQXNCO0FBQ2pELFFBQUlDLEdBQVEsR0FBR0MsU0FBZjs7QUFDQSwyQkFBc0JGLElBQXRCLEVBQTRCSixJQUE1QixFQUFrQztBQUNoQ08sTUFBQUEsR0FBRyxHQUFHO0FBQUE7O0FBQ0pGLFFBQUFBLEdBQUcsV0FBR0EsR0FBSCx1Q0FBVUosT0FBTyxDQUFDRyxJQUFELENBQXBCO0FBQ0EsZUFBT0MsR0FBUDtBQUNELE9BSitCOztBQUtoQ0csTUFBQUEsVUFBVSxFQUFFLElBTG9CO0FBTWhDQyxNQUFBQSxZQUFZLEVBQUU7QUFOa0IsS0FBbEM7QUFRRCxHQVZEO0FBV0Q7QUFFRCxNQUFNUCxPQUFPLEdBQUcsSUFBSUosT0FBSixFQUFoQjtBQUNBLGVBQWVJLE9BQWYiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBFdmVudEVtaXR0ZXIgfSBmcm9tICdldmVudHMnO1xuaW1wb3J0IFZFUlNJT04gZnJvbSAnLi9WRVJTSU9OJztcbmltcG9ydCBDb25uZWN0aW9uIGZyb20gJy4vY29ubmVjdGlvbic7XG5pbXBvcnQgT0F1dGgyIGZyb20gJy4vb2F1dGgyJztcbmltcG9ydCBTZkRhdGUgZnJvbSAnLi9kYXRlJztcbmltcG9ydCByZWdpc3RyeSwgeyBSZWdpc3RyeSB9IGZyb20gJy4vcmVnaXN0cnknO1xuaW1wb3J0IGNsaWVudCwgeyBCcm93c2VyQ2xpZW50IH0gZnJvbSAnLi9icm93c2VyL2NsaWVudCc7XG5pbXBvcnQgeyBKd3RPQXV0aDIgfSBmcm9tICcuL2p3dE9BdXRoMic7XG5cbi8qKlxuICpcbiAqL1xuY2xhc3MgSlNmb3JjZSBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIFZFUlNJT046IHR5cGVvZiBWRVJTSU9OID0gVkVSU0lPTjtcbiAgQ29ubmVjdGlvbjogdHlwZW9mIENvbm5lY3Rpb24gPSBDb25uZWN0aW9uO1xuICBPQXV0aDI6IHR5cGVvZiBPQXV0aDIgPSBPQXV0aDI7XG4gIEp3dE9BdXRoMjogdHlwZW9mIEp3dE9BdXRoMiA9IEp3dE9BdXRoMjtcbiAgU2ZEYXRlOiB0eXBlb2YgU2ZEYXRlID0gU2ZEYXRlO1xuICBEYXRlOiB0eXBlb2YgU2ZEYXRlID0gU2ZEYXRlO1xuICBCcm93c2VyQ2xpZW50OiB0eXBlb2YgQnJvd3NlckNsaWVudCA9IEJyb3dzZXJDbGllbnQ7XG4gIHJlZ2lzdHJ5OiBSZWdpc3RyeSA9IHJlZ2lzdHJ5O1xuICBicm93c2VyOiBCcm93c2VyQ2xpZW50ID0gY2xpZW50O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gcmVnaXN0ZXJNb2R1bGUoXG4gIG5hbWU6IHN0cmluZyxcbiAgZmFjdG9yeTogKGNvbm46IENvbm5lY3Rpb24pID0+IGFueSxcbikge1xuICBqc2ZvcmNlLm9uKCdjb25uZWN0aW9uOm5ldycsIChjb25uOiBDb25uZWN0aW9uKSA9PiB7XG4gICAgbGV0IG9iajogYW55ID0gdW5kZWZpbmVkO1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShjb25uLCBuYW1lLCB7XG4gICAgICBnZXQoKSB7XG4gICAgICAgIG9iaiA9IG9iaiA/PyBmYWN0b3J5KGNvbm4pO1xuICAgICAgICByZXR1cm4gb2JqO1xuICAgICAgfSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgfSk7XG4gIH0pO1xufVxuXG5jb25zdCBqc2ZvcmNlID0gbmV3IEpTZm9yY2UoKTtcbmV4cG9ydCBkZWZhdWx0IGpzZm9yY2U7XG4iXX0=