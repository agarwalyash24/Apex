module.exports = require('./lib').default;
