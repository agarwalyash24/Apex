import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _Set from "@babel/runtime-corejs3/core-js-stable/set";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import "regenerator-runtime/runtime";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _setTimeout from "@babel/runtime-corejs3/core-js-stable/set-timeout";

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context3; _forEachInstanceProperty(_context3 = ownKeys(Object(source), true)).call(_context3, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context4; _forEachInstanceProperty(_context4 = ownKeys(Object(source))).call(_context4, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

import { PassThrough } from 'stream';
import { concatStreamsAsDuplex, readAll } from './util/stream';

/**
 *
 */
export function createHttpRequestHandlerStreams(req) {
  var reqBody = req.body;
  var input = new PassThrough();
  var output = new PassThrough();
  var duplex = concatStreamsAsDuplex(input, output);

  if (typeof reqBody !== 'undefined') {
    _setTimeout(function () {
      duplex.end(reqBody, 'utf8');
    }, 0);
  }

  duplex.on('response', /*#__PURE__*/function () {
    var _ref = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee(res) {
      var resBody;
      return _regeneratorRuntime.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              if (!(duplex.listenerCount('complete') > 0)) {
                _context.next = 5;
                break;
              }

              _context.next = 3;
              return readAll(duplex);

            case 3:
              resBody = _context.sent;
              duplex.emit('complete', _objectSpread(_objectSpread({}, res), {}, {
                body: resBody
              }));

            case 5:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function (_x) {
      return _ref.apply(this, arguments);
    };
  }());
  return {
    input: input,
    output: output,
    stream: duplex
  };
}
var redirectStatuses = new _Set([301, 302, 303, 307, 308]);
/**
 *
 */

export function isRedirect(status) {
  return redirectStatuses.has(status);
}
/**
 *
 */

var MAX_REDIRECT_COUNT = 10;
/**
 *
 */

export function performRedirectRequest(req, res, followRedirect, counter, redirectCallback) {
  if (counter >= MAX_REDIRECT_COUNT) {
    throw new Error('Reached to maximum redirect count');
  }

  var redirectUrl = res.headers['location'];

  if (!redirectUrl) {
    throw new Error('No redirect URI found');
  }

  var getRedirectRequest = typeof followRedirect === 'function' ? followRedirect : function () {
    return {
      method: 'GET',
      url: redirectUrl,
      headers: req.headers
    };
  };
  var nextReqParams = getRedirectRequest(redirectUrl);

  if (!nextReqParams) {
    throw new Error('Cannot handle redirect for ' + redirectUrl);
  }

  redirectCallback(nextReqParams);
}
/**
 *
 */

export function executeWithTimeout(_x2, _x3, _x4) {
  return _executeWithTimeout.apply(this, arguments);
}

function _executeWithTimeout() {
  _executeWithTimeout = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee2(execFn, msec, cancelCallback) {
    var timeout, pid, res;
    return _regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            timeout = false;
            pid = msec != null ? _setTimeout(function () {
              timeout = true;
              cancelCallback === null || cancelCallback === void 0 ? void 0 : cancelCallback();
            }, msec) : undefined;
            _context2.prev = 2;
            _context2.next = 5;
            return execFn();

          case 5:
            res = _context2.sent;

          case 6:
            _context2.prev = 6;

            if (pid) {
              clearTimeout(pid);
            }

            return _context2.finish(6);

          case 9:
            if (!timeout) {
              _context2.next = 11;
              break;
            }

            throw new Error('Request Timeout');

          case 11:
            return _context2.abrupt("return", res);

          case 12:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2, null, [[2,, 6, 9]]);
  }));
  return _executeWithTimeout.apply(this, arguments);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9yZXF1ZXN0LWhlbHBlci50cyJdLCJuYW1lcyI6WyJQYXNzVGhyb3VnaCIsImNvbmNhdFN0cmVhbXNBc0R1cGxleCIsInJlYWRBbGwiLCJjcmVhdGVIdHRwUmVxdWVzdEhhbmRsZXJTdHJlYW1zIiwicmVxIiwicmVxQm9keSIsImJvZHkiLCJpbnB1dCIsIm91dHB1dCIsImR1cGxleCIsImVuZCIsIm9uIiwicmVzIiwibGlzdGVuZXJDb3VudCIsInJlc0JvZHkiLCJlbWl0Iiwic3RyZWFtIiwicmVkaXJlY3RTdGF0dXNlcyIsImlzUmVkaXJlY3QiLCJzdGF0dXMiLCJoYXMiLCJNQVhfUkVESVJFQ1RfQ09VTlQiLCJwZXJmb3JtUmVkaXJlY3RSZXF1ZXN0IiwiZm9sbG93UmVkaXJlY3QiLCJjb3VudGVyIiwicmVkaXJlY3RDYWxsYmFjayIsIkVycm9yIiwicmVkaXJlY3RVcmwiLCJoZWFkZXJzIiwiZ2V0UmVkaXJlY3RSZXF1ZXN0IiwibWV0aG9kIiwidXJsIiwibmV4dFJlcVBhcmFtcyIsImV4ZWN1dGVXaXRoVGltZW91dCIsImV4ZWNGbiIsIm1zZWMiLCJjYW5jZWxDYWxsYmFjayIsInRpbWVvdXQiLCJwaWQiLCJ1bmRlZmluZWQiLCJjbGVhclRpbWVvdXQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxTQUFTQSxXQUFULFFBQTRCLFFBQTVCO0FBQ0EsU0FBU0MscUJBQVQsRUFBZ0NDLE9BQWhDLFFBQStDLGVBQS9DOztBQUdBO0FBQ0E7QUFDQTtBQUNBLE9BQU8sU0FBU0MsK0JBQVQsQ0FBeUNDLEdBQXpDLEVBQTJEO0FBQUEsTUFDbERDLE9BRGtELEdBQ3RDRCxHQURzQyxDQUN4REUsSUFEd0Q7QUFFaEUsTUFBTUMsS0FBSyxHQUFHLElBQUlQLFdBQUosRUFBZDtBQUNBLE1BQU1RLE1BQU0sR0FBRyxJQUFJUixXQUFKLEVBQWY7QUFDQSxNQUFNUyxNQUFNLEdBQUdSLHFCQUFxQixDQUFDTSxLQUFELEVBQVFDLE1BQVIsQ0FBcEM7O0FBQ0EsTUFBSSxPQUFPSCxPQUFQLEtBQW1CLFdBQXZCLEVBQW9DO0FBQ2xDLGdCQUFXLFlBQU07QUFDZkksTUFBQUEsTUFBTSxDQUFDQyxHQUFQLENBQVdMLE9BQVgsRUFBb0IsTUFBcEI7QUFDRCxLQUZELEVBRUcsQ0FGSDtBQUdEOztBQUNESSxFQUFBQSxNQUFNLENBQUNFLEVBQVAsQ0FBVSxVQUFWO0FBQUEsd0VBQXNCLGlCQUFPQyxHQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUNoQkgsTUFBTSxDQUFDSSxhQUFQLENBQXFCLFVBQXJCLElBQW1DLENBRG5CO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEscUJBRUlYLE9BQU8sQ0FBQ08sTUFBRCxDQUZYOztBQUFBO0FBRVpLLGNBQUFBLE9BRlk7QUFHbEJMLGNBQUFBLE1BQU0sQ0FBQ00sSUFBUCxDQUFZLFVBQVosa0NBQ0tILEdBREw7QUFFRU4sZ0JBQUFBLElBQUksRUFBRVE7QUFGUjs7QUFIa0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FBdEI7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFTQSxTQUFPO0FBQUVQLElBQUFBLEtBQUssRUFBTEEsS0FBRjtBQUFTQyxJQUFBQSxNQUFNLEVBQU5BLE1BQVQ7QUFBaUJRLElBQUFBLE1BQU0sRUFBRVA7QUFBekIsR0FBUDtBQUNEO0FBRUQsSUFBTVEsZ0JBQWdCLEdBQUcsU0FBUSxDQUFDLEdBQUQsRUFBTSxHQUFOLEVBQVcsR0FBWCxFQUFnQixHQUFoQixFQUFxQixHQUFyQixDQUFSLENBQXpCO0FBRUE7QUFDQTtBQUNBOztBQUNBLE9BQU8sU0FBU0MsVUFBVCxDQUFvQkMsTUFBcEIsRUFBb0M7QUFDekMsU0FBT0YsZ0JBQWdCLENBQUNHLEdBQWpCLENBQXFCRCxNQUFyQixDQUFQO0FBQ0Q7QUFFRDtBQUNBO0FBQ0E7O0FBQ0EsSUFBTUUsa0JBQWtCLEdBQUcsRUFBM0I7QUFFQTtBQUNBO0FBQ0E7O0FBQ0EsT0FBTyxTQUFTQyxzQkFBVCxDQUNMbEIsR0FESyxFQUVMUSxHQUZLLEVBR0xXLGNBSEssRUFJTEMsT0FKSyxFQUtMQyxnQkFMSyxFQU1MO0FBQ0EsTUFBSUQsT0FBTyxJQUFJSCxrQkFBZixFQUFtQztBQUNqQyxVQUFNLElBQUlLLEtBQUosQ0FBVSxtQ0FBVixDQUFOO0FBQ0Q7O0FBQ0QsTUFBTUMsV0FBVyxHQUFHZixHQUFHLENBQUNnQixPQUFKLENBQVksVUFBWixDQUFwQjs7QUFDQSxNQUFJLENBQUNELFdBQUwsRUFBa0I7QUFDaEIsVUFBTSxJQUFJRCxLQUFKLENBQVUsdUJBQVYsQ0FBTjtBQUNEOztBQUNELE1BQU1HLGtCQUFrQixHQUN0QixPQUFPTixjQUFQLEtBQTBCLFVBQTFCLEdBQ0lBLGNBREosR0FFSTtBQUFBLFdBQU87QUFDTE8sTUFBQUEsTUFBTSxFQUFFLEtBREg7QUFFTEMsTUFBQUEsR0FBRyxFQUFFSixXQUZBO0FBR0xDLE1BQUFBLE9BQU8sRUFBRXhCLEdBQUcsQ0FBQ3dCO0FBSFIsS0FBUDtBQUFBLEdBSE47QUFRQSxNQUFNSSxhQUFhLEdBQUdILGtCQUFrQixDQUFDRixXQUFELENBQXhDOztBQUNBLE1BQUksQ0FBQ0ssYUFBTCxFQUFvQjtBQUNsQixVQUFNLElBQUlOLEtBQUosQ0FBVSxnQ0FBZ0NDLFdBQTFDLENBQU47QUFDRDs7QUFDREYsRUFBQUEsZ0JBQWdCLENBQUNPLGFBQUQsQ0FBaEI7QUFDRDtBQUVEO0FBQ0E7QUFDQTs7QUFDQSxnQkFBc0JDLGtCQUF0QjtBQUFBO0FBQUE7OztpRkFBTyxrQkFDTEMsTUFESyxFQUVMQyxJQUZLLEVBR0xDLGNBSEs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBS0RDLFlBQUFBLE9BTEMsR0FLUyxLQUxUO0FBTURDLFlBQUFBLEdBTkMsR0FPSEgsSUFBSSxJQUFJLElBQVIsR0FDSSxZQUFXLFlBQU07QUFDZkUsY0FBQUEsT0FBTyxHQUFHLElBQVY7QUFDQUQsY0FBQUEsY0FBYyxTQUFkLElBQUFBLGNBQWMsV0FBZCxZQUFBQSxjQUFjO0FBQ2YsYUFIRCxFQUdHRCxJQUhILENBREosR0FLSUksU0FaRDtBQUFBO0FBQUE7QUFBQSxtQkFlU0wsTUFBTSxFQWZmOztBQUFBO0FBZUh0QixZQUFBQSxHQWZHOztBQUFBO0FBQUE7O0FBaUJILGdCQUFJMEIsR0FBSixFQUFTO0FBQ1BFLGNBQUFBLFlBQVksQ0FBQ0YsR0FBRCxDQUFaO0FBQ0Q7O0FBbkJFOztBQUFBO0FBQUEsaUJBcUJERCxPQXJCQztBQUFBO0FBQUE7QUFBQTs7QUFBQSxrQkFzQkcsSUFBSVgsS0FBSixDQUFVLGlCQUFWLENBdEJIOztBQUFBO0FBQUEsOENBd0JFZCxHQXhCRjs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxHIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGFzc1Rocm91Z2ggfSBmcm9tICdzdHJlYW0nO1xuaW1wb3J0IHsgY29uY2F0U3RyZWFtc0FzRHVwbGV4LCByZWFkQWxsIH0gZnJvbSAnLi91dGlsL3N0cmVhbSc7XG5pbXBvcnQgeyBIdHRwUmVxdWVzdCwgSHR0cFJlcXVlc3RPcHRpb25zLCBIdHRwUmVzcG9uc2UgfSBmcm9tICcuL3R5cGVzJztcblxuLyoqXG4gKlxuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlSHR0cFJlcXVlc3RIYW5kbGVyU3RyZWFtcyhyZXE6IEh0dHBSZXF1ZXN0KSB7XG4gIGNvbnN0IHsgYm9keTogcmVxQm9keSB9ID0gcmVxO1xuICBjb25zdCBpbnB1dCA9IG5ldyBQYXNzVGhyb3VnaCgpO1xuICBjb25zdCBvdXRwdXQgPSBuZXcgUGFzc1Rocm91Z2goKTtcbiAgY29uc3QgZHVwbGV4ID0gY29uY2F0U3RyZWFtc0FzRHVwbGV4KGlucHV0LCBvdXRwdXQpO1xuICBpZiAodHlwZW9mIHJlcUJvZHkgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBkdXBsZXguZW5kKHJlcUJvZHksICd1dGY4Jyk7XG4gICAgfSwgMCk7XG4gIH1cbiAgZHVwbGV4Lm9uKCdyZXNwb25zZScsIGFzeW5jIChyZXMpID0+IHtcbiAgICBpZiAoZHVwbGV4Lmxpc3RlbmVyQ291bnQoJ2NvbXBsZXRlJykgPiAwKSB7XG4gICAgICBjb25zdCByZXNCb2R5ID0gYXdhaXQgcmVhZEFsbChkdXBsZXgpO1xuICAgICAgZHVwbGV4LmVtaXQoJ2NvbXBsZXRlJywge1xuICAgICAgICAuLi5yZXMsXG4gICAgICAgIGJvZHk6IHJlc0JvZHksXG4gICAgICB9KTtcbiAgICB9XG4gIH0pO1xuICByZXR1cm4geyBpbnB1dCwgb3V0cHV0LCBzdHJlYW06IGR1cGxleCB9O1xufVxuXG5jb25zdCByZWRpcmVjdFN0YXR1c2VzID0gbmV3IFNldChbMzAxLCAzMDIsIDMwMywgMzA3LCAzMDhdKTtcblxuLyoqXG4gKlxuICovXG5leHBvcnQgZnVuY3Rpb24gaXNSZWRpcmVjdChzdGF0dXM6IG51bWJlcikge1xuICByZXR1cm4gcmVkaXJlY3RTdGF0dXNlcy5oYXMoc3RhdHVzKTtcbn1cblxuLyoqXG4gKlxuICovXG5jb25zdCBNQVhfUkVESVJFQ1RfQ09VTlQgPSAxMDtcblxuLyoqXG4gKlxuICovXG5leHBvcnQgZnVuY3Rpb24gcGVyZm9ybVJlZGlyZWN0UmVxdWVzdChcbiAgcmVxOiBIdHRwUmVxdWVzdCxcbiAgcmVzOiBPbWl0PEh0dHBSZXNwb25zZSwgJ2JvZHknPixcbiAgZm9sbG93UmVkaXJlY3Q6IE5vbk51bGxhYmxlPEh0dHBSZXF1ZXN0T3B0aW9uc1snZm9sbG93UmVkaXJlY3QnXT4sXG4gIGNvdW50ZXI6IG51bWJlcixcbiAgcmVkaXJlY3RDYWxsYmFjazogKHJlcTogSHR0cFJlcXVlc3QpID0+IHZvaWQsXG4pIHtcbiAgaWYgKGNvdW50ZXIgPj0gTUFYX1JFRElSRUNUX0NPVU5UKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdSZWFjaGVkIHRvIG1heGltdW0gcmVkaXJlY3QgY291bnQnKTtcbiAgfVxuICBjb25zdCByZWRpcmVjdFVybCA9IHJlcy5oZWFkZXJzWydsb2NhdGlvbiddO1xuICBpZiAoIXJlZGlyZWN0VXJsKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdObyByZWRpcmVjdCBVUkkgZm91bmQnKTtcbiAgfVxuICBjb25zdCBnZXRSZWRpcmVjdFJlcXVlc3QgPVxuICAgIHR5cGVvZiBmb2xsb3dSZWRpcmVjdCA9PT0gJ2Z1bmN0aW9uJ1xuICAgICAgPyBmb2xsb3dSZWRpcmVjdFxuICAgICAgOiAoKSA9PiAoe1xuICAgICAgICAgIG1ldGhvZDogJ0dFVCcgYXMgY29uc3QsXG4gICAgICAgICAgdXJsOiByZWRpcmVjdFVybCxcbiAgICAgICAgICBoZWFkZXJzOiByZXEuaGVhZGVycyxcbiAgICAgICAgfSk7XG4gIGNvbnN0IG5leHRSZXFQYXJhbXMgPSBnZXRSZWRpcmVjdFJlcXVlc3QocmVkaXJlY3RVcmwpO1xuICBpZiAoIW5leHRSZXFQYXJhbXMpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBoYW5kbGUgcmVkaXJlY3QgZm9yICcgKyByZWRpcmVjdFVybCk7XG4gIH1cbiAgcmVkaXJlY3RDYWxsYmFjayhuZXh0UmVxUGFyYW1zKTtcbn1cblxuLyoqXG4gKlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZXhlY3V0ZVdpdGhUaW1lb3V0PFQ+KFxuICBleGVjRm46ICgpID0+IFByb21pc2U8VD4sXG4gIG1zZWM6IG51bWJlciB8IHVuZGVmaW5lZCxcbiAgY2FuY2VsQ2FsbGJhY2s/OiAoKSA9PiB2b2lkLFxuKTogUHJvbWlzZTxUPiB7XG4gIGxldCB0aW1lb3V0ID0gZmFsc2U7XG4gIGxldCBwaWQgPVxuICAgIG1zZWMgIT0gbnVsbFxuICAgICAgPyBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICB0aW1lb3V0ID0gdHJ1ZTtcbiAgICAgICAgICBjYW5jZWxDYWxsYmFjaz8uKCk7XG4gICAgICAgIH0sIG1zZWMpXG4gICAgICA6IHVuZGVmaW5lZDtcbiAgbGV0IHJlcztcbiAgdHJ5IHtcbiAgICByZXMgPSBhd2FpdCBleGVjRm4oKTtcbiAgfSBmaW5hbGx5IHtcbiAgICBpZiAocGlkKSB7XG4gICAgICBjbGVhclRpbWVvdXQocGlkKTtcbiAgICB9XG4gIH1cbiAgaWYgKHRpbWVvdXQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1JlcXVlc3QgVGltZW91dCcpO1xuICB9XG4gIHJldHVybiByZXM7XG59XG4iXX0=