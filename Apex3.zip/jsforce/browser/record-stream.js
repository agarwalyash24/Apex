import _getIterator from "@babel/runtime-corejs3/core-js/get-iterator";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _getIteratorMethod from "@babel/runtime-corejs3/core-js/get-iterator-method";
import _Symbol from "@babel/runtime-corejs3/core-js-stable/symbol";
import _Array$from from "@babel/runtime-corejs3/core-js-stable/array/from";
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";
import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import "core-js/modules/es.regexp.exec";
import "core-js/modules/es.string.replace";
import _slicedToArray from "@babel/runtime-corejs3/helpers/slicedToArray";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _assertThisInitialized from "@babel/runtime-corejs3/helpers/assertThisInitialized";
import _get from "@babel/runtime-corejs3/helpers/get";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _objectWithoutProperties from "@babel/runtime-corejs3/helpers/objectWithoutProperties";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _typeof from "@babel/runtime-corejs3/helpers/typeof";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _reduceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/reduce";

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof _Symbol === "undefined" || _getIteratorMethod(o) == null) { if (_Array$isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = _getIterator(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { var _context8; if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = _sliceInstanceProperty(_context8 = Object.prototype.toString.call(o)).call(_context8, 8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return _Array$from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = _Reflect$construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !_Reflect$construct) return false; if (_Reflect$construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(_Reflect$construct(Date, [], function () {})); return true; } catch (e) { return false; } }

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context6; _forEachInstanceProperty(_context6 = ownKeys(Object(source), true)).call(_context6, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context7; _forEachInstanceProperty(_context7 = ownKeys(Object(source))).call(_context7, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 * @file Represents stream that handles Salesforce record as stream data
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { Transform, PassThrough } from 'stream';
import { serializeCSVStream, parseCSVStream } from './csv';
import { concatStreamsAsDuplex } from './util/stream';
/**
 * type defs
 */

/**
 * @private
 */
function evalMapping(value, mapping) {
  if (typeof value === 'string') {
    var m = /^\$\{(\w+)\}$/.exec(value);

    if (m) {
      return mapping[m[1]];
    }

    return value.replace(/\$\{(\w+)\}/g, function ($0, prop) {
      var v = mapping[prop];
      return typeof v === 'undefined' || v === null ? '' : String(v);
    });
  }

  return value;
}
/**
 * @private
 */


function convertRecordForSerialization(record) {
  var _context;

  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  return _reduceInstanceProperty(_context = _Object$keys(record)).call(_context, function (rec, key) {
    var value = rec[key];
    var urec;

    if (key === 'attributes') {
      // 'attributes' prop will be ignored
      urec = _objectSpread({}, rec);
      delete urec[key];
      return urec;
    } else if (options.nullValue && value === null) {
      return _objectSpread(_objectSpread({}, rec), {}, _defineProperty({}, key, options.nullValue));
    } else if (value !== null && _typeof(value) === 'object') {
      var _context2;

      var precord = convertRecordForSerialization(value, options);
      return _reduceInstanceProperty(_context2 = _Object$keys(precord)).call(_context2, function (prec, pkey) {
        var _context3;

        prec[_concatInstanceProperty(_context3 = "".concat(key, ".")).call(_context3, pkey)] = precord[pkey]; // eslint-disable-line no-param-reassign

        return prec;
      }, _objectSpread({}, rec));
    }

    return rec;
  }, record);
}
/**
 * @private
 */


function createPipelineStream(s1, s2) {
  s1.pipe(s2);
  return concatStreamsAsDuplex(s1, s2, {
    writableObjectMode: true
  });
}

/**
 * @private
 */
var CSVStreamConverter = {
  serialize: function serialize() {
    var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

    var nullValue = options.nullValue,
        csvOpts = _objectWithoutProperties(options, ["nullValue"]);

    return createPipelineStream( // eslint-disable-next-line no-use-before-define
    _mapInstanceProperty(RecordStream).call(RecordStream, function (record) {
      return convertRecordForSerialization(record, options);
    }), serializeCSVStream(csvOpts));
  },
  parse: function parse() {
    var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return parseCSVStream(options);
  }
};
/**
 * @private
 */

var DataStreamConverters = {
  csv: CSVStreamConverter
};
/**
 * Class for Record Stream
 *
 * @class
 * @constructor
 * @extends stream.Transform
 */

export var RecordStream = /*#__PURE__*/function (_PassThrough) {
  _inherits(RecordStream, _PassThrough);

  var _super = _createSuper(RecordStream);

  /**
   *
   */
  function RecordStream() {
    var _this;

    _classCallCheck(this, RecordStream);

    _this = _super.call(this, {
      objectMode: true
    });

    _defineProperty(_assertThisInitialized(_this), "addListener", _this.on);

    return _this;
  }
  /**
   * Get record stream of queried records applying the given mapping function
   */


  _createClass(RecordStream, [{
    key: "map",
    value: function map(fn) {
      return this.pipe(_mapInstanceProperty(RecordStream).call(RecordStream, fn));
    }
    /**
     * Get record stream of queried records, applying the given filter function
     */

  }, {
    key: "filter",
    value: function filter(fn) {
      return this.pipe(_filterInstanceProperty(RecordStream).call(RecordStream, fn));
    }
    /* @override */

  }, {
    key: "on",
    value: function on(ev, fn) {
      return _get(_getPrototypeOf(RecordStream.prototype), "on", this).call(this, ev === 'record' ? 'data' : ev, fn);
    }
    /* @override */

  }], [{
    key: "map",

    /* --------------------------------------------------- */

    /**
     * Create a record stream which maps records and pass them to downstream
     */
    value: function map(fn) {
      var mapStream = new Transform({
        objectMode: true,
        transform: function transform(record, enc, callback) {
          var rec = fn(record) || record; // if not returned record, use same record

          mapStream.push(rec);
          callback();
        }
      });
      return mapStream;
    }
    /**
     * Create mapping stream using given record template
     */

  }, {
    key: "recordMapStream",
    value: function recordMapStream(record, noeval) {
      return _mapInstanceProperty(RecordStream).call(RecordStream, function (rec) {
        var mapped = {
          Id: rec.Id
        };

        for (var _i = 0, _Object$keys2 = _Object$keys(record); _i < _Object$keys2.length; _i++) {
          var _prop = _Object$keys2[_i];
          mapped[_prop] = noeval ? record[_prop] : evalMapping(record[_prop], rec);
        }

        return mapped;
      });
    }
    /**
     * Create a record stream which filters records and pass them to downstream
     *
     * @param {RecordFilterFunction} fn - Record filtering function
     * @returns {RecordStream.Serializable}
     */

  }, {
    key: "filter",
    value: function filter(fn) {
      var filterStream = new Transform({
        objectMode: true,
        transform: function transform(record, enc, callback) {
          if (fn(record)) {
            filterStream.push(record);
          }

          callback();
        }
      });
      return filterStream;
    }
  }]);

  return RecordStream;
}(PassThrough);
/**
 * @class RecordStream.Serializable
 * @extends {RecordStream}
 */

export var Serializable = /*#__PURE__*/function (_RecordStream) {
  _inherits(Serializable, _RecordStream);

  var _super2 = _createSuper(Serializable);

  function Serializable() {
    var _context4;

    var _this2;

    _classCallCheck(this, Serializable);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this2 = _super2.call.apply(_super2, _concatInstanceProperty(_context4 = [this]).call(_context4, args));

    _defineProperty(_assertThisInitialized(_this2), "_dataStreams", {});

    return _this2;
  }

  _createClass(Serializable, [{
    key: "stream",

    /**
     * Get readable data stream which emits serialized record data
     */
    value: function stream() {
      var type = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'csv';
      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      if (this._dataStreams[type]) {
        return this._dataStreams[type];
      }

      var converter = DataStreamConverters[type];

      if (!converter) {
        throw new Error("Converting [".concat(type, "] data stream is not supported."));
      }

      var dataStream = new PassThrough();
      this.pipe(converter.serialize(options)).pipe(dataStream);
      this._dataStreams[type] = dataStream;
      return dataStream;
    }
  }]);

  return Serializable;
}(RecordStream);
/**
 * @class RecordStream.Parsable
 * @extends {RecordStream}
 */

export var Parsable = /*#__PURE__*/function (_RecordStream2) {
  _inherits(Parsable, _RecordStream2);

  var _super3 = _createSuper(Parsable);

  function Parsable() {
    var _context5;

    var _this3;

    _classCallCheck(this, Parsable);

    for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
      args[_key3] = arguments[_key3];
    }

    _this3 = _super3.call.apply(_super3, _concatInstanceProperty(_context5 = [this]).call(_context5, args));

    _defineProperty(_assertThisInitialized(_this3), "_dataStreams", {});

    _defineProperty(_assertThisInitialized(_this3), "_execParse", false);

    _defineProperty(_assertThisInitialized(_this3), "_incomings", []);

    _defineProperty(_assertThisInitialized(_this3), "addListener", _this3.on);

    return _this3;
  }

  _createClass(Parsable, [{
    key: "stream",

    /**
     * Get writable data stream which accepts serialized record data
     */
    value: function stream() {
      var _this4 = this;

      var type = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'csv';
      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      if (this._dataStreams[type]) {
        return this._dataStreams[type];
      }

      var converter = DataStreamConverters[type];

      if (!converter) {
        throw new Error("Converting [".concat(type, "] data stream is not supported."));
      }

      var dataStream = new PassThrough();
      var parserStream = converter.parse(options);
      parserStream.on('error', function (err) {
        return _this4.emit('error', err);
      });
      parserStream.pipe(this).pipe(new PassThrough({
        objectMode: true,
        highWaterMark: 500 * 1000
      }));

      if (this._execParse) {
        dataStream.pipe(parserStream);
      } else {
        this._incomings.push([dataStream, parserStream]);
      }

      this._dataStreams[type] = dataStream;
      return dataStream;
    }
    /* @override */

  }, {
    key: "on",
    value: function on(ev, fn) {
      if (ev === 'readable' || ev === 'record') {
        if (!this._execParse) {
          this._execParse = true;

          var _iterator = _createForOfIteratorHelper(this._incomings),
              _step;

          try {
            for (_iterator.s(); !(_step = _iterator.n()).done;) {
              var _step$value = _slicedToArray(_step.value, 2),
                  dataStream = _step$value[0],
                  parserStream = _step$value[1];

              dataStream.pipe(parserStream);
            }
          } catch (err) {
            _iterator.e(err);
          } finally {
            _iterator.f();
          }
        }
      }

      return _get(_getPrototypeOf(Parsable.prototype), "on", this).call(this, ev, fn);
    }
    /* @override */

  }]);

  return Parsable;
}(RecordStream);
export default RecordStream;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9yZWNvcmQtc3RyZWFtLnRzIl0sIm5hbWVzIjpbIlRyYW5zZm9ybSIsIlBhc3NUaHJvdWdoIiwic2VyaWFsaXplQ1NWU3RyZWFtIiwicGFyc2VDU1ZTdHJlYW0iLCJjb25jYXRTdHJlYW1zQXNEdXBsZXgiLCJldmFsTWFwcGluZyIsInZhbHVlIiwibWFwcGluZyIsIm0iLCJleGVjIiwicmVwbGFjZSIsIiQwIiwicHJvcCIsInYiLCJTdHJpbmciLCJjb252ZXJ0UmVjb3JkRm9yU2VyaWFsaXphdGlvbiIsInJlY29yZCIsIm9wdGlvbnMiLCJyZWMiLCJrZXkiLCJ1cmVjIiwibnVsbFZhbHVlIiwicHJlY29yZCIsInByZWMiLCJwa2V5IiwiY3JlYXRlUGlwZWxpbmVTdHJlYW0iLCJzMSIsInMyIiwicGlwZSIsIndyaXRhYmxlT2JqZWN0TW9kZSIsIkNTVlN0cmVhbUNvbnZlcnRlciIsInNlcmlhbGl6ZSIsImNzdk9wdHMiLCJSZWNvcmRTdHJlYW0iLCJwYXJzZSIsIkRhdGFTdHJlYW1Db252ZXJ0ZXJzIiwiY3N2Iiwib2JqZWN0TW9kZSIsIm9uIiwiZm4iLCJldiIsIm1hcFN0cmVhbSIsInRyYW5zZm9ybSIsImVuYyIsImNhbGxiYWNrIiwicHVzaCIsIm5vZXZhbCIsIm1hcHBlZCIsIklkIiwiZmlsdGVyU3RyZWFtIiwiU2VyaWFsaXphYmxlIiwidHlwZSIsIl9kYXRhU3RyZWFtcyIsImNvbnZlcnRlciIsIkVycm9yIiwiZGF0YVN0cmVhbSIsIlBhcnNhYmxlIiwicGFyc2VyU3RyZWFtIiwiZXJyIiwiZW1pdCIsImhpZ2hXYXRlck1hcmsiLCJfZXhlY1BhcnNlIiwiX2luY29taW5ncyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBcUNBLFNBQXJDLEVBQWdEQyxXQUFoRCxRQUFtRSxRQUFuRTtBQUVBLFNBQVNDLGtCQUFULEVBQTZCQyxjQUE3QixRQUFtRCxPQUFuRDtBQUNBLFNBQVNDLHFCQUFULFFBQXNDLGVBQXRDO0FBRUE7QUFDQTtBQUNBOztBQU9BO0FBQ0E7QUFDQTtBQUNBLFNBQVNDLFdBQVQsQ0FBcUJDLEtBQXJCLEVBQWlDQyxPQUFqQyxFQUFzRTtBQUNwRSxNQUFJLE9BQU9ELEtBQVAsS0FBaUIsUUFBckIsRUFBK0I7QUFDN0IsUUFBTUUsQ0FBQyxHQUFHLGdCQUFnQkMsSUFBaEIsQ0FBcUJILEtBQXJCLENBQVY7O0FBQ0EsUUFBSUUsQ0FBSixFQUFPO0FBQ0wsYUFBT0QsT0FBTyxDQUFDQyxDQUFDLENBQUMsQ0FBRCxDQUFGLENBQWQ7QUFDRDs7QUFDRCxXQUFPRixLQUFLLENBQUNJLE9BQU4sQ0FBYyxjQUFkLEVBQThCLFVBQUNDLEVBQUQsRUFBS0MsSUFBTCxFQUFjO0FBQ2pELFVBQU1DLENBQUMsR0FBR04sT0FBTyxDQUFDSyxJQUFELENBQWpCO0FBQ0EsYUFBTyxPQUFPQyxDQUFQLEtBQWEsV0FBYixJQUE0QkEsQ0FBQyxLQUFLLElBQWxDLEdBQXlDLEVBQXpDLEdBQThDQyxNQUFNLENBQUNELENBQUQsQ0FBM0Q7QUFDRCxLQUhNLENBQVA7QUFJRDs7QUFDRCxTQUFPUCxLQUFQO0FBQ0Q7QUFFRDtBQUNBO0FBQ0E7OztBQUNBLFNBQVNTLDZCQUFULENBQ0VDLE1BREYsRUFHVTtBQUFBOztBQUFBLE1BRFJDLE9BQ1EsdUVBRDJCLEVBQzNCO0FBQ1IsU0FBTyxnREFBWUQsTUFBWixrQkFBMkIsVUFBQ0UsR0FBRCxFQUFjQyxHQUFkLEVBQThCO0FBQzlELFFBQU1iLEtBQUssR0FBSVksR0FBRCxDQUFhQyxHQUFiLENBQWQ7QUFDQSxRQUFJQyxJQUFKOztBQUNBLFFBQUlELEdBQUcsS0FBSyxZQUFaLEVBQTBCO0FBQ3hCO0FBQ0FDLE1BQUFBLElBQUkscUJBQVFGLEdBQVIsQ0FBSjtBQUNBLGFBQU9FLElBQUksQ0FBQ0QsR0FBRCxDQUFYO0FBQ0EsYUFBT0MsSUFBUDtBQUNELEtBTEQsTUFLTyxJQUFJSCxPQUFPLENBQUNJLFNBQVIsSUFBcUJmLEtBQUssS0FBSyxJQUFuQyxFQUF5QztBQUM5Qyw2Q0FBWVksR0FBWiwyQkFBa0JDLEdBQWxCLEVBQXdCRixPQUFPLENBQUNJLFNBQWhDO0FBQ0QsS0FGTSxNQUVBLElBQUlmLEtBQUssS0FBSyxJQUFWLElBQWtCLFFBQU9BLEtBQVAsTUFBaUIsUUFBdkMsRUFBaUQ7QUFBQTs7QUFDdEQsVUFBTWdCLE9BQU8sR0FBR1AsNkJBQTZCLENBQUNULEtBQUQsRUFBUVcsT0FBUixDQUE3QztBQUNBLGFBQU8saURBQVlLLE9BQVosbUJBQ0wsVUFBQ0MsSUFBRCxFQUFlQyxJQUFmLEVBQXdCO0FBQUE7O0FBQ3RCRCxRQUFBQSxJQUFJLCtDQUFJSixHQUFKLHdCQUFXSyxJQUFYLEVBQUosR0FBeUJGLE9BQU8sQ0FBQ0UsSUFBRCxDQUFoQyxDQURzQixDQUNrQjs7QUFDeEMsZUFBT0QsSUFBUDtBQUNELE9BSkksb0JBS0FMLEdBTEEsRUFBUDtBQU9EOztBQUNELFdBQU9BLEdBQVA7QUFDRCxHQXJCTSxFQXFCSkYsTUFyQkksQ0FBUDtBQXNCRDtBQUVEO0FBQ0E7QUFDQTs7O0FBQ0EsU0FBU1Msb0JBQVQsQ0FBOEJDLEVBQTlCLEVBQTBDQyxFQUExQyxFQUFzRDtBQUNwREQsRUFBQUEsRUFBRSxDQUFDRSxJQUFILENBQVFELEVBQVI7QUFDQSxTQUFPdkIscUJBQXFCLENBQUNzQixFQUFELEVBQUtDLEVBQUwsRUFBUztBQUFFRSxJQUFBQSxrQkFBa0IsRUFBRTtBQUF0QixHQUFULENBQTVCO0FBQ0Q7O0FBT0Q7QUFDQTtBQUNBO0FBQ0EsSUFBTUMsa0JBQW1DLEdBQUc7QUFDMUNDLEVBQUFBLFNBRDBDLHVCQUNXO0FBQUEsUUFBM0NkLE9BQTJDLHVFQUFKLEVBQUk7O0FBQUEsUUFDM0NJLFNBRDJDLEdBQ2pCSixPQURpQixDQUMzQ0ksU0FEMkM7QUFBQSxRQUM3QlcsT0FENkIsNEJBQ2pCZixPQURpQjs7QUFFbkQsV0FBT1Esb0JBQW9CLEVBQ3pCO0FBQ0EseUJBQUFRLFlBQVksTUFBWixDQUFBQSxZQUFZLEVBQUssVUFBQ2pCLE1BQUQ7QUFBQSxhQUNmRCw2QkFBNkIsQ0FBQ0MsTUFBRCxFQUFTQyxPQUFULENBRGQ7QUFBQSxLQUFMLENBRmEsRUFLekJmLGtCQUFrQixDQUFDOEIsT0FBRCxDQUxPLENBQTNCO0FBT0QsR0FWeUM7QUFXMUNFLEVBQUFBLEtBWDBDLG1CQVdHO0FBQUEsUUFBdkNqQixPQUF1Qyx1RUFBSixFQUFJO0FBQzNDLFdBQU9kLGNBQWMsQ0FBQ2MsT0FBRCxDQUFyQjtBQUNEO0FBYnlDLENBQTVDO0FBZ0JBO0FBQ0E7QUFDQTs7QUFDQSxJQUFNa0Isb0JBQXdELEdBQUc7QUFDL0RDLEVBQUFBLEdBQUcsRUFBRU47QUFEMEQsQ0FBakU7QUFJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxXQUFhRyxZQUFiO0FBQUE7O0FBQUE7O0FBQ0U7QUFDRjtBQUNBO0FBQ0UsMEJBQWM7QUFBQTs7QUFBQTs7QUFDWiw4QkFBTTtBQUFFSSxNQUFBQSxVQUFVLEVBQUU7QUFBZCxLQUFOOztBQURZLGtFQXdCQSxNQUFLQyxFQXhCTDs7QUFBQTtBQUViO0FBRUQ7QUFDRjtBQUNBOzs7QUFWQTtBQUFBO0FBQUEsd0JBV3lCQyxFQVh6QixFQVd1RDtBQUNuRCxhQUFPLEtBQUtYLElBQUwsQ0FBVSxxQkFBQUssWUFBWSxNQUFaLENBQUFBLFlBQVksRUFBWU0sRUFBWixDQUF0QixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBakJBO0FBQUE7QUFBQSwyQkFrQlNBLEVBbEJULEVBa0IwQztBQUN0QyxhQUFPLEtBQUtYLElBQUwsQ0FBVSx3QkFBQUssWUFBWSxNQUFaLENBQUFBLFlBQVksRUFBV00sRUFBWCxDQUF0QixDQUFQO0FBQ0Q7QUFFRDs7QUF0QkY7QUFBQTtBQUFBLHVCQXVCS0MsRUF2QkwsRUF1QmlCRCxFQXZCakIsRUF1QitDO0FBQzNDLGtGQUFnQkMsRUFBRSxLQUFLLFFBQVAsR0FBa0IsTUFBbEIsR0FBMkJBLEVBQTNDLEVBQStDRCxFQUEvQztBQUNEO0FBRUQ7O0FBM0JGO0FBQUE7O0FBOEJFOztBQUVBO0FBQ0Y7QUFDQTtBQWxDQSx3QkFvQ0lBLEVBcENKLEVBcUNJO0FBQ0EsVUFBTUUsU0FBUyxHQUFHLElBQUl6QyxTQUFKLENBQWM7QUFDOUJxQyxRQUFBQSxVQUFVLEVBQUUsSUFEa0I7QUFFOUJLLFFBQUFBLFNBRjhCLHFCQUVwQjFCLE1BRm9CLEVBRVoyQixHQUZZLEVBRVBDLFFBRk8sRUFFRztBQUMvQixjQUFNMUIsR0FBRyxHQUFHcUIsRUFBRSxDQUFDdkIsTUFBRCxDQUFGLElBQWNBLE1BQTFCLENBRCtCLENBQ0c7O0FBQ2xDeUIsVUFBQUEsU0FBUyxDQUFDSSxJQUFWLENBQWUzQixHQUFmO0FBQ0EwQixVQUFBQSxRQUFRO0FBQ1Q7QUFONkIsT0FBZCxDQUFsQjtBQVFBLGFBQU9ILFNBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUFuREE7QUFBQTtBQUFBLG9DQXVESXpCLE1BdkRKLEVBdURnQjhCLE1BdkRoQixFQXVEa0M7QUFDOUIsYUFBTyxxQkFBQWIsWUFBWSxNQUFaLENBQUFBLFlBQVksRUFBYSxVQUFDZixHQUFELEVBQVM7QUFDdkMsWUFBTTZCLE1BQWMsR0FBRztBQUFFQyxVQUFBQSxFQUFFLEVBQUU5QixHQUFHLENBQUM4QjtBQUFWLFNBQXZCOztBQUNBLHlDQUFtQixhQUFZaEMsTUFBWixDQUFuQixtQ0FBd0M7QUFBbkMsY0FBTUosS0FBSSxvQkFBVjtBQUNIbUMsVUFBQUEsTUFBTSxDQUFDbkMsS0FBRCxDQUFOLEdBQWVrQyxNQUFNLEdBQUc5QixNQUFNLENBQUNKLEtBQUQsQ0FBVCxHQUFrQlAsV0FBVyxDQUFDVyxNQUFNLENBQUNKLEtBQUQsQ0FBUCxFQUFlTSxHQUFmLENBQWxEO0FBQ0Q7O0FBQ0QsZUFBTzZCLE1BQVA7QUFDRCxPQU5rQixDQUFuQjtBQU9EO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQXRFQTtBQUFBO0FBQUEsMkJBdUU0Q1IsRUF2RTVDLEVBdUU4RTtBQUMxRSxVQUFNVSxZQUFZLEdBQUcsSUFBSWpELFNBQUosQ0FBYztBQUNqQ3FDLFFBQUFBLFVBQVUsRUFBRSxJQURxQjtBQUVqQ0ssUUFBQUEsU0FGaUMscUJBRXZCMUIsTUFGdUIsRUFFZjJCLEdBRmUsRUFFVkMsUUFGVSxFQUVBO0FBQy9CLGNBQUlMLEVBQUUsQ0FBQ3ZCLE1BQUQsQ0FBTixFQUFnQjtBQUNkaUMsWUFBQUEsWUFBWSxDQUFDSixJQUFiLENBQWtCN0IsTUFBbEI7QUFDRDs7QUFDRDRCLFVBQUFBLFFBQVE7QUFDVDtBQVBnQyxPQUFkLENBQXJCO0FBU0EsYUFBT0ssWUFBUDtBQUNEO0FBbEZIOztBQUFBO0FBQUEsRUFBNkRoRCxXQUE3RDtBQXFGQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxXQUFhaUQsWUFBYjtBQUFBOztBQUFBOztBQUFBO0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBOztBQUFBLG9FQUM2QyxFQUQ3Qzs7QUFBQTtBQUFBOztBQUFBO0FBQUE7O0FBR0U7QUFDRjtBQUNBO0FBTEEsNkJBTTZEO0FBQUEsVUFBcERDLElBQW9ELHVFQUFyQyxLQUFxQztBQUFBLFVBQTlCbEMsT0FBOEIsdUVBQVosRUFBWTs7QUFDekQsVUFBSSxLQUFLbUMsWUFBTCxDQUFrQkQsSUFBbEIsQ0FBSixFQUE2QjtBQUMzQixlQUFPLEtBQUtDLFlBQUwsQ0FBa0JELElBQWxCLENBQVA7QUFDRDs7QUFDRCxVQUFNRSxTQUFvQyxHQUFHbEIsb0JBQW9CLENBQUNnQixJQUFELENBQWpFOztBQUNBLFVBQUksQ0FBQ0UsU0FBTCxFQUFnQjtBQUNkLGNBQU0sSUFBSUMsS0FBSix1QkFBeUJILElBQXpCLHFDQUFOO0FBQ0Q7O0FBQ0QsVUFBTUksVUFBVSxHQUFHLElBQUl0RCxXQUFKLEVBQW5CO0FBQ0EsV0FBSzJCLElBQUwsQ0FBVXlCLFNBQVMsQ0FBQ3RCLFNBQVYsQ0FBb0JkLE9BQXBCLENBQVYsRUFBd0NXLElBQXhDLENBQTZDMkIsVUFBN0M7QUFDQSxXQUFLSCxZQUFMLENBQWtCRCxJQUFsQixJQUEwQkksVUFBMUI7QUFDQSxhQUFPQSxVQUFQO0FBQ0Q7QUFsQkg7O0FBQUE7QUFBQSxFQUE2RHRCLFlBQTdEO0FBcUJBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFdBQWF1QixRQUFiO0FBQUE7O0FBQUE7O0FBQUE7QUFBQTs7QUFBQTs7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7O0FBQUEsb0VBQzZDLEVBRDdDOztBQUFBLGtFQUV3QixLQUZ4Qjs7QUFBQSxrRUFHNEMsRUFINUM7O0FBQUEsbUVBNkNnQixPQUFLbEIsRUE3Q3JCOztBQUFBO0FBQUE7O0FBQUE7QUFBQTs7QUFLRTtBQUNGO0FBQ0E7QUFQQSw2QkFRNkQ7QUFBQTs7QUFBQSxVQUFwRGEsSUFBb0QsdUVBQXJDLEtBQXFDO0FBQUEsVUFBOUJsQyxPQUE4Qix1RUFBWixFQUFZOztBQUN6RCxVQUFJLEtBQUttQyxZQUFMLENBQWtCRCxJQUFsQixDQUFKLEVBQTZCO0FBQzNCLGVBQU8sS0FBS0MsWUFBTCxDQUFrQkQsSUFBbEIsQ0FBUDtBQUNEOztBQUNELFVBQU1FLFNBQW9DLEdBQUdsQixvQkFBb0IsQ0FBQ2dCLElBQUQsQ0FBakU7O0FBQ0EsVUFBSSxDQUFDRSxTQUFMLEVBQWdCO0FBQ2QsY0FBTSxJQUFJQyxLQUFKLHVCQUF5QkgsSUFBekIscUNBQU47QUFDRDs7QUFDRCxVQUFNSSxVQUFVLEdBQUcsSUFBSXRELFdBQUosRUFBbkI7QUFDQSxVQUFNd0QsWUFBWSxHQUFHSixTQUFTLENBQUNuQixLQUFWLENBQWdCakIsT0FBaEIsQ0FBckI7QUFDQXdDLE1BQUFBLFlBQVksQ0FBQ25CLEVBQWIsQ0FBZ0IsT0FBaEIsRUFBeUIsVUFBQ29CLEdBQUQ7QUFBQSxlQUFTLE1BQUksQ0FBQ0MsSUFBTCxDQUFVLE9BQVYsRUFBbUJELEdBQW5CLENBQVQ7QUFBQSxPQUF6QjtBQUNBRCxNQUFBQSxZQUFZLENBQ1Q3QixJQURILENBQ1EsSUFEUixFQUVHQSxJQUZILENBRVEsSUFBSTNCLFdBQUosQ0FBZ0I7QUFBRW9DLFFBQUFBLFVBQVUsRUFBRSxJQUFkO0FBQW9CdUIsUUFBQUEsYUFBYSxFQUFFLE1BQU07QUFBekMsT0FBaEIsQ0FGUjs7QUFHQSxVQUFJLEtBQUtDLFVBQVQsRUFBcUI7QUFDbkJOLFFBQUFBLFVBQVUsQ0FBQzNCLElBQVgsQ0FBZ0I2QixZQUFoQjtBQUNELE9BRkQsTUFFTztBQUNMLGFBQUtLLFVBQUwsQ0FBZ0JqQixJQUFoQixDQUFxQixDQUFDVSxVQUFELEVBQWFFLFlBQWIsQ0FBckI7QUFDRDs7QUFDRCxXQUFLTCxZQUFMLENBQWtCRCxJQUFsQixJQUEwQkksVUFBMUI7QUFDQSxhQUFPQSxVQUFQO0FBQ0Q7QUFFRDs7QUEvQkY7QUFBQTtBQUFBLHVCQWdDS2YsRUFoQ0wsRUFnQ2lCRCxFQWhDakIsRUFnQytDO0FBQzNDLFVBQUlDLEVBQUUsS0FBSyxVQUFQLElBQXFCQSxFQUFFLEtBQUssUUFBaEMsRUFBMEM7QUFDeEMsWUFBSSxDQUFDLEtBQUtxQixVQUFWLEVBQXNCO0FBQ3BCLGVBQUtBLFVBQUwsR0FBa0IsSUFBbEI7O0FBRG9CLHFEQUVxQixLQUFLQyxVQUYxQjtBQUFBOztBQUFBO0FBRXBCLGdFQUEwRDtBQUFBO0FBQUEsa0JBQTlDUCxVQUE4QztBQUFBLGtCQUFsQ0UsWUFBa0M7O0FBQ3hERixjQUFBQSxVQUFVLENBQUMzQixJQUFYLENBQWdCNkIsWUFBaEI7QUFDRDtBQUptQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBS3JCO0FBQ0Y7O0FBQ0QsOEVBQWdCakIsRUFBaEIsRUFBb0JELEVBQXBCO0FBQ0Q7QUFFRDs7QUE1Q0Y7O0FBQUE7QUFBQSxFQUF5RE4sWUFBekQ7QUFnREEsZUFBZUEsWUFBZiIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGZpbGUgUmVwcmVzZW50cyBzdHJlYW0gdGhhdCBoYW5kbGVzIFNhbGVzZm9yY2UgcmVjb3JkIGFzIHN0cmVhbSBkYXRhXG4gKiBAYXV0aG9yIFNoaW5pY2hpIFRvbWl0YSA8c2hpbmljaGkudG9taXRhQGdtYWlsLmNvbT5cbiAqL1xuaW1wb3J0IHsgUmVhZGFibGUsIFdyaXRhYmxlLCBEdXBsZXgsIFRyYW5zZm9ybSwgUGFzc1Rocm91Z2ggfSBmcm9tICdzdHJlYW0nO1xuaW1wb3J0IHsgUmVjb3JkLCBPcHRpb25hbCB9IGZyb20gJy4vdHlwZXMnO1xuaW1wb3J0IHsgc2VyaWFsaXplQ1NWU3RyZWFtLCBwYXJzZUNTVlN0cmVhbSB9IGZyb20gJy4vY3N2JztcbmltcG9ydCB7IGNvbmNhdFN0cmVhbXNBc0R1cGxleCB9IGZyb20gJy4vdXRpbC9zdHJlYW0nO1xuXG4vKipcbiAqIHR5cGUgZGVmc1xuICovXG5leHBvcnQgdHlwZSBSZWNvcmRTdHJlYW1TZXJpYWxpemVPcHRpb24gPSB7XG4gIG51bGxWYWx1ZT86IGFueTtcbn07XG5cbmV4cG9ydCB0eXBlIFJlY29yZFN0cmVhbVBhcnNlT3B0aW9uID0ge307XG5cbi8qKlxuICogQHByaXZhdGVcbiAqL1xuZnVuY3Rpb24gZXZhbE1hcHBpbmcodmFsdWU6IGFueSwgbWFwcGluZzogeyBbcHJvcDogc3RyaW5nXTogc3RyaW5nIH0pIHtcbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycpIHtcbiAgICBjb25zdCBtID0gL15cXCRcXHsoXFx3KylcXH0kLy5leGVjKHZhbHVlKTtcbiAgICBpZiAobSkge1xuICAgICAgcmV0dXJuIG1hcHBpbmdbbVsxXV07XG4gICAgfVxuICAgIHJldHVybiB2YWx1ZS5yZXBsYWNlKC9cXCRcXHsoXFx3KylcXH0vZywgKCQwLCBwcm9wKSA9PiB7XG4gICAgICBjb25zdCB2ID0gbWFwcGluZ1twcm9wXTtcbiAgICAgIHJldHVybiB0eXBlb2YgdiA9PT0gJ3VuZGVmaW5lZCcgfHwgdiA9PT0gbnVsbCA/ICcnIDogU3RyaW5nKHYpO1xuICAgIH0pO1xuICB9XG4gIHJldHVybiB2YWx1ZTtcbn1cblxuLyoqXG4gKiBAcHJpdmF0ZVxuICovXG5mdW5jdGlvbiBjb252ZXJ0UmVjb3JkRm9yU2VyaWFsaXphdGlvbihcbiAgcmVjb3JkOiBSZWNvcmQsXG4gIG9wdGlvbnM6IHsgbnVsbFZhbHVlPzogYm9vbGVhbiB9ID0ge30sXG4pOiBSZWNvcmQge1xuICByZXR1cm4gT2JqZWN0LmtleXMocmVjb3JkKS5yZWR1Y2UoKHJlYzogUmVjb3JkLCBrZXk6IHN0cmluZykgPT4ge1xuICAgIGNvbnN0IHZhbHVlID0gKHJlYyBhcyBhbnkpW2tleV07XG4gICAgbGV0IHVyZWM6IFJlY29yZDtcbiAgICBpZiAoa2V5ID09PSAnYXR0cmlidXRlcycpIHtcbiAgICAgIC8vICdhdHRyaWJ1dGVzJyBwcm9wIHdpbGwgYmUgaWdub3JlZFxuICAgICAgdXJlYyA9IHsgLi4ucmVjIH07XG4gICAgICBkZWxldGUgdXJlY1trZXldO1xuICAgICAgcmV0dXJuIHVyZWM7XG4gICAgfSBlbHNlIGlmIChvcHRpb25zLm51bGxWYWx1ZSAmJiB2YWx1ZSA9PT0gbnVsbCkge1xuICAgICAgcmV0dXJuIHsgLi4ucmVjLCBba2V5XTogb3B0aW9ucy5udWxsVmFsdWUgfSBhcyBSZWNvcmQ7XG4gICAgfSBlbHNlIGlmICh2YWx1ZSAhPT0gbnVsbCAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnKSB7XG4gICAgICBjb25zdCBwcmVjb3JkID0gY29udmVydFJlY29yZEZvclNlcmlhbGl6YXRpb24odmFsdWUsIG9wdGlvbnMpO1xuICAgICAgcmV0dXJuIE9iamVjdC5rZXlzKHByZWNvcmQpLnJlZHVjZShcbiAgICAgICAgKHByZWM6IFJlY29yZCwgcGtleSkgPT4ge1xuICAgICAgICAgIHByZWNbYCR7a2V5fS4ke3BrZXl9YF0gPSBwcmVjb3JkW3BrZXldOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLXBhcmFtLXJlYXNzaWduXG4gICAgICAgICAgcmV0dXJuIHByZWM7XG4gICAgICAgIH0sXG4gICAgICAgIHsgLi4ucmVjIH0sXG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gcmVjO1xuICB9LCByZWNvcmQpO1xufVxuXG4vKipcbiAqIEBwcml2YXRlXG4gKi9cbmZ1bmN0aW9uIGNyZWF0ZVBpcGVsaW5lU3RyZWFtKHMxOiBEdXBsZXgsIHMyOiBEdXBsZXgpIHtcbiAgczEucGlwZShzMik7XG4gIHJldHVybiBjb25jYXRTdHJlYW1zQXNEdXBsZXgoczEsIHMyLCB7IHdyaXRhYmxlT2JqZWN0TW9kZTogdHJ1ZSB9KTtcbn1cblxudHlwZSBTdHJlYW1Db252ZXJ0ZXIgPSB7XG4gIHNlcmlhbGl6ZTogKG9wdGlvbnM/OiBSZWNvcmRTdHJlYW1TZXJpYWxpemVPcHRpb24pID0+IER1cGxleDtcbiAgcGFyc2U6IChvcHRpb25zPzogUmVjb3JkU3RyZWFtUGFyc2VPcHRpb24pID0+IER1cGxleDtcbn07XG5cbi8qKlxuICogQHByaXZhdGVcbiAqL1xuY29uc3QgQ1NWU3RyZWFtQ29udmVydGVyOiBTdHJlYW1Db252ZXJ0ZXIgPSB7XG4gIHNlcmlhbGl6ZShvcHRpb25zOiBSZWNvcmRTdHJlYW1TZXJpYWxpemVPcHRpb24gPSB7fSkge1xuICAgIGNvbnN0IHsgbnVsbFZhbHVlLCAuLi5jc3ZPcHRzIH0gPSBvcHRpb25zO1xuICAgIHJldHVybiBjcmVhdGVQaXBlbGluZVN0cmVhbShcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby11c2UtYmVmb3JlLWRlZmluZVxuICAgICAgUmVjb3JkU3RyZWFtLm1hcCgocmVjb3JkKSA9PlxuICAgICAgICBjb252ZXJ0UmVjb3JkRm9yU2VyaWFsaXphdGlvbihyZWNvcmQsIG9wdGlvbnMpLFxuICAgICAgKSxcbiAgICAgIHNlcmlhbGl6ZUNTVlN0cmVhbShjc3ZPcHRzKSxcbiAgICApO1xuICB9LFxuICBwYXJzZShvcHRpb25zOiBSZWNvcmRTdHJlYW1QYXJzZU9wdGlvbiA9IHt9KSB7XG4gICAgcmV0dXJuIHBhcnNlQ1NWU3RyZWFtKG9wdGlvbnMpO1xuICB9LFxufTtcblxuLyoqXG4gKiBAcHJpdmF0ZVxuICovXG5jb25zdCBEYXRhU3RyZWFtQ29udmVydGVyczogeyBba2V5OiBzdHJpbmddOiBTdHJlYW1Db252ZXJ0ZXIgfSA9IHtcbiAgY3N2OiBDU1ZTdHJlYW1Db252ZXJ0ZXIsXG59O1xuXG4vKipcbiAqIENsYXNzIGZvciBSZWNvcmQgU3RyZWFtXG4gKlxuICogQGNsYXNzXG4gKiBAY29uc3RydWN0b3JcbiAqIEBleHRlbmRzIHN0cmVhbS5UcmFuc2Zvcm1cbiAqL1xuZXhwb3J0IGNsYXNzIFJlY29yZFN0cmVhbTxSIGV4dGVuZHMgUmVjb3JkID0gUmVjb3JkPiBleHRlbmRzIFBhc3NUaHJvdWdoIHtcbiAgLyoqXG4gICAqXG4gICAqL1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcih7IG9iamVjdE1vZGU6IHRydWUgfSk7XG4gIH1cblxuICAvKipcbiAgICogR2V0IHJlY29yZCBzdHJlYW0gb2YgcXVlcmllZCByZWNvcmRzIGFwcGx5aW5nIHRoZSBnaXZlbiBtYXBwaW5nIGZ1bmN0aW9uXG4gICAqL1xuICBtYXA8UlIgZXh0ZW5kcyBSZWNvcmQ+KGZuOiAocmVjOiBSKSA9PiBPcHRpb25hbDxSUj4pIHtcbiAgICByZXR1cm4gdGhpcy5waXBlKFJlY29yZFN0cmVhbS5tYXA8UiwgUlI+KGZuKSk7XG4gIH1cblxuICAvKipcbiAgICogR2V0IHJlY29yZCBzdHJlYW0gb2YgcXVlcmllZCByZWNvcmRzLCBhcHBseWluZyB0aGUgZ2l2ZW4gZmlsdGVyIGZ1bmN0aW9uXG4gICAqL1xuICBmaWx0ZXIoZm46IChyZWM6IFIpID0+IGJvb2xlYW4pOiBEdXBsZXgge1xuICAgIHJldHVybiB0aGlzLnBpcGUoUmVjb3JkU3RyZWFtLmZpbHRlcjxSPihmbikpO1xuICB9XG5cbiAgLyogQG92ZXJyaWRlICovXG4gIG9uKGV2OiBzdHJpbmcsIGZuOiAoLi4uYXJnczogYW55W10pID0+IHZvaWQpIHtcbiAgICByZXR1cm4gc3VwZXIub24oZXYgPT09ICdyZWNvcmQnID8gJ2RhdGEnIDogZXYsIGZuKTtcbiAgfVxuXG4gIC8qIEBvdmVycmlkZSAqL1xuICBhZGRMaXN0ZW5lciA9IHRoaXMub247XG5cbiAgLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhIHJlY29yZCBzdHJlYW0gd2hpY2ggbWFwcyByZWNvcmRzIGFuZCBwYXNzIHRoZW0gdG8gZG93bnN0cmVhbVxuICAgKi9cbiAgc3RhdGljIG1hcDxSMSBleHRlbmRzIFJlY29yZCA9IFJlY29yZCwgUjIgZXh0ZW5kcyBSZWNvcmQgPSBSZWNvcmQ+KFxuICAgIGZuOiAocmVjOiBSMSkgPT4gT3B0aW9uYWw8UjI+LFxuICApIHtcbiAgICBjb25zdCBtYXBTdHJlYW0gPSBuZXcgVHJhbnNmb3JtKHtcbiAgICAgIG9iamVjdE1vZGU6IHRydWUsXG4gICAgICB0cmFuc2Zvcm0ocmVjb3JkLCBlbmMsIGNhbGxiYWNrKSB7XG4gICAgICAgIGNvbnN0IHJlYyA9IGZuKHJlY29yZCkgfHwgcmVjb3JkOyAvLyBpZiBub3QgcmV0dXJuZWQgcmVjb3JkLCB1c2Ugc2FtZSByZWNvcmRcbiAgICAgICAgbWFwU3RyZWFtLnB1c2gocmVjKTtcbiAgICAgICAgY2FsbGJhY2soKTtcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgcmV0dXJuIG1hcFN0cmVhbTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGUgbWFwcGluZyBzdHJlYW0gdXNpbmcgZ2l2ZW4gcmVjb3JkIHRlbXBsYXRlXG4gICAqL1xuICBzdGF0aWMgcmVjb3JkTWFwU3RyZWFtPFxuICAgIFIxIGV4dGVuZHMgUmVjb3JkID0gUmVjb3JkLFxuICAgIFIyIGV4dGVuZHMgUmVjb3JkID0gUmVjb3JkXG4gID4ocmVjb3JkOiBSMiwgbm9ldmFsPzogYm9vbGVhbikge1xuICAgIHJldHVybiBSZWNvcmRTdHJlYW0ubWFwPFIxLCBSMj4oKHJlYykgPT4ge1xuICAgICAgY29uc3QgbWFwcGVkOiBSZWNvcmQgPSB7IElkOiByZWMuSWQgfTtcbiAgICAgIGZvciAoY29uc3QgcHJvcCBvZiBPYmplY3Qua2V5cyhyZWNvcmQpKSB7XG4gICAgICAgIG1hcHBlZFtwcm9wXSA9IG5vZXZhbCA/IHJlY29yZFtwcm9wXSA6IGV2YWxNYXBwaW5nKHJlY29yZFtwcm9wXSwgcmVjKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBtYXBwZWQgYXMgUjI7XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlIGEgcmVjb3JkIHN0cmVhbSB3aGljaCBmaWx0ZXJzIHJlY29yZHMgYW5kIHBhc3MgdGhlbSB0byBkb3duc3RyZWFtXG4gICAqXG4gICAqIEBwYXJhbSB7UmVjb3JkRmlsdGVyRnVuY3Rpb259IGZuIC0gUmVjb3JkIGZpbHRlcmluZyBmdW5jdGlvblxuICAgKiBAcmV0dXJucyB7UmVjb3JkU3RyZWFtLlNlcmlhbGl6YWJsZX1cbiAgICovXG4gIHN0YXRpYyBmaWx0ZXI8UjEgZXh0ZW5kcyBSZWNvcmQgPSBSZWNvcmQ+KGZuOiAocmVjOiBSMSkgPT4gYm9vbGVhbik6IER1cGxleCB7XG4gICAgY29uc3QgZmlsdGVyU3RyZWFtID0gbmV3IFRyYW5zZm9ybSh7XG4gICAgICBvYmplY3RNb2RlOiB0cnVlLFxuICAgICAgdHJhbnNmb3JtKHJlY29yZCwgZW5jLCBjYWxsYmFjaykge1xuICAgICAgICBpZiAoZm4ocmVjb3JkKSkge1xuICAgICAgICAgIGZpbHRlclN0cmVhbS5wdXNoKHJlY29yZCk7XG4gICAgICAgIH1cbiAgICAgICAgY2FsbGJhY2soKTtcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgcmV0dXJuIGZpbHRlclN0cmVhbTtcbiAgfVxufVxuXG4vKipcbiAqIEBjbGFzcyBSZWNvcmRTdHJlYW0uU2VyaWFsaXphYmxlXG4gKiBAZXh0ZW5kcyB7UmVjb3JkU3RyZWFtfVxuICovXG5leHBvcnQgY2xhc3MgU2VyaWFsaXphYmxlPFIgZXh0ZW5kcyBSZWNvcmQgPSBSZWNvcmQ+IGV4dGVuZHMgUmVjb3JkU3RyZWFtPFI+IHtcbiAgX2RhdGFTdHJlYW1zOiB7IFt0eXBlOiBzdHJpbmddOiBEdXBsZXggfSA9IHt9O1xuXG4gIC8qKlxuICAgKiBHZXQgcmVhZGFibGUgZGF0YSBzdHJlYW0gd2hpY2ggZW1pdHMgc2VyaWFsaXplZCByZWNvcmQgZGF0YVxuICAgKi9cbiAgc3RyZWFtKHR5cGU6IHN0cmluZyA9ICdjc3YnLCBvcHRpb25zOiBPYmplY3QgPSB7fSk6IER1cGxleCB7XG4gICAgaWYgKHRoaXMuX2RhdGFTdHJlYW1zW3R5cGVdKSB7XG4gICAgICByZXR1cm4gdGhpcy5fZGF0YVN0cmVhbXNbdHlwZV07XG4gICAgfVxuICAgIGNvbnN0IGNvbnZlcnRlcjogT3B0aW9uYWw8U3RyZWFtQ29udmVydGVyPiA9IERhdGFTdHJlYW1Db252ZXJ0ZXJzW3R5cGVdO1xuICAgIGlmICghY29udmVydGVyKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYENvbnZlcnRpbmcgWyR7dHlwZX1dIGRhdGEgc3RyZWFtIGlzIG5vdCBzdXBwb3J0ZWQuYCk7XG4gICAgfVxuICAgIGNvbnN0IGRhdGFTdHJlYW0gPSBuZXcgUGFzc1Rocm91Z2goKTtcbiAgICB0aGlzLnBpcGUoY29udmVydGVyLnNlcmlhbGl6ZShvcHRpb25zKSkucGlwZShkYXRhU3RyZWFtKTtcbiAgICB0aGlzLl9kYXRhU3RyZWFtc1t0eXBlXSA9IGRhdGFTdHJlYW07XG4gICAgcmV0dXJuIGRhdGFTdHJlYW07XG4gIH1cbn1cblxuLyoqXG4gKiBAY2xhc3MgUmVjb3JkU3RyZWFtLlBhcnNhYmxlXG4gKiBAZXh0ZW5kcyB7UmVjb3JkU3RyZWFtfVxuICovXG5leHBvcnQgY2xhc3MgUGFyc2FibGU8UiBleHRlbmRzIFJlY29yZCA9IFJlY29yZD4gZXh0ZW5kcyBSZWNvcmRTdHJlYW08Uj4ge1xuICBfZGF0YVN0cmVhbXM6IHsgW3R5cGU6IHN0cmluZ106IER1cGxleCB9ID0ge307XG4gIF9leGVjUGFyc2U6IGJvb2xlYW4gPSBmYWxzZTtcbiAgX2luY29taW5nczogQXJyYXk8W1JlYWRhYmxlLCBXcml0YWJsZV0+ID0gW107XG5cbiAgLyoqXG4gICAqIEdldCB3cml0YWJsZSBkYXRhIHN0cmVhbSB3aGljaCBhY2NlcHRzIHNlcmlhbGl6ZWQgcmVjb3JkIGRhdGFcbiAgICovXG4gIHN0cmVhbSh0eXBlOiBzdHJpbmcgPSAnY3N2Jywgb3B0aW9uczogT2JqZWN0ID0ge30pOiBEdXBsZXgge1xuICAgIGlmICh0aGlzLl9kYXRhU3RyZWFtc1t0eXBlXSkge1xuICAgICAgcmV0dXJuIHRoaXMuX2RhdGFTdHJlYW1zW3R5cGVdO1xuICAgIH1cbiAgICBjb25zdCBjb252ZXJ0ZXI6IE9wdGlvbmFsPFN0cmVhbUNvbnZlcnRlcj4gPSBEYXRhU3RyZWFtQ29udmVydGVyc1t0eXBlXTtcbiAgICBpZiAoIWNvbnZlcnRlcikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBDb252ZXJ0aW5nIFske3R5cGV9XSBkYXRhIHN0cmVhbSBpcyBub3Qgc3VwcG9ydGVkLmApO1xuICAgIH1cbiAgICBjb25zdCBkYXRhU3RyZWFtID0gbmV3IFBhc3NUaHJvdWdoKCk7XG4gICAgY29uc3QgcGFyc2VyU3RyZWFtID0gY29udmVydGVyLnBhcnNlKG9wdGlvbnMpO1xuICAgIHBhcnNlclN0cmVhbS5vbignZXJyb3InLCAoZXJyKSA9PiB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKSk7XG4gICAgcGFyc2VyU3RyZWFtXG4gICAgICAucGlwZSh0aGlzKVxuICAgICAgLnBpcGUobmV3IFBhc3NUaHJvdWdoKHsgb2JqZWN0TW9kZTogdHJ1ZSwgaGlnaFdhdGVyTWFyazogNTAwICogMTAwMCB9KSk7XG4gICAgaWYgKHRoaXMuX2V4ZWNQYXJzZSkge1xuICAgICAgZGF0YVN0cmVhbS5waXBlKHBhcnNlclN0cmVhbSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuX2luY29taW5ncy5wdXNoKFtkYXRhU3RyZWFtLCBwYXJzZXJTdHJlYW1dKTtcbiAgICB9XG4gICAgdGhpcy5fZGF0YVN0cmVhbXNbdHlwZV0gPSBkYXRhU3RyZWFtO1xuICAgIHJldHVybiBkYXRhU3RyZWFtO1xuICB9XG5cbiAgLyogQG92ZXJyaWRlICovXG4gIG9uKGV2OiBzdHJpbmcsIGZuOiAoLi4uYXJnczogYW55W10pID0+IHZvaWQpIHtcbiAgICBpZiAoZXYgPT09ICdyZWFkYWJsZScgfHwgZXYgPT09ICdyZWNvcmQnKSB7XG4gICAgICBpZiAoIXRoaXMuX2V4ZWNQYXJzZSkge1xuICAgICAgICB0aGlzLl9leGVjUGFyc2UgPSB0cnVlO1xuICAgICAgICBmb3IgKGNvbnN0IFtkYXRhU3RyZWFtLCBwYXJzZXJTdHJlYW1dIG9mIHRoaXMuX2luY29taW5ncykge1xuICAgICAgICAgIGRhdGFTdHJlYW0ucGlwZShwYXJzZXJTdHJlYW0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBzdXBlci5vbihldiwgZm4pO1xuICB9XG5cbiAgLyogQG92ZXJyaWRlICovXG4gIGFkZExpc3RlbmVyID0gdGhpcy5vbjtcbn1cblxuZXhwb3J0IGRlZmF1bHQgUmVjb3JkU3RyZWFtO1xuIl19