import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import "core-js/modules/es.array.join";
import "core-js/modules/es.number.constructor";
import "core-js/modules/es.object.to-string";
import "core-js/modules/es.regexp.constructor";
import "core-js/modules/es.regexp.exec";
import "core-js/modules/es.regexp.to-string";
import "core-js/modules/es.string.match";
import "core-js/modules/es.string.search";
import "core-js/modules/es.string.split";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _reverseInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/reverse";
import _Date$now from "@babel/runtime-corejs3/core-js-stable/date/now";
import _setInterval from "@babel/runtime-corejs3/core-js-stable/set-interval";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _setTimeout from "@babel/runtime-corejs3/core-js-stable/set-timeout";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _assertThisInitialized from "@babel/runtime-corejs3/helpers/assertThisInitialized";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _slicedToArray from "@babel/runtime-corejs3/helpers/slicedToArray";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context5; _forEachInstanceProperty(_context5 = ownKeys(Object(source), true)).call(_context5, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context6; _forEachInstanceProperty(_context6 = ownKeys(Object(source))).call(_context6, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = _Reflect$construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !_Reflect$construct) return false; if (_Reflect$construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(_Reflect$construct(Date, [], function () {})); return true; } catch (e) { return false; } }

/**
 * @file Browser client connection management class
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { EventEmitter } from 'events';
import qs from 'querystring';
import Connection from '../connection';
import OAuth2 from '../oauth2';
/**
 * @private
 */

function popupWin(url, w, h) {
  var _context, _context2, _context3;

  var left = screen.width / 2 - w / 2;
  var top = screen.height / 2 - h / 2;
  return window.open(url, undefined, _concatInstanceProperty(_context = _concatInstanceProperty(_context2 = _concatInstanceProperty(_context3 = "location=yes,toolbar=no,status=no,menubar=no,width=".concat(w, ",height=")).call(_context3, h, ",top=")).call(_context2, top, ",left=")).call(_context, left));
}
/**
 * @private
 */


function handleCallbackResponse() {
  var res = checkCallbackResponse();
  var state = localStorage.getItem('jsforce_state');

  if (res && state && res.body.state === state) {
    localStorage.removeItem('jsforce_state');

    var _state$split = state.split('.'),
        _state$split2 = _slicedToArray(_state$split, 2),
        prefix = _state$split2[0],
        promptType = _state$split2[1];

    var cli = new BrowserClient(prefix);

    if (res.success) {
      cli._storeTokens(res.body);

      location.hash = '';
    } else {
      cli._storeError(res.body);
    }

    if (promptType === 'popup') {
      window.close();
    }

    return true;
  }
}
/**
 * @private
 */


function checkCallbackResponse() {
  var params;

  if (window.location.hash) {
    params = qs.parse(window.location.hash.substring(1));

    if (params.access_token) {
      return {
        success: true,
        body: params
      };
    }
  } else if (window.location.search) {
    params = qs.parse(window.location.search.substring(1));

    if (params.error) {
      return {
        success: false,
        body: params
      };
    }
  }
}
/**
 *
 */


/**
 *
 */
var DEFAULT_POPUP_WIN_WIDTH = 912;
var DEFAULT_POPUP_WIN_HEIGHT = 513;
/** @private **/

var clientIdx = 0;
/**
 *
 */

export var BrowserClient = /*#__PURE__*/function (_EventEmitter) {
  _inherits(BrowserClient, _EventEmitter);

  var _super = _createSuper(BrowserClient);

  /**
   *
   */
  function BrowserClient(prefix) {
    var _this;

    _classCallCheck(this, BrowserClient);

    _this = _super.call(this);

    _defineProperty(_assertThisInitialized(_this), "_prefix", void 0);

    _defineProperty(_assertThisInitialized(_this), "_config", void 0);

    _defineProperty(_assertThisInitialized(_this), "_connection", void 0);

    _this._prefix = prefix || 'jsforce' + clientIdx++;
    return _this;
  }

  _createClass(BrowserClient, [{
    key: "init",

    /**
     *
     */
    value: function init(config) {
      var _this2 = this;

      if (handleCallbackResponse()) {
        return;
      }

      this._config = config;

      var tokens = this._getTokens();

      if (tokens) {
        this.connection._establish(tokens);

        _setTimeout(function () {
          _this2.emit('connect', _this2.connection);
        }, 10);
      }
    }
    /**
     *
     */

  }, {
    key: "login",
    value: function login() {
      var _this$_config,
          _size$width,
          _size$height,
          _this3 = this;

      var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      var scope = options.scope,
          size = options.size;
      var oauth2 = new OAuth2((_this$_config = this._config) !== null && _this$_config !== void 0 ? _this$_config : {});
      var rand = Math.random().toString(36).substring(2);
      var state = [this._prefix, 'popup', rand].join('.');
      localStorage.setItem('jsforce_state', state);
      var authzUrl = oauth2.getAuthorizationUrl(_objectSpread({
        response_type: 'token',
        state: state
      }, scope ? {
        scope: scope
      } : {}));
      var pw = popupWin(authzUrl, (_size$width = size === null || size === void 0 ? void 0 : size.width) !== null && _size$width !== void 0 ? _size$width : DEFAULT_POPUP_WIN_WIDTH, (_size$height = size === null || size === void 0 ? void 0 : size.height) !== null && _size$height !== void 0 ? _size$height : DEFAULT_POPUP_WIN_HEIGHT);
      return new _Promise(function (resolve, reject) {
        if (!pw) {
          var _state = [_this3._prefix, 'redirect', rand].join('.');

          localStorage.setItem('jsforce_state', _state);

          var _authzUrl = oauth2.getAuthorizationUrl(_objectSpread({
            response_type: 'token',
            state: _state
          }, scope ? {
            scope: scope
          } : {}));

          location.href = _authzUrl;
          return;
        }

        _this3._removeTokens();

        var pid = _setInterval(function () {
          try {
            if (!pw || pw.closed) {
              clearInterval(pid);

              var tokens = _this3._getTokens();

              if (tokens) {
                _this3.connection._establish(tokens);

                _this3.emit('connect', _this3.connection);

                resolve({
                  status: 'connect'
                });
              } else {
                var err = _this3._getError();

                if (err) {
                  reject(new Error(err.error + ': ' + err.error_description));
                } else {
                  resolve({
                    status: 'cancel'
                  });
                }
              }
            }
          } catch (e) {//
          }
        }, 1000);
      });
    }
    /**
     *
     */

  }, {
    key: "isLoggedIn",
    value: function isLoggedIn() {
      return !!this.connection.accessToken;
    }
    /**
     *
     */

  }, {
    key: "logout",
    value: function logout() {
      this.connection.logout();

      this._removeTokens();

      this.emit('disconnect');
    }
    /**
     * @private
     */

  }, {
    key: "_getTokens",
    value: function _getTokens() {
      var regexp = new RegExp('(^|;\\s*)' + this._prefix + '_loggedin=true(;|$)');

      if (document.cookie.match(regexp)) {
        var issuedAt = Number(localStorage.getItem(this._prefix + '_issued_at')); // 2 hours

        if (_Date$now() < issuedAt + 2 * 60 * 60 * 1000) {
          var userInfo;
          var idUrl = localStorage.getItem(this._prefix + '_id');

          if (idUrl) {
            var _context4;

            var _idUrl$split$reverse = _reverseInstanceProperty(_context4 = idUrl.split('/')).call(_context4),
                _idUrl$split$reverse2 = _slicedToArray(_idUrl$split$reverse, 2),
                id = _idUrl$split$reverse2[0],
                organizationId = _idUrl$split$reverse2[1];

            userInfo = {
              id: id,
              organizationId: organizationId,
              url: idUrl
            };
          }

          return {
            accessToken: localStorage.getItem(this._prefix + '_access_token'),
            instanceUrl: localStorage.getItem(this._prefix + '_instance_url'),
            userInfo: userInfo
          };
        }
      }

      return null;
    }
    /**
     * @private
     */

  }, {
    key: "_storeTokens",
    value: function _storeTokens(params) {
      localStorage.setItem(this._prefix + '_access_token', params.access_token);
      localStorage.setItem(this._prefix + '_instance_url', params.instance_url);
      localStorage.setItem(this._prefix + '_issued_at', params.issued_at);
      localStorage.setItem(this._prefix + '_id', params.id);
      document.cookie = this._prefix + '_loggedin=true;';
    }
    /**
     * @private
     */

  }, {
    key: "_removeTokens",
    value: function _removeTokens() {
      localStorage.removeItem(this._prefix + '_access_token');
      localStorage.removeItem(this._prefix + '_instance_url');
      localStorage.removeItem(this._prefix + '_issued_at');
      localStorage.removeItem(this._prefix + '_id');
      document.cookie = this._prefix + '_loggedin=';
    }
    /**
     * @private
     */

  }, {
    key: "_getError",
    value: function _getError() {
      try {
        var _localStorage$getItem;

        var err = JSON.parse((_localStorage$getItem = localStorage.getItem(this._prefix + '_error')) !== null && _localStorage$getItem !== void 0 ? _localStorage$getItem : '');
        localStorage.removeItem(this._prefix + '_error');
        return err;
      } catch (e) {//
      }
    }
    /**
     * @private
     */

  }, {
    key: "_storeError",
    value: function _storeError(err) {
      localStorage.setItem(this._prefix + '_error', _JSON$stringify(err));
    }
  }, {
    key: "connection",
    get: function get() {
      if (!this._connection) {
        this._connection = new Connection(this._config);
      }

      return this._connection;
    }
  }]);

  return BrowserClient;
}(EventEmitter);
/**
 *
 */

var client = new BrowserClient();
export default client;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9icm93c2VyL2NsaWVudC50cyJdLCJuYW1lcyI6WyJFdmVudEVtaXR0ZXIiLCJxcyIsIkNvbm5lY3Rpb24iLCJPQXV0aDIiLCJwb3B1cFdpbiIsInVybCIsInciLCJoIiwibGVmdCIsInNjcmVlbiIsIndpZHRoIiwidG9wIiwiaGVpZ2h0Iiwid2luZG93Iiwib3BlbiIsInVuZGVmaW5lZCIsImhhbmRsZUNhbGxiYWNrUmVzcG9uc2UiLCJyZXMiLCJjaGVja0NhbGxiYWNrUmVzcG9uc2UiLCJzdGF0ZSIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJib2R5IiwicmVtb3ZlSXRlbSIsInNwbGl0IiwicHJlZml4IiwicHJvbXB0VHlwZSIsImNsaSIsIkJyb3dzZXJDbGllbnQiLCJzdWNjZXNzIiwiX3N0b3JlVG9rZW5zIiwibG9jYXRpb24iLCJoYXNoIiwiX3N0b3JlRXJyb3IiLCJjbG9zZSIsInBhcmFtcyIsInBhcnNlIiwic3Vic3RyaW5nIiwiYWNjZXNzX3Rva2VuIiwic2VhcmNoIiwiZXJyb3IiLCJERUZBVUxUX1BPUFVQX1dJTl9XSURUSCIsIkRFRkFVTFRfUE9QVVBfV0lOX0hFSUdIVCIsImNsaWVudElkeCIsIl9wcmVmaXgiLCJjb25maWciLCJfY29uZmlnIiwidG9rZW5zIiwiX2dldFRva2VucyIsImNvbm5lY3Rpb24iLCJfZXN0YWJsaXNoIiwiZW1pdCIsIm9wdGlvbnMiLCJzY29wZSIsInNpemUiLCJvYXV0aDIiLCJyYW5kIiwiTWF0aCIsInJhbmRvbSIsInRvU3RyaW5nIiwiam9pbiIsInNldEl0ZW0iLCJhdXRoelVybCIsImdldEF1dGhvcml6YXRpb25VcmwiLCJyZXNwb25zZV90eXBlIiwicHciLCJyZXNvbHZlIiwicmVqZWN0IiwiaHJlZiIsIl9yZW1vdmVUb2tlbnMiLCJwaWQiLCJjbG9zZWQiLCJjbGVhckludGVydmFsIiwic3RhdHVzIiwiZXJyIiwiX2dldEVycm9yIiwiRXJyb3IiLCJlcnJvcl9kZXNjcmlwdGlvbiIsImUiLCJhY2Nlc3NUb2tlbiIsImxvZ291dCIsInJlZ2V4cCIsIlJlZ0V4cCIsImRvY3VtZW50IiwiY29va2llIiwibWF0Y2giLCJpc3N1ZWRBdCIsIk51bWJlciIsInVzZXJJbmZvIiwiaWRVcmwiLCJpZCIsIm9yZ2FuaXphdGlvbklkIiwiaW5zdGFuY2VVcmwiLCJpbnN0YW5jZV91cmwiLCJpc3N1ZWRfYXQiLCJKU09OIiwiX2Nvbm5lY3Rpb24iLCJjbGllbnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU0EsWUFBVCxRQUE2QixRQUE3QjtBQUNBLE9BQU9DLEVBQVAsTUFBZSxhQUFmO0FBQ0EsT0FBT0MsVUFBUCxNQUE2QyxlQUE3QztBQUNBLE9BQU9DLE1BQVAsTUFBc0MsV0FBdEM7QUFFQTtBQUNBO0FBQ0E7O0FBQ0EsU0FBU0MsUUFBVCxDQUFrQkMsR0FBbEIsRUFBK0JDLENBQS9CLEVBQTBDQyxDQUExQyxFQUFxRDtBQUFBOztBQUNuRCxNQUFNQyxJQUFJLEdBQUdDLE1BQU0sQ0FBQ0MsS0FBUCxHQUFlLENBQWYsR0FBbUJKLENBQUMsR0FBRyxDQUFwQztBQUNBLE1BQU1LLEdBQUcsR0FBR0YsTUFBTSxDQUFDRyxNQUFQLEdBQWdCLENBQWhCLEdBQW9CTCxDQUFDLEdBQUcsQ0FBcEM7QUFDQSxTQUFPTSxNQUFNLENBQUNDLElBQVAsQ0FDTFQsR0FESyxFQUVMVSxTQUZLLDBLQUdpRFQsQ0FIakQsK0JBRzZEQyxDQUg3RCw0QkFHc0VJLEdBSHRFLDRCQUdrRkgsSUFIbEYsRUFBUDtBQUtEO0FBRUQ7QUFDQTtBQUNBOzs7QUFDQSxTQUFTUSxzQkFBVCxHQUFrQztBQUNoQyxNQUFNQyxHQUFHLEdBQUdDLHFCQUFxQixFQUFqQztBQUNBLE1BQU1DLEtBQUssR0FBR0MsWUFBWSxDQUFDQyxPQUFiLENBQXFCLGVBQXJCLENBQWQ7O0FBQ0EsTUFBSUosR0FBRyxJQUFJRSxLQUFQLElBQWdCRixHQUFHLENBQUNLLElBQUosQ0FBU0gsS0FBVCxLQUFtQkEsS0FBdkMsRUFBOEM7QUFDNUNDLElBQUFBLFlBQVksQ0FBQ0csVUFBYixDQUF3QixlQUF4Qjs7QUFENEMsdUJBRWZKLEtBQUssQ0FBQ0ssS0FBTixDQUFZLEdBQVosQ0FGZTtBQUFBO0FBQUEsUUFFckNDLE1BRnFDO0FBQUEsUUFFN0JDLFVBRjZCOztBQUc1QyxRQUFNQyxHQUFHLEdBQUcsSUFBSUMsYUFBSixDQUFrQkgsTUFBbEIsQ0FBWjs7QUFDQSxRQUFJUixHQUFHLENBQUNZLE9BQVIsRUFBaUI7QUFDZkYsTUFBQUEsR0FBRyxDQUFDRyxZQUFKLENBQWlCYixHQUFHLENBQUNLLElBQXJCOztBQUNBUyxNQUFBQSxRQUFRLENBQUNDLElBQVQsR0FBZ0IsRUFBaEI7QUFDRCxLQUhELE1BR087QUFDTEwsTUFBQUEsR0FBRyxDQUFDTSxXQUFKLENBQWdCaEIsR0FBRyxDQUFDSyxJQUFwQjtBQUNEOztBQUNELFFBQUlJLFVBQVUsS0FBSyxPQUFuQixFQUE0QjtBQUMxQmIsTUFBQUEsTUFBTSxDQUFDcUIsS0FBUDtBQUNEOztBQUNELFdBQU8sSUFBUDtBQUNEO0FBQ0Y7QUFFRDtBQUNBO0FBQ0E7OztBQUNBLFNBQVNoQixxQkFBVCxHQUFpQztBQUMvQixNQUFJaUIsTUFBSjs7QUFDQSxNQUFJdEIsTUFBTSxDQUFDa0IsUUFBUCxDQUFnQkMsSUFBcEIsRUFBMEI7QUFDeEJHLElBQUFBLE1BQU0sR0FBR2xDLEVBQUUsQ0FBQ21DLEtBQUgsQ0FBU3ZCLE1BQU0sQ0FBQ2tCLFFBQVAsQ0FBZ0JDLElBQWhCLENBQXFCSyxTQUFyQixDQUErQixDQUEvQixDQUFULENBQVQ7O0FBQ0EsUUFBSUYsTUFBTSxDQUFDRyxZQUFYLEVBQXlCO0FBQ3ZCLGFBQU87QUFBRVQsUUFBQUEsT0FBTyxFQUFFLElBQVg7QUFBaUJQLFFBQUFBLElBQUksRUFBRWE7QUFBdkIsT0FBUDtBQUNEO0FBQ0YsR0FMRCxNQUtPLElBQUl0QixNQUFNLENBQUNrQixRQUFQLENBQWdCUSxNQUFwQixFQUE0QjtBQUNqQ0osSUFBQUEsTUFBTSxHQUFHbEMsRUFBRSxDQUFDbUMsS0FBSCxDQUFTdkIsTUFBTSxDQUFDa0IsUUFBUCxDQUFnQlEsTUFBaEIsQ0FBdUJGLFNBQXZCLENBQWlDLENBQWpDLENBQVQsQ0FBVDs7QUFDQSxRQUFJRixNQUFNLENBQUNLLEtBQVgsRUFBa0I7QUFDaEIsYUFBTztBQUFFWCxRQUFBQSxPQUFPLEVBQUUsS0FBWDtBQUFrQlAsUUFBQUEsSUFBSSxFQUFFYTtBQUF4QixPQUFQO0FBQ0Q7QUFDRjtBQUNGO0FBRUQ7QUFDQTtBQUNBOzs7QUFNQTtBQUNBO0FBQ0E7QUFDQSxJQUFNTSx1QkFBdUIsR0FBRyxHQUFoQztBQUNBLElBQU1DLHdCQUF3QixHQUFHLEdBQWpDO0FBRUE7O0FBQ0EsSUFBSUMsU0FBUyxHQUFHLENBQWhCO0FBRUE7QUFDQTtBQUNBOztBQUNBLFdBQWFmLGFBQWI7QUFBQTs7QUFBQTs7QUFLRTtBQUNGO0FBQ0E7QUFDRSx5QkFBWUgsTUFBWixFQUE2QjtBQUFBOztBQUFBOztBQUMzQjs7QUFEMkI7O0FBQUE7O0FBQUE7O0FBRTNCLFVBQUttQixPQUFMLEdBQWVuQixNQUFNLElBQUksWUFBWWtCLFNBQVMsRUFBOUM7QUFGMkI7QUFHNUI7O0FBWEg7QUFBQTs7QUFvQkU7QUFDRjtBQUNBO0FBdEJBLHlCQXVCT0UsTUF2QlAsRUF1QmlDO0FBQUE7O0FBQzdCLFVBQUk3QixzQkFBc0IsRUFBMUIsRUFBOEI7QUFDNUI7QUFDRDs7QUFDRCxXQUFLOEIsT0FBTCxHQUFlRCxNQUFmOztBQUNBLFVBQU1FLE1BQU0sR0FBRyxLQUFLQyxVQUFMLEVBQWY7O0FBQ0EsVUFBSUQsTUFBSixFQUFZO0FBQ1YsYUFBS0UsVUFBTCxDQUFnQkMsVUFBaEIsQ0FBMkJILE1BQTNCOztBQUNBLG9CQUFXLFlBQU07QUFDZixVQUFBLE1BQUksQ0FBQ0ksSUFBTCxDQUFVLFNBQVYsRUFBcUIsTUFBSSxDQUFDRixVQUExQjtBQUNELFNBRkQsRUFFRyxFQUZIO0FBR0Q7QUFDRjtBQUVEO0FBQ0Y7QUFDQTs7QUF2Q0E7QUFBQTtBQUFBLDRCQXdDb0M7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQSxVQUE1QkcsT0FBNEIsdUVBQUosRUFBSTtBQUFBLFVBQ3hCQyxLQUR3QixHQUNSRCxPQURRLENBQ3hCQyxLQUR3QjtBQUFBLFVBQ2pCQyxJQURpQixHQUNSRixPQURRLENBQ2pCRSxJQURpQjtBQUVoQyxVQUFNQyxNQUFNLEdBQUcsSUFBSXBELE1BQUosa0JBQVcsS0FBSzJDLE9BQWhCLHlEQUEyQixFQUEzQixDQUFmO0FBQ0EsVUFBTVUsSUFBSSxHQUFHQyxJQUFJLENBQUNDLE1BQUwsR0FBY0MsUUFBZCxDQUF1QixFQUF2QixFQUEyQnRCLFNBQTNCLENBQXFDLENBQXJDLENBQWI7QUFDQSxVQUFNbEIsS0FBSyxHQUFHLENBQUMsS0FBS3lCLE9BQU4sRUFBZSxPQUFmLEVBQXdCWSxJQUF4QixFQUE4QkksSUFBOUIsQ0FBbUMsR0FBbkMsQ0FBZDtBQUNBeEMsTUFBQUEsWUFBWSxDQUFDeUMsT0FBYixDQUFxQixlQUFyQixFQUFzQzFDLEtBQXRDO0FBQ0EsVUFBTTJDLFFBQVEsR0FBR1AsTUFBTSxDQUFDUSxtQkFBUDtBQUNmQyxRQUFBQSxhQUFhLEVBQUUsT0FEQTtBQUVmN0MsUUFBQUEsS0FBSyxFQUFMQTtBQUZlLFNBR1hrQyxLQUFLLEdBQUc7QUFBRUEsUUFBQUEsS0FBSyxFQUFMQTtBQUFGLE9BQUgsR0FBZSxFQUhULEVBQWpCO0FBS0EsVUFBTVksRUFBRSxHQUFHN0QsUUFBUSxDQUNqQjBELFFBRGlCLGlCQUVqQlIsSUFGaUIsYUFFakJBLElBRmlCLHVCQUVqQkEsSUFBSSxDQUFFNUMsS0FGVyxxREFFRitCLHVCQUZFLGtCQUdqQmEsSUFIaUIsYUFHakJBLElBSGlCLHVCQUdqQkEsSUFBSSxDQUFFMUMsTUFIVyx1REFHRDhCLHdCQUhDLENBQW5CO0FBS0EsYUFBTyxhQUFnQyxVQUFDd0IsT0FBRCxFQUFVQyxNQUFWLEVBQXFCO0FBQzFELFlBQUksQ0FBQ0YsRUFBTCxFQUFTO0FBQ1AsY0FBTTlDLE1BQUssR0FBRyxDQUFDLE1BQUksQ0FBQ3lCLE9BQU4sRUFBZSxVQUFmLEVBQTJCWSxJQUEzQixFQUFpQ0ksSUFBakMsQ0FBc0MsR0FBdEMsQ0FBZDs7QUFDQXhDLFVBQUFBLFlBQVksQ0FBQ3lDLE9BQWIsQ0FBcUIsZUFBckIsRUFBc0MxQyxNQUF0Qzs7QUFDQSxjQUFNMkMsU0FBUSxHQUFHUCxNQUFNLENBQUNRLG1CQUFQO0FBQ2ZDLFlBQUFBLGFBQWEsRUFBRSxPQURBO0FBRWY3QyxZQUFBQSxLQUFLLEVBQUxBO0FBRmUsYUFHWGtDLEtBQUssR0FBRztBQUFFQSxZQUFBQSxLQUFLLEVBQUxBO0FBQUYsV0FBSCxHQUFlLEVBSFQsRUFBakI7O0FBS0F0QixVQUFBQSxRQUFRLENBQUNxQyxJQUFULEdBQWdCTixTQUFoQjtBQUNBO0FBQ0Q7O0FBQ0QsUUFBQSxNQUFJLENBQUNPLGFBQUw7O0FBQ0EsWUFBTUMsR0FBRyxHQUFHLGFBQVksWUFBTTtBQUM1QixjQUFJO0FBQ0YsZ0JBQUksQ0FBQ0wsRUFBRCxJQUFPQSxFQUFFLENBQUNNLE1BQWQsRUFBc0I7QUFDcEJDLGNBQUFBLGFBQWEsQ0FBQ0YsR0FBRCxDQUFiOztBQUNBLGtCQUFNdkIsTUFBTSxHQUFHLE1BQUksQ0FBQ0MsVUFBTCxFQUFmOztBQUNBLGtCQUFJRCxNQUFKLEVBQVk7QUFDVixnQkFBQSxNQUFJLENBQUNFLFVBQUwsQ0FBZ0JDLFVBQWhCLENBQTJCSCxNQUEzQjs7QUFDQSxnQkFBQSxNQUFJLENBQUNJLElBQUwsQ0FBVSxTQUFWLEVBQXFCLE1BQUksQ0FBQ0YsVUFBMUI7O0FBQ0FpQixnQkFBQUEsT0FBTyxDQUFDO0FBQUVPLGtCQUFBQSxNQUFNLEVBQUU7QUFBVixpQkFBRCxDQUFQO0FBQ0QsZUFKRCxNQUlPO0FBQ0wsb0JBQU1DLEdBQUcsR0FBRyxNQUFJLENBQUNDLFNBQUwsRUFBWjs7QUFDQSxvQkFBSUQsR0FBSixFQUFTO0FBQ1BQLGtCQUFBQSxNQUFNLENBQUMsSUFBSVMsS0FBSixDQUFVRixHQUFHLENBQUNsQyxLQUFKLEdBQVksSUFBWixHQUFtQmtDLEdBQUcsQ0FBQ0csaUJBQWpDLENBQUQsQ0FBTjtBQUNELGlCQUZELE1BRU87QUFDTFgsa0JBQUFBLE9BQU8sQ0FBQztBQUFFTyxvQkFBQUEsTUFBTSxFQUFFO0FBQVYsbUJBQUQsQ0FBUDtBQUNEO0FBQ0Y7QUFDRjtBQUNGLFdBakJELENBaUJFLE9BQU9LLENBQVAsRUFBVSxDQUNWO0FBQ0Q7QUFDRixTQXJCVyxFQXFCVCxJQXJCUyxDQUFaO0FBc0JELE9BbkNNLENBQVA7QUFvQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBaEdBO0FBQUE7QUFBQSxpQ0FpR2U7QUFDWCxhQUFPLENBQUMsQ0FBQyxLQUFLN0IsVUFBTCxDQUFnQjhCLFdBQXpCO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBdkdBO0FBQUE7QUFBQSw2QkF3R1c7QUFDUCxXQUFLOUIsVUFBTCxDQUFnQitCLE1BQWhCOztBQUNBLFdBQUtYLGFBQUw7O0FBQ0EsV0FBS2xCLElBQUwsQ0FBVSxZQUFWO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBaEhBO0FBQUE7QUFBQSxpQ0FpSGU7QUFDWCxVQUFNOEIsTUFBTSxHQUFHLElBQUlDLE1BQUosQ0FDYixjQUFjLEtBQUt0QyxPQUFuQixHQUE2QixxQkFEaEIsQ0FBZjs7QUFHQSxVQUFJdUMsUUFBUSxDQUFDQyxNQUFULENBQWdCQyxLQUFoQixDQUFzQkosTUFBdEIsQ0FBSixFQUFtQztBQUNqQyxZQUFNSyxRQUFRLEdBQUdDLE1BQU0sQ0FDckJuRSxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsS0FBS3VCLE9BQUwsR0FBZSxZQUFwQyxDQURxQixDQUF2QixDQURpQyxDQUlqQzs7QUFDQSxZQUFJLGNBQWEwQyxRQUFRLEdBQUcsSUFBSSxFQUFKLEdBQVMsRUFBVCxHQUFjLElBQTFDLEVBQWdEO0FBQzlDLGNBQUlFLFFBQUo7QUFDQSxjQUFNQyxLQUFLLEdBQUdyRSxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsS0FBS3VCLE9BQUwsR0FBZSxLQUFwQyxDQUFkOztBQUNBLGNBQUk2QyxLQUFKLEVBQVc7QUFBQTs7QUFBQSx1Q0FDb0IscUNBQUFBLEtBQUssQ0FBQ2pFLEtBQU4sQ0FBWSxHQUFaLGtCQURwQjtBQUFBO0FBQUEsZ0JBQ0ZrRSxFQURFO0FBQUEsZ0JBQ0VDLGNBREY7O0FBRVRILFlBQUFBLFFBQVEsR0FBRztBQUFFRSxjQUFBQSxFQUFFLEVBQUZBLEVBQUY7QUFBTUMsY0FBQUEsY0FBYyxFQUFkQSxjQUFOO0FBQXNCdEYsY0FBQUEsR0FBRyxFQUFFb0Y7QUFBM0IsYUFBWDtBQUNEOztBQUNELGlCQUFPO0FBQ0xWLFlBQUFBLFdBQVcsRUFBRTNELFlBQVksQ0FBQ0MsT0FBYixDQUFxQixLQUFLdUIsT0FBTCxHQUFlLGVBQXBDLENBRFI7QUFFTGdELFlBQUFBLFdBQVcsRUFBRXhFLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixLQUFLdUIsT0FBTCxHQUFlLGVBQXBDLENBRlI7QUFHTDRDLFlBQUFBLFFBQVEsRUFBUkE7QUFISyxXQUFQO0FBS0Q7QUFDRjs7QUFDRCxhQUFPLElBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUE3SUE7QUFBQTtBQUFBLGlDQThJZXJELE1BOUlmLEVBOElzQztBQUNsQ2YsTUFBQUEsWUFBWSxDQUFDeUMsT0FBYixDQUFxQixLQUFLakIsT0FBTCxHQUFlLGVBQXBDLEVBQXFEVCxNQUFNLENBQUNHLFlBQTVEO0FBQ0FsQixNQUFBQSxZQUFZLENBQUN5QyxPQUFiLENBQXFCLEtBQUtqQixPQUFMLEdBQWUsZUFBcEMsRUFBcURULE1BQU0sQ0FBQzBELFlBQTVEO0FBQ0F6RSxNQUFBQSxZQUFZLENBQUN5QyxPQUFiLENBQXFCLEtBQUtqQixPQUFMLEdBQWUsWUFBcEMsRUFBa0RULE1BQU0sQ0FBQzJELFNBQXpEO0FBQ0ExRSxNQUFBQSxZQUFZLENBQUN5QyxPQUFiLENBQXFCLEtBQUtqQixPQUFMLEdBQWUsS0FBcEMsRUFBMkNULE1BQU0sQ0FBQ3VELEVBQWxEO0FBQ0FQLE1BQUFBLFFBQVEsQ0FBQ0MsTUFBVCxHQUFrQixLQUFLeEMsT0FBTCxHQUFlLGlCQUFqQztBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQXhKQTtBQUFBO0FBQUEsb0NBeUprQjtBQUNkeEIsTUFBQUEsWUFBWSxDQUFDRyxVQUFiLENBQXdCLEtBQUtxQixPQUFMLEdBQWUsZUFBdkM7QUFDQXhCLE1BQUFBLFlBQVksQ0FBQ0csVUFBYixDQUF3QixLQUFLcUIsT0FBTCxHQUFlLGVBQXZDO0FBQ0F4QixNQUFBQSxZQUFZLENBQUNHLFVBQWIsQ0FBd0IsS0FBS3FCLE9BQUwsR0FBZSxZQUF2QztBQUNBeEIsTUFBQUEsWUFBWSxDQUFDRyxVQUFiLENBQXdCLEtBQUtxQixPQUFMLEdBQWUsS0FBdkM7QUFDQXVDLE1BQUFBLFFBQVEsQ0FBQ0MsTUFBVCxHQUFrQixLQUFLeEMsT0FBTCxHQUFlLFlBQWpDO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBbktBO0FBQUE7QUFBQSxnQ0FvS2M7QUFDVixVQUFJO0FBQUE7O0FBQ0YsWUFBTThCLEdBQUcsR0FBR3FCLElBQUksQ0FBQzNELEtBQUwsMEJBQ1ZoQixZQUFZLENBQUNDLE9BQWIsQ0FBcUIsS0FBS3VCLE9BQUwsR0FBZSxRQUFwQyxDQURVLHlFQUN1QyxFQUR2QyxDQUFaO0FBR0F4QixRQUFBQSxZQUFZLENBQUNHLFVBQWIsQ0FBd0IsS0FBS3FCLE9BQUwsR0FBZSxRQUF2QztBQUNBLGVBQU84QixHQUFQO0FBQ0QsT0FORCxDQU1FLE9BQU9JLENBQVAsRUFBVSxDQUNWO0FBQ0Q7QUFDRjtBQUVEO0FBQ0Y7QUFDQTs7QUFsTEE7QUFBQTtBQUFBLGdDQW1MY0osR0FuTGQsRUFtTHdCO0FBQ3BCdEQsTUFBQUEsWUFBWSxDQUFDeUMsT0FBYixDQUFxQixLQUFLakIsT0FBTCxHQUFlLFFBQXBDLEVBQThDLGdCQUFlOEIsR0FBZixDQUE5QztBQUNEO0FBckxIO0FBQUE7QUFBQSx3QkFhK0I7QUFDM0IsVUFBSSxDQUFDLEtBQUtzQixXQUFWLEVBQXVCO0FBQ3JCLGFBQUtBLFdBQUwsR0FBbUIsSUFBSTlGLFVBQUosQ0FBZSxLQUFLNEMsT0FBcEIsQ0FBbkI7QUFDRDs7QUFDRCxhQUFPLEtBQUtrRCxXQUFaO0FBQ0Q7QUFsQkg7O0FBQUE7QUFBQSxFQUFtQ2hHLFlBQW5DO0FBd0xBO0FBQ0E7QUFDQTs7QUFDQSxJQUFNaUcsTUFBTSxHQUFHLElBQUlyRSxhQUFKLEVBQWY7QUFFQSxlQUFlcUUsTUFBZiIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGZpbGUgQnJvd3NlciBjbGllbnQgY29ubmVjdGlvbiBtYW5hZ2VtZW50IGNsYXNzXG4gKiBAYXV0aG9yIFNoaW5pY2hpIFRvbWl0YSA8c2hpbmljaGkudG9taXRhQGdtYWlsLmNvbT5cbiAqL1xuaW1wb3J0IHsgRXZlbnRFbWl0dGVyIH0gZnJvbSAnZXZlbnRzJztcbmltcG9ydCBxcyBmcm9tICdxdWVyeXN0cmluZyc7XG5pbXBvcnQgQ29ubmVjdGlvbiwgeyBDb25uZWN0aW9uQ29uZmlnIH0gZnJvbSAnLi4vY29ubmVjdGlvbic7XG5pbXBvcnQgT0F1dGgyLCB7IFRva2VuUmVzcG9uc2UgfSBmcm9tICcuLi9vYXV0aDInO1xuXG4vKipcbiAqIEBwcml2YXRlXG4gKi9cbmZ1bmN0aW9uIHBvcHVwV2luKHVybDogc3RyaW5nLCB3OiBudW1iZXIsIGg6IG51bWJlcikge1xuICBjb25zdCBsZWZ0ID0gc2NyZWVuLndpZHRoIC8gMiAtIHcgLyAyO1xuICBjb25zdCB0b3AgPSBzY3JlZW4uaGVpZ2h0IC8gMiAtIGggLyAyO1xuICByZXR1cm4gd2luZG93Lm9wZW4oXG4gICAgdXJsLFxuICAgIHVuZGVmaW5lZCxcbiAgICBgbG9jYXRpb249eWVzLHRvb2xiYXI9bm8sc3RhdHVzPW5vLG1lbnViYXI9bm8sd2lkdGg9JHt3fSxoZWlnaHQ9JHtofSx0b3A9JHt0b3B9LGxlZnQ9JHtsZWZ0fWAsXG4gICk7XG59XG5cbi8qKlxuICogQHByaXZhdGVcbiAqL1xuZnVuY3Rpb24gaGFuZGxlQ2FsbGJhY2tSZXNwb25zZSgpIHtcbiAgY29uc3QgcmVzID0gY2hlY2tDYWxsYmFja1Jlc3BvbnNlKCk7XG4gIGNvbnN0IHN0YXRlID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2pzZm9yY2Vfc3RhdGUnKTtcbiAgaWYgKHJlcyAmJiBzdGF0ZSAmJiByZXMuYm9keS5zdGF0ZSA9PT0gc3RhdGUpIHtcbiAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnanNmb3JjZV9zdGF0ZScpO1xuICAgIGNvbnN0IFtwcmVmaXgsIHByb21wdFR5cGVdID0gc3RhdGUuc3BsaXQoJy4nKTtcbiAgICBjb25zdCBjbGkgPSBuZXcgQnJvd3NlckNsaWVudChwcmVmaXgpO1xuICAgIGlmIChyZXMuc3VjY2Vzcykge1xuICAgICAgY2xpLl9zdG9yZVRva2VucyhyZXMuYm9keSBhcyBUb2tlblJlc3BvbnNlKTtcbiAgICAgIGxvY2F0aW9uLmhhc2ggPSAnJztcbiAgICB9IGVsc2Uge1xuICAgICAgY2xpLl9zdG9yZUVycm9yKHJlcy5ib2R5KTtcbiAgICB9XG4gICAgaWYgKHByb21wdFR5cGUgPT09ICdwb3B1cCcpIHtcbiAgICAgIHdpbmRvdy5jbG9zZSgpO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxufVxuXG4vKipcbiAqIEBwcml2YXRlXG4gKi9cbmZ1bmN0aW9uIGNoZWNrQ2FsbGJhY2tSZXNwb25zZSgpIHtcbiAgbGV0IHBhcmFtcztcbiAgaWYgKHdpbmRvdy5sb2NhdGlvbi5oYXNoKSB7XG4gICAgcGFyYW1zID0gcXMucGFyc2Uod2luZG93LmxvY2F0aW9uLmhhc2guc3Vic3RyaW5nKDEpKTtcbiAgICBpZiAocGFyYW1zLmFjY2Vzc190b2tlbikge1xuICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgYm9keTogcGFyYW1zIH07XG4gICAgfVxuICB9IGVsc2UgaWYgKHdpbmRvdy5sb2NhdGlvbi5zZWFyY2gpIHtcbiAgICBwYXJhbXMgPSBxcy5wYXJzZSh3aW5kb3cubG9jYXRpb24uc2VhcmNoLnN1YnN0cmluZygxKSk7XG4gICAgaWYgKHBhcmFtcy5lcnJvcikge1xuICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGJvZHk6IHBhcmFtcyB9O1xuICAgIH1cbiAgfVxufVxuXG4vKipcbiAqXG4gKi9cbmV4cG9ydCB0eXBlIExvZ2luT3B0aW9ucyA9IHtcbiAgc2NvcGU/OiBzdHJpbmc7XG4gIHNpemU/OiB7IHdpZHRoOiBudW1iZXI7IGhlaWdodDogbnVtYmVyIH07XG59O1xuXG4vKipcbiAqXG4gKi9cbmNvbnN0IERFRkFVTFRfUE9QVVBfV0lOX1dJRFRIID0gOTEyO1xuY29uc3QgREVGQVVMVF9QT1BVUF9XSU5fSEVJR0hUID0gNTEzO1xuXG4vKiogQHByaXZhdGUgKiovXG5sZXQgY2xpZW50SWR4ID0gMDtcblxuLyoqXG4gKlxuICovXG5leHBvcnQgY2xhc3MgQnJvd3NlckNsaWVudCBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIF9wcmVmaXg6IHN0cmluZztcbiAgX2NvbmZpZzogQ29ubmVjdGlvbkNvbmZpZyB8IHVuZGVmaW5lZDtcbiAgX2Nvbm5lY3Rpb246IENvbm5lY3Rpb24gfCB1bmRlZmluZWQ7XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBjb25zdHJ1Y3RvcihwcmVmaXg/OiBzdHJpbmcpIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuX3ByZWZpeCA9IHByZWZpeCB8fCAnanNmb3JjZScgKyBjbGllbnRJZHgrKztcbiAgfVxuXG4gIGdldCBjb25uZWN0aW9uKCk6IENvbm5lY3Rpb24ge1xuICAgIGlmICghdGhpcy5fY29ubmVjdGlvbikge1xuICAgICAgdGhpcy5fY29ubmVjdGlvbiA9IG5ldyBDb25uZWN0aW9uKHRoaXMuX2NvbmZpZyk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9jb25uZWN0aW9uO1xuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBpbml0KGNvbmZpZzogQ29ubmVjdGlvbkNvbmZpZykge1xuICAgIGlmIChoYW5kbGVDYWxsYmFja1Jlc3BvbnNlKCkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy5fY29uZmlnID0gY29uZmlnO1xuICAgIGNvbnN0IHRva2VucyA9IHRoaXMuX2dldFRva2VucygpO1xuICAgIGlmICh0b2tlbnMpIHtcbiAgICAgIHRoaXMuY29ubmVjdGlvbi5fZXN0YWJsaXNoKHRva2Vucyk7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgdGhpcy5lbWl0KCdjb25uZWN0JywgdGhpcy5jb25uZWN0aW9uKTtcbiAgICAgIH0sIDEwKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIGxvZ2luKG9wdGlvbnM6IExvZ2luT3B0aW9ucyA9IHt9KSB7XG4gICAgY29uc3QgeyBzY29wZSwgc2l6ZSB9ID0gb3B0aW9ucztcbiAgICBjb25zdCBvYXV0aDIgPSBuZXcgT0F1dGgyKHRoaXMuX2NvbmZpZyA/PyB7fSk7XG4gICAgY29uc3QgcmFuZCA9IE1hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnN1YnN0cmluZygyKTtcbiAgICBjb25zdCBzdGF0ZSA9IFt0aGlzLl9wcmVmaXgsICdwb3B1cCcsIHJhbmRdLmpvaW4oJy4nKTtcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnanNmb3JjZV9zdGF0ZScsIHN0YXRlKTtcbiAgICBjb25zdCBhdXRoelVybCA9IG9hdXRoMi5nZXRBdXRob3JpemF0aW9uVXJsKHtcbiAgICAgIHJlc3BvbnNlX3R5cGU6ICd0b2tlbicsXG4gICAgICBzdGF0ZSxcbiAgICAgIC4uLihzY29wZSA/IHsgc2NvcGUgfSA6IHt9KSxcbiAgICB9KTtcbiAgICBjb25zdCBwdyA9IHBvcHVwV2luKFxuICAgICAgYXV0aHpVcmwsXG4gICAgICBzaXplPy53aWR0aCA/PyBERUZBVUxUX1BPUFVQX1dJTl9XSURUSCxcbiAgICAgIHNpemU/LmhlaWdodCA/PyBERUZBVUxUX1BPUFVQX1dJTl9IRUlHSFQsXG4gICAgKTtcbiAgICByZXR1cm4gbmV3IFByb21pc2U8eyBzdGF0dXM6IHN0cmluZyB9PigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICBpZiAoIXB3KSB7XG4gICAgICAgIGNvbnN0IHN0YXRlID0gW3RoaXMuX3ByZWZpeCwgJ3JlZGlyZWN0JywgcmFuZF0uam9pbignLicpO1xuICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnanNmb3JjZV9zdGF0ZScsIHN0YXRlKTtcbiAgICAgICAgY29uc3QgYXV0aHpVcmwgPSBvYXV0aDIuZ2V0QXV0aG9yaXphdGlvblVybCh7XG4gICAgICAgICAgcmVzcG9uc2VfdHlwZTogJ3Rva2VuJyxcbiAgICAgICAgICBzdGF0ZSxcbiAgICAgICAgICAuLi4oc2NvcGUgPyB7IHNjb3BlIH0gOiB7fSksXG4gICAgICAgIH0pO1xuICAgICAgICBsb2NhdGlvbi5ocmVmID0gYXV0aHpVcmw7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHRoaXMuX3JlbW92ZVRva2VucygpO1xuICAgICAgY29uc3QgcGlkID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGlmICghcHcgfHwgcHcuY2xvc2VkKSB7XG4gICAgICAgICAgICBjbGVhckludGVydmFsKHBpZCk7XG4gICAgICAgICAgICBjb25zdCB0b2tlbnMgPSB0aGlzLl9nZXRUb2tlbnMoKTtcbiAgICAgICAgICAgIGlmICh0b2tlbnMpIHtcbiAgICAgICAgICAgICAgdGhpcy5jb25uZWN0aW9uLl9lc3RhYmxpc2godG9rZW5zKTtcbiAgICAgICAgICAgICAgdGhpcy5lbWl0KCdjb25uZWN0JywgdGhpcy5jb25uZWN0aW9uKTtcbiAgICAgICAgICAgICAgcmVzb2x2ZSh7IHN0YXR1czogJ2Nvbm5lY3QnIH0pO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgY29uc3QgZXJyID0gdGhpcy5fZ2V0RXJyb3IoKTtcbiAgICAgICAgICAgICAgaWYgKGVycikge1xuICAgICAgICAgICAgICAgIHJlamVjdChuZXcgRXJyb3IoZXJyLmVycm9yICsgJzogJyArIGVyci5lcnJvcl9kZXNjcmlwdGlvbikpO1xuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHJlc29sdmUoeyBzdGF0dXM6ICdjYW5jZWwnIH0pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgLy9cbiAgICAgICAgfVxuICAgICAgfSwgMTAwMCk7XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIGlzTG9nZ2VkSW4oKSB7XG4gICAgcmV0dXJuICEhdGhpcy5jb25uZWN0aW9uLmFjY2Vzc1Rva2VuO1xuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBsb2dvdXQoKSB7XG4gICAgdGhpcy5jb25uZWN0aW9uLmxvZ291dCgpO1xuICAgIHRoaXMuX3JlbW92ZVRva2VucygpO1xuICAgIHRoaXMuZW1pdCgnZGlzY29ubmVjdCcpO1xuICB9XG5cbiAgLyoqXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfZ2V0VG9rZW5zKCkge1xuICAgIGNvbnN0IHJlZ2V4cCA9IG5ldyBSZWdFeHAoXG4gICAgICAnKF58O1xcXFxzKiknICsgdGhpcy5fcHJlZml4ICsgJ19sb2dnZWRpbj10cnVlKDt8JCknLFxuICAgICk7XG4gICAgaWYgKGRvY3VtZW50LmNvb2tpZS5tYXRjaChyZWdleHApKSB7XG4gICAgICBjb25zdCBpc3N1ZWRBdCA9IE51bWJlcihcbiAgICAgICAgbG9jYWxTdG9yYWdlLmdldEl0ZW0odGhpcy5fcHJlZml4ICsgJ19pc3N1ZWRfYXQnKSxcbiAgICAgICk7XG4gICAgICAvLyAyIGhvdXJzXG4gICAgICBpZiAoRGF0ZS5ub3coKSA8IGlzc3VlZEF0ICsgMiAqIDYwICogNjAgKiAxMDAwKSB7XG4gICAgICAgIGxldCB1c2VySW5mbztcbiAgICAgICAgY29uc3QgaWRVcmwgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSh0aGlzLl9wcmVmaXggKyAnX2lkJyk7XG4gICAgICAgIGlmIChpZFVybCkge1xuICAgICAgICAgIGNvbnN0IFtpZCwgb3JnYW5pemF0aW9uSWRdID0gaWRVcmwuc3BsaXQoJy8nKS5yZXZlcnNlKCk7XG4gICAgICAgICAgdXNlckluZm8gPSB7IGlkLCBvcmdhbml6YXRpb25JZCwgdXJsOiBpZFVybCB9O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgYWNjZXNzVG9rZW46IGxvY2FsU3RvcmFnZS5nZXRJdGVtKHRoaXMuX3ByZWZpeCArICdfYWNjZXNzX3Rva2VuJyksXG4gICAgICAgICAgaW5zdGFuY2VVcmw6IGxvY2FsU3RvcmFnZS5nZXRJdGVtKHRoaXMuX3ByZWZpeCArICdfaW5zdGFuY2VfdXJsJyksXG4gICAgICAgICAgdXNlckluZm8sXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAgLyoqXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfc3RvcmVUb2tlbnMocGFyYW1zOiBUb2tlblJlc3BvbnNlKSB7XG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0odGhpcy5fcHJlZml4ICsgJ19hY2Nlc3NfdG9rZW4nLCBwYXJhbXMuYWNjZXNzX3Rva2VuKTtcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSh0aGlzLl9wcmVmaXggKyAnX2luc3RhbmNlX3VybCcsIHBhcmFtcy5pbnN0YW5jZV91cmwpO1xuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKHRoaXMuX3ByZWZpeCArICdfaXNzdWVkX2F0JywgcGFyYW1zLmlzc3VlZF9hdCk7XG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0odGhpcy5fcHJlZml4ICsgJ19pZCcsIHBhcmFtcy5pZCk7XG4gICAgZG9jdW1lbnQuY29va2llID0gdGhpcy5fcHJlZml4ICsgJ19sb2dnZWRpbj10cnVlOyc7XG4gIH1cblxuICAvKipcbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9yZW1vdmVUb2tlbnMoKSB7XG4gICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0odGhpcy5fcHJlZml4ICsgJ19hY2Nlc3NfdG9rZW4nKTtcbiAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSh0aGlzLl9wcmVmaXggKyAnX2luc3RhbmNlX3VybCcpO1xuICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKHRoaXMuX3ByZWZpeCArICdfaXNzdWVkX2F0Jyk7XG4gICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0odGhpcy5fcHJlZml4ICsgJ19pZCcpO1xuICAgIGRvY3VtZW50LmNvb2tpZSA9IHRoaXMuX3ByZWZpeCArICdfbG9nZ2VkaW49JztcbiAgfVxuXG4gIC8qKlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX2dldEVycm9yKCkge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBlcnIgPSBKU09OLnBhcnNlKFxuICAgICAgICBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSh0aGlzLl9wcmVmaXggKyAnX2Vycm9yJykgPz8gJycsXG4gICAgICApO1xuICAgICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0odGhpcy5fcHJlZml4ICsgJ19lcnJvcicpO1xuICAgICAgcmV0dXJuIGVycjtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAvL1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX3N0b3JlRXJyb3IoZXJyOiBhbnkpIHtcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSh0aGlzLl9wcmVmaXggKyAnX2Vycm9yJywgSlNPTi5zdHJpbmdpZnkoZXJyKSk7XG4gIH1cbn1cblxuLyoqXG4gKlxuICovXG5jb25zdCBjbGllbnQgPSBuZXcgQnJvd3NlckNsaWVudCgpO1xuXG5leHBvcnQgZGVmYXVsdCBjbGllbnQ7XG4iXX0=