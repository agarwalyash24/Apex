import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import "core-js/modules/es.number.constructor";
import "core-js/modules/es.object.to-string";
import "core-js/modules/es.promise";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _reduceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/reduce";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _indexOfInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/index-of";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import "regenerator-runtime/runtime";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context19; _forEachInstanceProperty(_context19 = ownKeys(Object(source), true)).call(_context19, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context20; _forEachInstanceProperty(_context20 = ownKeys(Object(source))).call(_context20, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 * @file Command line interface for JSforce
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import http from 'http';
import url from 'url';
import crypto from 'crypto';
import _openUrl from 'open';
import { Command } from 'commander';
import inquirer from 'inquirer';
import request from '../request';
import base64url from 'base64url';
import Repl from './repl';
import jsforce, { Connection, OAuth2 } from '..';
import version from '../VERSION';
var registry = jsforce.registry;

/**
 *
 */
export var Cli = /*#__PURE__*/function () {
  function Cli() {
    _classCallCheck(this, Cli);

    _defineProperty(this, "_repl", new Repl(this));

    _defineProperty(this, "_conn", new Connection());

    _defineProperty(this, "_connName", undefined);

    _defineProperty(this, "_outputEnabled", true);

    _defineProperty(this, "_defaultLoginUrl", undefined);
  }

  _createClass(Cli, [{
    key: "readCommand",

    /**
     *
     */
    value: function readCommand() {
      return new Command().option('-u, --username [username]', 'Salesforce username').option('-p, --password [password]', 'Salesforce password (and security token, if available)').option('-c, --connection [connection]', 'Connection name stored in connection registry').option('-l, --loginUrl [loginUrl]', 'Salesforce login url').option('--sandbox', 'Login to Salesforce sandbox').option('-e, --evalScript [evalScript]', 'Script to evaluate').version(version).parse(process.argv);
    }
  }, {
    key: "start",
    value: function () {
      var _start = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee() {
        var program;
        return _regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                program = this.readCommand();
                this._outputEnabled = !program.evalScript;
                _context.prev = 2;
                _context.next = 5;
                return this.connect(program);

              case 5:
                if (program.evalScript) {
                  this._repl.start({
                    interactive: false,
                    evalScript: program.evalScript
                  });
                } else {
                  this._repl.start();
                }

                _context.next = 12;
                break;

              case 8:
                _context.prev = 8;
                _context.t0 = _context["catch"](2);
                console.error(_context.t0);
                process.exit();

              case 12:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this, [[2, 8]]);
      }));

      function start() {
        return _start.apply(this, arguments);
      }

      return start;
    }()
  }, {
    key: "getCurrentConnection",
    value: function getCurrentConnection() {
      return this._conn;
    }
  }, {
    key: "print",
    value: function print() {
      if (this._outputEnabled) {
        var _console;

        (_console = console).log.apply(_console, arguments);
      }
    }
  }, {
    key: "saveCurrentConnection",
    value: function saveCurrentConnection() {
      if (this._connName) {
        var conn = this._conn;
        var connName = this._connName;
        var connConfig = {
          oauth2: conn.oauth2 ? {
            clientId: conn.oauth2.clientId || undefined,
            clientSecret: conn.oauth2.clientSecret || undefined,
            redirectUri: conn.oauth2.redirectUri || undefined,
            loginUrl: conn.oauth2.loginUrl || undefined
          } : undefined,
          accessToken: conn.accessToken || undefined,
          instanceUrl: conn.instanceUrl || undefined,
          refreshToken: conn.refreshToken || undefined
        };
        registry.saveConnectionConfig(connName, connConfig);
      }
    }
  }, {
    key: "setLoginServer",
    value: function setLoginServer(loginServer) {
      if (!loginServer) {
        return;
      }

      if (loginServer === 'production') {
        this._defaultLoginUrl = 'https://login.salesforce.com';
      } else if (loginServer === 'sandbox') {
        this._defaultLoginUrl = 'https://test.salesforce.com';
      } else if (_indexOfInstanceProperty(loginServer).call(loginServer, 'https://') !== 0) {
        this._defaultLoginUrl = 'https://' + loginServer;
      } else {
        this._defaultLoginUrl = loginServer;
      }

      this.print("Using \"".concat(this._defaultLoginUrl, "\" as default login URL."));
    }
    /**
     *
     */

  }, {
    key: "connect",
    value: function () {
      var _connect = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee2(options) {
        var _this = this;

        var loginServer, connConfig, username, password, identity;
        return _regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                loginServer = options.loginUrl ? options.loginUrl : options.sandbox ? 'sandbox' : null;
                this.setLoginServer(loginServer);
                this._connName = options.connection;
                _context2.next = 5;
                return registry.getConnectionConfig(options.connection);

              case 5:
                connConfig = _context2.sent;
                username = options.username;

                if (!connConfig) {
                  connConfig = {};

                  if (this._defaultLoginUrl) {
                    connConfig.loginUrl = this._defaultLoginUrl;
                  }

                  username = username || options.connection;
                }

                this._conn = new Connection(connConfig);
                password = options.password;

                if (!username) {
                  _context2.next = 16;
                  break;
                }

                _context2.next = 13;
                return this.startPasswordAuth(username, password);

              case 13:
                this.saveCurrentConnection();
                _context2.next = 34;
                break;

              case 16:
                if (!(this._connName && this._conn.accessToken)) {
                  _context2.next = 34;
                  break;
                }

                this._conn.on('refresh', function () {
                  _this.print('Refreshing access token ... ');

                  _this.saveCurrentConnection();
                });

                _context2.prev = 18;
                _context2.next = 21;
                return this._conn.identity();

              case 21:
                identity = _context2.sent;
                this.print("Logged in as : ".concat(identity.username));
                _context2.next = 34;
                break;

              case 25:
                _context2.prev = 25;
                _context2.t0 = _context2["catch"](18);

                if (_context2.t0 instanceof Error) {
                  this.print(_context2.t0.message);
                }

                if (!this._conn.oauth2) {
                  _context2.next = 32;
                  break;
                }

                throw new Error('Please re-authorize connection.');

              case 32:
                _context2.next = 34;
                return this.startPasswordAuth(this._connName);

              case 34:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this, [[18, 25]]);
      }));

      function connect(_x) {
        return _connect.apply(this, arguments);
      }

      return connect;
    }()
    /**
     *
     */

  }, {
    key: "startPasswordAuth",
    value: function () {
      var _startPasswordAuth = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee3(username, password) {
        return _regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.prev = 0;
                _context3.next = 3;
                return this.loginByPassword(username, password, 2);

              case 3:
                _context3.next = 12;
                break;

              case 5:
                _context3.prev = 5;
                _context3.t0 = _context3["catch"](0);

                if (!(_context3.t0 instanceof Error && _context3.t0.message === 'canceled')) {
                  _context3.next = 11;
                  break;
                }

                console.error('Password authentication canceled: Not logged in');
                _context3.next = 12;
                break;

              case 11:
                throw _context3.t0;

              case 12:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this, [[0, 5]]);
      }));

      function startPasswordAuth(_x2, _x3) {
        return _startPasswordAuth.apply(this, arguments);
      }

      return startPasswordAuth;
    }()
    /**
     *
     */

  }, {
    key: "loginByPassword",
    value: function () {
      var _loginByPassword = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee4(username, password, retryCount) {
        var pass, result;
        return _regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                if (!(password === '')) {
                  _context4.next = 2;
                  break;
                }

                throw new Error('canceled');

              case 2:
                if (!(password == null)) {
                  _context4.next = 7;
                  break;
                }

                _context4.next = 5;
                return this.promptPassword('Password: ');

              case 5:
                pass = _context4.sent;
                return _context4.abrupt("return", this.loginByPassword(username, pass, retryCount));

              case 7:
                _context4.prev = 7;
                _context4.next = 10;
                return this._conn.login(username, password);

              case 10:
                result = _context4.sent;
                this.print("Logged in as : ".concat(username));
                return _context4.abrupt("return", result);

              case 15:
                _context4.prev = 15;
                _context4.t0 = _context4["catch"](7);

                if (_context4.t0 instanceof Error) {
                  console.error(_context4.t0.message);
                }

                if (!(retryCount > 0)) {
                  _context4.next = 22;
                  break;
                }

                return _context4.abrupt("return", this.loginByPassword(username, undefined, retryCount - 1));

              case 22:
                throw new Error('canceled');

              case 23:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this, [[7, 15]]);
      }));

      function loginByPassword(_x4, _x5, _x6) {
        return _loginByPassword.apply(this, arguments);
      }

      return loginByPassword;
    }()
    /**
     *
     */

  }, {
    key: "disconnect",
    value: function disconnect(connName) {
      var name = connName || this._connName;

      if (name && registry.getConnectionConfig(name)) {
        registry.removeConnectionConfig(name);
        this.print("Disconnect connection '".concat(name, "'"));
      }

      this._connName = undefined;
      this._conn = new Connection();
    }
    /**
     *
     */

  }, {
    key: "authorize",
    value: function () {
      var _authorize = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee5(clientName) {
        var name, oauth2Config, oauth2, verifier, challenge, state, authzUrl, params, identity;
        return _regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                name = clientName || 'default';
                _context5.next = 3;
                return registry.getClientConfig(name);

              case 3:
                oauth2Config = _context5.sent;

                if (!(!oauth2Config || !oauth2Config.clientId)) {
                  _context5.next = 9;
                  break;
                }

                if (!(name === 'default' || name === 'sandbox')) {
                  _context5.next = 8;
                  break;
                }

                this.print('No client information registered. Downloading JSforce default client information...');
                return _context5.abrupt("return", this.downloadDefaultClientInfo(name));

              case 8:
                throw new Error("No OAuth2 client information registered : '".concat(name, "'. Please register client info first."));

              case 9:
                oauth2 = new OAuth2(oauth2Config);
                verifier = base64url.encode(crypto.randomBytes(32));
                challenge = base64url.encode(crypto.createHash('sha256').update(verifier).digest());
                state = base64url.encode(crypto.randomBytes(32));
                authzUrl = oauth2.getAuthorizationUrl({
                  code_challenge: challenge,
                  state: state
                });
                this.print('Opening authorization page in browser...');
                this.print("URL: ".concat(authzUrl));
                this.openUrl(authzUrl);
                _context5.next = 19;
                return this.waitCallback(oauth2Config.redirectUri, state);

              case 19:
                params = _context5.sent;

                if (params.code) {
                  _context5.next = 22;
                  break;
                }

                throw new Error('No authorization code returned.');

              case 22:
                if (!(params.state !== state)) {
                  _context5.next = 24;
                  break;
                }

                throw new Error('Invalid state parameter returned.');

              case 24:
                this._conn = new Connection({
                  oauth2: oauth2
                });
                this.print('Received authorization code. Please close the opened browser window.');
                _context5.next = 28;
                return this._conn.authorize(params.code, {
                  code_verifier: verifier
                });

              case 28:
                this.print('Authorized. Fetching user info...');
                _context5.next = 31;
                return this._conn.identity();

              case 31:
                identity = _context5.sent;
                this.print("Logged in as : ".concat(identity.username));
                this._connName = identity.username;
                this.saveCurrentConnection();

              case 35:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function authorize(_x7) {
        return _authorize.apply(this, arguments);
      }

      return authorize;
    }()
    /**
     *
     */

  }, {
    key: "downloadDefaultClientInfo",
    value: function () {
      var _downloadDefaultClientInfo = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee6(clientName) {
        var configUrl, res, clientConfig;
        return _regeneratorRuntime.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                configUrl = 'https://jsforce.github.io/client-config/default.json';
                _context6.next = 3;
                return new _Promise(function (resolve, reject) {
                  request({
                    method: 'GET',
                    url: configUrl
                  }).on('complete', resolve).on('error', reject);
                });

              case 3:
                res = _context6.sent;
                clientConfig = JSON.parse(res.body);

                if (clientName === 'sandbox') {
                  clientConfig.loginUrl = 'https://test.salesforce.com';
                }

                _context6.next = 8;
                return registry.registerClientConfig(clientName, clientConfig);

              case 8:
                this.print('Client information downloaded successfully.');
                return _context6.abrupt("return", this.authorize(clientName));

              case 10:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));

      function downloadDefaultClientInfo(_x8) {
        return _downloadDefaultClientInfo.apply(this, arguments);
      }

      return downloadDefaultClientInfo;
    }()
  }, {
    key: "waitCallback",
    value: function () {
      var _waitCallback = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee7(serverUrl, state) {
        var code;
        return _regeneratorRuntime.wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                if (!(serverUrl && _indexOfInstanceProperty(serverUrl).call(serverUrl, 'http://localhost:') === 0)) {
                  _context7.next = 4;
                  break;
                }

                return _context7.abrupt("return", new _Promise(function (resolve, reject) {
                  var server = http.createServer(function (req, res) {
                    if (!req.url) {
                      return;
                    }

                    var qparams = url.parse(req.url, true).query;
                    res.writeHead(200, {
                      'Content-Type': 'text/html'
                    });
                    res.write('<html><script>location.href="about:blank";</script></html>');
                    res.end();

                    if (qparams.error) {
                      reject(new Error(qparams.error));
                    } else {
                      resolve(qparams);
                    }

                    server.close();
                    req.connection.end();
                    req.connection.destroy();
                  });
                  var port = Number(url.parse(serverUrl).port);
                  server.listen(port, 'localhost');
                }));

              case 4:
                _context7.next = 6;
                return this.promptMessage('Copy & paste authz code passed in redirected URL: ');

              case 6:
                code = _context7.sent;
                return _context7.abrupt("return", {
                  code: decodeURIComponent(code),
                  state: state
                });

              case 8:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7, this);
      }));

      function waitCallback(_x9, _x10) {
        return _waitCallback.apply(this, arguments);
      }

      return waitCallback;
    }()
    /**
     *
     */

  }, {
    key: "register",
    value: function () {
      var _register = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee9(clientName, clientConfig) {
        var _context8,
            _this2 = this;

        var name, prompts, registered, msg, ok;
        return _regeneratorRuntime.wrap(function _callee9$(_context10) {
          while (1) {
            switch (_context10.prev = _context10.next) {
              case 0:
                name = clientName || 'default';
                prompts = {
                  clientId: 'Input client ID : ',
                  clientSecret: 'Input client secret (optional) : ',
                  redirectUri: 'Input redirect URI : ',
                  loginUrl: 'Input login URL (default is https://login.salesforce.com) : '
                };
                _context10.next = 4;
                return registry.getClientConfig(name);

              case 4:
                registered = _context10.sent;

                if (!registered) {
                  _context10.next = 12;
                  break;
                }

                msg = "Client '".concat(name, "' is already registered. Are you sure you want to override ? [yN] : ");
                _context10.next = 9;
                return this.promptConfirm(msg);

              case 9:
                ok = _context10.sent;

                if (ok) {
                  _context10.next = 12;
                  break;
                }

                throw new Error('Registration canceled.');

              case 12:
                _context10.next = 14;
                return _reduceInstanceProperty(_context8 = _Object$keys(prompts)).call(_context8, /*#__PURE__*/function () {
                  var _ref = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee8(promise, name) {
                    var cconfig, promptName, message, value;
                    return _regeneratorRuntime.wrap(function _callee8$(_context9) {
                      while (1) {
                        switch (_context9.prev = _context9.next) {
                          case 0:
                            _context9.next = 2;
                            return promise;

                          case 2:
                            cconfig = _context9.sent;
                            promptName = name;
                            message = prompts[promptName];

                            if (cconfig[promptName]) {
                              _context9.next = 11;
                              break;
                            }

                            _context9.next = 8;
                            return _this2.promptMessage(message);

                          case 8:
                            value = _context9.sent;

                            if (!value) {
                              _context9.next = 11;
                              break;
                            }

                            return _context9.abrupt("return", _objectSpread(_objectSpread({}, cconfig), {}, _defineProperty({}, promptName, value)));

                          case 11:
                            return _context9.abrupt("return", cconfig);

                          case 12:
                          case "end":
                            return _context9.stop();
                        }
                      }
                    }, _callee8);
                  }));

                  return function (_x13, _x14) {
                    return _ref.apply(this, arguments);
                  };
                }(), _Promise.resolve(clientConfig));

              case 14:
                clientConfig = _context10.sent;
                _context10.next = 17;
                return registry.registerClientConfig(name, clientConfig);

              case 17:
                this.print('Client registered successfully.');

              case 18:
              case "end":
                return _context10.stop();
            }
          }
        }, _callee9, this);
      }));

      function register(_x11, _x12) {
        return _register.apply(this, arguments);
      }

      return register;
    }()
    /**
     *
     */

  }, {
    key: "listConnections",
    value: function () {
      var _listConnections = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee10() {
        var names, i, name;
        return _regeneratorRuntime.wrap(function _callee10$(_context11) {
          while (1) {
            switch (_context11.prev = _context11.next) {
              case 0:
                _context11.next = 2;
                return registry.getConnectionNames();

              case 2:
                names = _context11.sent;

                for (i = 0; i < names.length; i++) {
                  name = names[i];
                  this.print((name === this._connName ? '* ' : '  ') + name);
                }

              case 4:
              case "end":
                return _context11.stop();
            }
          }
        }, _callee10, this);
      }));

      function listConnections() {
        return _listConnections.apply(this, arguments);
      }

      return listConnections;
    }()
    /**
     *
     */

  }, {
    key: "getConnectionNames",
    value: function () {
      var _getConnectionNames = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee11() {
        return _regeneratorRuntime.wrap(function _callee11$(_context12) {
          while (1) {
            switch (_context12.prev = _context12.next) {
              case 0:
                return _context12.abrupt("return", registry.getConnectionNames());

              case 1:
              case "end":
                return _context12.stop();
            }
          }
        }, _callee11);
      }));

      function getConnectionNames() {
        return _getConnectionNames.apply(this, arguments);
      }

      return getConnectionNames;
    }()
    /**
     *
     */

  }, {
    key: "getClientNames",
    value: function () {
      var _getClientNames = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee12() {
        return _regeneratorRuntime.wrap(function _callee12$(_context13) {
          while (1) {
            switch (_context13.prev = _context13.next) {
              case 0:
                return _context13.abrupt("return", registry.getClientNames());

              case 1:
              case "end":
                return _context13.stop();
            }
          }
        }, _callee12);
      }));

      function getClientNames() {
        return _getClientNames.apply(this, arguments);
      }

      return getClientNames;
    }()
    /**
     *
     */

  }, {
    key: "prompt",
    value: function () {
      var _prompt = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee13(type, message) {
        var answer;
        return _regeneratorRuntime.wrap(function _callee13$(_context14) {
          while (1) {
            switch (_context14.prev = _context14.next) {
              case 0:
                this._repl.pause();

                _context14.next = 3;
                return inquirer.prompt([{
                  type: type,
                  name: 'value',
                  message: message
                }]);

              case 3:
                answer = _context14.sent;

                this._repl.resume();

                return _context14.abrupt("return", answer.value);

              case 6:
              case "end":
                return _context14.stop();
            }
          }
        }, _callee13, this);
      }));

      function prompt(_x15, _x16) {
        return _prompt.apply(this, arguments);
      }

      return prompt;
    }()
    /**
     *
     */

  }, {
    key: "promptMessage",
    value: function () {
      var _promptMessage = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee14(message) {
        return _regeneratorRuntime.wrap(function _callee14$(_context15) {
          while (1) {
            switch (_context15.prev = _context15.next) {
              case 0:
                return _context15.abrupt("return", this.prompt('input', message));

              case 1:
              case "end":
                return _context15.stop();
            }
          }
        }, _callee14, this);
      }));

      function promptMessage(_x17) {
        return _promptMessage.apply(this, arguments);
      }

      return promptMessage;
    }()
  }, {
    key: "promptPassword",
    value: function () {
      var _promptPassword = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee15(message) {
        return _regeneratorRuntime.wrap(function _callee15$(_context16) {
          while (1) {
            switch (_context16.prev = _context16.next) {
              case 0:
                return _context16.abrupt("return", this.prompt('password', message));

              case 1:
              case "end":
                return _context16.stop();
            }
          }
        }, _callee15, this);
      }));

      function promptPassword(_x18) {
        return _promptPassword.apply(this, arguments);
      }

      return promptPassword;
    }()
    /**
     *
     */

  }, {
    key: "promptConfirm",
    value: function () {
      var _promptConfirm = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee16(message) {
        return _regeneratorRuntime.wrap(function _callee16$(_context17) {
          while (1) {
            switch (_context17.prev = _context17.next) {
              case 0:
                return _context17.abrupt("return", this.prompt('confirm', message));

              case 1:
              case "end":
                return _context17.stop();
            }
          }
        }, _callee16, this);
      }));

      function promptConfirm(_x19) {
        return _promptConfirm.apply(this, arguments);
      }

      return promptConfirm;
    }()
    /**
     *
     */

  }, {
    key: "openUrl",
    value: function openUrl(url) {
      _openUrl(url);
    }
    /**
     *
     */

  }, {
    key: "openUrlUsingSession",
    value: function openUrlUsingSession(url) {
      var _context18;

      var frontdoorUrl = _concatInstanceProperty(_context18 = "".concat(this._conn.instanceUrl, "/secur/frontdoor.jsp?sid=")).call(_context18, this._conn.accessToken);

      if (url) {
        frontdoorUrl += '&retURL=' + encodeURIComponent(url);
      }

      this.openUrl(frontdoorUrl);
    }
  }]);

  return Cli;
}();
/* ------------------------------------------------------------------------- */

var cli = new Cli();
export default cli;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9jbGkvY2xpLnRzIl0sIm5hbWVzIjpbImh0dHAiLCJ1cmwiLCJjcnlwdG8iLCJvcGVuVXJsIiwiQ29tbWFuZCIsImlucXVpcmVyIiwicmVxdWVzdCIsImJhc2U2NHVybCIsIlJlcGwiLCJqc2ZvcmNlIiwiQ29ubmVjdGlvbiIsIk9BdXRoMiIsInZlcnNpb24iLCJyZWdpc3RyeSIsIkNsaSIsInVuZGVmaW5lZCIsIm9wdGlvbiIsInBhcnNlIiwicHJvY2VzcyIsImFyZ3YiLCJwcm9ncmFtIiwicmVhZENvbW1hbmQiLCJfb3V0cHV0RW5hYmxlZCIsImV2YWxTY3JpcHQiLCJjb25uZWN0IiwiX3JlcGwiLCJzdGFydCIsImludGVyYWN0aXZlIiwiY29uc29sZSIsImVycm9yIiwiZXhpdCIsIl9jb25uIiwibG9nIiwiX2Nvbm5OYW1lIiwiY29ubiIsImNvbm5OYW1lIiwiY29ubkNvbmZpZyIsIm9hdXRoMiIsImNsaWVudElkIiwiY2xpZW50U2VjcmV0IiwicmVkaXJlY3RVcmkiLCJsb2dpblVybCIsImFjY2Vzc1Rva2VuIiwiaW5zdGFuY2VVcmwiLCJyZWZyZXNoVG9rZW4iLCJzYXZlQ29ubmVjdGlvbkNvbmZpZyIsImxvZ2luU2VydmVyIiwiX2RlZmF1bHRMb2dpblVybCIsInByaW50Iiwib3B0aW9ucyIsInNhbmRib3giLCJzZXRMb2dpblNlcnZlciIsImNvbm5lY3Rpb24iLCJnZXRDb25uZWN0aW9uQ29uZmlnIiwidXNlcm5hbWUiLCJwYXNzd29yZCIsInN0YXJ0UGFzc3dvcmRBdXRoIiwic2F2ZUN1cnJlbnRDb25uZWN0aW9uIiwib24iLCJpZGVudGl0eSIsIkVycm9yIiwibWVzc2FnZSIsImxvZ2luQnlQYXNzd29yZCIsInJldHJ5Q291bnQiLCJwcm9tcHRQYXNzd29yZCIsInBhc3MiLCJsb2dpbiIsInJlc3VsdCIsIm5hbWUiLCJyZW1vdmVDb25uZWN0aW9uQ29uZmlnIiwiY2xpZW50TmFtZSIsImdldENsaWVudENvbmZpZyIsIm9hdXRoMkNvbmZpZyIsImRvd25sb2FkRGVmYXVsdENsaWVudEluZm8iLCJ2ZXJpZmllciIsImVuY29kZSIsInJhbmRvbUJ5dGVzIiwiY2hhbGxlbmdlIiwiY3JlYXRlSGFzaCIsInVwZGF0ZSIsImRpZ2VzdCIsInN0YXRlIiwiYXV0aHpVcmwiLCJnZXRBdXRob3JpemF0aW9uVXJsIiwiY29kZV9jaGFsbGVuZ2UiLCJ3YWl0Q2FsbGJhY2siLCJwYXJhbXMiLCJjb2RlIiwiYXV0aG9yaXplIiwiY29kZV92ZXJpZmllciIsImNvbmZpZ1VybCIsInJlc29sdmUiLCJyZWplY3QiLCJtZXRob2QiLCJyZXMiLCJjbGllbnRDb25maWciLCJKU09OIiwiYm9keSIsInJlZ2lzdGVyQ2xpZW50Q29uZmlnIiwic2VydmVyVXJsIiwic2VydmVyIiwiY3JlYXRlU2VydmVyIiwicmVxIiwicXBhcmFtcyIsInF1ZXJ5Iiwid3JpdGVIZWFkIiwid3JpdGUiLCJlbmQiLCJjbG9zZSIsImRlc3Ryb3kiLCJwb3J0IiwiTnVtYmVyIiwibGlzdGVuIiwicHJvbXB0TWVzc2FnZSIsImRlY29kZVVSSUNvbXBvbmVudCIsInByb21wdHMiLCJyZWdpc3RlcmVkIiwibXNnIiwicHJvbXB0Q29uZmlybSIsIm9rIiwicHJvbWlzZSIsImNjb25maWciLCJwcm9tcHROYW1lIiwidmFsdWUiLCJnZXRDb25uZWN0aW9uTmFtZXMiLCJuYW1lcyIsImkiLCJsZW5ndGgiLCJnZXRDbGllbnROYW1lcyIsInR5cGUiLCJwYXVzZSIsInByb21wdCIsImFuc3dlciIsInJlc3VtZSIsImZyb250ZG9vclVybCIsImVuY29kZVVSSUNvbXBvbmVudCIsImNsaSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU9BLElBQVAsTUFBaUIsTUFBakI7QUFDQSxPQUFPQyxHQUFQLE1BQWdCLEtBQWhCO0FBQ0EsT0FBT0MsTUFBUCxNQUFtQixRQUFuQjtBQUNBLE9BQU9DLFFBQVAsTUFBb0IsTUFBcEI7QUFDQSxTQUFTQyxPQUFULFFBQXdCLFdBQXhCO0FBQ0EsT0FBT0MsUUFBUCxNQUFxQixVQUFyQjtBQUNBLE9BQU9DLE9BQVAsTUFBb0IsWUFBcEI7QUFDQSxPQUFPQyxTQUFQLE1BQXNCLFdBQXRCO0FBQ0EsT0FBT0MsSUFBUCxNQUFpQixRQUFqQjtBQUNBLE9BQU9DLE9BQVAsSUFBa0JDLFVBQWxCLEVBQThCQyxNQUE5QixRQUE0QyxJQUE1QztBQUNBLE9BQU9DLE9BQVAsTUFBb0IsWUFBcEI7QUFJQSxJQUFNQyxRQUFRLEdBQUdKLE9BQU8sQ0FBQ0ksUUFBekI7O0FBV0E7QUFDQTtBQUNBO0FBQ0EsV0FBYUMsR0FBYjtBQUFBO0FBQUE7O0FBQUEsbUNBQ2dCLElBQUlOLElBQUosQ0FBUyxJQUFULENBRGhCOztBQUFBLG1DQUVzQixJQUFJRSxVQUFKLEVBRnRCOztBQUFBLHVDQUdrQ0ssU0FIbEM7O0FBQUEsNENBSTRCLElBSjVCOztBQUFBLDhDQUt5Q0EsU0FMekM7QUFBQTs7QUFBQTtBQUFBOztBQU9FO0FBQ0Y7QUFDQTtBQVRBLGtDQVU0QjtBQUN4QixhQUFPLElBQUlYLE9BQUosR0FDSlksTUFESSxDQUNHLDJCQURILEVBQ2dDLHFCQURoQyxFQUVKQSxNQUZJLENBR0gsMkJBSEcsRUFJSCx3REFKRyxFQU1KQSxNQU5JLENBT0gsK0JBUEcsRUFRSCwrQ0FSRyxFQVVKQSxNQVZJLENBVUcsMkJBVkgsRUFVZ0Msc0JBVmhDLEVBV0pBLE1BWEksQ0FXRyxXQVhILEVBV2dCLDZCQVhoQixFQVlKQSxNQVpJLENBWUcsK0JBWkgsRUFZb0Msb0JBWnBDLEVBYUpKLE9BYkksQ0FhSUEsT0FiSixFQWNKSyxLQWRJLENBY0VDLE9BQU8sQ0FBQ0MsSUFkVixDQUFQO0FBZUQ7QUExQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBNkJVQyxnQkFBQUEsT0E3QlYsR0E2Qm9CLEtBQUtDLFdBQUwsRUE3QnBCO0FBOEJJLHFCQUFLQyxjQUFMLEdBQXNCLENBQUNGLE9BQU8sQ0FBQ0csVUFBL0I7QUE5Qko7QUFBQTtBQUFBLHVCQWdDWSxLQUFLQyxPQUFMLENBQWFKLE9BQWIsQ0FoQ1o7O0FBQUE7QUFpQ00sb0JBQUlBLE9BQU8sQ0FBQ0csVUFBWixFQUF3QjtBQUN0Qix1QkFBS0UsS0FBTCxDQUFXQyxLQUFYLENBQWlCO0FBQ2ZDLG9CQUFBQSxXQUFXLEVBQUUsS0FERTtBQUVmSixvQkFBQUEsVUFBVSxFQUFFSCxPQUFPLENBQUNHO0FBRkwsbUJBQWpCO0FBSUQsaUJBTEQsTUFLTztBQUNMLHVCQUFLRSxLQUFMLENBQVdDLEtBQVg7QUFDRDs7QUF4Q1A7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUEwQ01FLGdCQUFBQSxPQUFPLENBQUNDLEtBQVI7QUFDQVgsZ0JBQUFBLE9BQU8sQ0FBQ1ksSUFBUjs7QUEzQ047QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkNBK0N5QjtBQUNyQixhQUFPLEtBQUtDLEtBQVo7QUFDRDtBQWpESDtBQUFBO0FBQUEsNEJBbUR3QjtBQUNwQixVQUFJLEtBQUtULGNBQVQsRUFBeUI7QUFBQTs7QUFDdkIsb0JBQUFNLE9BQU8sRUFBQ0ksR0FBUjtBQUNEO0FBQ0Y7QUF2REg7QUFBQTtBQUFBLDRDQXlEMEI7QUFDdEIsVUFBSSxLQUFLQyxTQUFULEVBQW9CO0FBQ2xCLFlBQU1DLElBQUksR0FBRyxLQUFLSCxLQUFsQjtBQUNBLFlBQU1JLFFBQVEsR0FBRyxLQUFLRixTQUF0QjtBQUNBLFlBQU1HLFVBQVUsR0FBRztBQUNqQkMsVUFBQUEsTUFBTSxFQUFFSCxJQUFJLENBQUNHLE1BQUwsR0FDSjtBQUNFQyxZQUFBQSxRQUFRLEVBQUVKLElBQUksQ0FBQ0csTUFBTCxDQUFZQyxRQUFaLElBQXdCdkIsU0FEcEM7QUFFRXdCLFlBQUFBLFlBQVksRUFBRUwsSUFBSSxDQUFDRyxNQUFMLENBQVlFLFlBQVosSUFBNEJ4QixTQUY1QztBQUdFeUIsWUFBQUEsV0FBVyxFQUFFTixJQUFJLENBQUNHLE1BQUwsQ0FBWUcsV0FBWixJQUEyQnpCLFNBSDFDO0FBSUUwQixZQUFBQSxRQUFRLEVBQUVQLElBQUksQ0FBQ0csTUFBTCxDQUFZSSxRQUFaLElBQXdCMUI7QUFKcEMsV0FESSxHQU9KQSxTQVJhO0FBU2pCMkIsVUFBQUEsV0FBVyxFQUFFUixJQUFJLENBQUNRLFdBQUwsSUFBb0IzQixTQVRoQjtBQVVqQjRCLFVBQUFBLFdBQVcsRUFBRVQsSUFBSSxDQUFDUyxXQUFMLElBQW9CNUIsU0FWaEI7QUFXakI2QixVQUFBQSxZQUFZLEVBQUVWLElBQUksQ0FBQ1UsWUFBTCxJQUFxQjdCO0FBWGxCLFNBQW5CO0FBYUFGLFFBQUFBLFFBQVEsQ0FBQ2dDLG9CQUFULENBQThCVixRQUE5QixFQUF3Q0MsVUFBeEM7QUFDRDtBQUNGO0FBNUVIO0FBQUE7QUFBQSxtQ0E4RWlCVSxXQTlFakIsRUE4RWdEO0FBQzVDLFVBQUksQ0FBQ0EsV0FBTCxFQUFrQjtBQUNoQjtBQUNEOztBQUNELFVBQUlBLFdBQVcsS0FBSyxZQUFwQixFQUFrQztBQUNoQyxhQUFLQyxnQkFBTCxHQUF3Qiw4QkFBeEI7QUFDRCxPQUZELE1BRU8sSUFBSUQsV0FBVyxLQUFLLFNBQXBCLEVBQStCO0FBQ3BDLGFBQUtDLGdCQUFMLEdBQXdCLDZCQUF4QjtBQUNELE9BRk0sTUFFQSxJQUFJLHlCQUFBRCxXQUFXLE1BQVgsQ0FBQUEsV0FBVyxFQUFTLFVBQVQsQ0FBWCxLQUFvQyxDQUF4QyxFQUEyQztBQUNoRCxhQUFLQyxnQkFBTCxHQUF3QixhQUFhRCxXQUFyQztBQUNELE9BRk0sTUFFQTtBQUNMLGFBQUtDLGdCQUFMLEdBQXdCRCxXQUF4QjtBQUNEOztBQUNELFdBQUtFLEtBQUwsbUJBQXFCLEtBQUtELGdCQUExQjtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQWhHQTtBQUFBO0FBQUE7QUFBQSxnR0FpR2dCRSxPQWpHaEI7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBd0dVSCxnQkFBQUEsV0F4R1YsR0F3R3dCRyxPQUFPLENBQUNSLFFBQVIsR0FDaEJRLE9BQU8sQ0FBQ1IsUUFEUSxHQUVoQlEsT0FBTyxDQUFDQyxPQUFSLEdBQ0EsU0FEQSxHQUVBLElBNUdSO0FBNkdJLHFCQUFLQyxjQUFMLENBQW9CTCxXQUFwQjtBQUNBLHFCQUFLYixTQUFMLEdBQWlCZ0IsT0FBTyxDQUFDRyxVQUF6QjtBQTlHSjtBQUFBLHVCQStHMkJ2QyxRQUFRLENBQUN3QyxtQkFBVCxDQUE2QkosT0FBTyxDQUFDRyxVQUFyQyxDQS9HM0I7O0FBQUE7QUErR1FoQixnQkFBQUEsVUEvR1I7QUFnSFFrQixnQkFBQUEsUUFoSFIsR0FnSG1CTCxPQUFPLENBQUNLLFFBaEgzQjs7QUFpSEksb0JBQUksQ0FBQ2xCLFVBQUwsRUFBaUI7QUFDZkEsa0JBQUFBLFVBQVUsR0FBRyxFQUFiOztBQUNBLHNCQUFJLEtBQUtXLGdCQUFULEVBQTJCO0FBQ3pCWCxvQkFBQUEsVUFBVSxDQUFDSyxRQUFYLEdBQXNCLEtBQUtNLGdCQUEzQjtBQUNEOztBQUNETyxrQkFBQUEsUUFBUSxHQUFHQSxRQUFRLElBQUlMLE9BQU8sQ0FBQ0csVUFBL0I7QUFDRDs7QUFDRCxxQkFBS3JCLEtBQUwsR0FBYSxJQUFJckIsVUFBSixDQUFlMEIsVUFBZixDQUFiO0FBQ01tQixnQkFBQUEsUUF6SFYsR0F5SHFCTixPQUFPLENBQUNNLFFBekg3Qjs7QUFBQSxxQkEwSFFELFFBMUhSO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsdUJBMkhZLEtBQUtFLGlCQUFMLENBQXVCRixRQUF2QixFQUFpQ0MsUUFBakMsQ0EzSFo7O0FBQUE7QUE0SE0scUJBQUtFLHFCQUFMO0FBNUhOO0FBQUE7O0FBQUE7QUFBQSxzQkE4SFUsS0FBS3hCLFNBQUwsSUFBa0IsS0FBS0YsS0FBTCxDQUFXVyxXQTlIdkM7QUFBQTtBQUFBO0FBQUE7O0FBK0hRLHFCQUFLWCxLQUFMLENBQVcyQixFQUFYLENBQWMsU0FBZCxFQUF5QixZQUFNO0FBQzdCLGtCQUFBLEtBQUksQ0FBQ1YsS0FBTCxDQUFXLDhCQUFYOztBQUNBLGtCQUFBLEtBQUksQ0FBQ1MscUJBQUw7QUFDRCxpQkFIRDs7QUEvSFI7QUFBQTtBQUFBLHVCQW9JaUMsS0FBSzFCLEtBQUwsQ0FBVzRCLFFBQVgsRUFwSWpDOztBQUFBO0FBb0lnQkEsZ0JBQUFBLFFBcEloQjtBQXFJVSxxQkFBS1gsS0FBTCwwQkFBNkJXLFFBQVEsQ0FBQ0wsUUFBdEM7QUFySVY7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBdUlVLG9CQUFJLHdCQUFlTSxLQUFuQixFQUEwQjtBQUN4Qix1QkFBS1osS0FBTCxDQUFXLGFBQUlhLE9BQWY7QUFDRDs7QUF6SVgscUJBMEljLEtBQUs5QixLQUFMLENBQVdNLE1BMUl6QjtBQUFBO0FBQUE7QUFBQTs7QUFBQSxzQkEySWtCLElBQUl1QixLQUFKLENBQVUsaUNBQVYsQ0EzSWxCOztBQUFBO0FBQUE7QUFBQSx1QkE2SWtCLEtBQUtKLGlCQUFMLENBQXVCLEtBQUt2QixTQUE1QixDQTdJbEI7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFvSkU7QUFDRjtBQUNBOztBQXRKQTtBQUFBO0FBQUE7QUFBQSwwR0F1SjBCcUIsUUF2SjFCLEVBdUo0Q0MsUUF2SjVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBeUpZLEtBQUtPLGVBQUwsQ0FBcUJSLFFBQXJCLEVBQStCQyxRQUEvQixFQUF5QyxDQUF6QyxDQXpKWjs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBLHNCQTJKVSx3QkFBZUssS0FBZixJQUF3QixhQUFJQyxPQUFKLEtBQWdCLFVBM0psRDtBQUFBO0FBQUE7QUFBQTs7QUE0SlFqQyxnQkFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMsaURBQWQ7QUE1SlI7QUFBQTs7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBbUtFO0FBQ0Y7QUFDQTs7QUFyS0E7QUFBQTtBQUFBO0FBQUEsd0dBdUtJeUIsUUF2S0osRUF3S0lDLFFBeEtKLEVBeUtJUSxVQXpLSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkEyS1FSLFFBQVEsS0FBSyxFQTNLckI7QUFBQTtBQUFBO0FBQUE7O0FBQUEsc0JBNEtZLElBQUlLLEtBQUosQ0FBVSxVQUFWLENBNUtaOztBQUFBO0FBQUEsc0JBOEtRTCxRQUFRLElBQUksSUE5S3BCO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsdUJBK0t5QixLQUFLUyxjQUFMLENBQW9CLFlBQXBCLENBL0t6Qjs7QUFBQTtBQStLWUMsZ0JBQUFBLElBL0taO0FBQUEsa0RBZ0xhLEtBQUtILGVBQUwsQ0FBcUJSLFFBQXJCLEVBQStCVyxJQUEvQixFQUFxQ0YsVUFBckMsQ0FoTGI7O0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBbUwyQixLQUFLaEMsS0FBTCxDQUFXbUMsS0FBWCxDQUFpQlosUUFBakIsRUFBMkJDLFFBQTNCLENBbkwzQjs7QUFBQTtBQW1MWVksZ0JBQUFBLE1BbkxaO0FBb0xNLHFCQUFLbkIsS0FBTCwwQkFBNkJNLFFBQTdCO0FBcExOLGtEQXFMYWEsTUFyTGI7O0FBQUE7QUFBQTtBQUFBOztBQXVMTSxvQkFBSSx3QkFBZVAsS0FBbkIsRUFBMEI7QUFDeEJoQyxrQkFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMsYUFBSWdDLE9BQWxCO0FBQ0Q7O0FBekxQLHNCQTBMVUUsVUFBVSxHQUFHLENBMUx2QjtBQUFBO0FBQUE7QUFBQTs7QUFBQSxrREEyTGUsS0FBS0QsZUFBTCxDQUFxQlIsUUFBckIsRUFBK0J2QyxTQUEvQixFQUEwQ2dELFVBQVUsR0FBRyxDQUF2RCxDQTNMZjs7QUFBQTtBQUFBLHNCQTZMYyxJQUFJSCxLQUFKLENBQVUsVUFBVixDQTdMZDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQWtNRTtBQUNGO0FBQ0E7O0FBcE1BO0FBQUE7QUFBQSwrQkFxTWF6QixRQXJNYixFQXFNZ0M7QUFDNUIsVUFBTWlDLElBQUksR0FBR2pDLFFBQVEsSUFBSSxLQUFLRixTQUE5Qjs7QUFDQSxVQUFJbUMsSUFBSSxJQUFJdkQsUUFBUSxDQUFDd0MsbUJBQVQsQ0FBNkJlLElBQTdCLENBQVosRUFBZ0Q7QUFDOUN2RCxRQUFBQSxRQUFRLENBQUN3RCxzQkFBVCxDQUFnQ0QsSUFBaEM7QUFDQSxhQUFLcEIsS0FBTCxrQ0FBcUNvQixJQUFyQztBQUNEOztBQUNELFdBQUtuQyxTQUFMLEdBQWlCbEIsU0FBakI7QUFDQSxXQUFLZ0IsS0FBTCxHQUFhLElBQUlyQixVQUFKLEVBQWI7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUFqTkE7QUFBQTtBQUFBO0FBQUEsa0dBa05rQjRELFVBbE5sQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFtTlVGLGdCQUFBQSxJQW5OVixHQW1OaUJFLFVBQVUsSUFBSSxTQW5OL0I7QUFBQTtBQUFBLHVCQW9ONkJ6RCxRQUFRLENBQUMwRCxlQUFULENBQXlCSCxJQUF6QixDQXBON0I7O0FBQUE7QUFvTlFJLGdCQUFBQSxZQXBOUjs7QUFBQSxzQkFxTlEsQ0FBQ0EsWUFBRCxJQUFpQixDQUFDQSxZQUFZLENBQUNsQyxRQXJOdkM7QUFBQTtBQUFBO0FBQUE7O0FBQUEsc0JBc05VOEIsSUFBSSxLQUFLLFNBQVQsSUFBc0JBLElBQUksS0FBSyxTQXROekM7QUFBQTtBQUFBO0FBQUE7O0FBdU5RLHFCQUFLcEIsS0FBTCxDQUNFLHFGQURGO0FBdk5SLGtEQTBOZSxLQUFLeUIseUJBQUwsQ0FBK0JMLElBQS9CLENBMU5mOztBQUFBO0FBQUEsc0JBNE5ZLElBQUlSLEtBQUosc0RBQzBDUSxJQUQxQywyQ0E1Tlo7O0FBQUE7QUFnT1UvQixnQkFBQUEsTUFoT1YsR0FnT21CLElBQUkxQixNQUFKLENBQVc2RCxZQUFYLENBaE9uQjtBQWlPVUUsZ0JBQUFBLFFBak9WLEdBaU9xQm5FLFNBQVMsQ0FBQ29FLE1BQVYsQ0FBaUJ6RSxNQUFNLENBQUMwRSxXQUFQLENBQW1CLEVBQW5CLENBQWpCLENBak9yQjtBQWtPVUMsZ0JBQUFBLFNBbE9WLEdBa09zQnRFLFNBQVMsQ0FBQ29FLE1BQVYsQ0FDaEJ6RSxNQUFNLENBQUM0RSxVQUFQLENBQWtCLFFBQWxCLEVBQTRCQyxNQUE1QixDQUFtQ0wsUUFBbkMsRUFBNkNNLE1BQTdDLEVBRGdCLENBbE90QjtBQXFPVUMsZ0JBQUFBLEtBck9WLEdBcU9rQjFFLFNBQVMsQ0FBQ29FLE1BQVYsQ0FBaUJ6RSxNQUFNLENBQUMwRSxXQUFQLENBQW1CLEVBQW5CLENBQWpCLENBck9sQjtBQXNPVU0sZ0JBQUFBLFFBdE9WLEdBc09xQjdDLE1BQU0sQ0FBQzhDLG1CQUFQLENBQTJCO0FBQzFDQyxrQkFBQUEsY0FBYyxFQUFFUCxTQUQwQjtBQUUxQ0ksa0JBQUFBLEtBQUssRUFBTEE7QUFGMEMsaUJBQTNCLENBdE9yQjtBQTBPSSxxQkFBS2pDLEtBQUwsQ0FBVywwQ0FBWDtBQUNBLHFCQUFLQSxLQUFMLGdCQUFtQmtDLFFBQW5CO0FBQ0EscUJBQUsvRSxPQUFMLENBQWErRSxRQUFiO0FBNU9KO0FBQUEsdUJBNk95QixLQUFLRyxZQUFMLENBQWtCYixZQUFZLENBQUNoQyxXQUEvQixFQUE0Q3lDLEtBQTVDLENBN096Qjs7QUFBQTtBQTZPVUssZ0JBQUFBLE1BN09WOztBQUFBLG9CQThPU0EsTUFBTSxDQUFDQyxJQTlPaEI7QUFBQTtBQUFBO0FBQUE7O0FBQUEsc0JBK09ZLElBQUkzQixLQUFKLENBQVUsaUNBQVYsQ0EvT1o7O0FBQUE7QUFBQSxzQkFpUFEwQixNQUFNLENBQUNMLEtBQVAsS0FBaUJBLEtBalB6QjtBQUFBO0FBQUE7QUFBQTs7QUFBQSxzQkFrUFksSUFBSXJCLEtBQUosQ0FBVSxtQ0FBVixDQWxQWjs7QUFBQTtBQW9QSSxxQkFBSzdCLEtBQUwsR0FBYSxJQUFJckIsVUFBSixDQUFlO0FBQUUyQixrQkFBQUEsTUFBTSxFQUFOQTtBQUFGLGlCQUFmLENBQWI7QUFDQSxxQkFBS1csS0FBTCxDQUNFLHNFQURGO0FBclBKO0FBQUEsdUJBd1BVLEtBQUtqQixLQUFMLENBQVd5RCxTQUFYLENBQXFCRixNQUFNLENBQUNDLElBQTVCLEVBQWtDO0FBQUVFLGtCQUFBQSxhQUFhLEVBQUVmO0FBQWpCLGlCQUFsQyxDQXhQVjs7QUFBQTtBQXlQSSxxQkFBSzFCLEtBQUwsQ0FBVyxtQ0FBWDtBQXpQSjtBQUFBLHVCQTBQMkIsS0FBS2pCLEtBQUwsQ0FBVzRCLFFBQVgsRUExUDNCOztBQUFBO0FBMFBVQSxnQkFBQUEsUUExUFY7QUEyUEkscUJBQUtYLEtBQUwsMEJBQTZCVyxRQUFRLENBQUNMLFFBQXRDO0FBQ0EscUJBQUtyQixTQUFMLEdBQWlCMEIsUUFBUSxDQUFDTCxRQUExQjtBQUNBLHFCQUFLRyxxQkFBTDs7QUE3UEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFnUUU7QUFDRjtBQUNBOztBQWxRQTtBQUFBO0FBQUE7QUFBQSxrSEFtUWtDYSxVQW5RbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBb1FVb0IsZ0JBQUFBLFNBcFFWLEdBb1FzQixzREFwUXRCO0FBQUE7QUFBQSx1QkFxUXdDLGFBQVksVUFBQ0MsT0FBRCxFQUFVQyxNQUFWLEVBQXFCO0FBQ25FdEYsa0JBQUFBLE9BQU8sQ0FBQztBQUFFdUYsb0JBQUFBLE1BQU0sRUFBRSxLQUFWO0FBQWlCNUYsb0JBQUFBLEdBQUcsRUFBRXlGO0FBQXRCLG1CQUFELENBQVAsQ0FDR2hDLEVBREgsQ0FDTSxVQUROLEVBQ2tCaUMsT0FEbEIsRUFFR2pDLEVBRkgsQ0FFTSxPQUZOLEVBRWVrQyxNQUZmO0FBR0QsaUJBSm1DLENBclF4Qzs7QUFBQTtBQXFRVUUsZ0JBQUFBLEdBclFWO0FBMFFVQyxnQkFBQUEsWUExUVYsR0EwUXlCQyxJQUFJLENBQUMvRSxLQUFMLENBQVc2RSxHQUFHLENBQUNHLElBQWYsQ0ExUXpCOztBQTJRSSxvQkFBSTNCLFVBQVUsS0FBSyxTQUFuQixFQUE4QjtBQUM1QnlCLGtCQUFBQSxZQUFZLENBQUN0RCxRQUFiLEdBQXdCLDZCQUF4QjtBQUNEOztBQTdRTDtBQUFBLHVCQThRVTVCLFFBQVEsQ0FBQ3FGLG9CQUFULENBQThCNUIsVUFBOUIsRUFBMEN5QixZQUExQyxDQTlRVjs7QUFBQTtBQStRSSxxQkFBSy9DLEtBQUwsQ0FBVyw2Q0FBWDtBQS9RSixrREFnUlcsS0FBS3dDLFNBQUwsQ0FBZWxCLFVBQWYsQ0FoUlg7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxR0FvUkk2QixTQXBSSixFQXFSSWxCLEtBclJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQXVSUWtCLFNBQVMsSUFBSSx5QkFBQUEsU0FBUyxNQUFULENBQUFBLFNBQVMsRUFBUyxtQkFBVCxDQUFULEtBQTJDLENBdlJoRTtBQUFBO0FBQUE7QUFBQTs7QUFBQSxrREF3UmEsYUFBWSxVQUFDUixPQUFELEVBQVVDLE1BQVYsRUFBcUI7QUFDdEMsc0JBQU1RLE1BQU0sR0FBR3BHLElBQUksQ0FBQ3FHLFlBQUwsQ0FBa0IsVUFBQ0MsR0FBRCxFQUFNUixHQUFOLEVBQWM7QUFDN0Msd0JBQUksQ0FBQ1EsR0FBRyxDQUFDckcsR0FBVCxFQUFjO0FBQ1o7QUFDRDs7QUFDRCx3QkFBTXNHLE9BQU8sR0FBR3RHLEdBQUcsQ0FBQ2dCLEtBQUosQ0FBVXFGLEdBQUcsQ0FBQ3JHLEdBQWQsRUFBbUIsSUFBbkIsRUFBeUJ1RyxLQUF6QztBQUNBVixvQkFBQUEsR0FBRyxDQUFDVyxTQUFKLENBQWMsR0FBZCxFQUFtQjtBQUFFLHNDQUFnQjtBQUFsQixxQkFBbkI7QUFDQVgsb0JBQUFBLEdBQUcsQ0FBQ1ksS0FBSixDQUNFLDREQURGO0FBR0FaLG9CQUFBQSxHQUFHLENBQUNhLEdBQUo7O0FBQ0Esd0JBQUlKLE9BQU8sQ0FBQzFFLEtBQVosRUFBbUI7QUFDakIrRCxzQkFBQUEsTUFBTSxDQUFDLElBQUloQyxLQUFKLENBQVUyQyxPQUFPLENBQUMxRSxLQUFsQixDQUFELENBQU47QUFDRCxxQkFGRCxNQUVPO0FBQ0w4RCxzQkFBQUEsT0FBTyxDQUFDWSxPQUFELENBQVA7QUFDRDs7QUFDREgsb0JBQUFBLE1BQU0sQ0FBQ1EsS0FBUDtBQUNBTixvQkFBQUEsR0FBRyxDQUFDbEQsVUFBSixDQUFldUQsR0FBZjtBQUNBTCxvQkFBQUEsR0FBRyxDQUFDbEQsVUFBSixDQUFleUQsT0FBZjtBQUNELG1CQWxCYyxDQUFmO0FBbUJBLHNCQUFNQyxJQUFJLEdBQUdDLE1BQU0sQ0FBQzlHLEdBQUcsQ0FBQ2dCLEtBQUosQ0FBVWtGLFNBQVYsRUFBcUJXLElBQXRCLENBQW5CO0FBQ0FWLGtCQUFBQSxNQUFNLENBQUNZLE1BQVAsQ0FBY0YsSUFBZCxFQUFvQixXQUFwQjtBQUNELGlCQXRCTSxDQXhSYjs7QUFBQTtBQUFBO0FBQUEsdUJBZ1R5QixLQUFLRyxhQUFMLENBQ2pCLG9EQURpQixDQWhUekI7O0FBQUE7QUFnVFkxQixnQkFBQUEsSUFoVFo7QUFBQSxrREFtVGE7QUFBRUEsa0JBQUFBLElBQUksRUFBRTJCLGtCQUFrQixDQUFDM0IsSUFBRCxDQUExQjtBQUFrQ04sa0JBQUFBLEtBQUssRUFBTEE7QUFBbEMsaUJBblRiOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBdVRFO0FBQ0Y7QUFDQTs7QUF6VEE7QUFBQTtBQUFBO0FBQUEsaUdBMFRpQlgsVUExVGpCLEVBMFRpRHlCLFlBMVRqRDtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQTJUVTNCLGdCQUFBQSxJQTNUVixHQTJUaUJFLFVBQVUsSUFBSSxTQTNUL0I7QUE0VFU2QyxnQkFBQUEsT0E1VFYsR0E0VG9CO0FBQ2Q3RSxrQkFBQUEsUUFBUSxFQUFFLG9CQURJO0FBRWRDLGtCQUFBQSxZQUFZLEVBQUUsbUNBRkE7QUFHZEMsa0JBQUFBLFdBQVcsRUFBRSx1QkFIQztBQUlkQyxrQkFBQUEsUUFBUSxFQUFFO0FBSkksaUJBNVRwQjtBQUFBO0FBQUEsdUJBa1U2QjVCLFFBQVEsQ0FBQzBELGVBQVQsQ0FBeUJILElBQXpCLENBbFU3Qjs7QUFBQTtBQWtVVWdELGdCQUFBQSxVQWxVVjs7QUFBQSxxQkFtVVFBLFVBblVSO0FBQUE7QUFBQTtBQUFBOztBQW9VWUMsZ0JBQUFBLEdBcFVaLHFCQW9VNkJqRCxJQXBVN0I7QUFBQTtBQUFBLHVCQXFVdUIsS0FBS2tELGFBQUwsQ0FBbUJELEdBQW5CLENBclV2Qjs7QUFBQTtBQXFVWUUsZ0JBQUFBLEVBclVaOztBQUFBLG9CQXNVV0EsRUF0VVg7QUFBQTtBQUFBO0FBQUE7O0FBQUEsc0JBdVVjLElBQUkzRCxLQUFKLENBQVUsd0JBQVYsQ0F2VWQ7O0FBQUE7QUFBQTtBQUFBLHVCQTBVeUIsaURBQVl1RCxPQUFaO0FBQUEsc0ZBQTRCLGtCQUFPSyxPQUFQLEVBQWdCcEQsSUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FDekJvRCxPQUR5Qjs7QUFBQTtBQUN6Q0MsNEJBQUFBLE9BRHlDO0FBRXpDQyw0QkFBQUEsVUFGeUMsR0FFNUJ0RCxJQUY0QjtBQUd6Q1AsNEJBQUFBLE9BSHlDLEdBRy9Cc0QsT0FBTyxDQUFDTyxVQUFELENBSHdCOztBQUFBLGdDQUkxQ0QsT0FBTyxDQUFDQyxVQUFELENBSm1DO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsbUNBS3pCLE1BQUksQ0FBQ1QsYUFBTCxDQUFtQnBELE9BQW5CLENBTHlCOztBQUFBO0FBS3ZDOEQsNEJBQUFBLEtBTHVDOztBQUFBLGlDQU16Q0EsS0FOeUM7QUFBQTtBQUFBO0FBQUE7O0FBQUEsOEZBUXRDRixPQVJzQywyQkFTeENDLFVBVHdDLEVBUzNCQyxLQVQyQjs7QUFBQTtBQUFBLDhEQWF4Q0YsT0Fid0M7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTVCOztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWNsQixTQUFROUIsT0FBUixDQUFnQkksWUFBaEIsQ0Fka0IsQ0ExVXpCOztBQUFBO0FBMFVJQSxnQkFBQUEsWUExVUo7QUFBQTtBQUFBLHVCQXlWVWxGLFFBQVEsQ0FBQ3FGLG9CQUFULENBQThCOUIsSUFBOUIsRUFBb0MyQixZQUFwQyxDQXpWVjs7QUFBQTtBQTBWSSxxQkFBSy9DLEtBQUwsQ0FBVyxpQ0FBWDs7QUExVko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUE2VkU7QUFDRjtBQUNBOztBQS9WQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlXd0JuQyxRQUFRLENBQUMrRyxrQkFBVCxFQWpXeEI7O0FBQUE7QUFpV1VDLGdCQUFBQSxLQWpXVjs7QUFrV0kscUJBQVNDLENBQVQsR0FBYSxDQUFiLEVBQWdCQSxDQUFDLEdBQUdELEtBQUssQ0FBQ0UsTUFBMUIsRUFBa0NELENBQUMsRUFBbkMsRUFBdUM7QUFDakMxRCxrQkFBQUEsSUFEaUMsR0FDMUJ5RCxLQUFLLENBQUNDLENBQUQsQ0FEcUI7QUFFckMsdUJBQUs5RSxLQUFMLENBQVcsQ0FBQ29CLElBQUksS0FBSyxLQUFLbkMsU0FBZCxHQUEwQixJQUExQixHQUFpQyxJQUFsQyxJQUEwQ21DLElBQXJEO0FBQ0Q7O0FBcldMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBd1dFO0FBQ0Y7QUFDQTs7QUExV0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1EQTRXV3ZELFFBQVEsQ0FBQytHLGtCQUFULEVBNVdYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBK1dFO0FBQ0Y7QUFDQTs7QUFqWEE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1EQW1YVy9HLFFBQVEsQ0FBQ21ILGNBQVQsRUFuWFg7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFzWEU7QUFDRjtBQUNBOztBQXhYQTtBQUFBO0FBQUE7QUFBQSxnR0F5WGVDLElBelhmLEVBeVg2QnBFLE9Belg3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUEwWEkscUJBQUtwQyxLQUFMLENBQVd5RyxLQUFYOztBQTFYSjtBQUFBLHVCQTJYNEM3SCxRQUFRLENBQUM4SCxNQUFULENBQWdCLENBQ3REO0FBQ0VGLGtCQUFBQSxJQUFJLEVBQUpBLElBREY7QUFFRTdELGtCQUFBQSxJQUFJLEVBQUUsT0FGUjtBQUdFUCxrQkFBQUEsT0FBTyxFQUFQQTtBQUhGLGlCQURzRCxDQUFoQixDQTNYNUM7O0FBQUE7QUEyWFV1RSxnQkFBQUEsTUEzWFY7O0FBa1lJLHFCQUFLM0csS0FBTCxDQUFXNEcsTUFBWDs7QUFsWUosbURBbVlXRCxNQUFNLENBQUNULEtBbllsQjs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQXNZRTtBQUNGO0FBQ0E7O0FBeFlBO0FBQUE7QUFBQTtBQUFBLHVHQXlZc0I5RCxPQXpZdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1EQTBZVyxLQUFLc0UsTUFBTCxDQUFZLE9BQVosRUFBcUJ0RSxPQUFyQixDQTFZWDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdHQTZZdUJBLE9BN1l2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbURBOFlXLEtBQUtzRSxNQUFMLENBQVksVUFBWixFQUF3QnRFLE9BQXhCLENBOVlYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBaVpFO0FBQ0Y7QUFDQTs7QUFuWkE7QUFBQTtBQUFBO0FBQUEsdUdBb1pzQkEsT0FwWnRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtREFxWlcsS0FBS3NFLE1BQUwsQ0FBWSxTQUFaLEVBQXVCdEUsT0FBdkIsQ0FyWlg7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUF3WkU7QUFDRjtBQUNBOztBQTFaQTtBQUFBO0FBQUEsNEJBMlpVNUQsR0EzWlYsRUEyWnVCO0FBQ25CRSxNQUFBQSxRQUFPLENBQUNGLEdBQUQsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQWphQTtBQUFBO0FBQUEsd0NBa2FzQkEsR0FsYXRCLEVBa2FvQztBQUFBOztBQUNoQyxVQUFJcUksWUFBWSxrREFBTSxLQUFLdkcsS0FBTCxDQUFXWSxXQUFqQixpREFBd0QsS0FBS1osS0FBTCxDQUFXVyxXQUFuRSxDQUFoQjs7QUFDQSxVQUFJekMsR0FBSixFQUFTO0FBQ1BxSSxRQUFBQSxZQUFZLElBQUksYUFBYUMsa0JBQWtCLENBQUN0SSxHQUFELENBQS9DO0FBQ0Q7O0FBQ0QsV0FBS0UsT0FBTCxDQUFhbUksWUFBYjtBQUNEO0FBeGFIOztBQUFBO0FBQUE7QUEyYUE7O0FBRUEsSUFBTUUsR0FBRyxHQUFHLElBQUkxSCxHQUFKLEVBQVo7QUFFQSxlQUFlMEgsR0FBZiIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGZpbGUgQ29tbWFuZCBsaW5lIGludGVyZmFjZSBmb3IgSlNmb3JjZVxuICogQGF1dGhvciBTaGluaWNoaSBUb21pdGEgPHNoaW5pY2hpLnRvbWl0YUBnbWFpbC5jb20+XG4gKi9cbmltcG9ydCBodHRwIGZyb20gJ2h0dHAnO1xuaW1wb3J0IHVybCBmcm9tICd1cmwnO1xuaW1wb3J0IGNyeXB0byBmcm9tICdjcnlwdG8nO1xuaW1wb3J0IG9wZW5VcmwgZnJvbSAnb3Blbic7XG5pbXBvcnQgeyBDb21tYW5kIH0gZnJvbSAnY29tbWFuZGVyJztcbmltcG9ydCBpbnF1aXJlciBmcm9tICdpbnF1aXJlcic7XG5pbXBvcnQgcmVxdWVzdCBmcm9tICcuLi9yZXF1ZXN0JztcbmltcG9ydCBiYXNlNjR1cmwgZnJvbSAnYmFzZTY0dXJsJztcbmltcG9ydCBSZXBsIGZyb20gJy4vcmVwbCc7XG5pbXBvcnQganNmb3JjZSwgeyBDb25uZWN0aW9uLCBPQXV0aDIgfSBmcm9tICcuLic7XG5pbXBvcnQgdmVyc2lvbiBmcm9tICcuLi9WRVJTSU9OJztcbmltcG9ydCB7IE9wdGlvbmFsIH0gZnJvbSAnLi4vdHlwZXMnO1xuaW1wb3J0IHsgQ2xpZW50Q29uZmlnIH0gZnJvbSAnLi4vcmVnaXN0cnkvdHlwZXMnO1xuXG5jb25zdCByZWdpc3RyeSA9IGpzZm9yY2UucmVnaXN0cnk7XG5cbmludGVyZmFjZSBDbGlDb21tYW5kIGV4dGVuZHMgQ29tbWFuZCB7XG4gIGNvbm5lY3Rpb24/OiBzdHJpbmc7XG4gIHVzZXJuYW1lPzogc3RyaW5nO1xuICBwYXNzd29yZD86IHN0cmluZztcbiAgbG9naW5Vcmw/OiBzdHJpbmc7XG4gIHNhbmRib3g/OiBib29sZWFuO1xuICBldmFsU2NyaXB0Pzogc3RyaW5nO1xufVxuXG4vKipcbiAqXG4gKi9cbmV4cG9ydCBjbGFzcyBDbGkge1xuICBfcmVwbDogUmVwbCA9IG5ldyBSZXBsKHRoaXMpO1xuICBfY29ubjogQ29ubmVjdGlvbiA9IG5ldyBDb25uZWN0aW9uKCk7XG4gIF9jb25uTmFtZTogc3RyaW5nIHwgdW5kZWZpbmVkID0gdW5kZWZpbmVkO1xuICBfb3V0cHV0RW5hYmxlZDogYm9vbGVhbiA9IHRydWU7XG4gIF9kZWZhdWx0TG9naW5Vcmw6IHN0cmluZyB8IHVuZGVmaW5lZCA9IHVuZGVmaW5lZDtcblxuICAvKipcbiAgICpcbiAgICovXG4gIHJlYWRDb21tYW5kKCk6IENsaUNvbW1hbmQge1xuICAgIHJldHVybiBuZXcgQ29tbWFuZCgpXG4gICAgICAub3B0aW9uKCctdSwgLS11c2VybmFtZSBbdXNlcm5hbWVdJywgJ1NhbGVzZm9yY2UgdXNlcm5hbWUnKVxuICAgICAgLm9wdGlvbihcbiAgICAgICAgJy1wLCAtLXBhc3N3b3JkIFtwYXNzd29yZF0nLFxuICAgICAgICAnU2FsZXNmb3JjZSBwYXNzd29yZCAoYW5kIHNlY3VyaXR5IHRva2VuLCBpZiBhdmFpbGFibGUpJyxcbiAgICAgIClcbiAgICAgIC5vcHRpb24oXG4gICAgICAgICctYywgLS1jb25uZWN0aW9uIFtjb25uZWN0aW9uXScsXG4gICAgICAgICdDb25uZWN0aW9uIG5hbWUgc3RvcmVkIGluIGNvbm5lY3Rpb24gcmVnaXN0cnknLFxuICAgICAgKVxuICAgICAgLm9wdGlvbignLWwsIC0tbG9naW5VcmwgW2xvZ2luVXJsXScsICdTYWxlc2ZvcmNlIGxvZ2luIHVybCcpXG4gICAgICAub3B0aW9uKCctLXNhbmRib3gnLCAnTG9naW4gdG8gU2FsZXNmb3JjZSBzYW5kYm94JylcbiAgICAgIC5vcHRpb24oJy1lLCAtLWV2YWxTY3JpcHQgW2V2YWxTY3JpcHRdJywgJ1NjcmlwdCB0byBldmFsdWF0ZScpXG4gICAgICAudmVyc2lvbih2ZXJzaW9uKVxuICAgICAgLnBhcnNlKHByb2Nlc3MuYXJndik7XG4gIH1cblxuICBhc3luYyBzdGFydCgpIHtcbiAgICBjb25zdCBwcm9ncmFtID0gdGhpcy5yZWFkQ29tbWFuZCgpO1xuICAgIHRoaXMuX291dHB1dEVuYWJsZWQgPSAhcHJvZ3JhbS5ldmFsU2NyaXB0O1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCB0aGlzLmNvbm5lY3QocHJvZ3JhbSk7XG4gICAgICBpZiAocHJvZ3JhbS5ldmFsU2NyaXB0KSB7XG4gICAgICAgIHRoaXMuX3JlcGwuc3RhcnQoe1xuICAgICAgICAgIGludGVyYWN0aXZlOiBmYWxzZSxcbiAgICAgICAgICBldmFsU2NyaXB0OiBwcm9ncmFtLmV2YWxTY3JpcHQsXG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5fcmVwbC5zdGFydCgpO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xuICAgICAgcHJvY2Vzcy5leGl0KCk7XG4gICAgfVxuICB9XG5cbiAgZ2V0Q3VycmVudENvbm5lY3Rpb24oKSB7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm47XG4gIH1cblxuICBwcmludCguLi5hcmdzOiBhbnlbXSkge1xuICAgIGlmICh0aGlzLl9vdXRwdXRFbmFibGVkKSB7XG4gICAgICBjb25zb2xlLmxvZyguLi5hcmdzKTtcbiAgICB9XG4gIH1cblxuICBzYXZlQ3VycmVudENvbm5lY3Rpb24oKSB7XG4gICAgaWYgKHRoaXMuX2Nvbm5OYW1lKSB7XG4gICAgICBjb25zdCBjb25uID0gdGhpcy5fY29ubjtcbiAgICAgIGNvbnN0IGNvbm5OYW1lID0gdGhpcy5fY29ubk5hbWU7XG4gICAgICBjb25zdCBjb25uQ29uZmlnID0ge1xuICAgICAgICBvYXV0aDI6IGNvbm4ub2F1dGgyXG4gICAgICAgICAgPyB7XG4gICAgICAgICAgICAgIGNsaWVudElkOiBjb25uLm9hdXRoMi5jbGllbnRJZCB8fCB1bmRlZmluZWQsXG4gICAgICAgICAgICAgIGNsaWVudFNlY3JldDogY29ubi5vYXV0aDIuY2xpZW50U2VjcmV0IHx8IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgcmVkaXJlY3RVcmk6IGNvbm4ub2F1dGgyLnJlZGlyZWN0VXJpIHx8IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgbG9naW5Vcmw6IGNvbm4ub2F1dGgyLmxvZ2luVXJsIHx8IHVuZGVmaW5lZCxcbiAgICAgICAgICAgIH1cbiAgICAgICAgICA6IHVuZGVmaW5lZCxcbiAgICAgICAgYWNjZXNzVG9rZW46IGNvbm4uYWNjZXNzVG9rZW4gfHwgdW5kZWZpbmVkLFxuICAgICAgICBpbnN0YW5jZVVybDogY29ubi5pbnN0YW5jZVVybCB8fCB1bmRlZmluZWQsXG4gICAgICAgIHJlZnJlc2hUb2tlbjogY29ubi5yZWZyZXNoVG9rZW4gfHwgdW5kZWZpbmVkLFxuICAgICAgfTtcbiAgICAgIHJlZ2lzdHJ5LnNhdmVDb25uZWN0aW9uQ29uZmlnKGNvbm5OYW1lLCBjb25uQ29uZmlnKTtcbiAgICB9XG4gIH1cblxuICBzZXRMb2dpblNlcnZlcihsb2dpblNlcnZlcjogT3B0aW9uYWw8c3RyaW5nPikge1xuICAgIGlmICghbG9naW5TZXJ2ZXIpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKGxvZ2luU2VydmVyID09PSAncHJvZHVjdGlvbicpIHtcbiAgICAgIHRoaXMuX2RlZmF1bHRMb2dpblVybCA9ICdodHRwczovL2xvZ2luLnNhbGVzZm9yY2UuY29tJztcbiAgICB9IGVsc2UgaWYgKGxvZ2luU2VydmVyID09PSAnc2FuZGJveCcpIHtcbiAgICAgIHRoaXMuX2RlZmF1bHRMb2dpblVybCA9ICdodHRwczovL3Rlc3Quc2FsZXNmb3JjZS5jb20nO1xuICAgIH0gZWxzZSBpZiAobG9naW5TZXJ2ZXIuaW5kZXhPZignaHR0cHM6Ly8nKSAhPT0gMCkge1xuICAgICAgdGhpcy5fZGVmYXVsdExvZ2luVXJsID0gJ2h0dHBzOi8vJyArIGxvZ2luU2VydmVyO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLl9kZWZhdWx0TG9naW5VcmwgPSBsb2dpblNlcnZlcjtcbiAgICB9XG4gICAgdGhpcy5wcmludChgVXNpbmcgXCIke3RoaXMuX2RlZmF1bHRMb2dpblVybH1cIiBhcyBkZWZhdWx0IGxvZ2luIFVSTC5gKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgY29ubmVjdChvcHRpb25zOiB7XG4gICAgdXNlcm5hbWU/OiBzdHJpbmc7XG4gICAgcGFzc3dvcmQ/OiBzdHJpbmc7XG4gICAgY29ubmVjdGlvbj86IHN0cmluZztcbiAgICBsb2dpblVybD86IHN0cmluZztcbiAgICBzYW5kYm94PzogYm9vbGVhbjtcbiAgfSkge1xuICAgIGNvbnN0IGxvZ2luU2VydmVyID0gb3B0aW9ucy5sb2dpblVybFxuICAgICAgPyBvcHRpb25zLmxvZ2luVXJsXG4gICAgICA6IG9wdGlvbnMuc2FuZGJveFxuICAgICAgPyAnc2FuZGJveCdcbiAgICAgIDogbnVsbDtcbiAgICB0aGlzLnNldExvZ2luU2VydmVyKGxvZ2luU2VydmVyKTtcbiAgICB0aGlzLl9jb25uTmFtZSA9IG9wdGlvbnMuY29ubmVjdGlvbjtcbiAgICBsZXQgY29ubkNvbmZpZyA9IGF3YWl0IHJlZ2lzdHJ5LmdldENvbm5lY3Rpb25Db25maWcob3B0aW9ucy5jb25uZWN0aW9uKTtcbiAgICBsZXQgdXNlcm5hbWUgPSBvcHRpb25zLnVzZXJuYW1lO1xuICAgIGlmICghY29ubkNvbmZpZykge1xuICAgICAgY29ubkNvbmZpZyA9IHt9O1xuICAgICAgaWYgKHRoaXMuX2RlZmF1bHRMb2dpblVybCkge1xuICAgICAgICBjb25uQ29uZmlnLmxvZ2luVXJsID0gdGhpcy5fZGVmYXVsdExvZ2luVXJsO1xuICAgICAgfVxuICAgICAgdXNlcm5hbWUgPSB1c2VybmFtZSB8fCBvcHRpb25zLmNvbm5lY3Rpb247XG4gICAgfVxuICAgIHRoaXMuX2Nvbm4gPSBuZXcgQ29ubmVjdGlvbihjb25uQ29uZmlnKTtcbiAgICBjb25zdCBwYXNzd29yZCA9IG9wdGlvbnMucGFzc3dvcmQ7XG4gICAgaWYgKHVzZXJuYW1lKSB7XG4gICAgICBhd2FpdCB0aGlzLnN0YXJ0UGFzc3dvcmRBdXRoKHVzZXJuYW1lLCBwYXNzd29yZCk7XG4gICAgICB0aGlzLnNhdmVDdXJyZW50Q29ubmVjdGlvbigpO1xuICAgIH0gZWxzZSB7XG4gICAgICBpZiAodGhpcy5fY29ubk5hbWUgJiYgdGhpcy5fY29ubi5hY2Nlc3NUb2tlbikge1xuICAgICAgICB0aGlzLl9jb25uLm9uKCdyZWZyZXNoJywgKCkgPT4ge1xuICAgICAgICAgIHRoaXMucHJpbnQoJ1JlZnJlc2hpbmcgYWNjZXNzIHRva2VuIC4uLiAnKTtcbiAgICAgICAgICB0aGlzLnNhdmVDdXJyZW50Q29ubmVjdGlvbigpO1xuICAgICAgICB9KTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCBpZGVudGl0eSA9IGF3YWl0IHRoaXMuX2Nvbm4uaWRlbnRpdHkoKTtcbiAgICAgICAgICB0aGlzLnByaW50KGBMb2dnZWQgaW4gYXMgOiAke2lkZW50aXR5LnVzZXJuYW1lfWApO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICBpZiAoZXJyIGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICAgICAgICAgIHRoaXMucHJpbnQoZXJyLm1lc3NhZ2UpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAodGhpcy5fY29ubi5vYXV0aDIpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignUGxlYXNlIHJlLWF1dGhvcml6ZSBjb25uZWN0aW9uLicpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBhd2FpdCB0aGlzLnN0YXJ0UGFzc3dvcmRBdXRoKHRoaXMuX2Nvbm5OYW1lKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIGFzeW5jIHN0YXJ0UGFzc3dvcmRBdXRoKHVzZXJuYW1lOiBzdHJpbmcsIHBhc3N3b3JkPzogc3RyaW5nKSB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHRoaXMubG9naW5CeVBhc3N3b3JkKHVzZXJuYW1lLCBwYXNzd29yZCwgMik7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBpZiAoZXJyIGluc3RhbmNlb2YgRXJyb3IgJiYgZXJyLm1lc3NhZ2UgPT09ICdjYW5jZWxlZCcpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcignUGFzc3dvcmQgYXV0aGVudGljYXRpb24gY2FuY2VsZWQ6IE5vdCBsb2dnZWQgaW4nKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRocm93IGVycjtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIGFzeW5jIGxvZ2luQnlQYXNzd29yZChcbiAgICB1c2VybmFtZTogc3RyaW5nLFxuICAgIHBhc3N3b3JkOiBzdHJpbmcgfCB1bmRlZmluZWQsXG4gICAgcmV0cnlDb3VudDogbnVtYmVyLFxuICApOiBQcm9taXNlPHsgaWQ6IHN0cmluZyB9PiB7XG4gICAgaWYgKHBhc3N3b3JkID09PSAnJykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdjYW5jZWxlZCcpO1xuICAgIH1cbiAgICBpZiAocGFzc3dvcmQgPT0gbnVsbCkge1xuICAgICAgY29uc3QgcGFzcyA9IGF3YWl0IHRoaXMucHJvbXB0UGFzc3dvcmQoJ1Bhc3N3b3JkOiAnKTtcbiAgICAgIHJldHVybiB0aGlzLmxvZ2luQnlQYXNzd29yZCh1c2VybmFtZSwgcGFzcywgcmV0cnlDb3VudCk7XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB0aGlzLl9jb25uLmxvZ2luKHVzZXJuYW1lLCBwYXNzd29yZCk7XG4gICAgICB0aGlzLnByaW50KGBMb2dnZWQgaW4gYXMgOiAke3VzZXJuYW1lfWApO1xuICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGVyci5tZXNzYWdlKTtcbiAgICAgIH1cbiAgICAgIGlmIChyZXRyeUNvdW50ID4gMCkge1xuICAgICAgICByZXR1cm4gdGhpcy5sb2dpbkJ5UGFzc3dvcmQodXNlcm5hbWUsIHVuZGVmaW5lZCwgcmV0cnlDb3VudCAtIDEpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdjYW5jZWxlZCcpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgZGlzY29ubmVjdChjb25uTmFtZT86IHN0cmluZykge1xuICAgIGNvbnN0IG5hbWUgPSBjb25uTmFtZSB8fCB0aGlzLl9jb25uTmFtZTtcbiAgICBpZiAobmFtZSAmJiByZWdpc3RyeS5nZXRDb25uZWN0aW9uQ29uZmlnKG5hbWUpKSB7XG4gICAgICByZWdpc3RyeS5yZW1vdmVDb25uZWN0aW9uQ29uZmlnKG5hbWUpO1xuICAgICAgdGhpcy5wcmludChgRGlzY29ubmVjdCBjb25uZWN0aW9uICcke25hbWV9J2ApO1xuICAgIH1cbiAgICB0aGlzLl9jb25uTmFtZSA9IHVuZGVmaW5lZDtcbiAgICB0aGlzLl9jb25uID0gbmV3IENvbm5lY3Rpb24oKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgYXV0aG9yaXplKGNsaWVudE5hbWU6IHN0cmluZykge1xuICAgIGNvbnN0IG5hbWUgPSBjbGllbnROYW1lIHx8ICdkZWZhdWx0JztcbiAgICB2YXIgb2F1dGgyQ29uZmlnID0gYXdhaXQgcmVnaXN0cnkuZ2V0Q2xpZW50Q29uZmlnKG5hbWUpO1xuICAgIGlmICghb2F1dGgyQ29uZmlnIHx8ICFvYXV0aDJDb25maWcuY2xpZW50SWQpIHtcbiAgICAgIGlmIChuYW1lID09PSAnZGVmYXVsdCcgfHwgbmFtZSA9PT0gJ3NhbmRib3gnKSB7XG4gICAgICAgIHRoaXMucHJpbnQoXG4gICAgICAgICAgJ05vIGNsaWVudCBpbmZvcm1hdGlvbiByZWdpc3RlcmVkLiBEb3dubG9hZGluZyBKU2ZvcmNlIGRlZmF1bHQgY2xpZW50IGluZm9ybWF0aW9uLi4uJyxcbiAgICAgICAgKTtcbiAgICAgICAgcmV0dXJuIHRoaXMuZG93bmxvYWREZWZhdWx0Q2xpZW50SW5mbyhuYW1lKTtcbiAgICAgIH1cbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgYE5vIE9BdXRoMiBjbGllbnQgaW5mb3JtYXRpb24gcmVnaXN0ZXJlZCA6ICcke25hbWV9Jy4gUGxlYXNlIHJlZ2lzdGVyIGNsaWVudCBpbmZvIGZpcnN0LmAsXG4gICAgICApO1xuICAgIH1cbiAgICBjb25zdCBvYXV0aDIgPSBuZXcgT0F1dGgyKG9hdXRoMkNvbmZpZyk7XG4gICAgY29uc3QgdmVyaWZpZXIgPSBiYXNlNjR1cmwuZW5jb2RlKGNyeXB0by5yYW5kb21CeXRlcygzMikpO1xuICAgIGNvbnN0IGNoYWxsZW5nZSA9IGJhc2U2NHVybC5lbmNvZGUoXG4gICAgICBjcnlwdG8uY3JlYXRlSGFzaCgnc2hhMjU2JykudXBkYXRlKHZlcmlmaWVyKS5kaWdlc3QoKSxcbiAgICApO1xuICAgIGNvbnN0IHN0YXRlID0gYmFzZTY0dXJsLmVuY29kZShjcnlwdG8ucmFuZG9tQnl0ZXMoMzIpKTtcbiAgICBjb25zdCBhdXRoelVybCA9IG9hdXRoMi5nZXRBdXRob3JpemF0aW9uVXJsKHtcbiAgICAgIGNvZGVfY2hhbGxlbmdlOiBjaGFsbGVuZ2UsXG4gICAgICBzdGF0ZSxcbiAgICB9KTtcbiAgICB0aGlzLnByaW50KCdPcGVuaW5nIGF1dGhvcml6YXRpb24gcGFnZSBpbiBicm93c2VyLi4uJyk7XG4gICAgdGhpcy5wcmludChgVVJMOiAke2F1dGh6VXJsfWApO1xuICAgIHRoaXMub3BlblVybChhdXRoelVybCk7XG4gICAgY29uc3QgcGFyYW1zID0gYXdhaXQgdGhpcy53YWl0Q2FsbGJhY2sob2F1dGgyQ29uZmlnLnJlZGlyZWN0VXJpLCBzdGF0ZSk7XG4gICAgaWYgKCFwYXJhbXMuY29kZSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdObyBhdXRob3JpemF0aW9uIGNvZGUgcmV0dXJuZWQuJyk7XG4gICAgfVxuICAgIGlmIChwYXJhbXMuc3RhdGUgIT09IHN0YXRlKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ludmFsaWQgc3RhdGUgcGFyYW1ldGVyIHJldHVybmVkLicpO1xuICAgIH1cbiAgICB0aGlzLl9jb25uID0gbmV3IENvbm5lY3Rpb24oeyBvYXV0aDIgfSk7XG4gICAgdGhpcy5wcmludChcbiAgICAgICdSZWNlaXZlZCBhdXRob3JpemF0aW9uIGNvZGUuIFBsZWFzZSBjbG9zZSB0aGUgb3BlbmVkIGJyb3dzZXIgd2luZG93LicsXG4gICAgKTtcbiAgICBhd2FpdCB0aGlzLl9jb25uLmF1dGhvcml6ZShwYXJhbXMuY29kZSwgeyBjb2RlX3ZlcmlmaWVyOiB2ZXJpZmllciB9KTtcbiAgICB0aGlzLnByaW50KCdBdXRob3JpemVkLiBGZXRjaGluZyB1c2VyIGluZm8uLi4nKTtcbiAgICBjb25zdCBpZGVudGl0eSA9IGF3YWl0IHRoaXMuX2Nvbm4uaWRlbnRpdHkoKTtcbiAgICB0aGlzLnByaW50KGBMb2dnZWQgaW4gYXMgOiAke2lkZW50aXR5LnVzZXJuYW1lfWApO1xuICAgIHRoaXMuX2Nvbm5OYW1lID0gaWRlbnRpdHkudXNlcm5hbWU7XG4gICAgdGhpcy5zYXZlQ3VycmVudENvbm5lY3Rpb24oKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgZG93bmxvYWREZWZhdWx0Q2xpZW50SW5mbyhjbGllbnROYW1lOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBjb25maWdVcmwgPSAnaHR0cHM6Ly9qc2ZvcmNlLmdpdGh1Yi5pby9jbGllbnQtY29uZmlnL2RlZmF1bHQuanNvbic7XG4gICAgY29uc3QgcmVzOiB7IGJvZHk6IHN0cmluZyB9ID0gYXdhaXQgbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgcmVxdWVzdCh7IG1ldGhvZDogJ0dFVCcsIHVybDogY29uZmlnVXJsIH0pXG4gICAgICAgIC5vbignY29tcGxldGUnLCByZXNvbHZlKVxuICAgICAgICAub24oJ2Vycm9yJywgcmVqZWN0KTtcbiAgICB9KTtcbiAgICBjb25zdCBjbGllbnRDb25maWcgPSBKU09OLnBhcnNlKHJlcy5ib2R5KTtcbiAgICBpZiAoY2xpZW50TmFtZSA9PT0gJ3NhbmRib3gnKSB7XG4gICAgICBjbGllbnRDb25maWcubG9naW5VcmwgPSAnaHR0cHM6Ly90ZXN0LnNhbGVzZm9yY2UuY29tJztcbiAgICB9XG4gICAgYXdhaXQgcmVnaXN0cnkucmVnaXN0ZXJDbGllbnRDb25maWcoY2xpZW50TmFtZSwgY2xpZW50Q29uZmlnKTtcbiAgICB0aGlzLnByaW50KCdDbGllbnQgaW5mb3JtYXRpb24gZG93bmxvYWRlZCBzdWNjZXNzZnVsbHkuJyk7XG4gICAgcmV0dXJuIHRoaXMuYXV0aG9yaXplKGNsaWVudE5hbWUpO1xuICB9XG5cbiAgYXN5bmMgd2FpdENhbGxiYWNrKFxuICAgIHNlcnZlclVybDogc3RyaW5nIHwgdW5kZWZpbmVkLFxuICAgIHN0YXRlOiBzdHJpbmcsXG4gICk6IFByb21pc2U8eyBjb2RlOiBzdHJpbmc7IHN0YXRlOiBzdHJpbmcgfT4ge1xuICAgIGlmIChzZXJ2ZXJVcmwgJiYgc2VydmVyVXJsLmluZGV4T2YoJ2h0dHA6Ly9sb2NhbGhvc3Q6JykgPT09IDApIHtcbiAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgIGNvbnN0IHNlcnZlciA9IGh0dHAuY3JlYXRlU2VydmVyKChyZXEsIHJlcykgPT4ge1xuICAgICAgICAgIGlmICghcmVxLnVybCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCBxcGFyYW1zID0gdXJsLnBhcnNlKHJlcS51cmwsIHRydWUpLnF1ZXJ5O1xuICAgICAgICAgIHJlcy53cml0ZUhlYWQoMjAwLCB7ICdDb250ZW50LVR5cGUnOiAndGV4dC9odG1sJyB9KTtcbiAgICAgICAgICByZXMud3JpdGUoXG4gICAgICAgICAgICAnPGh0bWw+PHNjcmlwdD5sb2NhdGlvbi5ocmVmPVwiYWJvdXQ6YmxhbmtcIjs8L3NjcmlwdD48L2h0bWw+JyxcbiAgICAgICAgICApO1xuICAgICAgICAgIHJlcy5lbmQoKTtcbiAgICAgICAgICBpZiAocXBhcmFtcy5lcnJvcikge1xuICAgICAgICAgICAgcmVqZWN0KG5ldyBFcnJvcihxcGFyYW1zLmVycm9yIGFzIHN0cmluZykpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXNvbHZlKHFwYXJhbXMgYXMgeyBjb2RlOiBzdHJpbmc7IHN0YXRlOiBzdHJpbmcgfSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHNlcnZlci5jbG9zZSgpO1xuICAgICAgICAgIHJlcS5jb25uZWN0aW9uLmVuZCgpO1xuICAgICAgICAgIHJlcS5jb25uZWN0aW9uLmRlc3Ryb3koKTtcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IHBvcnQgPSBOdW1iZXIodXJsLnBhcnNlKHNlcnZlclVybCkucG9ydCk7XG4gICAgICAgIHNlcnZlci5saXN0ZW4ocG9ydCwgJ2xvY2FsaG9zdCcpO1xuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IGNvZGUgPSBhd2FpdCB0aGlzLnByb21wdE1lc3NhZ2UoXG4gICAgICAgICdDb3B5ICYgcGFzdGUgYXV0aHogY29kZSBwYXNzZWQgaW4gcmVkaXJlY3RlZCBVUkw6ICcsXG4gICAgICApO1xuICAgICAgcmV0dXJuIHsgY29kZTogZGVjb2RlVVJJQ29tcG9uZW50KGNvZGUpLCBzdGF0ZSB9O1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgcmVnaXN0ZXIoY2xpZW50TmFtZTogc3RyaW5nIHwgdW5kZWZpbmVkLCBjbGllbnRDb25maWc6IENsaWVudENvbmZpZykge1xuICAgIGNvbnN0IG5hbWUgPSBjbGllbnROYW1lIHx8ICdkZWZhdWx0JztcbiAgICBjb25zdCBwcm9tcHRzID0ge1xuICAgICAgY2xpZW50SWQ6ICdJbnB1dCBjbGllbnQgSUQgOiAnLFxuICAgICAgY2xpZW50U2VjcmV0OiAnSW5wdXQgY2xpZW50IHNlY3JldCAob3B0aW9uYWwpIDogJyxcbiAgICAgIHJlZGlyZWN0VXJpOiAnSW5wdXQgcmVkaXJlY3QgVVJJIDogJyxcbiAgICAgIGxvZ2luVXJsOiAnSW5wdXQgbG9naW4gVVJMIChkZWZhdWx0IGlzIGh0dHBzOi8vbG9naW4uc2FsZXNmb3JjZS5jb20pIDogJyxcbiAgICB9O1xuICAgIGNvbnN0IHJlZ2lzdGVyZWQgPSBhd2FpdCByZWdpc3RyeS5nZXRDbGllbnRDb25maWcobmFtZSk7XG4gICAgaWYgKHJlZ2lzdGVyZWQpIHtcbiAgICAgIGNvbnN0IG1zZyA9IGBDbGllbnQgJyR7bmFtZX0nIGlzIGFscmVhZHkgcmVnaXN0ZXJlZC4gQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIG92ZXJyaWRlID8gW3lOXSA6IGA7XG4gICAgICBjb25zdCBvayA9IGF3YWl0IHRoaXMucHJvbXB0Q29uZmlybShtc2cpO1xuICAgICAgaWYgKCFvaykge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1JlZ2lzdHJhdGlvbiBjYW5jZWxlZC4nKTtcbiAgICAgIH1cbiAgICB9XG4gICAgY2xpZW50Q29uZmlnID0gYXdhaXQgT2JqZWN0LmtleXMocHJvbXB0cykucmVkdWNlKGFzeW5jIChwcm9taXNlLCBuYW1lKSA9PiB7XG4gICAgICBjb25zdCBjY29uZmlnID0gYXdhaXQgcHJvbWlzZTtcbiAgICAgIGNvbnN0IHByb21wdE5hbWUgPSBuYW1lIGFzIGtleW9mIHR5cGVvZiBwcm9tcHRzO1xuICAgICAgY29uc3QgbWVzc2FnZSA9IHByb21wdHNbcHJvbXB0TmFtZV07XG4gICAgICBpZiAoIWNjb25maWdbcHJvbXB0TmFtZV0pIHtcbiAgICAgICAgY29uc3QgdmFsdWUgPSBhd2FpdCB0aGlzLnByb21wdE1lc3NhZ2UobWVzc2FnZSk7XG4gICAgICAgIGlmICh2YWx1ZSkge1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAuLi5jY29uZmlnLFxuICAgICAgICAgICAgW3Byb21wdE5hbWVdOiB2YWx1ZSxcbiAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gY2NvbmZpZztcbiAgICB9LCBQcm9taXNlLnJlc29sdmUoY2xpZW50Q29uZmlnKSk7XG4gICAgYXdhaXQgcmVnaXN0cnkucmVnaXN0ZXJDbGllbnRDb25maWcobmFtZSwgY2xpZW50Q29uZmlnKTtcbiAgICB0aGlzLnByaW50KCdDbGllbnQgcmVnaXN0ZXJlZCBzdWNjZXNzZnVsbHkuJyk7XG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIGFzeW5jIGxpc3RDb25uZWN0aW9ucygpIHtcbiAgICBjb25zdCBuYW1lcyA9IGF3YWl0IHJlZ2lzdHJ5LmdldENvbm5lY3Rpb25OYW1lcygpO1xuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbmFtZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgIHZhciBuYW1lID0gbmFtZXNbaV07XG4gICAgICB0aGlzLnByaW50KChuYW1lID09PSB0aGlzLl9jb25uTmFtZSA/ICcqICcgOiAnICAnKSArIG5hbWUpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgZ2V0Q29ubmVjdGlvbk5hbWVzKCkge1xuICAgIHJldHVybiByZWdpc3RyeS5nZXRDb25uZWN0aW9uTmFtZXMoKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgZ2V0Q2xpZW50TmFtZXMoKSB7XG4gICAgcmV0dXJuIHJlZ2lzdHJ5LmdldENsaWVudE5hbWVzKCk7XG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIGFzeW5jIHByb21wdCh0eXBlOiBzdHJpbmcsIG1lc3NhZ2U6IHN0cmluZykge1xuICAgIHRoaXMuX3JlcGwucGF1c2UoKTtcbiAgICBjb25zdCBhbnN3ZXI6IHsgdmFsdWU6IHN0cmluZyB9ID0gYXdhaXQgaW5xdWlyZXIucHJvbXB0KFtcbiAgICAgIHtcbiAgICAgICAgdHlwZSxcbiAgICAgICAgbmFtZTogJ3ZhbHVlJyxcbiAgICAgICAgbWVzc2FnZSxcbiAgICAgIH0sXG4gICAgXSk7XG4gICAgdGhpcy5fcmVwbC5yZXN1bWUoKTtcbiAgICByZXR1cm4gYW5zd2VyLnZhbHVlO1xuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBhc3luYyBwcm9tcHRNZXNzYWdlKG1lc3NhZ2U6IHN0cmluZykge1xuICAgIHJldHVybiB0aGlzLnByb21wdCgnaW5wdXQnLCBtZXNzYWdlKTtcbiAgfVxuXG4gIGFzeW5jIHByb21wdFBhc3N3b3JkKG1lc3NhZ2U6IHN0cmluZykge1xuICAgIHJldHVybiB0aGlzLnByb21wdCgncGFzc3dvcmQnLCBtZXNzYWdlKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgcHJvbXB0Q29uZmlybShtZXNzYWdlOiBzdHJpbmcpIHtcbiAgICByZXR1cm4gdGhpcy5wcm9tcHQoJ2NvbmZpcm0nLCBtZXNzYWdlKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgb3BlblVybCh1cmw6IHN0cmluZykge1xuICAgIG9wZW5VcmwodXJsKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgb3BlblVybFVzaW5nU2Vzc2lvbih1cmw/OiBzdHJpbmcpIHtcbiAgICBsZXQgZnJvbnRkb29yVXJsID0gYCR7dGhpcy5fY29ubi5pbnN0YW5jZVVybH0vc2VjdXIvZnJvbnRkb29yLmpzcD9zaWQ9JHt0aGlzLl9jb25uLmFjY2Vzc1Rva2VufWA7XG4gICAgaWYgKHVybCkge1xuICAgICAgZnJvbnRkb29yVXJsICs9ICcmcmV0VVJMPScgKyBlbmNvZGVVUklDb21wb25lbnQodXJsKTtcbiAgICB9XG4gICAgdGhpcy5vcGVuVXJsKGZyb250ZG9vclVybCk7XG4gIH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5jb25zdCBjbGkgPSBuZXcgQ2xpKCk7XG5cbmV4cG9ydCBkZWZhdWx0IGNsaTtcbiJdfQ==