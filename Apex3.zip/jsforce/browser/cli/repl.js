import _getIterator from "@babel/runtime-corejs3/core-js/get-iterator";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _getIteratorMethod from "@babel/runtime-corejs3/core-js/get-iterator-method";
import _Symbol from "@babel/runtime-corejs3/core-js-stable/symbol";
import _Array$from from "@babel/runtime-corejs3/core-js-stable/array/from";
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";
import "core-js/modules/es.regexp.exec";
import "core-js/modules/es.string.replace";
import "core-js/modules/es.string.split";
import _Object$keys2 from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _Object$getOwnPropertyNames from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-names";
import _Object$getPrototypeOf from "@babel/runtime-corejs3/core-js-stable/object/get-prototype-of";
import _indexOfInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/index-of";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _slicedToArray from "@babel/runtime-corejs3/helpers/slicedToArray";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import "regenerator-runtime/runtime";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof _Symbol === "undefined" || _getIteratorMethod(o) == null) { if (_Array$isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = _getIterator(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { var _context6; if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = _sliceInstanceProperty(_context6 = Object.prototype.toString.call(o)).call(_context6, 8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return _Array$from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

/**
 * @file Creates REPL interface with built in Salesforce API objects and automatically resolves promise object
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 * @private
 */
import { EventEmitter } from 'events';
import { start as startRepl } from 'repl';
import { Transform } from 'stream';
import jsforce from '..';
import { isPromiseLike, isNumber, isFunction, isObject } from '../util/function';

/**
 * Intercept the evaled value returned from repl evaluator, convert and send back to output.
 * @private
 */
function injectBefore(replServer, method, beforeFn) {
  var _orig = replServer[method];

  replServer[method] = function () {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    var callback = args.pop();
    beforeFn.apply(null, _concatInstanceProperty(args).call(args, function (err, res) {
      if (err || res) {
        callback(err, res);
      } else {
        _orig.apply(replServer, _concatInstanceProperty(args).call(args, callback));
      }
    }));
  };

  return replServer;
}
/**
 * @private
 */


function injectAfter(replServer, method, afterFn) {
  var _orig = replServer[method];

  replServer[method] = function () {
    for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      args[_key2] = arguments[_key2];
    }

    var callback = args.pop();

    _orig.apply(replServer, _concatInstanceProperty(args).call(args, function () {
      try {
        for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
          args[_key3] = arguments[_key3];
        }

        afterFn.apply(null, _concatInstanceProperty(args).call(args, callback));
      } catch (e) {
        callback(e);
      }
    }));
  };

  return replServer;
}
/**
 * When the result was "promise", resolve its value
 * @private
 */


function promisify(err, value, callback) {
  // callback immediately if no value passed
  if (!callback && isFunction(value)) {
    callback = value;
    return callback();
  }

  if (err) {
    throw err;
  }

  if (isPromiseLike(value)) {
    value.then(function (v) {
      callback(null, v);
    }, function (err) {
      callback(err);
    });
  } else {
    callback(null, value);
  }
}
/**
 * Output object to stdout in JSON representation
 * @private
 */


function outputToStdout(prettyPrint) {
  if (prettyPrint && !isNumber(prettyPrint)) {
    prettyPrint = 4;
  }

  return function (err, value, callback) {
    if (err) {
      console.error(err);
    } else {
      var str = _JSON$stringify(value, null, prettyPrint);

      console.log(str);
    }

    callback(err, value);
  };
}
/**
 * define get accessor using Object.defineProperty
 * @private
 */


function defineProp(obj, prop, getter) {
  if (_Object$defineProperty) {
    _Object$defineProperty(obj, prop, {
      get: getter
    });
  }
}
/**
 *
 */


export var Repl = /*#__PURE__*/function () {
  function Repl(cli) {
    var _this = this;

    _classCallCheck(this, Repl);

    _defineProperty(this, "_cli", void 0);

    _defineProperty(this, "_in", void 0);

    _defineProperty(this, "_out", void 0);

    _defineProperty(this, "_interactive", true);

    _defineProperty(this, "_paused", false);

    _defineProperty(this, "_replServer", undefined);

    this._cli = cli;
    this._in = new Transform();
    this._out = new Transform();

    this._in._transform = function (chunk, encoding, callback) {
      if (!_this._paused) {
        _this._in.push(chunk);
      }

      callback();
    };

    this._out._transform = function (chunk, encoding, callback) {
      if (!_this._paused && _this._interactive !== false) {
        _this._out.push(chunk);
      }

      callback();
    };
  }
  /**
   *
   */


  _createClass(Repl, [{
    key: "start",
    value: function start() {
      var _this2 = this;

      var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      this._interactive = options.interactive !== false;
      process.stdin.resume();

      if (process.stdin.setRawMode) {
        process.stdin.setRawMode(true);
      }

      process.stdin.pipe(this._in);

      this._out.pipe(process.stdout);

      defineProp(this._out, 'columns', function () {
        return process.stdout.columns;
      });
      this._replServer = startRepl({
        input: this._in,
        output: this._out,
        terminal: true
      });

      this._defineAdditionalCommands();

      this._replServer = injectBefore(this._replServer, 'completer', function (line, callback) {
        _this2.complete(line).then(function (rets) {
          callback(null, rets);
        }).catch(function (err) {
          callback(err);
        });
      });
      this._replServer = injectAfter(this._replServer, 'eval', promisify);

      if (options.interactive === false) {
        this._replServer = injectAfter(this._replServer, 'eval', outputToStdout(options.prettyPrint));
        this._replServer = injectAfter(this._replServer, 'eval', function () {
          process.exit();
        });
      }

      this._replServer.on('exit', function () {
        return process.exit();
      });

      this._defineBuiltinVars(this._replServer.context);

      if (options.evalScript) {
        this._in.write(options.evalScript + '\n', 'utf-8');
      }

      return this;
    }
    /**
     *
     */

  }, {
    key: "_defineAdditionalCommands",
    value: function _defineAdditionalCommands() {
      var cli = this._cli;
      var replServer = this._replServer;

      if (!replServer) {
        return;
      }

      replServer.defineCommand('connections', {
        help: 'List currenty registered Salesforce connections',
        action: function () {
          var _action = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee() {
            return _regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return cli.listConnections();

                  case 2:
                    replServer.displayPrompt();

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee);
          }));

          function action() {
            return _action.apply(this, arguments);
          }

          return action;
        }()
      });
      replServer.defineCommand('connect', {
        help: 'Connect to Salesforce instance',
        action: function () {
          var _action2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee2() {
            var _len4,
                args,
                _key4,
                name,
                password,
                params,
                _args2 = arguments;

            return _regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    for (_len4 = _args2.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
                      args[_key4] = _args2[_key4];
                    }

                    name = args[0], password = args[1];
                    params = password ? {
                      connection: name,
                      username: name,
                      password: password
                    } : {
                      connection: name,
                      username: name
                    };
                    _context2.prev = 3;
                    _context2.next = 6;
                    return cli.connect(params);

                  case 6:
                    _context2.next = 11;
                    break;

                  case 8:
                    _context2.prev = 8;
                    _context2.t0 = _context2["catch"](3);

                    if (_context2.t0 instanceof Error) {
                      console.error(_context2.t0.message);
                    }

                  case 11:
                    replServer.displayPrompt();

                  case 12:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, null, [[3, 8]]);
          }));

          function action() {
            return _action2.apply(this, arguments);
          }

          return action;
        }()
      });
      replServer.defineCommand('disconnect', {
        help: 'Disconnect connection and erase it from registry',
        action: function action(name) {
          cli.disconnect(name);
          replServer.displayPrompt();
        }
      });
      replServer.defineCommand('use', {
        help: 'Specify login server to establish connection',
        action: function action(loginServer) {
          cli.setLoginServer(loginServer);
          replServer.displayPrompt();
        }
      });
      replServer.defineCommand('authorize', {
        help: 'Connect to Salesforce using OAuth2 authorization flow',
        action: function () {
          var _action3 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee3(clientName) {
            return _regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.prev = 0;
                    _context3.next = 3;
                    return cli.authorize(clientName);

                  case 3:
                    _context3.next = 8;
                    break;

                  case 5:
                    _context3.prev = 5;
                    _context3.t0 = _context3["catch"](0);

                    if (_context3.t0 instanceof Error) {
                      console.error(_context3.t0.message);
                    }

                  case 8:
                    replServer.displayPrompt();

                  case 9:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, null, [[0, 5]]);
          }));

          function action(_x) {
            return _action3.apply(this, arguments);
          }

          return action;
        }()
      });
      replServer.defineCommand('register', {
        help: 'Register OAuth2 client information',
        action: function () {
          var _action4 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee4() {
            var _len5,
                args,
                _key5,
                clientName,
                clientId,
                clientSecret,
                redirectUri,
                loginUrl,
                config,
                _args4 = arguments;

            return _regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    for (_len5 = _args4.length, args = new Array(_len5), _key5 = 0; _key5 < _len5; _key5++) {
                      args[_key5] = _args4[_key5];
                    }

                    clientName = args[0], clientId = args[1], clientSecret = args[2], redirectUri = args[3], loginUrl = args[4];
                    config = {
                      clientId: clientId,
                      clientSecret: clientSecret,
                      redirectUri: redirectUri,
                      loginUrl: loginUrl
                    };
                    _context4.prev = 3;
                    _context4.next = 6;
                    return cli.register(clientName, config);

                  case 6:
                    _context4.next = 11;
                    break;

                  case 8:
                    _context4.prev = 8;
                    _context4.t0 = _context4["catch"](3);

                    if (_context4.t0 instanceof Error) {
                      console.error(_context4.t0.message);
                    }

                  case 11:
                    replServer.displayPrompt();

                  case 12:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, null, [[3, 8]]);
          }));

          function action() {
            return _action4.apply(this, arguments);
          }

          return action;
        }()
      });
      replServer.defineCommand('open', {
        help: 'Open Salesforce web page using established connection',
        action: function action(url) {
          cli.openUrlUsingSession(url);
          replServer.displayPrompt();
        }
      });
    }
    /**
     *
     */

  }, {
    key: "pause",
    value: function pause() {
      this._paused = true;

      if (process.stdin.setRawMode) {
        process.stdin.setRawMode(false);
      }
    }
    /**
     *
     */

  }, {
    key: "resume",
    value: function resume() {
      this._paused = false;
      process.stdin.resume();

      if (process.stdin.setRawMode) {
        process.stdin.setRawMode(true);
      }
    }
    /**
     *
     */

  }, {
    key: "complete",
    value: function () {
      var _complete = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee5(line) {
        var tokens, _tokens, command, _tokens$, keyword, candidates;

        return _regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                tokens = line.replace(/^\s+/, '').split(/\s+/);
                _tokens = _slicedToArray(tokens, 2), command = _tokens[0], _tokens$ = _tokens[1], keyword = _tokens$ === void 0 ? '' : _tokens$;

                if (!(command[0] === '.' && tokens.length === 2)) {
                  _context5.next = 19;
                  break;
                }

                candidates = [];

                if (!(command === '.connect' || command === '.disconnect')) {
                  _context5.next = 10;
                  break;
                }

                _context5.next = 7;
                return this._cli.getConnectionNames();

              case 7:
                candidates = _context5.sent;
                _context5.next = 17;
                break;

              case 10:
                if (!(command === '.authorize')) {
                  _context5.next = 16;
                  break;
                }

                _context5.next = 13;
                return this._cli.getClientNames();

              case 13:
                candidates = _context5.sent;
                _context5.next = 17;
                break;

              case 16:
                if (command === '.use') {
                  candidates = ['production', 'sandbox'];
                }

              case 17:
                candidates = _filterInstanceProperty(candidates).call(candidates, function (name) {
                  return _indexOfInstanceProperty(name).call(name, keyword) === 0;
                });
                return _context5.abrupt("return", [candidates, keyword]);

              case 19:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function complete(_x2) {
        return _complete.apply(this, arguments);
      }

      return complete;
    }()
    /**
     * Map all jsforce object to REPL context
     * @private
     */

  }, {
    key: "_defineBuiltinVars",
    value: function _defineBuiltinVars(context) {
      var cli = this._cli; // define salesforce package root objects

      for (var key in jsforce) {
        if (Object.prototype.hasOwnProperty.call(jsforce, key) && !global[key]) {
          context[key] = jsforce[key];
        }
      } // expose jsforce package root object in context.


      context.jsforce = jsforce;

      function createProxyFunc(prop) {
        return function () {
          var _ref;

          var conn = cli.getCurrentConnection();
          return (_ref = conn)[prop].apply(_ref, arguments);
        };
      }

      function createProxyAccessor(prop) {
        return function () {
          var conn = cli.getCurrentConnection();
          return conn[prop];
        };
      }

      var conn = cli.getCurrentConnection(); // list all props in connection instance, other than EventEmitter or object built-in methods

      var props = {};
      var o = conn;

      while (o && o !== EventEmitter.prototype && o !== Object.prototype) {
        var _iterator = _createForOfIteratorHelper(_Object$getOwnPropertyNames(o)),
            _step;

        try {
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            var p = _step.value;

            if (p !== 'constructor') {
              props[p] = true;
            }
          }
        } catch (err) {
          _iterator.e(err);
        } finally {
          _iterator.f();
        }

        o = _Object$getPrototypeOf(o);
      }

      for (var _i = 0, _Object$keys = _Object$keys2(props); _i < _Object$keys.length; _i++) {
        var _prop = _Object$keys[_i];

        if (typeof global[_prop] !== 'undefined') {
          // avoid global override
          continue;
        }

        if (_indexOfInstanceProperty(_prop).call(_prop, '_') === 0) {
          // ignore private
          continue;
        }

        if (isFunction(conn[_prop])) {
          context[_prop] = createProxyFunc(_prop);
        } else if (isObject(conn[_prop])) {
          defineProp(context, _prop, createProxyAccessor(_prop));
        }
      } // expose default connection as "$conn"


      defineProp(context, '$conn', function () {
        return cli.getCurrentConnection();
      });
    }
  }]);

  return Repl;
}();
export default Repl;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9jbGkvcmVwbC50cyJdLCJuYW1lcyI6WyJFdmVudEVtaXR0ZXIiLCJzdGFydCIsInN0YXJ0UmVwbCIsIlRyYW5zZm9ybSIsImpzZm9yY2UiLCJpc1Byb21pc2VMaWtlIiwiaXNOdW1iZXIiLCJpc0Z1bmN0aW9uIiwiaXNPYmplY3QiLCJpbmplY3RCZWZvcmUiLCJyZXBsU2VydmVyIiwibWV0aG9kIiwiYmVmb3JlRm4iLCJfb3JpZyIsImFyZ3MiLCJjYWxsYmFjayIsInBvcCIsImFwcGx5IiwiZXJyIiwicmVzIiwiaW5qZWN0QWZ0ZXIiLCJhZnRlckZuIiwiZSIsInByb21pc2lmeSIsInZhbHVlIiwidGhlbiIsInYiLCJvdXRwdXRUb1N0ZG91dCIsInByZXR0eVByaW50IiwiY29uc29sZSIsImVycm9yIiwic3RyIiwibG9nIiwiZGVmaW5lUHJvcCIsIm9iaiIsInByb3AiLCJnZXR0ZXIiLCJnZXQiLCJSZXBsIiwiY2xpIiwidW5kZWZpbmVkIiwiX2NsaSIsIl9pbiIsIl9vdXQiLCJfdHJhbnNmb3JtIiwiY2h1bmsiLCJlbmNvZGluZyIsIl9wYXVzZWQiLCJwdXNoIiwiX2ludGVyYWN0aXZlIiwib3B0aW9ucyIsImludGVyYWN0aXZlIiwicHJvY2VzcyIsInN0ZGluIiwicmVzdW1lIiwic2V0UmF3TW9kZSIsInBpcGUiLCJzdGRvdXQiLCJjb2x1bW5zIiwiX3JlcGxTZXJ2ZXIiLCJpbnB1dCIsIm91dHB1dCIsInRlcm1pbmFsIiwiX2RlZmluZUFkZGl0aW9uYWxDb21tYW5kcyIsImxpbmUiLCJjb21wbGV0ZSIsInJldHMiLCJjYXRjaCIsImV4aXQiLCJvbiIsIl9kZWZpbmVCdWlsdGluVmFycyIsImNvbnRleHQiLCJldmFsU2NyaXB0Iiwid3JpdGUiLCJkZWZpbmVDb21tYW5kIiwiaGVscCIsImFjdGlvbiIsImxpc3RDb25uZWN0aW9ucyIsImRpc3BsYXlQcm9tcHQiLCJuYW1lIiwicGFzc3dvcmQiLCJwYXJhbXMiLCJjb25uZWN0aW9uIiwidXNlcm5hbWUiLCJjb25uZWN0IiwiRXJyb3IiLCJtZXNzYWdlIiwiZGlzY29ubmVjdCIsImxvZ2luU2VydmVyIiwic2V0TG9naW5TZXJ2ZXIiLCJjbGllbnROYW1lIiwiYXV0aG9yaXplIiwiY2xpZW50SWQiLCJjbGllbnRTZWNyZXQiLCJyZWRpcmVjdFVyaSIsImxvZ2luVXJsIiwiY29uZmlnIiwicmVnaXN0ZXIiLCJ1cmwiLCJvcGVuVXJsVXNpbmdTZXNzaW9uIiwidG9rZW5zIiwicmVwbGFjZSIsInNwbGl0IiwiY29tbWFuZCIsImtleXdvcmQiLCJsZW5ndGgiLCJjYW5kaWRhdGVzIiwiZ2V0Q29ubmVjdGlvbk5hbWVzIiwiZ2V0Q2xpZW50TmFtZXMiLCJrZXkiLCJPYmplY3QiLCJwcm90b3R5cGUiLCJoYXNPd25Qcm9wZXJ0eSIsImNhbGwiLCJnbG9iYWwiLCJjcmVhdGVQcm94eUZ1bmMiLCJjb25uIiwiZ2V0Q3VycmVudENvbm5lY3Rpb24iLCJjcmVhdGVQcm94eUFjY2Vzc29yIiwicHJvcHMiLCJvIiwicCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTQSxZQUFULFFBQTZCLFFBQTdCO0FBQ0EsU0FBcUJDLEtBQUssSUFBSUMsU0FBOUIsUUFBK0MsTUFBL0M7QUFDQSxTQUFTQyxTQUFULFFBQTBCLFFBQTFCO0FBQ0EsT0FBT0MsT0FBUCxNQUFvQixJQUFwQjtBQUNBLFNBQ0VDLGFBREYsRUFFRUMsUUFGRixFQUdFQyxVQUhGLEVBSUVDLFFBSkYsUUFLTyxrQkFMUDs7QUFRQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVNDLFlBQVQsQ0FDRUMsVUFERixFQUVFQyxNQUZGLEVBR0VDLFFBSEYsRUFJRTtBQUNBLE1BQU1DLEtBQWUsR0FBSUgsVUFBRCxDQUFvQkMsTUFBcEIsQ0FBeEI7O0FBQ0NELEVBQUFBLFVBQUQsQ0FBb0JDLE1BQXBCLElBQThCLFlBQW9CO0FBQUEsc0NBQWhCRyxJQUFnQjtBQUFoQkEsTUFBQUEsSUFBZ0I7QUFBQTs7QUFDaEQsUUFBTUMsUUFBUSxHQUFHRCxJQUFJLENBQUNFLEdBQUwsRUFBakI7QUFDQUosSUFBQUEsUUFBUSxDQUFDSyxLQUFULENBQ0UsSUFERixFQUVFLHdCQUFBSCxJQUFJLE1BQUosQ0FBQUEsSUFBSSxFQUFRLFVBQUNJLEdBQUQsRUFBV0MsR0FBWCxFQUF3QjtBQUNsQyxVQUFJRCxHQUFHLElBQUlDLEdBQVgsRUFBZ0I7QUFDZEosUUFBQUEsUUFBUSxDQUFDRyxHQUFELEVBQU1DLEdBQU4sQ0FBUjtBQUNELE9BRkQsTUFFTztBQUNMTixRQUFBQSxLQUFLLENBQUNJLEtBQU4sQ0FBWVAsVUFBWixFQUF3Qix3QkFBQUksSUFBSSxNQUFKLENBQUFBLElBQUksRUFBUUMsUUFBUixDQUE1QjtBQUNEO0FBQ0YsS0FORyxDQUZOO0FBVUQsR0FaRDs7QUFhQSxTQUFPTCxVQUFQO0FBQ0Q7QUFFRDtBQUNBO0FBQ0E7OztBQUNBLFNBQVNVLFdBQVQsQ0FDRVYsVUFERixFQUVFQyxNQUZGLEVBR0VVLE9BSEYsRUFJRTtBQUNBLE1BQU1SLEtBQWUsR0FBSUgsVUFBRCxDQUFvQkMsTUFBcEIsQ0FBeEI7O0FBQ0NELEVBQUFBLFVBQUQsQ0FBb0JDLE1BQXBCLElBQThCLFlBQW9CO0FBQUEsdUNBQWhCRyxJQUFnQjtBQUFoQkEsTUFBQUEsSUFBZ0I7QUFBQTs7QUFDaEQsUUFBTUMsUUFBUSxHQUFHRCxJQUFJLENBQUNFLEdBQUwsRUFBakI7O0FBQ0FILElBQUFBLEtBQUssQ0FBQ0ksS0FBTixDQUNFUCxVQURGLEVBRUUsd0JBQUFJLElBQUksTUFBSixDQUFBQSxJQUFJLEVBQVEsWUFBb0I7QUFDOUIsVUFBSTtBQUFBLDJDQURVQSxJQUNWO0FBRFVBLFVBQUFBLElBQ1Y7QUFBQTs7QUFDRk8sUUFBQUEsT0FBTyxDQUFDSixLQUFSLENBQWMsSUFBZCxFQUFvQix3QkFBQUgsSUFBSSxNQUFKLENBQUFBLElBQUksRUFBUUMsUUFBUixDQUF4QjtBQUNELE9BRkQsQ0FFRSxPQUFPTyxDQUFQLEVBQVU7QUFDVlAsUUFBQUEsUUFBUSxDQUFDTyxDQUFELENBQVI7QUFDRDtBQUNGLEtBTkcsQ0FGTjtBQVVELEdBWkQ7O0FBYUEsU0FBT1osVUFBUDtBQUNEO0FBRUQ7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLFNBQVNhLFNBQVQsQ0FDRUwsR0FERixFQUVFTSxLQUZGLEVBR0VULFFBSEYsRUFJRTtBQUNBO0FBQ0EsTUFBSSxDQUFDQSxRQUFELElBQWFSLFVBQVUsQ0FBQ2lCLEtBQUQsQ0FBM0IsRUFBb0M7QUFDbENULElBQUFBLFFBQVEsR0FBR1MsS0FBWDtBQUNBLFdBQU9ULFFBQVEsRUFBZjtBQUNEOztBQUNELE1BQUlHLEdBQUosRUFBUztBQUNQLFVBQU1BLEdBQU47QUFDRDs7QUFDRCxNQUFJYixhQUFhLENBQUNtQixLQUFELENBQWpCLEVBQTBCO0FBQ3hCQSxJQUFBQSxLQUFLLENBQUNDLElBQU4sQ0FDRSxVQUFDQyxDQUFELEVBQVk7QUFDVlgsTUFBQUEsUUFBUSxDQUFDLElBQUQsRUFBT1csQ0FBUCxDQUFSO0FBQ0QsS0FISCxFQUlFLFVBQUNSLEdBQUQsRUFBYztBQUNaSCxNQUFBQSxRQUFRLENBQUNHLEdBQUQsQ0FBUjtBQUNELEtBTkg7QUFRRCxHQVRELE1BU087QUFDTEgsSUFBQUEsUUFBUSxDQUFDLElBQUQsRUFBT1MsS0FBUCxDQUFSO0FBQ0Q7QUFDRjtBQUVEO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxTQUFTRyxjQUFULENBQXdCQyxXQUF4QixFQUF1RDtBQUNyRCxNQUFJQSxXQUFXLElBQUksQ0FBQ3RCLFFBQVEsQ0FBQ3NCLFdBQUQsQ0FBNUIsRUFBMkM7QUFDekNBLElBQUFBLFdBQVcsR0FBRyxDQUFkO0FBQ0Q7O0FBQ0QsU0FBTyxVQUFDVixHQUFELEVBQVdNLEtBQVgsRUFBdUJULFFBQXZCLEVBQThDO0FBQ25ELFFBQUlHLEdBQUosRUFBUztBQUNQVyxNQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBY1osR0FBZDtBQUNELEtBRkQsTUFFTztBQUNMLFVBQU1hLEdBQUcsR0FBRyxnQkFBZVAsS0FBZixFQUFzQixJQUF0QixFQUE0QkksV0FBNUIsQ0FBWjs7QUFDQUMsTUFBQUEsT0FBTyxDQUFDRyxHQUFSLENBQVlELEdBQVo7QUFDRDs7QUFDRGhCLElBQUFBLFFBQVEsQ0FBQ0csR0FBRCxFQUFNTSxLQUFOLENBQVI7QUFDRCxHQVJEO0FBU0Q7QUFFRDtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsU0FBU1MsVUFBVCxDQUFvQkMsR0FBcEIsRUFBaUNDLElBQWpDLEVBQStDQyxNQUEvQyxFQUFrRTtBQUNoRSw4QkFBMkI7QUFDekIsMkJBQXNCRixHQUF0QixFQUEyQkMsSUFBM0IsRUFBaUM7QUFBRUUsTUFBQUEsR0FBRyxFQUFFRDtBQUFQLEtBQWpDO0FBQ0Q7QUFDRjtBQUVEO0FBQ0E7QUFDQTs7O0FBQ0EsV0FBYUUsSUFBYjtBQVFFLGdCQUFZQyxHQUFaLEVBQXNCO0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUEsMENBSkUsSUFJRjs7QUFBQSxxQ0FISCxLQUdHOztBQUFBLHlDQUZnQkMsU0FFaEI7O0FBQ3BCLFNBQUtDLElBQUwsR0FBWUYsR0FBWjtBQUNBLFNBQUtHLEdBQUwsR0FBVyxJQUFJdkMsU0FBSixFQUFYO0FBQ0EsU0FBS3dDLElBQUwsR0FBWSxJQUFJeEMsU0FBSixFQUFaOztBQUNBLFNBQUt1QyxHQUFMLENBQVNFLFVBQVQsR0FBc0IsVUFBQ0MsS0FBRCxFQUFRQyxRQUFSLEVBQWtCL0IsUUFBbEIsRUFBK0I7QUFDbkQsVUFBSSxDQUFDLEtBQUksQ0FBQ2dDLE9BQVYsRUFBbUI7QUFDakIsUUFBQSxLQUFJLENBQUNMLEdBQUwsQ0FBU00sSUFBVCxDQUFjSCxLQUFkO0FBQ0Q7O0FBQ0Q5QixNQUFBQSxRQUFRO0FBQ1QsS0FMRDs7QUFNQSxTQUFLNEIsSUFBTCxDQUFVQyxVQUFWLEdBQXVCLFVBQUNDLEtBQUQsRUFBUUMsUUFBUixFQUFrQi9CLFFBQWxCLEVBQStCO0FBQ3BELFVBQUksQ0FBQyxLQUFJLENBQUNnQyxPQUFOLElBQWlCLEtBQUksQ0FBQ0UsWUFBTCxLQUFzQixLQUEzQyxFQUFrRDtBQUNoRCxRQUFBLEtBQUksQ0FBQ04sSUFBTCxDQUFVSyxJQUFWLENBQWVILEtBQWY7QUFDRDs7QUFDRDlCLE1BQUFBLFFBQVE7QUFDVCxLQUxEO0FBTUQ7QUFFRDtBQUNGO0FBQ0E7OztBQTVCQTtBQUFBO0FBQUEsNEJBbUNJO0FBQUE7O0FBQUEsVUFMQW1DLE9BS0EsdUVBREksRUFDSjtBQUNBLFdBQUtELFlBQUwsR0FBb0JDLE9BQU8sQ0FBQ0MsV0FBUixLQUF3QixLQUE1QztBQUVBQyxNQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBY0MsTUFBZDs7QUFDQSxVQUFJRixPQUFPLENBQUNDLEtBQVIsQ0FBY0UsVUFBbEIsRUFBOEI7QUFDNUJILFFBQUFBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjRSxVQUFkLENBQXlCLElBQXpCO0FBQ0Q7O0FBQ0RILE1BQUFBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjRyxJQUFkLENBQW1CLEtBQUtkLEdBQXhCOztBQUVBLFdBQUtDLElBQUwsQ0FBVWEsSUFBVixDQUFlSixPQUFPLENBQUNLLE1BQXZCOztBQUVBeEIsTUFBQUEsVUFBVSxDQUFDLEtBQUtVLElBQU4sRUFBWSxTQUFaLEVBQXVCO0FBQUEsZUFBTVMsT0FBTyxDQUFDSyxNQUFSLENBQWVDLE9BQXJCO0FBQUEsT0FBdkIsQ0FBVjtBQUVBLFdBQUtDLFdBQUwsR0FBbUJ6RCxTQUFTLENBQUM7QUFDM0IwRCxRQUFBQSxLQUFLLEVBQUUsS0FBS2xCLEdBRGU7QUFFM0JtQixRQUFBQSxNQUFNLEVBQUUsS0FBS2xCLElBRmM7QUFHM0JtQixRQUFBQSxRQUFRLEVBQUU7QUFIaUIsT0FBRCxDQUE1Qjs7QUFNQSxXQUFLQyx5QkFBTDs7QUFFQSxXQUFLSixXQUFMLEdBQW1CbEQsWUFBWSxDQUM3QixLQUFLa0QsV0FEd0IsRUFFN0IsV0FGNkIsRUFHN0IsVUFBQ0ssSUFBRCxFQUFlakQsUUFBZixFQUFzQztBQUNwQyxRQUFBLE1BQUksQ0FBQ2tELFFBQUwsQ0FBY0QsSUFBZCxFQUNHdkMsSUFESCxDQUNRLFVBQUN5QyxJQUFELEVBQVU7QUFDZG5ELFVBQUFBLFFBQVEsQ0FBQyxJQUFELEVBQU9tRCxJQUFQLENBQVI7QUFDRCxTQUhILEVBSUdDLEtBSkgsQ0FJUyxVQUFDakQsR0FBRCxFQUFTO0FBQ2RILFVBQUFBLFFBQVEsQ0FBQ0csR0FBRCxDQUFSO0FBQ0QsU0FOSDtBQU9ELE9BWDRCLENBQS9CO0FBYUEsV0FBS3lDLFdBQUwsR0FBbUJ2QyxXQUFXLENBQUMsS0FBS3VDLFdBQU4sRUFBbUIsTUFBbkIsRUFBMkJwQyxTQUEzQixDQUE5Qjs7QUFFQSxVQUFJMkIsT0FBTyxDQUFDQyxXQUFSLEtBQXdCLEtBQTVCLEVBQW1DO0FBQ2pDLGFBQUtRLFdBQUwsR0FBbUJ2QyxXQUFXLENBQzVCLEtBQUt1QyxXQUR1QixFQUU1QixNQUY0QixFQUc1QmhDLGNBQWMsQ0FBQ3VCLE9BQU8sQ0FBQ3RCLFdBQVQsQ0FIYyxDQUE5QjtBQUtBLGFBQUsrQixXQUFMLEdBQW1CdkMsV0FBVyxDQUFDLEtBQUt1QyxXQUFOLEVBQW1CLE1BQW5CLEVBQTJCLFlBQVk7QUFDbkVQLFVBQUFBLE9BQU8sQ0FBQ2dCLElBQVI7QUFDRCxTQUY2QixDQUE5QjtBQUdEOztBQUNELFdBQUtULFdBQUwsQ0FBaUJVLEVBQWpCLENBQW9CLE1BQXBCLEVBQTRCO0FBQUEsZUFBTWpCLE9BQU8sQ0FBQ2dCLElBQVIsRUFBTjtBQUFBLE9BQTVCOztBQUVBLFdBQUtFLGtCQUFMLENBQXdCLEtBQUtYLFdBQUwsQ0FBaUJZLE9BQXpDOztBQUVBLFVBQUlyQixPQUFPLENBQUNzQixVQUFaLEVBQXdCO0FBQ3RCLGFBQUs5QixHQUFMLENBQVMrQixLQUFULENBQWV2QixPQUFPLENBQUNzQixVQUFSLEdBQXFCLElBQXBDLEVBQTBDLE9BQTFDO0FBQ0Q7O0FBRUQsYUFBTyxJQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBOUZBO0FBQUE7QUFBQSxnREErRjhCO0FBQzFCLFVBQU1qQyxHQUFHLEdBQUcsS0FBS0UsSUFBakI7QUFDQSxVQUFNL0IsVUFBVSxHQUFHLEtBQUtpRCxXQUF4Qjs7QUFDQSxVQUFJLENBQUNqRCxVQUFMLEVBQWlCO0FBQ2Y7QUFDRDs7QUFDREEsTUFBQUEsVUFBVSxDQUFDZ0UsYUFBWCxDQUF5QixhQUF6QixFQUF3QztBQUN0Q0MsUUFBQUEsSUFBSSxFQUFFLGlEQURnQztBQUV0Q0MsUUFBQUEsTUFBTTtBQUFBLGlGQUFFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUNBckMsR0FBRyxDQUFDc0MsZUFBSixFQURBOztBQUFBO0FBRU5uRSxvQkFBQUEsVUFBVSxDQUFDb0UsYUFBWDs7QUFGTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFGOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBRmdDLE9BQXhDO0FBT0FwRSxNQUFBQSxVQUFVLENBQUNnRSxhQUFYLENBQXlCLFNBQXpCLEVBQW9DO0FBQ2xDQyxRQUFBQSxJQUFJLEVBQUUsZ0NBRDRCO0FBRWxDQyxRQUFBQSxNQUFNO0FBQUEsa0ZBQUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdEQUFVOUQsSUFBVjtBQUFVQSxzQkFBQUEsSUFBVjtBQUFBOztBQUNDaUUsb0JBQUFBLElBREQsR0FDbUJqRSxJQURuQixLQUNPa0UsUUFEUCxHQUNtQmxFLElBRG5CO0FBRUFtRSxvQkFBQUEsTUFGQSxHQUVTRCxRQUFRLEdBQ25CO0FBQUVFLHNCQUFBQSxVQUFVLEVBQUVILElBQWQ7QUFBb0JJLHNCQUFBQSxRQUFRLEVBQUVKLElBQTlCO0FBQW9DQyxzQkFBQUEsUUFBUSxFQUFFQTtBQUE5QyxxQkFEbUIsR0FFbkI7QUFBRUUsc0JBQUFBLFVBQVUsRUFBRUgsSUFBZDtBQUFvQkksc0JBQUFBLFFBQVEsRUFBRUo7QUFBOUIscUJBSkU7QUFBQTtBQUFBO0FBQUEsMkJBTUV4QyxHQUFHLENBQUM2QyxPQUFKLENBQVlILE1BQVosQ0FORjs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQVFKLHdCQUFJLHdCQUFlSSxLQUFuQixFQUEwQjtBQUN4QnhELHNCQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYyxhQUFJd0QsT0FBbEI7QUFDRDs7QUFWRztBQVlONUUsb0JBQUFBLFVBQVUsQ0FBQ29FLGFBQVg7O0FBWk07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBRjs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUY0QixPQUFwQztBQWlCQXBFLE1BQUFBLFVBQVUsQ0FBQ2dFLGFBQVgsQ0FBeUIsWUFBekIsRUFBdUM7QUFDckNDLFFBQUFBLElBQUksRUFBRSxrREFEK0I7QUFFckNDLFFBQUFBLE1BQU0sRUFBRSxnQkFBQ0csSUFBRCxFQUFVO0FBQ2hCeEMsVUFBQUEsR0FBRyxDQUFDZ0QsVUFBSixDQUFlUixJQUFmO0FBQ0FyRSxVQUFBQSxVQUFVLENBQUNvRSxhQUFYO0FBQ0Q7QUFMb0MsT0FBdkM7QUFPQXBFLE1BQUFBLFVBQVUsQ0FBQ2dFLGFBQVgsQ0FBeUIsS0FBekIsRUFBZ0M7QUFDOUJDLFFBQUFBLElBQUksRUFBRSw4Q0FEd0I7QUFFOUJDLFFBQUFBLE1BQU0sRUFBRSxnQkFBQ1ksV0FBRCxFQUFpQjtBQUN2QmpELFVBQUFBLEdBQUcsQ0FBQ2tELGNBQUosQ0FBbUJELFdBQW5CO0FBQ0E5RSxVQUFBQSxVQUFVLENBQUNvRSxhQUFYO0FBQ0Q7QUFMNkIsT0FBaEM7QUFPQXBFLE1BQUFBLFVBQVUsQ0FBQ2dFLGFBQVgsQ0FBeUIsV0FBekIsRUFBc0M7QUFDcENDLFFBQUFBLElBQUksRUFBRSx1REFEOEI7QUFFcENDLFFBQUFBLE1BQU07QUFBQSxrRkFBRSxrQkFBT2MsVUFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVFbkQsR0FBRyxDQUFDb0QsU0FBSixDQUFjRCxVQUFkLENBRkY7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFJSix3QkFBSSx3QkFBZUwsS0FBbkIsRUFBMEI7QUFDeEJ4RCxzQkFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWMsYUFBSXdELE9BQWxCO0FBQ0Q7O0FBTkc7QUFRTjVFLG9CQUFBQSxVQUFVLENBQUNvRSxhQUFYOztBQVJNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUY7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFGOEIsT0FBdEM7QUFhQXBFLE1BQUFBLFVBQVUsQ0FBQ2dFLGFBQVgsQ0FBeUIsVUFBekIsRUFBcUM7QUFDbkNDLFFBQUFBLElBQUksRUFBRSxvQ0FENkI7QUFFbkNDLFFBQUFBLE1BQU07QUFBQSxrRkFBRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0RBQVU5RCxJQUFWO0FBQVVBLHNCQUFBQSxJQUFWO0FBQUE7O0FBRUo0RSxvQkFBQUEsVUFGSSxHQU9GNUUsSUFQRSxLQUdKOEUsUUFISSxHQU9GOUUsSUFQRSxLQUlKK0UsWUFKSSxHQU9GL0UsSUFQRSxLQUtKZ0YsV0FMSSxHQU9GaEYsSUFQRSxLQU1KaUYsUUFOSSxHQU9GakYsSUFQRTtBQVFBa0Ysb0JBQUFBLE1BUkEsR0FRUztBQUFFSixzQkFBQUEsUUFBUSxFQUFSQSxRQUFGO0FBQVlDLHNCQUFBQSxZQUFZLEVBQVpBLFlBQVo7QUFBMEJDLHNCQUFBQSxXQUFXLEVBQVhBLFdBQTFCO0FBQXVDQyxzQkFBQUEsUUFBUSxFQUFSQTtBQUF2QyxxQkFSVDtBQUFBO0FBQUE7QUFBQSwyQkFVRXhELEdBQUcsQ0FBQzBELFFBQUosQ0FBYVAsVUFBYixFQUF5Qk0sTUFBekIsQ0FWRjs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQVlKLHdCQUFJLHdCQUFlWCxLQUFuQixFQUEwQjtBQUN4QnhELHNCQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBYyxhQUFJd0QsT0FBbEI7QUFDRDs7QUFkRztBQWdCTjVFLG9CQUFBQSxVQUFVLENBQUNvRSxhQUFYOztBQWhCTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFGOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBRjZCLE9BQXJDO0FBcUJBcEUsTUFBQUEsVUFBVSxDQUFDZ0UsYUFBWCxDQUF5QixNQUF6QixFQUFpQztBQUMvQkMsUUFBQUEsSUFBSSxFQUFFLHVEQUR5QjtBQUUvQkMsUUFBQUEsTUFBTSxFQUFFLGdCQUFDc0IsR0FBRCxFQUFTO0FBQ2YzRCxVQUFBQSxHQUFHLENBQUM0RCxtQkFBSixDQUF3QkQsR0FBeEI7QUFDQXhGLFVBQUFBLFVBQVUsQ0FBQ29FLGFBQVg7QUFDRDtBQUw4QixPQUFqQztBQU9EO0FBRUQ7QUFDRjtBQUNBOztBQXhMQTtBQUFBO0FBQUEsNEJBeUxVO0FBQ04sV0FBSy9CLE9BQUwsR0FBZSxJQUFmOztBQUNBLFVBQUlLLE9BQU8sQ0FBQ0MsS0FBUixDQUFjRSxVQUFsQixFQUE4QjtBQUM1QkgsUUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWNFLFVBQWQsQ0FBeUIsS0FBekI7QUFDRDtBQUNGO0FBRUQ7QUFDRjtBQUNBOztBQWxNQTtBQUFBO0FBQUEsNkJBbU1XO0FBQ1AsV0FBS1IsT0FBTCxHQUFlLEtBQWY7QUFDQUssTUFBQUEsT0FBTyxDQUFDQyxLQUFSLENBQWNDLE1BQWQ7O0FBQ0EsVUFBSUYsT0FBTyxDQUFDQyxLQUFSLENBQWNFLFVBQWxCLEVBQThCO0FBQzVCSCxRQUFBQSxPQUFPLENBQUNDLEtBQVIsQ0FBY0UsVUFBZCxDQUF5QixJQUF6QjtBQUNEO0FBQ0Y7QUFFRDtBQUNGO0FBQ0E7O0FBN01BO0FBQUE7QUFBQTtBQUFBLGlHQThNaUJTLElBOU1qQjtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBK01Vb0MsZ0JBQUFBLE1BL01WLEdBK01tQnBDLElBQUksQ0FBQ3FDLE9BQUwsQ0FBYSxNQUFiLEVBQXFCLEVBQXJCLEVBQXlCQyxLQUF6QixDQUErQixLQUEvQixDQS9NbkI7QUFBQSx5Q0FnTm9DRixNQWhOcEMsTUFnTldHLE9BaE5YLHNDQWdOb0JDLE9BaE5wQix5QkFnTjhCLEVBaE45Qjs7QUFBQSxzQkFpTlFELE9BQU8sQ0FBQyxDQUFELENBQVAsS0FBZSxHQUFmLElBQXNCSCxNQUFNLENBQUNLLE1BQVAsS0FBa0IsQ0FqTmhEO0FBQUE7QUFBQTtBQUFBOztBQWtOVUMsZ0JBQUFBLFVBbE5WLEdBa05pQyxFQWxOakM7O0FBQUEsc0JBbU5VSCxPQUFPLEtBQUssVUFBWixJQUEwQkEsT0FBTyxLQUFLLGFBbk5oRDtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHVCQW9OMkIsS0FBSzlELElBQUwsQ0FBVWtFLGtCQUFWLEVBcE4zQjs7QUFBQTtBQW9OUUQsZ0JBQUFBLFVBcE5SO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHNCQXFOaUJILE9BQU8sS0FBSyxZQXJON0I7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSx1QkFzTjJCLEtBQUs5RCxJQUFMLENBQVVtRSxjQUFWLEVBdE4zQjs7QUFBQTtBQXNOUUYsZ0JBQUFBLFVBdE5SO0FBQUE7QUFBQTs7QUFBQTtBQXVOYSxvQkFBSUgsT0FBTyxLQUFLLE1BQWhCLEVBQXdCO0FBQzdCRyxrQkFBQUEsVUFBVSxHQUFHLENBQUMsWUFBRCxFQUFlLFNBQWYsQ0FBYjtBQUNEOztBQXpOUDtBQTBOTUEsZ0JBQUFBLFVBQVUsR0FBRyx3QkFBQUEsVUFBVSxNQUFWLENBQUFBLFVBQVUsRUFBUSxVQUFDM0IsSUFBRDtBQUFBLHlCQUFVLHlCQUFBQSxJQUFJLE1BQUosQ0FBQUEsSUFBSSxFQUFTeUIsT0FBVCxDQUFKLEtBQTBCLENBQXBDO0FBQUEsaUJBQVIsQ0FBdkI7QUExTk4sa0RBMk5hLENBQUNFLFVBQUQsRUFBYUYsT0FBYixDQTNOYjs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQStORTtBQUNGO0FBQ0E7QUFDQTs7QUFsT0E7QUFBQTtBQUFBLHVDQW1PcUJqQyxPQW5PckIsRUFtTzBEO0FBQ3RELFVBQU1oQyxHQUFHLEdBQUcsS0FBS0UsSUFBakIsQ0FEc0QsQ0FHdEQ7O0FBQ0EsV0FBSyxJQUFNb0UsR0FBWCxJQUFrQnpHLE9BQWxCLEVBQTJCO0FBQ3pCLFlBQ0UwRyxNQUFNLENBQUNDLFNBQVAsQ0FBaUJDLGNBQWpCLENBQWdDQyxJQUFoQyxDQUFxQzdHLE9BQXJDLEVBQThDeUcsR0FBOUMsS0FDQSxDQUFFSyxNQUFELENBQWdCTCxHQUFoQixDQUZILEVBR0U7QUFDQXRDLFVBQUFBLE9BQU8sQ0FBQ3NDLEdBQUQsQ0FBUCxHQUFnQnpHLE9BQUQsQ0FBaUJ5RyxHQUFqQixDQUFmO0FBQ0Q7QUFDRixPQVhxRCxDQVl0RDs7O0FBQ0F0QyxNQUFBQSxPQUFPLENBQUNuRSxPQUFSLEdBQWtCQSxPQUFsQjs7QUFFQSxlQUFTK0csZUFBVCxDQUF5QmhGLElBQXpCLEVBQXVDO0FBQ3JDLGVBQU8sWUFBb0I7QUFBQTs7QUFDekIsY0FBTWlGLElBQUksR0FBRzdFLEdBQUcsQ0FBQzhFLG9CQUFKLEVBQWI7QUFDQSxpQkFBTyxRQUFDRCxJQUFELEVBQWNqRixJQUFkLHdCQUFQO0FBQ0QsU0FIRDtBQUlEOztBQUVELGVBQVNtRixtQkFBVCxDQUE2Qm5GLElBQTdCLEVBQTJDO0FBQ3pDLGVBQU8sWUFBTTtBQUNYLGNBQU1pRixJQUFJLEdBQUc3RSxHQUFHLENBQUM4RSxvQkFBSixFQUFiO0FBQ0EsaUJBQVFELElBQUQsQ0FBY2pGLElBQWQsQ0FBUDtBQUNELFNBSEQ7QUFJRDs7QUFFRCxVQUFNaUYsSUFBSSxHQUFHN0UsR0FBRyxDQUFDOEUsb0JBQUosRUFBYixDQTdCc0QsQ0E4QnREOztBQUNBLFVBQU1FLEtBQWtDLEdBQUcsRUFBM0M7QUFDQSxVQUFJQyxDQUFTLEdBQUdKLElBQWhCOztBQUNBLGFBQU9JLENBQUMsSUFBSUEsQ0FBQyxLQUFLeEgsWUFBWSxDQUFDK0csU0FBeEIsSUFBcUNTLENBQUMsS0FBS1YsTUFBTSxDQUFDQyxTQUF6RCxFQUFvRTtBQUFBLG1EQUNsRCw0QkFBMkJTLENBQTNCLENBRGtEO0FBQUE7O0FBQUE7QUFDbEUsOERBQStDO0FBQUEsZ0JBQXBDQyxDQUFvQzs7QUFDN0MsZ0JBQUlBLENBQUMsS0FBSyxhQUFWLEVBQXlCO0FBQ3ZCRixjQUFBQSxLQUFLLENBQUNFLENBQUQsQ0FBTCxHQUFXLElBQVg7QUFDRDtBQUNGO0FBTGlFO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBTWxFRCxRQUFBQSxDQUFDLEdBQUcsdUJBQXNCQSxDQUF0QixDQUFKO0FBQ0Q7O0FBQ0Qsc0NBQW1CLGNBQVlELEtBQVosQ0FBbkIsa0NBQXVDO0FBQWxDLFlBQU1wRixLQUFJLG1CQUFWOztBQUNILFlBQUksT0FBUStFLE1BQUQsQ0FBZ0IvRSxLQUFoQixDQUFQLEtBQWlDLFdBQXJDLEVBQWtEO0FBQ2hEO0FBQ0E7QUFDRDs7QUFDRCxZQUFJLHlCQUFBQSxLQUFJLE1BQUosQ0FBQUEsS0FBSSxFQUFTLEdBQVQsQ0FBSixLQUFzQixDQUExQixFQUE2QjtBQUMzQjtBQUNBO0FBQ0Q7O0FBQ0QsWUFBSTVCLFVBQVUsQ0FBRTZHLElBQUQsQ0FBY2pGLEtBQWQsQ0FBRCxDQUFkLEVBQXFDO0FBQ25Db0MsVUFBQUEsT0FBTyxDQUFDcEMsS0FBRCxDQUFQLEdBQWdCZ0YsZUFBZSxDQUFDaEYsS0FBRCxDQUEvQjtBQUNELFNBRkQsTUFFTyxJQUFJM0IsUUFBUSxDQUFFNEcsSUFBRCxDQUFjakYsS0FBZCxDQUFELENBQVosRUFBbUM7QUFDeENGLFVBQUFBLFVBQVUsQ0FBQ3NDLE9BQUQsRUFBVXBDLEtBQVYsRUFBZ0JtRixtQkFBbUIsQ0FBQ25GLEtBQUQsQ0FBbkMsQ0FBVjtBQUNEO0FBQ0YsT0F2RHFELENBeUR0RDs7O0FBQ0FGLE1BQUFBLFVBQVUsQ0FBQ3NDLE9BQUQsRUFBVSxPQUFWLEVBQW1CLFlBQU07QUFDakMsZUFBT2hDLEdBQUcsQ0FBQzhFLG9CQUFKLEVBQVA7QUFDRCxPQUZTLENBQVY7QUFHRDtBQWhTSDs7QUFBQTtBQUFBO0FBbVNBLGVBQWUvRSxJQUFmIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAZmlsZSBDcmVhdGVzIFJFUEwgaW50ZXJmYWNlIHdpdGggYnVpbHQgaW4gU2FsZXNmb3JjZSBBUEkgb2JqZWN0cyBhbmQgYXV0b21hdGljYWxseSByZXNvbHZlcyBwcm9taXNlIG9iamVjdFxuICogQGF1dGhvciBTaGluaWNoaSBUb21pdGEgPHNoaW5pY2hpLnRvbWl0YUBnbWFpbC5jb20+XG4gKiBAcHJpdmF0ZVxuICovXG5pbXBvcnQgeyBFdmVudEVtaXR0ZXIgfSBmcm9tICdldmVudHMnO1xuaW1wb3J0IHsgUkVQTFNlcnZlciwgc3RhcnQgYXMgc3RhcnRSZXBsIH0gZnJvbSAncmVwbCc7XG5pbXBvcnQgeyBUcmFuc2Zvcm0gfSBmcm9tICdzdHJlYW0nO1xuaW1wb3J0IGpzZm9yY2UgZnJvbSAnLi4nO1xuaW1wb3J0IHtcbiAgaXNQcm9taXNlTGlrZSxcbiAgaXNOdW1iZXIsXG4gIGlzRnVuY3Rpb24sXG4gIGlzT2JqZWN0LFxufSBmcm9tICcuLi91dGlsL2Z1bmN0aW9uJztcbmltcG9ydCB7IENsaSB9IGZyb20gJy4vY2xpJztcblxuLyoqXG4gKiBJbnRlcmNlcHQgdGhlIGV2YWxlZCB2YWx1ZSByZXR1cm5lZCBmcm9tIHJlcGwgZXZhbHVhdG9yLCBjb252ZXJ0IGFuZCBzZW5kIGJhY2sgdG8gb3V0cHV0LlxuICogQHByaXZhdGVcbiAqL1xuZnVuY3Rpb24gaW5qZWN0QmVmb3JlKFxuICByZXBsU2VydmVyOiBSRVBMU2VydmVyLFxuICBtZXRob2Q6IHN0cmluZyxcbiAgYmVmb3JlRm46IEZ1bmN0aW9uLFxuKSB7XG4gIGNvbnN0IF9vcmlnOiBGdW5jdGlvbiA9IChyZXBsU2VydmVyIGFzIGFueSlbbWV0aG9kXTtcbiAgKHJlcGxTZXJ2ZXIgYXMgYW55KVttZXRob2RdID0gKC4uLmFyZ3M6IGFueVtdKSA9PiB7XG4gICAgY29uc3QgY2FsbGJhY2sgPSBhcmdzLnBvcCgpO1xuICAgIGJlZm9yZUZuLmFwcGx5KFxuICAgICAgbnVsbCxcbiAgICAgIGFyZ3MuY29uY2F0KChlcnI6IGFueSwgcmVzOiBhbnkpID0+IHtcbiAgICAgICAgaWYgKGVyciB8fCByZXMpIHtcbiAgICAgICAgICBjYWxsYmFjayhlcnIsIHJlcyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgX29yaWcuYXBwbHkocmVwbFNlcnZlciwgYXJncy5jb25jYXQoY2FsbGJhY2spKTtcbiAgICAgICAgfVxuICAgICAgfSksXG4gICAgKTtcbiAgfTtcbiAgcmV0dXJuIHJlcGxTZXJ2ZXI7XG59XG5cbi8qKlxuICogQHByaXZhdGVcbiAqL1xuZnVuY3Rpb24gaW5qZWN0QWZ0ZXIoXG4gIHJlcGxTZXJ2ZXI6IFJFUExTZXJ2ZXIsXG4gIG1ldGhvZDogc3RyaW5nLFxuICBhZnRlckZuOiBGdW5jdGlvbixcbikge1xuICBjb25zdCBfb3JpZzogRnVuY3Rpb24gPSAocmVwbFNlcnZlciBhcyBhbnkpW21ldGhvZF07XG4gIChyZXBsU2VydmVyIGFzIGFueSlbbWV0aG9kXSA9ICguLi5hcmdzOiBhbnlbXSkgPT4ge1xuICAgIGNvbnN0IGNhbGxiYWNrID0gYXJncy5wb3AoKTtcbiAgICBfb3JpZy5hcHBseShcbiAgICAgIHJlcGxTZXJ2ZXIsXG4gICAgICBhcmdzLmNvbmNhdCgoLi4uYXJnczogYW55W10pID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBhZnRlckZuLmFwcGx5KG51bGwsIGFyZ3MuY29uY2F0KGNhbGxiYWNrKSk7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICBjYWxsYmFjayhlKTtcbiAgICAgICAgfVxuICAgICAgfSksXG4gICAgKTtcbiAgfTtcbiAgcmV0dXJuIHJlcGxTZXJ2ZXI7XG59XG5cbi8qKlxuICogV2hlbiB0aGUgcmVzdWx0IHdhcyBcInByb21pc2VcIiwgcmVzb2x2ZSBpdHMgdmFsdWVcbiAqIEBwcml2YXRlXG4gKi9cbmZ1bmN0aW9uIHByb21pc2lmeShcbiAgZXJyOiBFcnJvciB8IG51bGwgfCB1bmRlZmluZWQsXG4gIHZhbHVlOiBhbnksXG4gIGNhbGxiYWNrOiBGdW5jdGlvbixcbikge1xuICAvLyBjYWxsYmFjayBpbW1lZGlhdGVseSBpZiBubyB2YWx1ZSBwYXNzZWRcbiAgaWYgKCFjYWxsYmFjayAmJiBpc0Z1bmN0aW9uKHZhbHVlKSkge1xuICAgIGNhbGxiYWNrID0gdmFsdWU7XG4gICAgcmV0dXJuIGNhbGxiYWNrKCk7XG4gIH1cbiAgaWYgKGVycikge1xuICAgIHRocm93IGVycjtcbiAgfVxuICBpZiAoaXNQcm9taXNlTGlrZSh2YWx1ZSkpIHtcbiAgICB2YWx1ZS50aGVuKFxuICAgICAgKHY6IGFueSkgPT4ge1xuICAgICAgICBjYWxsYmFjayhudWxsLCB2KTtcbiAgICAgIH0sXG4gICAgICAoZXJyOiBhbnkpID0+IHtcbiAgICAgICAgY2FsbGJhY2soZXJyKTtcbiAgICAgIH0sXG4gICAgKTtcbiAgfSBlbHNlIHtcbiAgICBjYWxsYmFjayhudWxsLCB2YWx1ZSk7XG4gIH1cbn1cblxuLyoqXG4gKiBPdXRwdXQgb2JqZWN0IHRvIHN0ZG91dCBpbiBKU09OIHJlcHJlc2VudGF0aW9uXG4gKiBAcHJpdmF0ZVxuICovXG5mdW5jdGlvbiBvdXRwdXRUb1N0ZG91dChwcmV0dHlQcmludD86IHN0cmluZyB8IG51bWJlcikge1xuICBpZiAocHJldHR5UHJpbnQgJiYgIWlzTnVtYmVyKHByZXR0eVByaW50KSkge1xuICAgIHByZXR0eVByaW50ID0gNDtcbiAgfVxuICByZXR1cm4gKGVycjogYW55LCB2YWx1ZTogYW55LCBjYWxsYmFjazogRnVuY3Rpb24pID0+IHtcbiAgICBpZiAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGVycik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IHN0ciA9IEpTT04uc3RyaW5naWZ5KHZhbHVlLCBudWxsLCBwcmV0dHlQcmludCk7XG4gICAgICBjb25zb2xlLmxvZyhzdHIpO1xuICAgIH1cbiAgICBjYWxsYmFjayhlcnIsIHZhbHVlKTtcbiAgfTtcbn1cblxuLyoqXG4gKiBkZWZpbmUgZ2V0IGFjY2Vzc29yIHVzaW5nIE9iamVjdC5kZWZpbmVQcm9wZXJ0eVxuICogQHByaXZhdGVcbiAqL1xuZnVuY3Rpb24gZGVmaW5lUHJvcChvYmo6IE9iamVjdCwgcHJvcDogc3RyaW5nLCBnZXR0ZXI6ICgpID0+IGFueSkge1xuICBpZiAoT2JqZWN0LmRlZmluZVByb3BlcnR5KSB7XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG9iaiwgcHJvcCwgeyBnZXQ6IGdldHRlciB9KTtcbiAgfVxufVxuXG4vKipcbiAqXG4gKi9cbmV4cG9ydCBjbGFzcyBSZXBsIHtcbiAgX2NsaTogQ2xpO1xuICBfaW46IFRyYW5zZm9ybTtcbiAgX291dDogVHJhbnNmb3JtO1xuICBfaW50ZXJhY3RpdmU6IGJvb2xlYW4gPSB0cnVlO1xuICBfcGF1c2VkOiBib29sZWFuID0gZmFsc2U7XG4gIF9yZXBsU2VydmVyOiBSRVBMU2VydmVyIHwgdW5kZWZpbmVkID0gdW5kZWZpbmVkO1xuXG4gIGNvbnN0cnVjdG9yKGNsaTogQ2xpKSB7XG4gICAgdGhpcy5fY2xpID0gY2xpO1xuICAgIHRoaXMuX2luID0gbmV3IFRyYW5zZm9ybSgpO1xuICAgIHRoaXMuX291dCA9IG5ldyBUcmFuc2Zvcm0oKTtcbiAgICB0aGlzLl9pbi5fdHJhbnNmb3JtID0gKGNodW5rLCBlbmNvZGluZywgY2FsbGJhY2spID0+IHtcbiAgICAgIGlmICghdGhpcy5fcGF1c2VkKSB7XG4gICAgICAgIHRoaXMuX2luLnB1c2goY2h1bmspO1xuICAgICAgfVxuICAgICAgY2FsbGJhY2soKTtcbiAgICB9O1xuICAgIHRoaXMuX291dC5fdHJhbnNmb3JtID0gKGNodW5rLCBlbmNvZGluZywgY2FsbGJhY2spID0+IHtcbiAgICAgIGlmICghdGhpcy5fcGF1c2VkICYmIHRoaXMuX2ludGVyYWN0aXZlICE9PSBmYWxzZSkge1xuICAgICAgICB0aGlzLl9vdXQucHVzaChjaHVuayk7XG4gICAgICB9XG4gICAgICBjYWxsYmFjaygpO1xuICAgIH07XG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIHN0YXJ0KFxuICAgIG9wdGlvbnM6IHtcbiAgICAgIGludGVyYWN0aXZlPzogYm9vbGVhbjtcbiAgICAgIHByZXR0eVByaW50Pzogc3RyaW5nIHwgbnVtYmVyO1xuICAgICAgZXZhbFNjcmlwdD86IHN0cmluZztcbiAgICB9ID0ge30sXG4gICkge1xuICAgIHRoaXMuX2ludGVyYWN0aXZlID0gb3B0aW9ucy5pbnRlcmFjdGl2ZSAhPT0gZmFsc2U7XG5cbiAgICBwcm9jZXNzLnN0ZGluLnJlc3VtZSgpO1xuICAgIGlmIChwcm9jZXNzLnN0ZGluLnNldFJhd01vZGUpIHtcbiAgICAgIHByb2Nlc3Muc3RkaW4uc2V0UmF3TW9kZSh0cnVlKTtcbiAgICB9XG4gICAgcHJvY2Vzcy5zdGRpbi5waXBlKHRoaXMuX2luKTtcblxuICAgIHRoaXMuX291dC5waXBlKHByb2Nlc3Muc3Rkb3V0KTtcblxuICAgIGRlZmluZVByb3AodGhpcy5fb3V0LCAnY29sdW1ucycsICgpID0+IHByb2Nlc3Muc3Rkb3V0LmNvbHVtbnMpO1xuXG4gICAgdGhpcy5fcmVwbFNlcnZlciA9IHN0YXJ0UmVwbCh7XG4gICAgICBpbnB1dDogdGhpcy5faW4sXG4gICAgICBvdXRwdXQ6IHRoaXMuX291dCxcbiAgICAgIHRlcm1pbmFsOiB0cnVlLFxuICAgIH0pO1xuXG4gICAgdGhpcy5fZGVmaW5lQWRkaXRpb25hbENvbW1hbmRzKCk7XG5cbiAgICB0aGlzLl9yZXBsU2VydmVyID0gaW5qZWN0QmVmb3JlKFxuICAgICAgdGhpcy5fcmVwbFNlcnZlcixcbiAgICAgICdjb21wbGV0ZXInLFxuICAgICAgKGxpbmU6IHN0cmluZywgY2FsbGJhY2s6IEZ1bmN0aW9uKSA9PiB7XG4gICAgICAgIHRoaXMuY29tcGxldGUobGluZSlcbiAgICAgICAgICAudGhlbigocmV0cykgPT4ge1xuICAgICAgICAgICAgY2FsbGJhY2sobnVsbCwgcmV0cyk7XG4gICAgICAgICAgfSlcbiAgICAgICAgICAuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICAgICAgY2FsbGJhY2soZXJyKTtcbiAgICAgICAgICB9KTtcbiAgICAgIH0sXG4gICAgKTtcbiAgICB0aGlzLl9yZXBsU2VydmVyID0gaW5qZWN0QWZ0ZXIodGhpcy5fcmVwbFNlcnZlciwgJ2V2YWwnLCBwcm9taXNpZnkpO1xuXG4gICAgaWYgKG9wdGlvbnMuaW50ZXJhY3RpdmUgPT09IGZhbHNlKSB7XG4gICAgICB0aGlzLl9yZXBsU2VydmVyID0gaW5qZWN0QWZ0ZXIoXG4gICAgICAgIHRoaXMuX3JlcGxTZXJ2ZXIsXG4gICAgICAgICdldmFsJyxcbiAgICAgICAgb3V0cHV0VG9TdGRvdXQob3B0aW9ucy5wcmV0dHlQcmludCksXG4gICAgICApO1xuICAgICAgdGhpcy5fcmVwbFNlcnZlciA9IGluamVjdEFmdGVyKHRoaXMuX3JlcGxTZXJ2ZXIsICdldmFsJywgZnVuY3Rpb24gKCkge1xuICAgICAgICBwcm9jZXNzLmV4aXQoKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICB0aGlzLl9yZXBsU2VydmVyLm9uKCdleGl0JywgKCkgPT4gcHJvY2Vzcy5leGl0KCkpO1xuXG4gICAgdGhpcy5fZGVmaW5lQnVpbHRpblZhcnModGhpcy5fcmVwbFNlcnZlci5jb250ZXh0KTtcblxuICAgIGlmIChvcHRpb25zLmV2YWxTY3JpcHQpIHtcbiAgICAgIHRoaXMuX2luLndyaXRlKG9wdGlvbnMuZXZhbFNjcmlwdCArICdcXG4nLCAndXRmLTgnKTtcbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcztcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgX2RlZmluZUFkZGl0aW9uYWxDb21tYW5kcygpIHtcbiAgICBjb25zdCBjbGkgPSB0aGlzLl9jbGk7XG4gICAgY29uc3QgcmVwbFNlcnZlciA9IHRoaXMuX3JlcGxTZXJ2ZXI7XG4gICAgaWYgKCFyZXBsU2VydmVyKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHJlcGxTZXJ2ZXIuZGVmaW5lQ29tbWFuZCgnY29ubmVjdGlvbnMnLCB7XG4gICAgICBoZWxwOiAnTGlzdCBjdXJyZW50eSByZWdpc3RlcmVkIFNhbGVzZm9yY2UgY29ubmVjdGlvbnMnLFxuICAgICAgYWN0aW9uOiBhc3luYyAoKSA9PiB7XG4gICAgICAgIGF3YWl0IGNsaS5saXN0Q29ubmVjdGlvbnMoKTtcbiAgICAgICAgcmVwbFNlcnZlci5kaXNwbGF5UHJvbXB0KCk7XG4gICAgICB9LFxuICAgIH0pO1xuICAgIHJlcGxTZXJ2ZXIuZGVmaW5lQ29tbWFuZCgnY29ubmVjdCcsIHtcbiAgICAgIGhlbHA6ICdDb25uZWN0IHRvIFNhbGVzZm9yY2UgaW5zdGFuY2UnLFxuICAgICAgYWN0aW9uOiBhc3luYyAoLi4uYXJnczogc3RyaW5nW10pID0+IHtcbiAgICAgICAgY29uc3QgW25hbWUsIHBhc3N3b3JkXSA9IGFyZ3M7XG4gICAgICAgIGNvbnN0IHBhcmFtcyA9IHBhc3N3b3JkXG4gICAgICAgICAgPyB7IGNvbm5lY3Rpb246IG5hbWUsIHVzZXJuYW1lOiBuYW1lLCBwYXNzd29yZDogcGFzc3dvcmQgfVxuICAgICAgICAgIDogeyBjb25uZWN0aW9uOiBuYW1lLCB1c2VybmFtZTogbmFtZSB9O1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGF3YWl0IGNsaS5jb25uZWN0KHBhcmFtcyk7XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnIubWVzc2FnZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJlcGxTZXJ2ZXIuZGlzcGxheVByb21wdCgpO1xuICAgICAgfSxcbiAgICB9KTtcbiAgICByZXBsU2VydmVyLmRlZmluZUNvbW1hbmQoJ2Rpc2Nvbm5lY3QnLCB7XG4gICAgICBoZWxwOiAnRGlzY29ubmVjdCBjb25uZWN0aW9uIGFuZCBlcmFzZSBpdCBmcm9tIHJlZ2lzdHJ5JyxcbiAgICAgIGFjdGlvbjogKG5hbWUpID0+IHtcbiAgICAgICAgY2xpLmRpc2Nvbm5lY3QobmFtZSk7XG4gICAgICAgIHJlcGxTZXJ2ZXIuZGlzcGxheVByb21wdCgpO1xuICAgICAgfSxcbiAgICB9KTtcbiAgICByZXBsU2VydmVyLmRlZmluZUNvbW1hbmQoJ3VzZScsIHtcbiAgICAgIGhlbHA6ICdTcGVjaWZ5IGxvZ2luIHNlcnZlciB0byBlc3RhYmxpc2ggY29ubmVjdGlvbicsXG4gICAgICBhY3Rpb246IChsb2dpblNlcnZlcikgPT4ge1xuICAgICAgICBjbGkuc2V0TG9naW5TZXJ2ZXIobG9naW5TZXJ2ZXIpO1xuICAgICAgICByZXBsU2VydmVyLmRpc3BsYXlQcm9tcHQoKTtcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgcmVwbFNlcnZlci5kZWZpbmVDb21tYW5kKCdhdXRob3JpemUnLCB7XG4gICAgICBoZWxwOiAnQ29ubmVjdCB0byBTYWxlc2ZvcmNlIHVzaW5nIE9BdXRoMiBhdXRob3JpemF0aW9uIGZsb3cnLFxuICAgICAgYWN0aW9uOiBhc3luYyAoY2xpZW50TmFtZSkgPT4ge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGF3YWl0IGNsaS5hdXRob3JpemUoY2xpZW50TmFtZSk7XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnIubWVzc2FnZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJlcGxTZXJ2ZXIuZGlzcGxheVByb21wdCgpO1xuICAgICAgfSxcbiAgICB9KTtcbiAgICByZXBsU2VydmVyLmRlZmluZUNvbW1hbmQoJ3JlZ2lzdGVyJywge1xuICAgICAgaGVscDogJ1JlZ2lzdGVyIE9BdXRoMiBjbGllbnQgaW5mb3JtYXRpb24nLFxuICAgICAgYWN0aW9uOiBhc3luYyAoLi4uYXJnczogc3RyaW5nW10pID0+IHtcbiAgICAgICAgY29uc3QgW1xuICAgICAgICAgIGNsaWVudE5hbWUsXG4gICAgICAgICAgY2xpZW50SWQsXG4gICAgICAgICAgY2xpZW50U2VjcmV0LFxuICAgICAgICAgIHJlZGlyZWN0VXJpLFxuICAgICAgICAgIGxvZ2luVXJsLFxuICAgICAgICBdID0gYXJncztcbiAgICAgICAgY29uc3QgY29uZmlnID0geyBjbGllbnRJZCwgY2xpZW50U2VjcmV0LCByZWRpcmVjdFVyaSwgbG9naW5VcmwgfTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBhd2FpdCBjbGkucmVnaXN0ZXIoY2xpZW50TmFtZSwgY29uZmlnKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGVyci5tZXNzYWdlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmVwbFNlcnZlci5kaXNwbGF5UHJvbXB0KCk7XG4gICAgICB9LFxuICAgIH0pO1xuICAgIHJlcGxTZXJ2ZXIuZGVmaW5lQ29tbWFuZCgnb3BlbicsIHtcbiAgICAgIGhlbHA6ICdPcGVuIFNhbGVzZm9yY2Ugd2ViIHBhZ2UgdXNpbmcgZXN0YWJsaXNoZWQgY29ubmVjdGlvbicsXG4gICAgICBhY3Rpb246ICh1cmwpID0+IHtcbiAgICAgICAgY2xpLm9wZW5VcmxVc2luZ1Nlc3Npb24odXJsKTtcbiAgICAgICAgcmVwbFNlcnZlci5kaXNwbGF5UHJvbXB0KCk7XG4gICAgICB9LFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBwYXVzZSgpIHtcbiAgICB0aGlzLl9wYXVzZWQgPSB0cnVlO1xuICAgIGlmIChwcm9jZXNzLnN0ZGluLnNldFJhd01vZGUpIHtcbiAgICAgIHByb2Nlc3Muc3RkaW4uc2V0UmF3TW9kZShmYWxzZSk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICByZXN1bWUoKSB7XG4gICAgdGhpcy5fcGF1c2VkID0gZmFsc2U7XG4gICAgcHJvY2Vzcy5zdGRpbi5yZXN1bWUoKTtcbiAgICBpZiAocHJvY2Vzcy5zdGRpbi5zZXRSYXdNb2RlKSB7XG4gICAgICBwcm9jZXNzLnN0ZGluLnNldFJhd01vZGUodHJ1ZSk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBhc3luYyBjb21wbGV0ZShsaW5lOiBzdHJpbmcpIHtcbiAgICBjb25zdCB0b2tlbnMgPSBsaW5lLnJlcGxhY2UoL15cXHMrLywgJycpLnNwbGl0KC9cXHMrLyk7XG4gICAgY29uc3QgW2NvbW1hbmQsIGtleXdvcmQgPSAnJ10gPSB0b2tlbnM7XG4gICAgaWYgKGNvbW1hbmRbMF0gPT09ICcuJyAmJiB0b2tlbnMubGVuZ3RoID09PSAyKSB7XG4gICAgICBsZXQgY2FuZGlkYXRlczogc3RyaW5nW10gPSBbXTtcbiAgICAgIGlmIChjb21tYW5kID09PSAnLmNvbm5lY3QnIHx8IGNvbW1hbmQgPT09ICcuZGlzY29ubmVjdCcpIHtcbiAgICAgICAgY2FuZGlkYXRlcyA9IGF3YWl0IHRoaXMuX2NsaS5nZXRDb25uZWN0aW9uTmFtZXMoKTtcbiAgICAgIH0gZWxzZSBpZiAoY29tbWFuZCA9PT0gJy5hdXRob3JpemUnKSB7XG4gICAgICAgIGNhbmRpZGF0ZXMgPSBhd2FpdCB0aGlzLl9jbGkuZ2V0Q2xpZW50TmFtZXMoKTtcbiAgICAgIH0gZWxzZSBpZiAoY29tbWFuZCA9PT0gJy51c2UnKSB7XG4gICAgICAgIGNhbmRpZGF0ZXMgPSBbJ3Byb2R1Y3Rpb24nLCAnc2FuZGJveCddO1xuICAgICAgfVxuICAgICAgY2FuZGlkYXRlcyA9IGNhbmRpZGF0ZXMuZmlsdGVyKChuYW1lKSA9PiBuYW1lLmluZGV4T2Yoa2V5d29yZCkgPT09IDApO1xuICAgICAgcmV0dXJuIFtjYW5kaWRhdGVzLCBrZXl3b3JkXTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogTWFwIGFsbCBqc2ZvcmNlIG9iamVjdCB0byBSRVBMIGNvbnRleHRcbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9kZWZpbmVCdWlsdGluVmFycyhjb250ZXh0OiB7IFt2YXJOYW1lOiBzdHJpbmddOiBhbnkgfSkge1xuICAgIGNvbnN0IGNsaSA9IHRoaXMuX2NsaTtcblxuICAgIC8vIGRlZmluZSBzYWxlc2ZvcmNlIHBhY2thZ2Ugcm9vdCBvYmplY3RzXG4gICAgZm9yIChjb25zdCBrZXkgaW4ganNmb3JjZSkge1xuICAgICAgaWYgKFxuICAgICAgICBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoanNmb3JjZSwga2V5KSAmJlxuICAgICAgICAhKGdsb2JhbCBhcyBhbnkpW2tleV1cbiAgICAgICkge1xuICAgICAgICBjb250ZXh0W2tleV0gPSAoanNmb3JjZSBhcyBhbnkpW2tleV07XG4gICAgICB9XG4gICAgfVxuICAgIC8vIGV4cG9zZSBqc2ZvcmNlIHBhY2thZ2Ugcm9vdCBvYmplY3QgaW4gY29udGV4dC5cbiAgICBjb250ZXh0LmpzZm9yY2UgPSBqc2ZvcmNlO1xuXG4gICAgZnVuY3Rpb24gY3JlYXRlUHJveHlGdW5jKHByb3A6IHN0cmluZykge1xuICAgICAgcmV0dXJuICguLi5hcmdzOiBhbnlbXSkgPT4ge1xuICAgICAgICBjb25zdCBjb25uID0gY2xpLmdldEN1cnJlbnRDb25uZWN0aW9uKCk7XG4gICAgICAgIHJldHVybiAoY29ubiBhcyBhbnkpW3Byb3BdKC4uLmFyZ3MpO1xuICAgICAgfTtcbiAgICB9XG5cbiAgICBmdW5jdGlvbiBjcmVhdGVQcm94eUFjY2Vzc29yKHByb3A6IHN0cmluZykge1xuICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgY29uc3QgY29ubiA9IGNsaS5nZXRDdXJyZW50Q29ubmVjdGlvbigpO1xuICAgICAgICByZXR1cm4gKGNvbm4gYXMgYW55KVtwcm9wXTtcbiAgICAgIH07XG4gICAgfVxuXG4gICAgY29uc3QgY29ubiA9IGNsaS5nZXRDdXJyZW50Q29ubmVjdGlvbigpO1xuICAgIC8vIGxpc3QgYWxsIHByb3BzIGluIGNvbm5lY3Rpb24gaW5zdGFuY2UsIG90aGVyIHRoYW4gRXZlbnRFbWl0dGVyIG9yIG9iamVjdCBidWlsdC1pbiBtZXRob2RzXG4gICAgY29uc3QgcHJvcHM6IHsgW3Byb3A6IHN0cmluZ106IGJvb2xlYW4gfSA9IHt9O1xuICAgIGxldCBvOiBvYmplY3QgPSBjb25uO1xuICAgIHdoaWxlIChvICYmIG8gIT09IEV2ZW50RW1pdHRlci5wcm90b3R5cGUgJiYgbyAhPT0gT2JqZWN0LnByb3RvdHlwZSkge1xuICAgICAgZm9yIChjb25zdCBwIG9mIE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKG8pKSB7XG4gICAgICAgIGlmIChwICE9PSAnY29uc3RydWN0b3InKSB7XG4gICAgICAgICAgcHJvcHNbcF0gPSB0cnVlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBvID0gT2JqZWN0LmdldFByb3RvdHlwZU9mKG8pO1xuICAgIH1cbiAgICBmb3IgKGNvbnN0IHByb3Agb2YgT2JqZWN0LmtleXMocHJvcHMpKSB7XG4gICAgICBpZiAodHlwZW9mIChnbG9iYWwgYXMgYW55KVtwcm9wXSAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgLy8gYXZvaWQgZ2xvYmFsIG92ZXJyaWRlXG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgaWYgKHByb3AuaW5kZXhPZignXycpID09PSAwKSB7XG4gICAgICAgIC8vIGlnbm9yZSBwcml2YXRlXG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgaWYgKGlzRnVuY3Rpb24oKGNvbm4gYXMgYW55KVtwcm9wXSkpIHtcbiAgICAgICAgY29udGV4dFtwcm9wXSA9IGNyZWF0ZVByb3h5RnVuYyhwcm9wKTtcbiAgICAgIH0gZWxzZSBpZiAoaXNPYmplY3QoKGNvbm4gYXMgYW55KVtwcm9wXSkpIHtcbiAgICAgICAgZGVmaW5lUHJvcChjb250ZXh0LCBwcm9wLCBjcmVhdGVQcm94eUFjY2Vzc29yKHByb3ApKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBleHBvc2UgZGVmYXVsdCBjb25uZWN0aW9uIGFzIFwiJGNvbm5cIlxuICAgIGRlZmluZVByb3AoY29udGV4dCwgJyRjb25uJywgKCkgPT4ge1xuICAgICAgcmV0dXJuIGNsaS5nZXRDdXJyZW50Q29ubmVjdGlvbigpO1xuICAgIH0pO1xuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IFJlcGw7XG4iXX0=