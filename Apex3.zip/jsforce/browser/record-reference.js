import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import "core-js/modules/es.array.join";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import "regenerator-runtime/runtime";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context3; _forEachInstanceProperty(_context3 = ownKeys(Object(source), true)).call(_context3, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context4; _forEachInstanceProperty(_context4 = ownKeys(Object(source))).call(_context4, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 *
 */

/**
 * Remote reference to record information
 */
export var RecordReference = /*#__PURE__*/function () {
  /**
   *
   */
  function RecordReference(conn, type, id) {
    _classCallCheck(this, RecordReference);

    _defineProperty(this, "type", void 0);

    _defineProperty(this, "id", void 0);

    _defineProperty(this, "_conn", void 0);

    _defineProperty(this, "delete", this.destroy);

    _defineProperty(this, "del", this.destroy);

    this._conn = conn;
    this.type = type;
    this.id = id;
  }
  /**
   * Retrieve record field information
   */


  _createClass(RecordReference, [{
    key: "retrieve",
    value: function () {
      var _retrieve = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee(options) {
        var rec;
        return _regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return this._conn.retrieve(this.type, this.id, options);

              case 2:
                rec = _context.sent;
                return _context.abrupt("return", rec);

              case 4:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function retrieve(_x) {
        return _retrieve.apply(this, arguments);
      }

      return retrieve;
    }()
    /**
     * Update record field information
     */

  }, {
    key: "update",
    value: function () {
      var _update = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee2(record, options) {
        var record_;
        return _regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                record_ = _objectSpread(_objectSpread({}, record), {}, {
                  Id: this.id
                });
                return _context2.abrupt("return", this._conn.update(this.type, record_, options));

              case 2:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function update(_x2, _x3) {
        return _update.apply(this, arguments);
      }

      return update;
    }()
    /**
     * Delete record field
     */

  }, {
    key: "destroy",
    value: function destroy(options) {
      return this._conn.destroy(this.type, this.id, options);
    }
    /**
     * Synonym of Record#destroy()
     */

  }, {
    key: "blob",

    /**
     * Get blob field as stream
     *
     * @param {String} fieldName - Blob field name
     * @returns {stream.Stream}
     */
    value: function blob(fieldName) {
      var url = [this._conn._baseUrl(), 'sobjects', this.type, this.id, fieldName].join('/');
      return this._conn.request(url).stream();
    }
  }]);

  return RecordReference;
}();
export default RecordReference;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9yZWNvcmQtcmVmZXJlbmNlLnRzIl0sIm5hbWVzIjpbIlJlY29yZFJlZmVyZW5jZSIsImNvbm4iLCJ0eXBlIiwiaWQiLCJkZXN0cm95IiwiX2Nvbm4iLCJvcHRpb25zIiwicmV0cmlldmUiLCJyZWMiLCJyZWNvcmQiLCJyZWNvcmRfIiwiSWQiLCJ1cGRhdGUiLCJmaWVsZE5hbWUiLCJ1cmwiLCJfYmFzZVVybCIsImpvaW4iLCJyZXF1ZXN0Iiwic3RyZWFtIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTs7QUFXQTtBQUNBO0FBQ0E7QUFDQSxXQUFhQSxlQUFiO0FBVUU7QUFDRjtBQUNBO0FBQ0UsMkJBQVlDLElBQVosRUFBaUNDLElBQWpDLEVBQTBDQyxFQUExQyxFQUFzRDtBQUFBOztBQUFBOztBQUFBOztBQUFBOztBQUFBLG9DQWdDN0MsS0FBS0MsT0FoQ3dDOztBQUFBLGlDQXFDaEQsS0FBS0EsT0FyQzJDOztBQUNwRCxTQUFLQyxLQUFMLEdBQWFKLElBQWI7QUFDQSxTQUFLQyxJQUFMLEdBQVlBLElBQVo7QUFDQSxTQUFLQyxFQUFMLEdBQVVBLEVBQVY7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7O0FBckJBO0FBQUE7QUFBQTtBQUFBLGdHQXNCaUJHLE9BdEJqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXVCc0IsS0FBS0QsS0FBTCxDQUFXRSxRQUFYLENBQW9CLEtBQUtMLElBQXpCLEVBQStCLEtBQUtDLEVBQXBDLEVBQXdDRyxPQUF4QyxDQXZCdEI7O0FBQUE7QUF1QlVFLGdCQUFBQSxHQXZCVjtBQUFBLGlEQXdCV0EsR0F4Qlg7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUEyQkU7QUFDRjtBQUNBOztBQTdCQTtBQUFBO0FBQUE7QUFBQSwrRkE4QmVDLE1BOUJmLEVBOEJvQ0gsT0E5QnBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQStCVUksZ0JBQUFBLE9BL0JWLG1DQStCeUJELE1BL0J6QjtBQStCaUNFLGtCQUFBQSxFQUFFLEVBQUUsS0FBS1I7QUEvQjFDO0FBQUEsa0RBZ0NXLEtBQUtFLEtBQUwsQ0FBV08sTUFBWCxDQUFrQixLQUFLVixJQUF2QixFQUE2QlEsT0FBN0IsRUFBc0NKLE9BQXRDLENBaENYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBbUNFO0FBQ0Y7QUFDQTs7QUFyQ0E7QUFBQTtBQUFBLDRCQXNDVUEsT0F0Q1YsRUFzQ2dDO0FBQzVCLGFBQU8sS0FBS0QsS0FBTCxDQUFXRCxPQUFYLENBQW1CLEtBQUtGLElBQXhCLEVBQThCLEtBQUtDLEVBQW5DLEVBQXVDRyxPQUF2QyxDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBNUNBO0FBQUE7O0FBb0RFO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQXpEQSx5QkEwRE9PLFNBMURQLEVBMEQwQjtBQUN0QixVQUFNQyxHQUFHLEdBQUcsQ0FDVixLQUFLVCxLQUFMLENBQVdVLFFBQVgsRUFEVSxFQUVWLFVBRlUsRUFHVixLQUFLYixJQUhLLEVBSVYsS0FBS0MsRUFKSyxFQUtWVSxTQUxVLEVBTVZHLElBTlUsQ0FNTCxHQU5LLENBQVo7QUFPQSxhQUFPLEtBQUtYLEtBQUwsQ0FBV1ksT0FBWCxDQUFtQkgsR0FBbkIsRUFBd0JJLE1BQXhCLEVBQVA7QUFDRDtBQW5FSDs7QUFBQTtBQUFBO0FBc0VBLGVBQWVsQixlQUFmIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKlxuICovXG5pbXBvcnQgQ29ubmVjdGlvbiBmcm9tICcuL2Nvbm5lY3Rpb24nO1xuaW1wb3J0IHtcbiAgUmV0cmlldmVPcHRpb25zLFxuICBEbWxPcHRpb25zLFxuICBTY2hlbWEsXG4gIFNPYmplY3ROYW1lcyxcbiAgU09iamVjdElucHV0UmVjb3JkLFxuICBTT2JqZWN0VXBkYXRlUmVjb3JkLFxufSBmcm9tICcuL3R5cGVzJztcblxuLyoqXG4gKiBSZW1vdGUgcmVmZXJlbmNlIHRvIHJlY29yZCBpbmZvcm1hdGlvblxuICovXG5leHBvcnQgY2xhc3MgUmVjb3JkUmVmZXJlbmNlPFxuICBTIGV4dGVuZHMgU2NoZW1hLFxuICBOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+LFxuICBJbnB1dFJlY29yZCBleHRlbmRzIFNPYmplY3RJbnB1dFJlY29yZDxTLCBOPiA9IFNPYmplY3RJbnB1dFJlY29yZDxTLCBOPixcbiAgUmV0cmlldmVSZWNvcmQgZXh0ZW5kcyBTT2JqZWN0VXBkYXRlUmVjb3JkPFMsIE4+ID0gU09iamVjdFVwZGF0ZVJlY29yZDxTLCBOPlxuPiB7XG4gIHR5cGU6IE47XG4gIGlkOiBzdHJpbmc7XG4gIF9jb25uOiBDb25uZWN0aW9uPFM+O1xuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgY29uc3RydWN0b3IoY29ubjogQ29ubmVjdGlvbjxTPiwgdHlwZTogTiwgaWQ6IHN0cmluZykge1xuICAgIHRoaXMuX2Nvbm4gPSBjb25uO1xuICAgIHRoaXMudHlwZSA9IHR5cGU7XG4gICAgdGhpcy5pZCA9IGlkO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHJpZXZlIHJlY29yZCBmaWVsZCBpbmZvcm1hdGlvblxuICAgKi9cbiAgYXN5bmMgcmV0cmlldmUob3B0aW9ucz86IFJldHJpZXZlT3B0aW9ucykge1xuICAgIGNvbnN0IHJlYyA9IGF3YWl0IHRoaXMuX2Nvbm4ucmV0cmlldmUodGhpcy50eXBlLCB0aGlzLmlkLCBvcHRpb25zKTtcbiAgICByZXR1cm4gcmVjIGFzIFJldHJpZXZlUmVjb3JkO1xuICB9XG5cbiAgLyoqXG4gICAqIFVwZGF0ZSByZWNvcmQgZmllbGQgaW5mb3JtYXRpb25cbiAgICovXG4gIGFzeW5jIHVwZGF0ZShyZWNvcmQ6IElucHV0UmVjb3JkLCBvcHRpb25zPzogRG1sT3B0aW9ucykge1xuICAgIGNvbnN0IHJlY29yZF8gPSB7IC4uLnJlY29yZCwgSWQ6IHRoaXMuaWQgfTtcbiAgICByZXR1cm4gdGhpcy5fY29ubi51cGRhdGUodGhpcy50eXBlLCByZWNvcmRfLCBvcHRpb25zKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZWxldGUgcmVjb3JkIGZpZWxkXG4gICAqL1xuICBkZXN0cm95KG9wdGlvbnM/OiBEbWxPcHRpb25zKSB7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4uZGVzdHJveSh0aGlzLnR5cGUsIHRoaXMuaWQsIG9wdGlvbnMpO1xuICB9XG5cbiAgLyoqXG4gICAqIFN5bm9ueW0gb2YgUmVjb3JkI2Rlc3Ryb3koKVxuICAgKi9cbiAgZGVsZXRlID0gdGhpcy5kZXN0cm95O1xuXG4gIC8qKlxuICAgKiBTeW5vbnltIG9mIFJlY29yZCNkZXN0cm95KClcbiAgICovXG4gIGRlbCA9IHRoaXMuZGVzdHJveTtcblxuICAvKipcbiAgICogR2V0IGJsb2IgZmllbGQgYXMgc3RyZWFtXG4gICAqXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBmaWVsZE5hbWUgLSBCbG9iIGZpZWxkIG5hbWVcbiAgICogQHJldHVybnMge3N0cmVhbS5TdHJlYW19XG4gICAqL1xuICBibG9iKGZpZWxkTmFtZTogc3RyaW5nKSB7XG4gICAgY29uc3QgdXJsID0gW1xuICAgICAgdGhpcy5fY29ubi5fYmFzZVVybCgpLFxuICAgICAgJ3NvYmplY3RzJyxcbiAgICAgIHRoaXMudHlwZSxcbiAgICAgIHRoaXMuaWQsXG4gICAgICBmaWVsZE5hbWUsXG4gICAgXS5qb2luKCcvJyk7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4ucmVxdWVzdCh1cmwpLnN0cmVhbSgpO1xuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IFJlY29yZFJlZmVyZW5jZTtcbiJdfQ==