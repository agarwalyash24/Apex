import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import "core-js/modules/es.object.to-string";
import "core-js/modules/es.regexp.to-string";
import _get from "@babel/runtime-corejs3/helpers/get";
import _setTimeout from "@babel/runtime-corejs3/core-js-stable/set-timeout";
import _assertThisInitialized from "@babel/runtime-corejs3/helpers/assertThisInitialized";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import "regenerator-runtime/runtime";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime-corejs3/helpers/objectWithoutProperties";

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = _Reflect$construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !_Reflect$construct) return false; if (_Reflect$construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(_Reflect$construct(Date, [], function () {})); return true; } catch (e) { return false; } }

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context12; _forEachInstanceProperty(_context12 = ownKeys(Object(source), true)).call(_context12, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context13; _forEachInstanceProperty(_context13 = ownKeys(Object(source))).call(_context13, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 * @file Manages Salesforce Metadata API
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { EventEmitter } from 'events';
import { Readable } from 'stream';
import FormData from 'form-data';
import { registerModule } from '../jsforce';
import SOAP from '../soap';
import { isObject } from '../util/function';
import { ApiSchemas } from './metadata/schema';
export * from './metadata/schema';
/**
 *
 */

/**
 *
 */
function deallocateTypeWithMetadata(metadata) {
  var _ref = metadata,
      $ = _ref.$,
      md = _objectWithoutProperties(_ref, ["$"]);

  return md;
}

function assignTypeWithMetadata(metadata, type) {
  var convert = function convert(md) {
    return _objectSpread(_defineProperty({}, '@xsi:type', type), md);
  };

  return _Array$isArray(metadata) ? _mapInstanceProperty(metadata).call(metadata, convert) : convert(metadata);
}
/**
 * Class for Salesforce Metadata API
 */


export var MetadataApi = /*#__PURE__*/function () {
  /**
   * Polling interval in milliseconds
   */

  /**
   * Polling timeout in milliseconds
   */

  /**
   *
   */
  function MetadataApi(conn) {
    _classCallCheck(this, MetadataApi);

    _defineProperty(this, "_conn", void 0);

    _defineProperty(this, "pollInterval", 1000);

    _defineProperty(this, "pollTimeout", 10000);

    this._conn = conn;
  }
  /**
   * Call Metadata API SOAP endpoint
   *
   * @private
   */


  _createClass(MetadataApi, [{
    key: "_invoke",
    value: function () {
      var _invoke2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee(method, message, schema) {
        var _context;

        var soapEndpoint, res;
        return _regeneratorRuntime.wrap(function _callee$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                soapEndpoint = new SOAP(this._conn, {
                  xmlns: 'http://soap.sforce.com/2006/04/metadata',
                  endpointUrl: _concatInstanceProperty(_context = "".concat(this._conn.instanceUrl, "/services/Soap/m/")).call(_context, this._conn.version)
                });
                _context2.next = 3;
                return soapEndpoint.invoke(method, message, schema ? {
                  result: schema
                } : undefined, ApiSchemas);

              case 3:
                res = _context2.sent;
                return _context2.abrupt("return", res.result);

              case 5:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee, this);
      }));

      function _invoke(_x, _x2, _x3) {
        return _invoke2.apply(this, arguments);
      }

      return _invoke;
    }()
    /**
     * Add one or more new metadata components to the organization.
     */

  }, {
    key: "create",
    value: function create(type, metadata) {
      var isArray = _Array$isArray(metadata);

      metadata = assignTypeWithMetadata(metadata, type);
      var schema = isArray ? [ApiSchemas.SaveResult] : ApiSchemas.SaveResult;
      return this._invoke('createMetadata', {
        metadata: metadata
      }, schema);
    }
    /**
     * Read specified metadata components in the organization.
     */

  }, {
    key: "read",
    value: function () {
      var _read = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee2(type, fullNames) {
        var _context3;

        var ReadResultSchema, res;
        return _regeneratorRuntime.wrap(function _callee2$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                ReadResultSchema = type in ApiSchemas ? {
                  type: ApiSchemas.ReadResult.type,
                  props: {
                    records: [type]
                  }
                } : ApiSchemas.ReadResult;
                _context4.next = 3;
                return this._invoke('readMetadata', {
                  type: type,
                  fullNames: fullNames
                }, ReadResultSchema);

              case 3:
                res = _context4.sent;
                return _context4.abrupt("return", _Array$isArray(fullNames) ? _mapInstanceProperty(_context3 = res.records).call(_context3, deallocateTypeWithMetadata) : deallocateTypeWithMetadata(res.records[0]));

              case 5:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee2, this);
      }));

      function read(_x4, _x5) {
        return _read.apply(this, arguments);
      }

      return read;
    }()
    /**
     * Update one or more metadata components in the organization.
     */

  }, {
    key: "update",
    value: function update(type, metadata) {
      var isArray = _Array$isArray(metadata);

      metadata = assignTypeWithMetadata(metadata, type);
      var schema = isArray ? [ApiSchemas.SaveResult] : ApiSchemas.SaveResult;
      return this._invoke('updateMetadata', {
        metadata: metadata
      }, schema);
    }
    /**
     * Upsert one or more components in your organization's data.
     */

  }, {
    key: "upsert",
    value: function upsert(type, metadata) {
      var isArray = _Array$isArray(metadata);

      metadata = assignTypeWithMetadata(metadata, type);
      var schema = isArray ? [ApiSchemas.UpsertResult] : ApiSchemas.UpsertResult;
      return this._invoke('upsertMetadata', {
        metadata: metadata
      }, schema);
    }
    /**
     * Deletes specified metadata components in the organization.
     */

  }, {
    key: "delete",
    value: function _delete(type, fullNames) {
      var schema = _Array$isArray(fullNames) ? [ApiSchemas.SaveResult] : ApiSchemas.SaveResult;
      return this._invoke('deleteMetadata', {
        type: type,
        fullNames: fullNames
      }, schema);
    }
    /**
     * Rename fullname of a metadata component in the organization
     */

  }, {
    key: "rename",
    value: function rename(type, oldFullName, newFullName) {
      return this._invoke('renameMetadata', {
        type: type,
        oldFullName: oldFullName,
        newFullName: newFullName
      }, ApiSchemas.SaveResult);
    }
    /**
     * Retrieves the metadata which describes your organization, including Apex classes and triggers,
     * custom objects, custom fields on standard objects, tab sets that define an app,
     * and many other components.
     */

  }, {
    key: "describe",
    value: function describe(asOfVersion) {
      if (!asOfVersion) {
        asOfVersion = this._conn.version;
      }

      return this._invoke('describeMetadata', {
        asOfVersion: asOfVersion
      }, ApiSchemas.DescribeMetadataResult);
    }
    /**
     * Retrieves property information about metadata components in your organization
     */

  }, {
    key: "list",
    value: function list(queries, asOfVersion) {
      if (!asOfVersion) {
        asOfVersion = this._conn.version;
      }

      return this._invoke('listMetadata', {
        queries: queries,
        asOfVersion: asOfVersion
      }, [ApiSchemas.FileProperties]);
    }
    /**
     * Checks the status of asynchronous metadata calls
     */

  }, {
    key: "checkStatus",
    value: function checkStatus(asyncProcessId) {
      var res = this._invoke('checkStatus', {
        asyncProcessId: asyncProcessId
      }, ApiSchemas.AsyncResult);

      return new AsyncResultLocator(this, res);
    }
    /**
     * Retrieves XML file representations of components in an organization
     */

  }, {
    key: "retrieve",
    value: function retrieve(request) {
      var res = this._invoke('retrieve', {
        request: request
      }, ApiSchemas.RetrieveResult);

      return new RetrieveResultLocator(this, res);
    }
    /**
     * Checks the status of declarative metadata call retrieve() and returns the zip file contents
     */

  }, {
    key: "checkRetrieveStatus",
    value: function checkRetrieveStatus(asyncProcessId) {
      return this._invoke('checkRetrieveStatus', {
        asyncProcessId: asyncProcessId
      }, ApiSchemas.RetrieveResult);
    }
    /**
     * Will deploy a recently validated deploy request
     *
     * @param options.id = the deploy ID that's been validated already from a previous checkOnly deploy request
     * @param options.rest = a boolean whether or not to use the REST API
     * @returns the deploy ID of the recent validation request
     */

  }, {
    key: "deployRecentValidation",
    value: function () {
      var _deployRecentValidation = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee3(options) {
        var id, rest, response, messageBody, requestInfo, requestOptions;
        return _regeneratorRuntime.wrap(function _callee3$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                id = options.id, rest = options.rest;

                if (!rest) {
                  _context5.next = 10;
                  break;
                }

                messageBody = _JSON$stringify({
                  validatedDeployRequestId: id
                });
                requestInfo = {
                  method: 'POST',
                  url: "".concat(this._conn._baseUrl(), "/metadata/deployRequest"),
                  body: messageBody,
                  headers: {
                    'content-type': 'application/json'
                  }
                };
                requestOptions = {
                  headers: 'json'
                }; // This is the deploy ID of the deployRecentValidation response, not
                // the already validated deploy ID (i.e., validateddeployrequestid).
                // REST returns an object with an id property, SOAP returns the id as a string directly.

                _context5.next = 7;
                return this._conn.request(requestInfo, requestOptions);

              case 7:
                response = _context5.sent.id;
                _context5.next = 13;
                break;

              case 10:
                _context5.next = 12;
                return this._invoke('deployRecentValidation', {
                  validationId: id
                });

              case 12:
                response = _context5.sent;

              case 13:
                return _context5.abrupt("return", response);

              case 14:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee3, this);
      }));

      function deployRecentValidation(_x6) {
        return _deployRecentValidation.apply(this, arguments);
      }

      return deployRecentValidation;
    }()
    /**
     * Deploy components into an organization using zipped file representations
     * using the REST Metadata API instead of SOAP
     */

  }, {
    key: "deployRest",
    value: function deployRest(zipInput) {
      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      var form = new FormData();
      form.append('file', zipInput, {
        contentType: 'application/zip',
        filename: 'package.xml'
      }); // Add the deploy options

      form.append('entity_content', _JSON$stringify({
        deployOptions: options
      }), {
        contentType: 'application/json'
      });
      var request = {
        url: '/metadata/deployRequest',
        method: 'POST',
        headers: _objectSpread({}, form.getHeaders()),
        body: form.getBuffer()
      };

      var res = this._conn.request(request);

      return new DeployResultLocator(this, res);
    }
    /**
     * Deploy components into an organization using zipped file representations
     */

  }, {
    key: "deploy",
    value: function deploy(zipInput) {
      var _this = this;

      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      var res = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee4() {
        var zipContentB64;
        return _regeneratorRuntime.wrap(function _callee4$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                _context6.next = 2;
                return new _Promise(function (resolve, reject) {
                  if (isObject(zipInput) && 'pipe' in zipInput && typeof zipInput.pipe === 'function') {
                    var bufs = [];
                    zipInput.on('data', function (d) {
                      return bufs.push(d);
                    });
                    zipInput.on('error', reject);
                    zipInput.on('end', function () {
                      resolve(_concatInstanceProperty(Buffer).call(Buffer, bufs).toString('base64'));
                    }); // zipInput.resume();
                  } else if (zipInput instanceof Buffer) {
                    resolve(zipInput.toString('base64'));
                  } else if (zipInput instanceof String || typeof zipInput === 'string') {
                    resolve(zipInput);
                  } else {
                    throw 'Unexpected zipInput type';
                  }
                });

              case 2:
                zipContentB64 = _context6.sent;
                return _context6.abrupt("return", _this._invoke('deploy', {
                  ZipFile: zipContentB64,
                  DeployOptions: options
                }, ApiSchemas.DeployResult));

              case 4:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee4);
      }))();

      return new DeployResultLocator(this, res);
    }
    /**
     * Checks the status of declarative metadata call deploy()
     */

  }, {
    key: "checkDeployStatus",
    value: function checkDeployStatus(asyncProcessId) {
      var includeDetails = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
      return this._invoke('checkDeployStatus', {
        asyncProcessId: asyncProcessId,
        includeDetails: includeDetails
      }, ApiSchemas.DeployResult);
    }
  }]);

  return MetadataApi;
}();
/*--------------------------------------------*/

/**
 * The locator class for Metadata API asynchronous call result
 */

export var AsyncResultLocator = /*#__PURE__*/function (_EventEmitter) {
  _inherits(AsyncResultLocator, _EventEmitter);

  var _super = _createSuper(AsyncResultLocator);

  /**
   *
   */
  function AsyncResultLocator(meta, promise) {
    var _this2;

    _classCallCheck(this, AsyncResultLocator);

    _this2 = _super.call(this);

    _defineProperty(_assertThisInitialized(_this2), "_meta", void 0);

    _defineProperty(_assertThisInitialized(_this2), "_promise", void 0);

    _defineProperty(_assertThisInitialized(_this2), "_id", void 0);

    _this2._meta = meta;
    _this2._promise = promise;
    return _this2;
  }
  /**
   * Promise/A+ interface
   * http://promises-aplus.github.io/promises-spec/
   *
   * @method Metadata~AsyncResultLocator#then
   */


  _createClass(AsyncResultLocator, [{
    key: "then",
    value: function then(onResolve, onReject) {
      return this._promise.then(onResolve, onReject);
    }
    /**
     * Check the status of async request
     */

  }, {
    key: "check",
    value: function () {
      var _check = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee5() {
        var result;
        return _regeneratorRuntime.wrap(function _callee5$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                _context7.next = 2;
                return this._promise;

              case 2:
                result = _context7.sent;
                this._id = result.id;
                _context7.next = 6;
                return this._meta.checkStatus(result.id);

              case 6:
                return _context7.abrupt("return", _context7.sent);

              case 7:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee5, this);
      }));

      function check() {
        return _check.apply(this, arguments);
      }

      return check;
    }()
    /**
     * Polling until async call status becomes complete or error
     */

  }, {
    key: "poll",
    value: function poll(interval, timeout) {
      var _this3 = this;

      var startTime = new Date().getTime();

      var poll = /*#__PURE__*/function () {
        var _ref3 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee6() {
          var now, errMsg, _result;

          return _regeneratorRuntime.wrap(function _callee6$(_context8) {
            while (1) {
              switch (_context8.prev = _context8.next) {
                case 0:
                  _context8.prev = 0;
                  now = new Date().getTime();

                  if (!(startTime + timeout < now)) {
                    _context8.next = 7;
                    break;
                  }

                  errMsg = 'Polling time out.';

                  if (_this3._id) {
                    errMsg += ' Process Id = ' + _this3._id;
                  }

                  _this3.emit('error', new Error(errMsg));

                  return _context8.abrupt("return");

                case 7:
                  _context8.next = 9;
                  return _this3.check();

                case 9:
                  _result = _context8.sent;

                  if (_result.done) {
                    _this3.emit('complete', _result);
                  } else {
                    _this3.emit('progress', _result);

                    _setTimeout(poll, interval);
                  }

                  _context8.next = 16;
                  break;

                case 13:
                  _context8.prev = 13;
                  _context8.t0 = _context8["catch"](0);

                  _this3.emit('error', _context8.t0);

                case 16:
                case "end":
                  return _context8.stop();
              }
            }
          }, _callee6, null, [[0, 13]]);
        }));

        return function poll() {
          return _ref3.apply(this, arguments);
        };
      }();

      _setTimeout(poll, interval);
    }
    /**
     * Check and wait until the async requests become in completed status
     */

  }, {
    key: "complete",
    value: function complete() {
      var _this4 = this;

      return new _Promise(function (resolve, reject) {
        _this4.on('complete', resolve);

        _this4.on('error', reject);

        _this4.poll(_this4._meta.pollInterval, _this4._meta.pollTimeout);
      });
    }
  }]);

  return AsyncResultLocator;
}(EventEmitter);
/*--------------------------------------------*/

/**
 * The locator class to track retreive() Metadata API call result
 */

export var RetrieveResultLocator = /*#__PURE__*/function (_AsyncResultLocator) {
  _inherits(RetrieveResultLocator, _AsyncResultLocator);

  var _super2 = _createSuper(RetrieveResultLocator);

  function RetrieveResultLocator() {
    _classCallCheck(this, RetrieveResultLocator);

    return _super2.apply(this, arguments);
  }

  _createClass(RetrieveResultLocator, [{
    key: "complete",

    /**
     * Check and wait until the async request becomes in completed status,
     * and retrieve the result data.
     */
    value: function () {
      var _complete = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee7() {
        var result;
        return _regeneratorRuntime.wrap(function _callee7$(_context9) {
          while (1) {
            switch (_context9.prev = _context9.next) {
              case 0:
                _context9.next = 2;
                return _get(_getPrototypeOf(RetrieveResultLocator.prototype), "complete", this).call(this);

              case 2:
                result = _context9.sent;
                return _context9.abrupt("return", this._meta.checkRetrieveStatus(result.id));

              case 4:
              case "end":
                return _context9.stop();
            }
          }
        }, _callee7, this);
      }));

      function complete() {
        return _complete.apply(this, arguments);
      }

      return complete;
    }()
    /**
     * Change the retrieved result to Node.js readable stream
     */

  }, {
    key: "stream",
    value: function stream() {
      var _this5 = this;

      var resultStream = new Readable();
      var reading = false;
      resultStream._read = /*#__PURE__*/_asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee8() {
        var _result2;

        return _regeneratorRuntime.wrap(function _callee8$(_context10) {
          while (1) {
            switch (_context10.prev = _context10.next) {
              case 0:
                if (!reading) {
                  _context10.next = 2;
                  break;
                }

                return _context10.abrupt("return");

              case 2:
                reading = true;
                _context10.prev = 3;
                _context10.next = 6;
                return _this5.complete();

              case 6:
                _result2 = _context10.sent;
                resultStream.push(Buffer.from(_result2.zipFile, 'base64'));
                resultStream.push(null);
                _context10.next = 14;
                break;

              case 11:
                _context10.prev = 11;
                _context10.t0 = _context10["catch"](3);
                resultStream.emit('error', _context10.t0);

              case 14:
              case "end":
                return _context10.stop();
            }
          }
        }, _callee8, null, [[3, 11]]);
      }));
      return resultStream;
    }
  }]);

  return RetrieveResultLocator;
}(AsyncResultLocator);
/*--------------------------------------------*/

/**
 * The locator class to track deploy() Metadata API call result
 *
 * @protected
 * @class Metadata~DeployResultLocator
 * @extends Metadata~AsyncResultLocator
 * @param {Metadata} meta - Metadata API object
 * @param {Promise.<Metadata~AsyncResult>} result - Promise object for async result of deploy() call
 */

export var DeployResultLocator = /*#__PURE__*/function (_AsyncResultLocator2) {
  _inherits(DeployResultLocator, _AsyncResultLocator2);

  var _super3 = _createSuper(DeployResultLocator);

  function DeployResultLocator() {
    _classCallCheck(this, DeployResultLocator);

    return _super3.apply(this, arguments);
  }

  _createClass(DeployResultLocator, [{
    key: "complete",

    /**
     * Check and wait until the async request becomes in completed status,
     * and retrieve the result data.
     */
    value: function () {
      var _complete2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee9(includeDetails) {
        var result;
        return _regeneratorRuntime.wrap(function _callee9$(_context11) {
          while (1) {
            switch (_context11.prev = _context11.next) {
              case 0:
                _context11.next = 2;
                return _get(_getPrototypeOf(DeployResultLocator.prototype), "complete", this).call(this);

              case 2:
                result = _context11.sent;
                return _context11.abrupt("return", this._meta.checkDeployStatus(result.id, includeDetails));

              case 4:
              case "end":
                return _context11.stop();
            }
          }
        }, _callee9, this);
      }));

      function complete(_x7) {
        return _complete2.apply(this, arguments);
      }

      return complete;
    }()
  }]);

  return DeployResultLocator;
}(AsyncResultLocator);
/*--------------------------------------------*/

/*
 * Register hook in connection instantiation for dynamically adding this API module features
 */

registerModule('metadata', function (conn) {
  return new MetadataApi(conn);
});
export default MetadataApi;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9hcGkvbWV0YWRhdGEudHMiXSwibmFtZXMiOlsiRXZlbnRFbWl0dGVyIiwiUmVhZGFibGUiLCJGb3JtRGF0YSIsInJlZ2lzdGVyTW9kdWxlIiwiU09BUCIsImlzT2JqZWN0IiwiQXBpU2NoZW1hcyIsImRlYWxsb2NhdGVUeXBlV2l0aE1ldGFkYXRhIiwibWV0YWRhdGEiLCIkIiwibWQiLCJhc3NpZ25UeXBlV2l0aE1ldGFkYXRhIiwidHlwZSIsImNvbnZlcnQiLCJNZXRhZGF0YUFwaSIsImNvbm4iLCJfY29ubiIsIm1ldGhvZCIsIm1lc3NhZ2UiLCJzY2hlbWEiLCJzb2FwRW5kcG9pbnQiLCJ4bWxucyIsImVuZHBvaW50VXJsIiwiaW5zdGFuY2VVcmwiLCJ2ZXJzaW9uIiwiaW52b2tlIiwicmVzdWx0IiwidW5kZWZpbmVkIiwicmVzIiwiaXNBcnJheSIsIlNhdmVSZXN1bHQiLCJfaW52b2tlIiwiZnVsbE5hbWVzIiwiUmVhZFJlc3VsdFNjaGVtYSIsIlJlYWRSZXN1bHQiLCJwcm9wcyIsInJlY29yZHMiLCJVcHNlcnRSZXN1bHQiLCJvbGRGdWxsTmFtZSIsIm5ld0Z1bGxOYW1lIiwiYXNPZlZlcnNpb24iLCJEZXNjcmliZU1ldGFkYXRhUmVzdWx0IiwicXVlcmllcyIsIkZpbGVQcm9wZXJ0aWVzIiwiYXN5bmNQcm9jZXNzSWQiLCJBc3luY1Jlc3VsdCIsIkFzeW5jUmVzdWx0TG9jYXRvciIsInJlcXVlc3QiLCJSZXRyaWV2ZVJlc3VsdCIsIlJldHJpZXZlUmVzdWx0TG9jYXRvciIsIm9wdGlvbnMiLCJpZCIsInJlc3QiLCJtZXNzYWdlQm9keSIsInZhbGlkYXRlZERlcGxveVJlcXVlc3RJZCIsInJlcXVlc3RJbmZvIiwidXJsIiwiX2Jhc2VVcmwiLCJib2R5IiwiaGVhZGVycyIsInJlcXVlc3RPcHRpb25zIiwicmVzcG9uc2UiLCJ2YWxpZGF0aW9uSWQiLCJ6aXBJbnB1dCIsImZvcm0iLCJhcHBlbmQiLCJjb250ZW50VHlwZSIsImZpbGVuYW1lIiwiZGVwbG95T3B0aW9ucyIsImdldEhlYWRlcnMiLCJnZXRCdWZmZXIiLCJEZXBsb3lSZXN1bHRMb2NhdG9yIiwicmVzb2x2ZSIsInJlamVjdCIsInBpcGUiLCJidWZzIiwib24iLCJkIiwicHVzaCIsIkJ1ZmZlciIsInRvU3RyaW5nIiwiU3RyaW5nIiwiemlwQ29udGVudEI2NCIsIlppcEZpbGUiLCJEZXBsb3lPcHRpb25zIiwiRGVwbG95UmVzdWx0IiwiaW5jbHVkZURldGFpbHMiLCJtZXRhIiwicHJvbWlzZSIsIl9tZXRhIiwiX3Byb21pc2UiLCJvblJlc29sdmUiLCJvblJlamVjdCIsInRoZW4iLCJfaWQiLCJjaGVja1N0YXR1cyIsImludGVydmFsIiwidGltZW91dCIsInN0YXJ0VGltZSIsIkRhdGUiLCJnZXRUaW1lIiwicG9sbCIsIm5vdyIsImVyck1zZyIsImVtaXQiLCJFcnJvciIsImNoZWNrIiwiZG9uZSIsInBvbGxJbnRlcnZhbCIsInBvbGxUaW1lb3V0IiwiY2hlY2tSZXRyaWV2ZVN0YXR1cyIsInJlc3VsdFN0cmVhbSIsInJlYWRpbmciLCJfcmVhZCIsImNvbXBsZXRlIiwiZnJvbSIsInppcEZpbGUiLCJjaGVja0RlcGxveVN0YXR1cyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVNBLFlBQVQsUUFBNkIsUUFBN0I7QUFDQSxTQUFTQyxRQUFULFFBQXlCLFFBQXpCO0FBQ0EsT0FBT0MsUUFBUCxNQUFxQixXQUFyQjtBQUNBLFNBQVNDLGNBQVQsUUFBK0IsWUFBL0I7QUFFQSxPQUFPQyxJQUFQLE1BQWlCLFNBQWpCO0FBQ0EsU0FBU0MsUUFBVCxRQUF5QixrQkFBekI7QUFFQSxTQUNFQyxVQURGLFFBZU8sbUJBZlA7QUFnQkEsY0FBYyxtQkFBZDtBQUVBO0FBQ0E7QUFDQTs7QUFpQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU0MsMEJBQVQsQ0FBd0RDLFFBQXhELEVBQXdFO0FBQUEsYUFDakRBLFFBRGlEO0FBQUEsTUFDOURDLENBRDhELFFBQzlEQSxDQUQ4RDtBQUFBLE1BQ3hEQyxFQUR3RDs7QUFFdEUsU0FBT0EsRUFBUDtBQUNEOztBQUVELFNBQVNDLHNCQUFULENBQWdDSCxRQUFoQyxFQUFpRUksSUFBakUsRUFBK0U7QUFDN0UsTUFBTUMsT0FBTyxHQUFHLFNBQVZBLE9BQVUsQ0FBQ0gsRUFBRDtBQUFBLDZDQUFzQixXQUF0QixFQUFvQ0UsSUFBcEMsR0FBNkNGLEVBQTdDO0FBQUEsR0FBaEI7O0FBQ0EsU0FBTyxlQUFjRixRQUFkLElBQTBCLHFCQUFBQSxRQUFRLE1BQVIsQ0FBQUEsUUFBUSxFQUFLSyxPQUFMLENBQWxDLEdBQWtEQSxPQUFPLENBQUNMLFFBQUQsQ0FBaEU7QUFDRDtBQUVEO0FBQ0E7QUFDQTs7O0FBQ0EsV0FBYU0sV0FBYjtBQUdFO0FBQ0Y7QUFDQTs7QUFHRTtBQUNGO0FBQ0E7O0FBR0U7QUFDRjtBQUNBO0FBQ0UsdUJBQVlDLElBQVosRUFBaUM7QUFBQTs7QUFBQTs7QUFBQSwwQ0FWVixJQVVVOztBQUFBLHlDQUxYLEtBS1c7O0FBQy9CLFNBQUtDLEtBQUwsR0FBYUQsSUFBYjtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTs7O0FBeEJBO0FBQUE7QUFBQTtBQUFBLCtGQTBCSUUsTUExQkosRUEyQklDLE9BM0JKLEVBNEJJQyxNQTVCSjtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUE4QlVDLGdCQUFBQSxZQTlCVixHQThCeUIsSUFBSWhCLElBQUosQ0FBUyxLQUFLWSxLQUFkLEVBQXFCO0FBQ3hDSyxrQkFBQUEsS0FBSyxFQUFFLHlDQURpQztBQUV4Q0Msa0JBQUFBLFdBQVcsK0NBQUssS0FBS04sS0FBTCxDQUFXTyxXQUFoQix1Q0FBK0MsS0FBS1AsS0FBTCxDQUFXUSxPQUExRDtBQUY2QixpQkFBckIsQ0E5QnpCO0FBQUE7QUFBQSx1QkFrQ3NCSixZQUFZLENBQUNLLE1BQWIsQ0FDaEJSLE1BRGdCLEVBRWhCQyxPQUZnQixFQUdoQkMsTUFBTSxHQUFJO0FBQUVPLGtCQUFBQSxNQUFNLEVBQUVQO0FBQVYsaUJBQUosR0FBd0NRLFNBSDlCLEVBSWhCckIsVUFKZ0IsQ0FsQ3RCOztBQUFBO0FBa0NVc0IsZ0JBQUFBLEdBbENWO0FBQUEsa0RBd0NXQSxHQUFHLENBQUNGLE1BeENmOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBMkNFO0FBQ0Y7QUFDQTs7QUE3Q0E7QUFBQTtBQUFBLDJCQTZEU2QsSUE3RFQsRUE2RHVCSixRQTdEdkIsRUE2RHdEO0FBQ3BELFVBQU1xQixPQUFPLEdBQUcsZUFBY3JCLFFBQWQsQ0FBaEI7O0FBQ0FBLE1BQUFBLFFBQVEsR0FBR0csc0JBQXNCLENBQUNILFFBQUQsRUFBV0ksSUFBWCxDQUFqQztBQUNBLFVBQU1PLE1BQU0sR0FBR1UsT0FBTyxHQUFHLENBQUN2QixVQUFVLENBQUN3QixVQUFaLENBQUgsR0FBNkJ4QixVQUFVLENBQUN3QixVQUE5RDtBQUNBLGFBQU8sS0FBS0MsT0FBTCxDQUFhLGdCQUFiLEVBQStCO0FBQUV2QixRQUFBQSxRQUFRLEVBQVJBO0FBQUYsT0FBL0IsRUFBNkNXLE1BQTdDLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUF0RUE7QUFBQTtBQUFBO0FBQUEsNkZBc0ZhUCxJQXRGYixFQXNGMkJvQixTQXRGM0I7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBdUZVQyxnQkFBQUEsZ0JBdkZWLEdBd0ZNckIsSUFBSSxJQUFJTixVQUFSLEdBQ0s7QUFDQ00sa0JBQUFBLElBQUksRUFBRU4sVUFBVSxDQUFDNEIsVUFBWCxDQUFzQnRCLElBRDdCO0FBRUN1QixrQkFBQUEsS0FBSyxFQUFFO0FBQ0xDLG9CQUFBQSxPQUFPLEVBQUUsQ0FBQ3hCLElBQUQ7QUFESjtBQUZSLGlCQURMLEdBT0lOLFVBQVUsQ0FBQzRCLFVBL0ZyQjtBQUFBO0FBQUEsdUJBZ0drQyxLQUFLSCxPQUFMLENBQzVCLGNBRDRCLEVBRTVCO0FBQUVuQixrQkFBQUEsSUFBSSxFQUFKQSxJQUFGO0FBQVFvQixrQkFBQUEsU0FBUyxFQUFUQTtBQUFSLGlCQUY0QixFQUc1QkMsZ0JBSDRCLENBaEdsQzs7QUFBQTtBQWdHVUwsZ0JBQUFBLEdBaEdWO0FBQUEsa0RBcUdXLGVBQWNJLFNBQWQsSUFDSCxpQ0FBQUosR0FBRyxDQUFDUSxPQUFKLGtCQUFnQjdCLDBCQUFoQixDQURHLEdBRUhBLDBCQUEwQixDQUFDcUIsR0FBRyxDQUFDUSxPQUFKLENBQVksQ0FBWixDQUFELENBdkdsQzs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQTBHRTtBQUNGO0FBQ0E7O0FBNUdBO0FBQUE7QUFBQSwyQkErSFN4QixJQS9IVCxFQStIdUJKLFFBL0h2QixFQStId0Q7QUFDcEQsVUFBTXFCLE9BQU8sR0FBRyxlQUFjckIsUUFBZCxDQUFoQjs7QUFDQUEsTUFBQUEsUUFBUSxHQUFHRyxzQkFBc0IsQ0FBQ0gsUUFBRCxFQUFXSSxJQUFYLENBQWpDO0FBQ0EsVUFBTU8sTUFBTSxHQUFHVSxPQUFPLEdBQUcsQ0FBQ3ZCLFVBQVUsQ0FBQ3dCLFVBQVosQ0FBSCxHQUE2QnhCLFVBQVUsQ0FBQ3dCLFVBQTlEO0FBQ0EsYUFBTyxLQUFLQyxPQUFMLENBQWEsZ0JBQWIsRUFBK0I7QUFBRXZCLFFBQUFBLFFBQVEsRUFBUkE7QUFBRixPQUEvQixFQUE2Q1csTUFBN0MsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQXhJQTtBQUFBO0FBQUEsMkJBd0pTUCxJQXhKVCxFQXdKdUJKLFFBeEp2QixFQXdKd0Q7QUFDcEQsVUFBTXFCLE9BQU8sR0FBRyxlQUFjckIsUUFBZCxDQUFoQjs7QUFDQUEsTUFBQUEsUUFBUSxHQUFHRyxzQkFBc0IsQ0FBQ0gsUUFBRCxFQUFXSSxJQUFYLENBQWpDO0FBQ0EsVUFBTU8sTUFBTSxHQUFHVSxPQUFPLEdBQ2xCLENBQUN2QixVQUFVLENBQUMrQixZQUFaLENBRGtCLEdBRWxCL0IsVUFBVSxDQUFDK0IsWUFGZjtBQUdBLGFBQU8sS0FBS04sT0FBTCxDQUFhLGdCQUFiLEVBQStCO0FBQUV2QixRQUFBQSxRQUFRLEVBQVJBO0FBQUYsT0FBL0IsRUFBNkNXLE1BQTdDLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUFuS0E7QUFBQTtBQUFBLDRCQTBLU1AsSUExS1QsRUEwS3VCb0IsU0ExS3ZCLEVBMEtxRDtBQUNqRCxVQUFNYixNQUFNLEdBQUcsZUFBY2EsU0FBZCxJQUNYLENBQUMxQixVQUFVLENBQUN3QixVQUFaLENBRFcsR0FFWHhCLFVBQVUsQ0FBQ3dCLFVBRmY7QUFHQSxhQUFPLEtBQUtDLE9BQUwsQ0FBYSxnQkFBYixFQUErQjtBQUFFbkIsUUFBQUEsSUFBSSxFQUFKQSxJQUFGO0FBQVFvQixRQUFBQSxTQUFTLEVBQVRBO0FBQVIsT0FBL0IsRUFBb0RiLE1BQXBELENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUFuTEE7QUFBQTtBQUFBLDJCQXFMSVAsSUFyTEosRUFzTEkwQixXQXRMSixFQXVMSUMsV0F2TEosRUF3THlCO0FBQ3JCLGFBQU8sS0FBS1IsT0FBTCxDQUNMLGdCQURLLEVBRUw7QUFBRW5CLFFBQUFBLElBQUksRUFBSkEsSUFBRjtBQUFRMEIsUUFBQUEsV0FBVyxFQUFYQSxXQUFSO0FBQXFCQyxRQUFBQSxXQUFXLEVBQVhBO0FBQXJCLE9BRkssRUFHTGpDLFVBQVUsQ0FBQ3dCLFVBSE4sQ0FBUDtBQUtEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTs7QUFwTUE7QUFBQTtBQUFBLDZCQXFNV1UsV0FyTVgsRUFxTWtFO0FBQzlELFVBQUksQ0FBQ0EsV0FBTCxFQUFrQjtBQUNoQkEsUUFBQUEsV0FBVyxHQUFHLEtBQUt4QixLQUFMLENBQVdRLE9BQXpCO0FBQ0Q7O0FBQ0QsYUFBTyxLQUFLTyxPQUFMLENBQ0wsa0JBREssRUFFTDtBQUFFUyxRQUFBQSxXQUFXLEVBQVhBO0FBQUYsT0FGSyxFQUdMbEMsVUFBVSxDQUFDbUMsc0JBSE4sQ0FBUDtBQUtEO0FBRUQ7QUFDRjtBQUNBOztBQWxOQTtBQUFBO0FBQUEseUJBb05JQyxPQXBOSixFQXFOSUYsV0FyTkosRUFzTitCO0FBQzNCLFVBQUksQ0FBQ0EsV0FBTCxFQUFrQjtBQUNoQkEsUUFBQUEsV0FBVyxHQUFHLEtBQUt4QixLQUFMLENBQVdRLE9BQXpCO0FBQ0Q7O0FBQ0QsYUFBTyxLQUFLTyxPQUFMLENBQWEsY0FBYixFQUE2QjtBQUFFVyxRQUFBQSxPQUFPLEVBQVBBLE9BQUY7QUFBV0YsUUFBQUEsV0FBVyxFQUFYQTtBQUFYLE9BQTdCLEVBQXVELENBQzVEbEMsVUFBVSxDQUFDcUMsY0FEaUQsQ0FBdkQsQ0FBUDtBQUdEO0FBRUQ7QUFDRjtBQUNBOztBQWpPQTtBQUFBO0FBQUEsZ0NBa09jQyxjQWxPZCxFQWtPc0M7QUFDbEMsVUFBTWhCLEdBQUcsR0FBRyxLQUFLRyxPQUFMLENBQ1YsYUFEVSxFQUVWO0FBQUVhLFFBQUFBLGNBQWMsRUFBZEE7QUFBRixPQUZVLEVBR1Z0QyxVQUFVLENBQUN1QyxXQUhELENBQVo7O0FBS0EsYUFBTyxJQUFJQyxrQkFBSixDQUF1QixJQUF2QixFQUE2QmxCLEdBQTdCLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUE3T0E7QUFBQTtBQUFBLDZCQThPV21CLE9BOU9YLEVBOE84QztBQUMxQyxVQUFNbkIsR0FBRyxHQUFHLEtBQUtHLE9BQUwsQ0FDVixVQURVLEVBRVY7QUFBRWdCLFFBQUFBLE9BQU8sRUFBUEE7QUFBRixPQUZVLEVBR1Z6QyxVQUFVLENBQUMwQyxjQUhELENBQVo7O0FBS0EsYUFBTyxJQUFJQyxxQkFBSixDQUEwQixJQUExQixFQUFnQ3JCLEdBQWhDLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUF6UEE7QUFBQTtBQUFBLHdDQTBQc0JnQixjQTFQdEIsRUEwUHVFO0FBQ25FLGFBQU8sS0FBS2IsT0FBTCxDQUNMLHFCQURLLEVBRUw7QUFBRWEsUUFBQUEsY0FBYyxFQUFkQTtBQUFGLE9BRkssRUFHTHRDLFVBQVUsQ0FBQzBDLGNBSE4sQ0FBUDtBQUtEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBeFFBO0FBQUE7QUFBQTtBQUFBLCtHQXlRc0NFLE9BelF0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUE2UVlDLGdCQUFBQSxFQTdRWixHQTZReUJELE9BN1F6QixDQTZRWUMsRUE3UVosRUE2UWdCQyxJQTdRaEIsR0E2UXlCRixPQTdRekIsQ0E2UWdCRSxJQTdRaEI7O0FBQUEscUJBK1FRQSxJQS9RUjtBQUFBO0FBQUE7QUFBQTs7QUFnUllDLGdCQUFBQSxXQWhSWixHQWdSMEIsZ0JBQWU7QUFDakNDLGtCQUFBQSx3QkFBd0IsRUFBRUg7QUFETyxpQkFBZixDQWhSMUI7QUFvUllJLGdCQUFBQSxXQXBSWixHQW9SdUM7QUFDL0J0QyxrQkFBQUEsTUFBTSxFQUFFLE1BRHVCO0FBRS9CdUMsa0JBQUFBLEdBQUcsWUFBSyxLQUFLeEMsS0FBTCxDQUFXeUMsUUFBWCxFQUFMLDRCQUY0QjtBQUcvQkMsa0JBQUFBLElBQUksRUFBRUwsV0FIeUI7QUFJL0JNLGtCQUFBQSxPQUFPLEVBQUU7QUFDUCxvQ0FBZ0I7QUFEVDtBQUpzQixpQkFwUnZDO0FBNFJZQyxnQkFBQUEsY0E1UlosR0E0UjZCO0FBQUVELGtCQUFBQSxPQUFPLEVBQUU7QUFBWCxpQkE1UjdCLEVBNlJNO0FBQ0E7QUFDQTs7QUEvUk47QUFBQSx1QkFpU2MsS0FBSzNDLEtBQUwsQ0FBVytCLE9BQVgsQ0FBbUNRLFdBQW5DLEVBQWdESyxjQUFoRCxDQWpTZDs7QUFBQTtBQWdTTUMsZ0JBQUFBLFFBaFNOLGtCQWtTUVYsRUFsU1I7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQSx1QkFvU3VCLEtBQUtwQixPQUFMLENBQWEsd0JBQWIsRUFBdUM7QUFDdEQrQixrQkFBQUEsWUFBWSxFQUFFWDtBQUR3QyxpQkFBdkMsQ0FwU3ZCOztBQUFBO0FBb1NNVSxnQkFBQUEsUUFwU047O0FBQUE7QUFBQSxrREF5U1dBLFFBelNYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBNFNFO0FBQ0Y7QUFDQTtBQUNBOztBQS9TQTtBQUFBO0FBQUEsK0JBaVRJRSxRQWpUSixFQW1UNEI7QUFBQSxVQUR4QmIsT0FDd0IsdUVBRFUsRUFDVjtBQUN4QixVQUFNYyxJQUFJLEdBQUcsSUFBSTlELFFBQUosRUFBYjtBQUNBOEQsTUFBQUEsSUFBSSxDQUFDQyxNQUFMLENBQVksTUFBWixFQUFvQkYsUUFBcEIsRUFBOEI7QUFDNUJHLFFBQUFBLFdBQVcsRUFBRSxpQkFEZTtBQUU1QkMsUUFBQUEsUUFBUSxFQUFFO0FBRmtCLE9BQTlCLEVBRndCLENBT3hCOztBQUNBSCxNQUFBQSxJQUFJLENBQUNDLE1BQUwsQ0FBWSxnQkFBWixFQUE4QixnQkFBZTtBQUFFRyxRQUFBQSxhQUFhLEVBQUVsQjtBQUFqQixPQUFmLENBQTlCLEVBQTBFO0FBQ3hFZ0IsUUFBQUEsV0FBVyxFQUFFO0FBRDJELE9BQTFFO0FBSUEsVUFBTW5CLE9BQW9CLEdBQUc7QUFDM0JTLFFBQUFBLEdBQUcsRUFBRSx5QkFEc0I7QUFFM0J2QyxRQUFBQSxNQUFNLEVBQUUsTUFGbUI7QUFHM0IwQyxRQUFBQSxPQUFPLG9CQUFPSyxJQUFJLENBQUNLLFVBQUwsRUFBUCxDQUhvQjtBQUkzQlgsUUFBQUEsSUFBSSxFQUFFTSxJQUFJLENBQUNNLFNBQUw7QUFKcUIsT0FBN0I7O0FBTUEsVUFBTTFDLEdBQUcsR0FBRyxLQUFLWixLQUFMLENBQVcrQixPQUFYLENBQWdDQSxPQUFoQyxDQUFaOztBQUVBLGFBQU8sSUFBSXdCLG1CQUFKLENBQXdCLElBQXhCLEVBQThCM0MsR0FBOUIsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQTVVQTtBQUFBO0FBQUEsMkJBOFVJbUMsUUE5VUosRUFnVjRCO0FBQUE7O0FBQUEsVUFEeEJiLE9BQ3dCLHVFQURVLEVBQ1Y7O0FBQ3hCLFVBQU10QixHQUFHLEdBQUcseURBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFDaUIsYUFBWSxVQUFDNEMsT0FBRCxFQUFVQyxNQUFWLEVBQXFCO0FBQzNELHNCQUNFcEUsUUFBUSxDQUFDMEQsUUFBRCxDQUFSLElBQ0EsVUFBVUEsUUFEVixJQUVBLE9BQU9BLFFBQVEsQ0FBQ1csSUFBaEIsS0FBeUIsVUFIM0IsRUFJRTtBQUNBLHdCQUFNQyxJQUFjLEdBQUcsRUFBdkI7QUFDQVosb0JBQUFBLFFBQVEsQ0FBQ2EsRUFBVCxDQUFZLE1BQVosRUFBb0IsVUFBQ0MsQ0FBRDtBQUFBLDZCQUFPRixJQUFJLENBQUNHLElBQUwsQ0FBVUQsQ0FBVixDQUFQO0FBQUEscUJBQXBCO0FBQ0FkLG9CQUFBQSxRQUFRLENBQUNhLEVBQVQsQ0FBWSxPQUFaLEVBQXFCSCxNQUFyQjtBQUNBVixvQkFBQUEsUUFBUSxDQUFDYSxFQUFULENBQVksS0FBWixFQUFtQixZQUFNO0FBQ3ZCSixzQkFBQUEsT0FBTyxDQUFDLHdCQUFBTyxNQUFNLE1BQU4sQ0FBQUEsTUFBTSxFQUFRSixJQUFSLENBQU4sQ0FBb0JLLFFBQXBCLENBQTZCLFFBQTdCLENBQUQsQ0FBUDtBQUNELHFCQUZELEVBSkEsQ0FPQTtBQUNELG1CQVpELE1BWU8sSUFBSWpCLFFBQVEsWUFBWWdCLE1BQXhCLEVBQWdDO0FBQ3JDUCxvQkFBQUEsT0FBTyxDQUFDVCxRQUFRLENBQUNpQixRQUFULENBQWtCLFFBQWxCLENBQUQsQ0FBUDtBQUNELG1CQUZNLE1BRUEsSUFBSWpCLFFBQVEsWUFBWWtCLE1BQXBCLElBQThCLE9BQU9sQixRQUFQLEtBQW9CLFFBQXRELEVBQWdFO0FBQ3JFUyxvQkFBQUEsT0FBTyxDQUFDVCxRQUFELENBQVA7QUFDRCxtQkFGTSxNQUVBO0FBQ0wsMEJBQU0sMEJBQU47QUFDRDtBQUNGLGlCQXBCMkIsQ0FEakI7O0FBQUE7QUFDTG1CLGdCQUFBQSxhQURLO0FBQUEsa0RBdUJKLEtBQUksQ0FBQ25ELE9BQUwsQ0FDTCxRQURLLEVBRUw7QUFDRW9ELGtCQUFBQSxPQUFPLEVBQUVELGFBRFg7QUFFRUUsa0JBQUFBLGFBQWEsRUFBRWxDO0FBRmpCLGlCQUZLLEVBTUw1QyxVQUFVLENBQUMrRSxZQU5OLENBdkJJOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BQUQsSUFBWjs7QUFpQ0EsYUFBTyxJQUFJZCxtQkFBSixDQUF3QixJQUF4QixFQUE4QjNDLEdBQTlCLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUF2WEE7QUFBQTtBQUFBLHNDQXlYSWdCLGNBelhKLEVBMlgyQjtBQUFBLFVBRHZCMEMsY0FDdUIsdUVBREcsS0FDSDtBQUN2QixhQUFPLEtBQUt2RCxPQUFMLENBQ0wsbUJBREssRUFFTDtBQUNFYSxRQUFBQSxjQUFjLEVBQWRBLGNBREY7QUFFRTBDLFFBQUFBLGNBQWMsRUFBZEE7QUFGRixPQUZLLEVBTUxoRixVQUFVLENBQUMrRSxZQU5OLENBQVA7QUFRRDtBQXBZSDs7QUFBQTtBQUFBO0FBdVlBOztBQUVBO0FBQ0E7QUFDQTs7QUFDQSxXQUFhdkMsa0JBQWI7QUFBQTs7QUFBQTs7QUFRRTtBQUNGO0FBQ0E7QUFDRSw4QkFBWXlDLElBQVosRUFBa0NDLE9BQWxDLEVBQWlFO0FBQUE7O0FBQUE7O0FBQy9EOztBQUQrRDs7QUFBQTs7QUFBQTs7QUFFL0QsV0FBS0MsS0FBTCxHQUFhRixJQUFiO0FBQ0EsV0FBS0csUUFBTCxHQUFnQkYsT0FBaEI7QUFIK0Q7QUFJaEU7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQXRCQTtBQUFBO0FBQUEseUJBd0JJRyxTQXhCSixFQXlCSUMsUUF6QkosRUEwQm9CO0FBQ2hCLGFBQU8sS0FBS0YsUUFBTCxDQUFjRyxJQUFkLENBQW1CRixTQUFuQixFQUE4QkMsUUFBOUIsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQWhDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWtDeUIsS0FBS0YsUUFsQzlCOztBQUFBO0FBa0NVaEUsZ0JBQUFBLE1BbENWO0FBbUNJLHFCQUFLb0UsR0FBTCxHQUFXcEUsTUFBTSxDQUFDeUIsRUFBbEI7QUFuQ0o7QUFBQSx1QkFvQ2lCLEtBQUtzQyxLQUFMLENBQVdNLFdBQVgsQ0FBdUJyRSxNQUFNLENBQUN5QixFQUE5QixDQXBDakI7O0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQXVDRTtBQUNGO0FBQ0E7O0FBekNBO0FBQUE7QUFBQSx5QkEwQ082QyxRQTFDUCxFQTBDeUJDLE9BMUN6QixFQTBDMEM7QUFBQTs7QUFDdEMsVUFBTUMsU0FBUyxHQUFHLElBQUlDLElBQUosR0FBV0MsT0FBWCxFQUFsQjs7QUFDQSxVQUFNQyxJQUFJO0FBQUEsNkVBQUc7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUhDLGtCQUFBQSxHQUZHLEdBRUcsSUFBSUgsSUFBSixHQUFXQyxPQUFYLEVBRkg7O0FBQUEsd0JBR0xGLFNBQVMsR0FBR0QsT0FBWixHQUFzQkssR0FIakI7QUFBQTtBQUFBO0FBQUE7O0FBSUhDLGtCQUFBQSxNQUpHLEdBSU0sbUJBSk47O0FBS1Asc0JBQUksTUFBSSxDQUFDVCxHQUFULEVBQWM7QUFDWlMsb0JBQUFBLE1BQU0sSUFBSSxtQkFBbUIsTUFBSSxDQUFDVCxHQUFsQztBQUNEOztBQUNELGtCQUFBLE1BQUksQ0FBQ1UsSUFBTCxDQUFVLE9BQVYsRUFBbUIsSUFBSUMsS0FBSixDQUFVRixNQUFWLENBQW5COztBQVJPOztBQUFBO0FBQUE7QUFBQSx5QkFXWSxNQUFJLENBQUNHLEtBQUwsRUFYWjs7QUFBQTtBQVdIaEYsa0JBQUFBLE9BWEc7O0FBWVQsc0JBQUlBLE9BQU0sQ0FBQ2lGLElBQVgsRUFBaUI7QUFDZixvQkFBQSxNQUFJLENBQUNILElBQUwsQ0FBVSxVQUFWLEVBQXNCOUUsT0FBdEI7QUFDRCxtQkFGRCxNQUVPO0FBQ0wsb0JBQUEsTUFBSSxDQUFDOEUsSUFBTCxDQUFVLFVBQVYsRUFBc0I5RSxPQUF0Qjs7QUFDQSxnQ0FBVzJFLElBQVgsRUFBaUJMLFFBQWpCO0FBQ0Q7O0FBakJRO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQW1CVCxrQkFBQSxNQUFJLENBQUNRLElBQUwsQ0FBVSxPQUFWOztBQW5CUztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFIOztBQUFBLHdCQUFKSCxJQUFJO0FBQUE7QUFBQTtBQUFBLFNBQVY7O0FBc0JBLGtCQUFXQSxJQUFYLEVBQWlCTCxRQUFqQjtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQXZFQTtBQUFBO0FBQUEsK0JBd0VhO0FBQUE7O0FBQ1QsYUFBTyxhQUFlLFVBQUN4QixPQUFELEVBQVVDLE1BQVYsRUFBcUI7QUFDekMsUUFBQSxNQUFJLENBQUNHLEVBQUwsQ0FBUSxVQUFSLEVBQW9CSixPQUFwQjs7QUFDQSxRQUFBLE1BQUksQ0FBQ0ksRUFBTCxDQUFRLE9BQVIsRUFBaUJILE1BQWpCOztBQUNBLFFBQUEsTUFBSSxDQUFDNEIsSUFBTCxDQUFVLE1BQUksQ0FBQ1osS0FBTCxDQUFXbUIsWUFBckIsRUFBbUMsTUFBSSxDQUFDbkIsS0FBTCxDQUFXb0IsV0FBOUM7QUFDRCxPQUpNLENBQVA7QUFLRDtBQTlFSDs7QUFBQTtBQUFBLEVBR1U3RyxZQUhWO0FBaUZBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQSxXQUFhaUQscUJBQWI7QUFBQTs7QUFBQTs7QUFBQTtBQUFBOztBQUFBO0FBQUE7O0FBQUE7QUFBQTs7QUFJRTtBQUNGO0FBQ0E7QUFDQTtBQVBBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQVNVdkIsZ0JBQUFBLE1BVFY7QUFBQSxrREFVVyxLQUFLK0QsS0FBTCxDQUFXcUIsbUJBQVgsQ0FBK0JwRixNQUFNLENBQUN5QixFQUF0QyxDQVZYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBYUU7QUFDRjtBQUNBOztBQWZBO0FBQUE7QUFBQSw2QkFnQlc7QUFBQTs7QUFDUCxVQUFNNEQsWUFBWSxHQUFHLElBQUk5RyxRQUFKLEVBQXJCO0FBQ0EsVUFBSStHLE9BQU8sR0FBRyxLQUFkO0FBQ0FELE1BQUFBLFlBQVksQ0FBQ0UsS0FBYix5RUFBcUI7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUNmRCxPQURlO0FBQUE7QUFBQTtBQUFBOztBQUFBOztBQUFBO0FBSW5CQSxnQkFBQUEsT0FBTyxHQUFHLElBQVY7QUFKbUI7QUFBQTtBQUFBLHVCQU1JLE1BQUksQ0FBQ0UsUUFBTCxFQU5KOztBQUFBO0FBTVh4RixnQkFBQUEsUUFOVztBQU9qQnFGLGdCQUFBQSxZQUFZLENBQUNqQyxJQUFiLENBQWtCQyxNQUFNLENBQUNvQyxJQUFQLENBQVl6RixRQUFNLENBQUMwRixPQUFuQixFQUE0QixRQUE1QixDQUFsQjtBQUNBTCxnQkFBQUEsWUFBWSxDQUFDakMsSUFBYixDQUFrQixJQUFsQjtBQVJpQjtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQVVqQmlDLGdCQUFBQSxZQUFZLENBQUNQLElBQWIsQ0FBa0IsT0FBbEI7O0FBVmlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BQXJCO0FBYUEsYUFBT08sWUFBUDtBQUNEO0FBakNIOztBQUFBO0FBQUEsRUFBNkRqRSxrQkFBN0Q7QUFvQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFdBQWF5QixtQkFBYjtBQUFBOztBQUFBOztBQUFBO0FBQUE7O0FBQUE7QUFBQTs7QUFBQTtBQUFBOztBQUlFO0FBQ0Y7QUFDQTtBQUNBO0FBUEE7QUFBQSxrR0FRaUJlLGNBUmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFTVTVELGdCQUFBQSxNQVRWO0FBQUEsbURBVVcsS0FBSytELEtBQUwsQ0FBVzRCLGlCQUFYLENBQTZCM0YsTUFBTSxDQUFDeUIsRUFBcEMsRUFBd0NtQyxjQUF4QyxDQVZYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSxFQUEyRHhDLGtCQUEzRDtBQWNBOztBQUNBO0FBQ0E7QUFDQTs7QUFDQTNDLGNBQWMsQ0FBQyxVQUFELEVBQWEsVUFBQ1ksSUFBRDtBQUFBLFNBQVUsSUFBSUQsV0FBSixDQUFnQkMsSUFBaEIsQ0FBVjtBQUFBLENBQWIsQ0FBZDtBQUVBLGVBQWVELFdBQWYiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBmaWxlIE1hbmFnZXMgU2FsZXNmb3JjZSBNZXRhZGF0YSBBUElcbiAqIEBhdXRob3IgU2hpbmljaGkgVG9taXRhIDxzaGluaWNoaS50b21pdGFAZ21haWwuY29tPlxuICovXG5pbXBvcnQgeyBFdmVudEVtaXR0ZXIgfSBmcm9tICdldmVudHMnO1xuaW1wb3J0IHsgUmVhZGFibGUgfSBmcm9tICdzdHJlYW0nO1xuaW1wb3J0IEZvcm1EYXRhIGZyb20gJ2Zvcm0tZGF0YSc7XG5pbXBvcnQgeyByZWdpc3Rlck1vZHVsZSB9IGZyb20gJy4uL2pzZm9yY2UnO1xuaW1wb3J0IENvbm5lY3Rpb24gZnJvbSAnLi4vY29ubmVjdGlvbic7XG5pbXBvcnQgU09BUCBmcm9tICcuLi9zb2FwJztcbmltcG9ydCB7IGlzT2JqZWN0IH0gZnJvbSAnLi4vdXRpbC9mdW5jdGlvbic7XG5pbXBvcnQgeyBTY2hlbWEsIFNvYXBTY2hlbWFEZWYsIFNvYXBTY2hlbWEsIEh0dHBSZXF1ZXN0IH0gZnJvbSAnLi4vdHlwZXMnO1xuaW1wb3J0IHtcbiAgQXBpU2NoZW1hcyxcbiAgTWV0YWRhdGEsXG4gIFJlYWRSZXN1bHQsXG4gIFNhdmVSZXN1bHQsXG4gIFVwc2VydFJlc3VsdCxcbiAgTGlzdE1ldGFkYXRhUXVlcnksXG4gIEZpbGVQcm9wZXJ0aWVzLFxuICBEZXNjcmliZU1ldGFkYXRhUmVzdWx0LFxuICBSZXRyaWV2ZVJlcXVlc3QsXG4gIERlcGxveU9wdGlvbnMsXG4gIFJldHJpZXZlUmVzdWx0LFxuICBEZXBsb3lSZXN1bHQsXG4gIEFzeW5jUmVzdWx0LFxuICBBcGlTY2hlbWFUeXBlcyxcbn0gZnJvbSAnLi9tZXRhZGF0YS9zY2hlbWEnO1xuZXhwb3J0ICogZnJvbSAnLi9tZXRhZGF0YS9zY2hlbWEnO1xuXG4vKipcbiAqXG4gKi9cbnR5cGUgTWV0YWRhdGFUeXBlXzxcbiAgSyBleHRlbmRzIGtleW9mIEFwaVNjaGVtYVR5cGVzID0ga2V5b2YgQXBpU2NoZW1hVHlwZXNcbj4gPSBLIGV4dGVuZHMga2V5b2YgQXBpU2NoZW1hVHlwZXNcbiAgPyBBcGlTY2hlbWFUeXBlc1tLXSBleHRlbmRzIE1ldGFkYXRhXG4gICAgPyBLXG4gICAgOiBuZXZlclxuICA6IG5ldmVyO1xuXG5leHBvcnQgdHlwZSBNZXRhZGF0YVR5cGUgPSBNZXRhZGF0YVR5cGVfO1xuXG5leHBvcnQgdHlwZSBNZXRhZGF0YURlZmluaXRpb248XG4gIFQgZXh0ZW5kcyBzdHJpbmcsXG4gIE0gZXh0ZW5kcyBNZXRhZGF0YSA9IE1ldGFkYXRhXG4+ID0gTWV0YWRhdGEgZXh0ZW5kcyBNXG4gID8gVCBleHRlbmRzIGtleW9mIEFwaVNjaGVtYVR5cGVzICYgTWV0YWRhdGFUeXBlXG4gICAgPyBBcGlTY2hlbWFUeXBlc1tUXSBleHRlbmRzIE1ldGFkYXRhXG4gICAgICA/IEFwaVNjaGVtYVR5cGVzW1RdXG4gICAgICA6IE1ldGFkYXRhXG4gICAgOiBNZXRhZGF0YVxuICA6IE07XG5cbnR5cGUgRGVlcFBhcnRpYWw8VD4gPSBUIGV4dGVuZHMgYW55W11cbiAgPyBEZWVwUGFydGlhbDxUW251bWJlcl0+W11cbiAgOiBUIGV4dGVuZHMgb2JqZWN0XG4gID8geyBbSyBpbiBrZXlvZiBUXT86IERlZXBQYXJ0aWFsPFRbS10+IH1cbiAgOiBUO1xuXG5leHBvcnQgdHlwZSBJbnB1dE1ldGFkYXRhRGVmaW5pdGlvbjxcbiAgVCBleHRlbmRzIHN0cmluZyxcbiAgTSBleHRlbmRzIE1ldGFkYXRhID0gTWV0YWRhdGFcbj4gPSBEZWVwUGFydGlhbDxNZXRhZGF0YURlZmluaXRpb248VCwgTT4+O1xuXG4vKipcbiAqXG4gKi9cbmZ1bmN0aW9uIGRlYWxsb2NhdGVUeXBlV2l0aE1ldGFkYXRhPE0gZXh0ZW5kcyBNZXRhZGF0YT4obWV0YWRhdGE6IE0pOiBNIHtcbiAgY29uc3QgeyAkLCAuLi5tZCB9ID0gbWV0YWRhdGEgYXMgYW55O1xuICByZXR1cm4gbWQ7XG59XG5cbmZ1bmN0aW9uIGFzc2lnblR5cGVXaXRoTWV0YWRhdGEobWV0YWRhdGE6IE1ldGFkYXRhIHwgTWV0YWRhdGFbXSwgdHlwZTogc3RyaW5nKSB7XG4gIGNvbnN0IGNvbnZlcnQgPSAobWQ6IE1ldGFkYXRhKSA9PiAoeyBbJ0B4c2k6dHlwZSddOiB0eXBlLCAuLi5tZCB9KTtcbiAgcmV0dXJuIEFycmF5LmlzQXJyYXkobWV0YWRhdGEpID8gbWV0YWRhdGEubWFwKGNvbnZlcnQpIDogY29udmVydChtZXRhZGF0YSk7XG59XG5cbi8qKlxuICogQ2xhc3MgZm9yIFNhbGVzZm9yY2UgTWV0YWRhdGEgQVBJXG4gKi9cbmV4cG9ydCBjbGFzcyBNZXRhZGF0YUFwaTxTIGV4dGVuZHMgU2NoZW1hPiB7XG4gIF9jb25uOiBDb25uZWN0aW9uPFM+O1xuXG4gIC8qKlxuICAgKiBQb2xsaW5nIGludGVydmFsIGluIG1pbGxpc2Vjb25kc1xuICAgKi9cbiAgcG9sbEludGVydmFsOiBudW1iZXIgPSAxMDAwO1xuXG4gIC8qKlxuICAgKiBQb2xsaW5nIHRpbWVvdXQgaW4gbWlsbGlzZWNvbmRzXG4gICAqL1xuICBwb2xsVGltZW91dDogbnVtYmVyID0gMTAwMDA7XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBjb25zdHJ1Y3Rvcihjb25uOiBDb25uZWN0aW9uPFM+KSB7XG4gICAgdGhpcy5fY29ubiA9IGNvbm47XG4gIH1cblxuICAvKipcbiAgICogQ2FsbCBNZXRhZGF0YSBBUEkgU09BUCBlbmRwb2ludFxuICAgKlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgYXN5bmMgX2ludm9rZShcbiAgICBtZXRob2Q6IHN0cmluZyxcbiAgICBtZXNzYWdlOiBvYmplY3QsXG4gICAgc2NoZW1hPzogU29hcFNjaGVtYSB8IFNvYXBTY2hlbWFEZWYsXG4gICkge1xuICAgIGNvbnN0IHNvYXBFbmRwb2ludCA9IG5ldyBTT0FQKHRoaXMuX2Nvbm4sIHtcbiAgICAgIHhtbG5zOiAnaHR0cDovL3NvYXAuc2ZvcmNlLmNvbS8yMDA2LzA0L21ldGFkYXRhJyxcbiAgICAgIGVuZHBvaW50VXJsOiBgJHt0aGlzLl9jb25uLmluc3RhbmNlVXJsfS9zZXJ2aWNlcy9Tb2FwL20vJHt0aGlzLl9jb25uLnZlcnNpb259YCxcbiAgICB9KTtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBzb2FwRW5kcG9pbnQuaW52b2tlKFxuICAgICAgbWV0aG9kLFxuICAgICAgbWVzc2FnZSxcbiAgICAgIHNjaGVtYSA/ICh7IHJlc3VsdDogc2NoZW1hIH0gYXMgU29hcFNjaGVtYSkgOiB1bmRlZmluZWQsXG4gICAgICBBcGlTY2hlbWFzLFxuICAgICk7XG4gICAgcmV0dXJuIHJlcy5yZXN1bHQ7XG4gIH1cblxuICAvKipcbiAgICogQWRkIG9uZSBvciBtb3JlIG5ldyBtZXRhZGF0YSBjb21wb25lbnRzIHRvIHRoZSBvcmdhbml6YXRpb24uXG4gICAqL1xuICBjcmVhdGU8XG4gICAgTSBleHRlbmRzIE1ldGFkYXRhID0gTWV0YWRhdGEsXG4gICAgVCBleHRlbmRzIE1ldGFkYXRhVHlwZSA9IE1ldGFkYXRhVHlwZSxcbiAgICBNRCBleHRlbmRzIElucHV0TWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+ID0gSW5wdXRNZXRhZGF0YURlZmluaXRpb248VCwgTT5cbiAgPih0eXBlOiBULCBtZXRhZGF0YTogTURbXSk6IFByb21pc2U8U2F2ZVJlc3VsdFtdPjtcbiAgY3JlYXRlPFxuICAgIE0gZXh0ZW5kcyBNZXRhZGF0YSA9IE1ldGFkYXRhLFxuICAgIFQgZXh0ZW5kcyBNZXRhZGF0YVR5cGUgPSBNZXRhZGF0YVR5cGUsXG4gICAgTUQgZXh0ZW5kcyBJbnB1dE1ldGFkYXRhRGVmaW5pdGlvbjxULCBNPiA9IElucHV0TWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+XG4gID4odHlwZTogVCwgbWV0YWRhdGE6IE1EKTogUHJvbWlzZTxTYXZlUmVzdWx0PjtcbiAgY3JlYXRlPFxuICAgIE0gZXh0ZW5kcyBNZXRhZGF0YSA9IE1ldGFkYXRhLFxuICAgIFQgZXh0ZW5kcyBNZXRhZGF0YVR5cGUgPSBNZXRhZGF0YVR5cGUsXG4gICAgTUQgZXh0ZW5kcyBJbnB1dE1ldGFkYXRhRGVmaW5pdGlvbjxULCBNPiA9IElucHV0TWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+XG4gID4odHlwZTogVCwgbWV0YWRhdGE6IE1EIHwgTURbXSk6IFByb21pc2U8U2F2ZVJlc3VsdCB8IFNhdmVSZXN1bHRbXT47XG4gIGNyZWF0ZSh0eXBlOiBzdHJpbmcsIG1ldGFkYXRhOiBNZXRhZGF0YSB8IE1ldGFkYXRhW10pIHtcbiAgICBjb25zdCBpc0FycmF5ID0gQXJyYXkuaXNBcnJheShtZXRhZGF0YSk7XG4gICAgbWV0YWRhdGEgPSBhc3NpZ25UeXBlV2l0aE1ldGFkYXRhKG1ldGFkYXRhLCB0eXBlKTtcbiAgICBjb25zdCBzY2hlbWEgPSBpc0FycmF5ID8gW0FwaVNjaGVtYXMuU2F2ZVJlc3VsdF0gOiBBcGlTY2hlbWFzLlNhdmVSZXN1bHQ7XG4gICAgcmV0dXJuIHRoaXMuX2ludm9rZSgnY3JlYXRlTWV0YWRhdGEnLCB7IG1ldGFkYXRhIH0sIHNjaGVtYSk7XG4gIH1cblxuICAvKipcbiAgICogUmVhZCBzcGVjaWZpZWQgbWV0YWRhdGEgY29tcG9uZW50cyBpbiB0aGUgb3JnYW5pemF0aW9uLlxuICAgKi9cbiAgcmVhZDxcbiAgICBNIGV4dGVuZHMgTWV0YWRhdGEgPSBNZXRhZGF0YSxcbiAgICBUIGV4dGVuZHMgTWV0YWRhdGFUeXBlID0gTWV0YWRhdGFUeXBlLFxuICAgIE1EIGV4dGVuZHMgTWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+ID0gTWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+XG4gID4odHlwZTogVCwgZnVsbE5hbWVzOiBzdHJpbmdbXSk6IFByb21pc2U8TURbXT47XG4gIHJlYWQ8XG4gICAgTSBleHRlbmRzIE1ldGFkYXRhID0gTWV0YWRhdGEsXG4gICAgVCBleHRlbmRzIE1ldGFkYXRhVHlwZSA9IE1ldGFkYXRhVHlwZSxcbiAgICBNRCBleHRlbmRzIE1ldGFkYXRhRGVmaW5pdGlvbjxULCBNPiA9IE1ldGFkYXRhRGVmaW5pdGlvbjxULCBNPlxuICA+KHR5cGU6IFQsIGZ1bGxOYW1lczogc3RyaW5nKTogUHJvbWlzZTxNRD47XG4gIHJlYWQ8XG4gICAgTSBleHRlbmRzIE1ldGFkYXRhID0gTWV0YWRhdGEsXG4gICAgVCBleHRlbmRzIE1ldGFkYXRhVHlwZSA9IE1ldGFkYXRhVHlwZSxcbiAgICBNRCBleHRlbmRzIE1ldGFkYXRhRGVmaW5pdGlvbjxULCBNPiA9IE1ldGFkYXRhRGVmaW5pdGlvbjxULCBNPlxuICA+KHR5cGU6IFQsIGZ1bGxOYW1lczogc3RyaW5nIHwgc3RyaW5nW10pOiBQcm9taXNlPE1EIHwgTURbXT47XG4gIGFzeW5jIHJlYWQodHlwZTogc3RyaW5nLCBmdWxsTmFtZXM6IHN0cmluZyB8IHN0cmluZ1tdKSB7XG4gICAgY29uc3QgUmVhZFJlc3VsdFNjaGVtYSA9XG4gICAgICB0eXBlIGluIEFwaVNjaGVtYXNcbiAgICAgICAgPyAoe1xuICAgICAgICAgICAgdHlwZTogQXBpU2NoZW1hcy5SZWFkUmVzdWx0LnR5cGUsXG4gICAgICAgICAgICBwcm9wczoge1xuICAgICAgICAgICAgICByZWNvcmRzOiBbdHlwZV0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0gYXMgY29uc3QpXG4gICAgICAgIDogQXBpU2NoZW1hcy5SZWFkUmVzdWx0O1xuICAgIGNvbnN0IHJlczogUmVhZFJlc3VsdCA9IGF3YWl0IHRoaXMuX2ludm9rZShcbiAgICAgICdyZWFkTWV0YWRhdGEnLFxuICAgICAgeyB0eXBlLCBmdWxsTmFtZXMgfSxcbiAgICAgIFJlYWRSZXN1bHRTY2hlbWEsXG4gICAgKTtcbiAgICByZXR1cm4gQXJyYXkuaXNBcnJheShmdWxsTmFtZXMpXG4gICAgICA/IHJlcy5yZWNvcmRzLm1hcChkZWFsbG9jYXRlVHlwZVdpdGhNZXRhZGF0YSlcbiAgICAgIDogZGVhbGxvY2F0ZVR5cGVXaXRoTWV0YWRhdGEocmVzLnJlY29yZHNbMF0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFVwZGF0ZSBvbmUgb3IgbW9yZSBtZXRhZGF0YSBjb21wb25lbnRzIGluIHRoZSBvcmdhbml6YXRpb24uXG4gICAqL1xuICB1cGRhdGU8XG4gICAgTSBleHRlbmRzIE1ldGFkYXRhID0gTWV0YWRhdGEsXG4gICAgVCBleHRlbmRzIHN0cmluZyA9IHN0cmluZyxcbiAgICBNRCBleHRlbmRzIElucHV0TWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+ID0gSW5wdXRNZXRhZGF0YURlZmluaXRpb248VCwgTT5cbiAgPih0eXBlOiBULCBtZXRhZGF0YTogUGFydGlhbDxNRD5bXSk6IFByb21pc2U8U2F2ZVJlc3VsdFtdPjtcbiAgdXBkYXRlPFxuICAgIE0gZXh0ZW5kcyBNZXRhZGF0YSA9IE1ldGFkYXRhLFxuICAgIFQgZXh0ZW5kcyBzdHJpbmcgPSBzdHJpbmcsXG4gICAgTUQgZXh0ZW5kcyBJbnB1dE1ldGFkYXRhRGVmaW5pdGlvbjxULCBNPiA9IElucHV0TWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+XG4gID4odHlwZTogVCwgbWV0YWRhdGE6IFBhcnRpYWw8TUQ+KTogUHJvbWlzZTxTYXZlUmVzdWx0PjtcbiAgdXBkYXRlPFxuICAgIE0gZXh0ZW5kcyBNZXRhZGF0YSA9IE1ldGFkYXRhLFxuICAgIFQgZXh0ZW5kcyBzdHJpbmcgPSBzdHJpbmcsXG4gICAgTUQgZXh0ZW5kcyBJbnB1dE1ldGFkYXRhRGVmaW5pdGlvbjxULCBNPiA9IElucHV0TWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+XG4gID4oXG4gICAgdHlwZTogVCxcbiAgICBtZXRhZGF0YTogUGFydGlhbDxNRD4gfCBQYXJ0aWFsPE1EPltdLFxuICApOiBQcm9taXNlPFNhdmVSZXN1bHQgfCBTYXZlUmVzdWx0W10+O1xuICB1cGRhdGUodHlwZTogc3RyaW5nLCBtZXRhZGF0YTogTWV0YWRhdGEgfCBNZXRhZGF0YVtdKSB7XG4gICAgY29uc3QgaXNBcnJheSA9IEFycmF5LmlzQXJyYXkobWV0YWRhdGEpO1xuICAgIG1ldGFkYXRhID0gYXNzaWduVHlwZVdpdGhNZXRhZGF0YShtZXRhZGF0YSwgdHlwZSk7XG4gICAgY29uc3Qgc2NoZW1hID0gaXNBcnJheSA/IFtBcGlTY2hlbWFzLlNhdmVSZXN1bHRdIDogQXBpU2NoZW1hcy5TYXZlUmVzdWx0O1xuICAgIHJldHVybiB0aGlzLl9pbnZva2UoJ3VwZGF0ZU1ldGFkYXRhJywgeyBtZXRhZGF0YSB9LCBzY2hlbWEpO1xuICB9XG5cbiAgLyoqXG4gICAqIFVwc2VydCBvbmUgb3IgbW9yZSBjb21wb25lbnRzIGluIHlvdXIgb3JnYW5pemF0aW9uJ3MgZGF0YS5cbiAgICovXG4gIHVwc2VydDxcbiAgICBNIGV4dGVuZHMgTWV0YWRhdGEgPSBNZXRhZGF0YSxcbiAgICBUIGV4dGVuZHMgc3RyaW5nID0gc3RyaW5nLFxuICAgIE1EIGV4dGVuZHMgSW5wdXRNZXRhZGF0YURlZmluaXRpb248VCwgTT4gPSBJbnB1dE1ldGFkYXRhRGVmaW5pdGlvbjxULCBNPlxuICA+KHR5cGU6IFQsIG1ldGFkYXRhOiBNRFtdKTogUHJvbWlzZTxVcHNlcnRSZXN1bHRbXT47XG4gIHVwc2VydDxcbiAgICBNIGV4dGVuZHMgTWV0YWRhdGEgPSBNZXRhZGF0YSxcbiAgICBUIGV4dGVuZHMgc3RyaW5nID0gc3RyaW5nLFxuICAgIE1EIGV4dGVuZHMgSW5wdXRNZXRhZGF0YURlZmluaXRpb248VCwgTT4gPSBJbnB1dE1ldGFkYXRhRGVmaW5pdGlvbjxULCBNPlxuICA+KHR5cGU6IFQsIG1ldGFkYXRhOiBNRCk6IFByb21pc2U8VXBzZXJ0UmVzdWx0PjtcbiAgdXBzZXJ0PFxuICAgIE0gZXh0ZW5kcyBNZXRhZGF0YSA9IE1ldGFkYXRhLFxuICAgIFQgZXh0ZW5kcyBzdHJpbmcgPSBzdHJpbmcsXG4gICAgTUQgZXh0ZW5kcyBJbnB1dE1ldGFkYXRhRGVmaW5pdGlvbjxULCBNPiA9IElucHV0TWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+XG4gID4odHlwZTogVCwgbWV0YWRhdGE6IE1EIHwgTURbXSk6IFByb21pc2U8VXBzZXJ0UmVzdWx0IHwgVXBzZXJ0UmVzdWx0W10+O1xuICB1cHNlcnQodHlwZTogc3RyaW5nLCBtZXRhZGF0YTogTWV0YWRhdGEgfCBNZXRhZGF0YVtdKSB7XG4gICAgY29uc3QgaXNBcnJheSA9IEFycmF5LmlzQXJyYXkobWV0YWRhdGEpO1xuICAgIG1ldGFkYXRhID0gYXNzaWduVHlwZVdpdGhNZXRhZGF0YShtZXRhZGF0YSwgdHlwZSk7XG4gICAgY29uc3Qgc2NoZW1hID0gaXNBcnJheVxuICAgICAgPyBbQXBpU2NoZW1hcy5VcHNlcnRSZXN1bHRdXG4gICAgICA6IEFwaVNjaGVtYXMuVXBzZXJ0UmVzdWx0O1xuICAgIHJldHVybiB0aGlzLl9pbnZva2UoJ3Vwc2VydE1ldGFkYXRhJywgeyBtZXRhZGF0YSB9LCBzY2hlbWEpO1xuICB9XG5cbiAgLyoqXG4gICAqIERlbGV0ZXMgc3BlY2lmaWVkIG1ldGFkYXRhIGNvbXBvbmVudHMgaW4gdGhlIG9yZ2FuaXphdGlvbi5cbiAgICovXG4gIGRlbGV0ZSh0eXBlOiBzdHJpbmcsIGZ1bGxOYW1lczogc3RyaW5nW10pOiBQcm9taXNlPFNhdmVSZXN1bHRbXT47XG4gIGRlbGV0ZSh0eXBlOiBzdHJpbmcsIGZ1bGxOYW1lczogc3RyaW5nKTogUHJvbWlzZTxTYXZlUmVzdWx0PjtcbiAgZGVsZXRlKFxuICAgIHR5cGU6IHN0cmluZyxcbiAgICBmdWxsTmFtZXM6IHN0cmluZyB8IHN0cmluZ1tdLFxuICApOiBQcm9taXNlPFNhdmVSZXN1bHQgfCBTYXZlUmVzdWx0W10+O1xuICBkZWxldGUodHlwZTogc3RyaW5nLCBmdWxsTmFtZXM6IHN0cmluZyB8IHN0cmluZ1tdKSB7XG4gICAgY29uc3Qgc2NoZW1hID0gQXJyYXkuaXNBcnJheShmdWxsTmFtZXMpXG4gICAgICA/IFtBcGlTY2hlbWFzLlNhdmVSZXN1bHRdXG4gICAgICA6IEFwaVNjaGVtYXMuU2F2ZVJlc3VsdDtcbiAgICByZXR1cm4gdGhpcy5faW52b2tlKCdkZWxldGVNZXRhZGF0YScsIHsgdHlwZSwgZnVsbE5hbWVzIH0sIHNjaGVtYSk7XG4gIH1cblxuICAvKipcbiAgICogUmVuYW1lIGZ1bGxuYW1lIG9mIGEgbWV0YWRhdGEgY29tcG9uZW50IGluIHRoZSBvcmdhbml6YXRpb25cbiAgICovXG4gIHJlbmFtZShcbiAgICB0eXBlOiBzdHJpbmcsXG4gICAgb2xkRnVsbE5hbWU6IHN0cmluZyxcbiAgICBuZXdGdWxsTmFtZTogc3RyaW5nLFxuICApOiBQcm9taXNlPFNhdmVSZXN1bHQ+IHtcbiAgICByZXR1cm4gdGhpcy5faW52b2tlKFxuICAgICAgJ3JlbmFtZU1ldGFkYXRhJyxcbiAgICAgIHsgdHlwZSwgb2xkRnVsbE5hbWUsIG5ld0Z1bGxOYW1lIH0sXG4gICAgICBBcGlTY2hlbWFzLlNhdmVSZXN1bHQsXG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXRyaWV2ZXMgdGhlIG1ldGFkYXRhIHdoaWNoIGRlc2NyaWJlcyB5b3VyIG9yZ2FuaXphdGlvbiwgaW5jbHVkaW5nIEFwZXggY2xhc3NlcyBhbmQgdHJpZ2dlcnMsXG4gICAqIGN1c3RvbSBvYmplY3RzLCBjdXN0b20gZmllbGRzIG9uIHN0YW5kYXJkIG9iamVjdHMsIHRhYiBzZXRzIHRoYXQgZGVmaW5lIGFuIGFwcCxcbiAgICogYW5kIG1hbnkgb3RoZXIgY29tcG9uZW50cy5cbiAgICovXG4gIGRlc2NyaWJlKGFzT2ZWZXJzaW9uPzogc3RyaW5nKTogUHJvbWlzZTxEZXNjcmliZU1ldGFkYXRhUmVzdWx0PiB7XG4gICAgaWYgKCFhc09mVmVyc2lvbikge1xuICAgICAgYXNPZlZlcnNpb24gPSB0aGlzLl9jb25uLnZlcnNpb247XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9pbnZva2UoXG4gICAgICAnZGVzY3JpYmVNZXRhZGF0YScsXG4gICAgICB7IGFzT2ZWZXJzaW9uIH0sXG4gICAgICBBcGlTY2hlbWFzLkRlc2NyaWJlTWV0YWRhdGFSZXN1bHQsXG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXRyaWV2ZXMgcHJvcGVydHkgaW5mb3JtYXRpb24gYWJvdXQgbWV0YWRhdGEgY29tcG9uZW50cyBpbiB5b3VyIG9yZ2FuaXphdGlvblxuICAgKi9cbiAgbGlzdChcbiAgICBxdWVyaWVzOiBMaXN0TWV0YWRhdGFRdWVyeSB8IExpc3RNZXRhZGF0YVF1ZXJ5W10sXG4gICAgYXNPZlZlcnNpb24/OiBzdHJpbmcsXG4gICk6IFByb21pc2U8RmlsZVByb3BlcnRpZXNbXT4ge1xuICAgIGlmICghYXNPZlZlcnNpb24pIHtcbiAgICAgIGFzT2ZWZXJzaW9uID0gdGhpcy5fY29ubi52ZXJzaW9uO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5faW52b2tlKCdsaXN0TWV0YWRhdGEnLCB7IHF1ZXJpZXMsIGFzT2ZWZXJzaW9uIH0sIFtcbiAgICAgIEFwaVNjaGVtYXMuRmlsZVByb3BlcnRpZXMsXG4gICAgXSk7XG4gIH1cblxuICAvKipcbiAgICogQ2hlY2tzIHRoZSBzdGF0dXMgb2YgYXN5bmNocm9ub3VzIG1ldGFkYXRhIGNhbGxzXG4gICAqL1xuICBjaGVja1N0YXR1cyhhc3luY1Byb2Nlc3NJZDogc3RyaW5nKSB7XG4gICAgY29uc3QgcmVzID0gdGhpcy5faW52b2tlKFxuICAgICAgJ2NoZWNrU3RhdHVzJyxcbiAgICAgIHsgYXN5bmNQcm9jZXNzSWQgfSxcbiAgICAgIEFwaVNjaGVtYXMuQXN5bmNSZXN1bHQsXG4gICAgKTtcbiAgICByZXR1cm4gbmV3IEFzeW5jUmVzdWx0TG9jYXRvcih0aGlzLCByZXMpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHJpZXZlcyBYTUwgZmlsZSByZXByZXNlbnRhdGlvbnMgb2YgY29tcG9uZW50cyBpbiBhbiBvcmdhbml6YXRpb25cbiAgICovXG4gIHJldHJpZXZlKHJlcXVlc3Q6IFBhcnRpYWw8UmV0cmlldmVSZXF1ZXN0Pikge1xuICAgIGNvbnN0IHJlcyA9IHRoaXMuX2ludm9rZShcbiAgICAgICdyZXRyaWV2ZScsXG4gICAgICB7IHJlcXVlc3QgfSxcbiAgICAgIEFwaVNjaGVtYXMuUmV0cmlldmVSZXN1bHQsXG4gICAgKTtcbiAgICByZXR1cm4gbmV3IFJldHJpZXZlUmVzdWx0TG9jYXRvcih0aGlzLCByZXMpO1xuICB9XG5cbiAgLyoqXG4gICAqIENoZWNrcyB0aGUgc3RhdHVzIG9mIGRlY2xhcmF0aXZlIG1ldGFkYXRhIGNhbGwgcmV0cmlldmUoKSBhbmQgcmV0dXJucyB0aGUgemlwIGZpbGUgY29udGVudHNcbiAgICovXG4gIGNoZWNrUmV0cmlldmVTdGF0dXMoYXN5bmNQcm9jZXNzSWQ6IHN0cmluZyk6IFByb21pc2U8UmV0cmlldmVSZXN1bHQ+IHtcbiAgICByZXR1cm4gdGhpcy5faW52b2tlKFxuICAgICAgJ2NoZWNrUmV0cmlldmVTdGF0dXMnLFxuICAgICAgeyBhc3luY1Byb2Nlc3NJZCB9LFxuICAgICAgQXBpU2NoZW1hcy5SZXRyaWV2ZVJlc3VsdCxcbiAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIFdpbGwgZGVwbG95IGEgcmVjZW50bHkgdmFsaWRhdGVkIGRlcGxveSByZXF1ZXN0XG4gICAqXG4gICAqIEBwYXJhbSBvcHRpb25zLmlkID0gdGhlIGRlcGxveSBJRCB0aGF0J3MgYmVlbiB2YWxpZGF0ZWQgYWxyZWFkeSBmcm9tIGEgcHJldmlvdXMgY2hlY2tPbmx5IGRlcGxveSByZXF1ZXN0XG4gICAqIEBwYXJhbSBvcHRpb25zLnJlc3QgPSBhIGJvb2xlYW4gd2hldGhlciBvciBub3QgdG8gdXNlIHRoZSBSRVNUIEFQSVxuICAgKiBAcmV0dXJucyB0aGUgZGVwbG95IElEIG9mIHRoZSByZWNlbnQgdmFsaWRhdGlvbiByZXF1ZXN0XG4gICAqL1xuICBwdWJsaWMgYXN5bmMgZGVwbG95UmVjZW50VmFsaWRhdGlvbihvcHRpb25zOiB7XG4gICAgaWQ6IHN0cmluZztcbiAgICByZXN0PzogYm9vbGVhbjtcbiAgfSk6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgY29uc3QgeyBpZCwgcmVzdCB9ID0gb3B0aW9ucztcbiAgICBsZXQgcmVzcG9uc2U6IHN0cmluZztcbiAgICBpZiAocmVzdCkge1xuICAgICAgY29uc3QgbWVzc2FnZUJvZHkgPSBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHZhbGlkYXRlZERlcGxveVJlcXVlc3RJZDogaWQsXG4gICAgICB9KTtcblxuICAgICAgY29uc3QgcmVxdWVzdEluZm86IEh0dHBSZXF1ZXN0ID0ge1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgdXJsOiBgJHt0aGlzLl9jb25uLl9iYXNlVXJsKCl9L21ldGFkYXRhL2RlcGxveVJlcXVlc3RgLFxuICAgICAgICBib2R5OiBtZXNzYWdlQm9keSxcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICdjb250ZW50LXR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgIH0sXG4gICAgICB9O1xuICAgICAgY29uc3QgcmVxdWVzdE9wdGlvbnMgPSB7IGhlYWRlcnM6ICdqc29uJyB9O1xuICAgICAgLy8gVGhpcyBpcyB0aGUgZGVwbG95IElEIG9mIHRoZSBkZXBsb3lSZWNlbnRWYWxpZGF0aW9uIHJlc3BvbnNlLCBub3RcbiAgICAgIC8vIHRoZSBhbHJlYWR5IHZhbGlkYXRlZCBkZXBsb3kgSUQgKGkuZS4sIHZhbGlkYXRlZGRlcGxveXJlcXVlc3RpZCkuXG4gICAgICAvLyBSRVNUIHJldHVybnMgYW4gb2JqZWN0IHdpdGggYW4gaWQgcHJvcGVydHksIFNPQVAgcmV0dXJucyB0aGUgaWQgYXMgYSBzdHJpbmcgZGlyZWN0bHkuXG4gICAgICByZXNwb25zZSA9IChcbiAgICAgICAgYXdhaXQgdGhpcy5fY29ubi5yZXF1ZXN0PHsgaWQ6IHN0cmluZyB9PihyZXF1ZXN0SW5mbywgcmVxdWVzdE9wdGlvbnMpXG4gICAgICApLmlkO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXNwb25zZSA9IGF3YWl0IHRoaXMuX2ludm9rZSgnZGVwbG95UmVjZW50VmFsaWRhdGlvbicsIHtcbiAgICAgICAgdmFsaWRhdGlvbklkOiBpZCxcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIHJldHVybiByZXNwb25zZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZXBsb3kgY29tcG9uZW50cyBpbnRvIGFuIG9yZ2FuaXphdGlvbiB1c2luZyB6aXBwZWQgZmlsZSByZXByZXNlbnRhdGlvbnNcbiAgICogdXNpbmcgdGhlIFJFU1QgTWV0YWRhdGEgQVBJIGluc3RlYWQgb2YgU09BUFxuICAgKi9cbiAgZGVwbG95UmVzdChcbiAgICB6aXBJbnB1dDogQnVmZmVyLFxuICAgIG9wdGlvbnM6IFBhcnRpYWw8RGVwbG95T3B0aW9ucz4gPSB7fSxcbiAgKTogRGVwbG95UmVzdWx0TG9jYXRvcjxTPiB7XG4gICAgY29uc3QgZm9ybSA9IG5ldyBGb3JtRGF0YSgpO1xuICAgIGZvcm0uYXBwZW5kKCdmaWxlJywgemlwSW5wdXQsIHtcbiAgICAgIGNvbnRlbnRUeXBlOiAnYXBwbGljYXRpb24vemlwJyxcbiAgICAgIGZpbGVuYW1lOiAncGFja2FnZS54bWwnLFxuICAgIH0pO1xuXG4gICAgLy8gQWRkIHRoZSBkZXBsb3kgb3B0aW9uc1xuICAgIGZvcm0uYXBwZW5kKCdlbnRpdHlfY29udGVudCcsIEpTT04uc3RyaW5naWZ5KHsgZGVwbG95T3B0aW9uczogb3B0aW9ucyB9KSwge1xuICAgICAgY29udGVudFR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICB9KTtcblxuICAgIGNvbnN0IHJlcXVlc3Q6IEh0dHBSZXF1ZXN0ID0ge1xuICAgICAgdXJsOiAnL21ldGFkYXRhL2RlcGxveVJlcXVlc3QnLFxuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICBoZWFkZXJzOiB7IC4uLmZvcm0uZ2V0SGVhZGVycygpIH0sXG4gICAgICBib2R5OiBmb3JtLmdldEJ1ZmZlcigpLFxuICAgIH07XG4gICAgY29uc3QgcmVzID0gdGhpcy5fY29ubi5yZXF1ZXN0PEFzeW5jUmVzdWx0PihyZXF1ZXN0KTtcblxuICAgIHJldHVybiBuZXcgRGVwbG95UmVzdWx0TG9jYXRvcih0aGlzLCByZXMpO1xuICB9XG5cbiAgLyoqXG4gICAqIERlcGxveSBjb21wb25lbnRzIGludG8gYW4gb3JnYW5pemF0aW9uIHVzaW5nIHppcHBlZCBmaWxlIHJlcHJlc2VudGF0aW9uc1xuICAgKi9cbiAgZGVwbG95KFxuICAgIHppcElucHV0OiBSZWFkYWJsZSB8IEJ1ZmZlciB8IHN0cmluZyxcbiAgICBvcHRpb25zOiBQYXJ0aWFsPERlcGxveU9wdGlvbnM+ID0ge30sXG4gICk6IERlcGxveVJlc3VsdExvY2F0b3I8Uz4ge1xuICAgIGNvbnN0IHJlcyA9IChhc3luYyAoKSA9PiB7XG4gICAgICBjb25zdCB6aXBDb250ZW50QjY0ID0gYXdhaXQgbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICBpZiAoXG4gICAgICAgICAgaXNPYmplY3QoemlwSW5wdXQpICYmXG4gICAgICAgICAgJ3BpcGUnIGluIHppcElucHV0ICYmXG4gICAgICAgICAgdHlwZW9mIHppcElucHV0LnBpcGUgPT09ICdmdW5jdGlvbidcbiAgICAgICAgKSB7XG4gICAgICAgICAgY29uc3QgYnVmczogQnVmZmVyW10gPSBbXTtcbiAgICAgICAgICB6aXBJbnB1dC5vbignZGF0YScsIChkKSA9PiBidWZzLnB1c2goZCkpO1xuICAgICAgICAgIHppcElucHV0Lm9uKCdlcnJvcicsIHJlamVjdCk7XG4gICAgICAgICAgemlwSW5wdXQub24oJ2VuZCcsICgpID0+IHtcbiAgICAgICAgICAgIHJlc29sdmUoQnVmZmVyLmNvbmNhdChidWZzKS50b1N0cmluZygnYmFzZTY0JykpO1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIC8vIHppcElucHV0LnJlc3VtZSgpO1xuICAgICAgICB9IGVsc2UgaWYgKHppcElucHV0IGluc3RhbmNlb2YgQnVmZmVyKSB7XG4gICAgICAgICAgcmVzb2x2ZSh6aXBJbnB1dC50b1N0cmluZygnYmFzZTY0JykpO1xuICAgICAgICB9IGVsc2UgaWYgKHppcElucHV0IGluc3RhbmNlb2YgU3RyaW5nIHx8IHR5cGVvZiB6aXBJbnB1dCA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICByZXNvbHZlKHppcElucHV0KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aHJvdyAnVW5leHBlY3RlZCB6aXBJbnB1dCB0eXBlJztcbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICAgIHJldHVybiB0aGlzLl9pbnZva2UoXG4gICAgICAgICdkZXBsb3knLFxuICAgICAgICB7XG4gICAgICAgICAgWmlwRmlsZTogemlwQ29udGVudEI2NCxcbiAgICAgICAgICBEZXBsb3lPcHRpb25zOiBvcHRpb25zLFxuICAgICAgICB9LFxuICAgICAgICBBcGlTY2hlbWFzLkRlcGxveVJlc3VsdCxcbiAgICAgICk7XG4gICAgfSkoKTtcblxuICAgIHJldHVybiBuZXcgRGVwbG95UmVzdWx0TG9jYXRvcih0aGlzLCByZXMpO1xuICB9XG5cbiAgLyoqXG4gICAqIENoZWNrcyB0aGUgc3RhdHVzIG9mIGRlY2xhcmF0aXZlIG1ldGFkYXRhIGNhbGwgZGVwbG95KClcbiAgICovXG4gIGNoZWNrRGVwbG95U3RhdHVzKFxuICAgIGFzeW5jUHJvY2Vzc0lkOiBzdHJpbmcsXG4gICAgaW5jbHVkZURldGFpbHM6IGJvb2xlYW4gPSBmYWxzZSxcbiAgKTogUHJvbWlzZTxEZXBsb3lSZXN1bHQ+IHtcbiAgICByZXR1cm4gdGhpcy5faW52b2tlKFxuICAgICAgJ2NoZWNrRGVwbG95U3RhdHVzJyxcbiAgICAgIHtcbiAgICAgICAgYXN5bmNQcm9jZXNzSWQsXG4gICAgICAgIGluY2x1ZGVEZXRhaWxzLFxuICAgICAgfSxcbiAgICAgIEFwaVNjaGVtYXMuRGVwbG95UmVzdWx0LFxuICAgICk7XG4gIH1cbn1cblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbi8qKlxuICogVGhlIGxvY2F0b3IgY2xhc3MgZm9yIE1ldGFkYXRhIEFQSSBhc3luY2hyb25vdXMgY2FsbCByZXN1bHRcbiAqL1xuZXhwb3J0IGNsYXNzIEFzeW5jUmVzdWx0TG9jYXRvcjxcbiAgUyBleHRlbmRzIFNjaGVtYSxcbiAgUiBleHRlbmRzIHt9ID0gQXN5bmNSZXN1bHRcbj4gZXh0ZW5kcyBFdmVudEVtaXR0ZXIge1xuICBfbWV0YTogTWV0YWRhdGFBcGk8Uz47XG4gIF9wcm9taXNlOiBQcm9taXNlPEFzeW5jUmVzdWx0PjtcbiAgX2lkOiBzdHJpbmcgfCB1bmRlZmluZWQ7XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBjb25zdHJ1Y3RvcihtZXRhOiBNZXRhZGF0YUFwaTxTPiwgcHJvbWlzZTogUHJvbWlzZTxBc3luY1Jlc3VsdD4pIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuX21ldGEgPSBtZXRhO1xuICAgIHRoaXMuX3Byb21pc2UgPSBwcm9taXNlO1xuICB9XG5cbiAgLyoqXG4gICAqIFByb21pc2UvQSsgaW50ZXJmYWNlXG4gICAqIGh0dHA6Ly9wcm9taXNlcy1hcGx1cy5naXRodWIuaW8vcHJvbWlzZXMtc3BlYy9cbiAgICpcbiAgICogQG1ldGhvZCBNZXRhZGF0YX5Bc3luY1Jlc3VsdExvY2F0b3IjdGhlblxuICAgKi9cbiAgdGhlbjxVLCBWPihcbiAgICBvblJlc29sdmU/OiAoKHJlc3VsdDogQXN5bmNSZXN1bHQpID0+IFUgfCBQcm9taXNlPFU+KSB8IG51bGwgfCB1bmRlZmluZWQsXG4gICAgb25SZWplY3Q/OiAoKGVycjogRXJyb3IpID0+IFYgfCBQcm9taXNlPFY+KSB8IG51bGwgfCB1bmRlZmluZWQsXG4gICk6IFByb21pc2U8VSB8IFY+IHtcbiAgICByZXR1cm4gdGhpcy5fcHJvbWlzZS50aGVuKG9uUmVzb2x2ZSwgb25SZWplY3QpO1xuICB9XG5cbiAgLyoqXG4gICAqIENoZWNrIHRoZSBzdGF0dXMgb2YgYXN5bmMgcmVxdWVzdFxuICAgKi9cbiAgYXN5bmMgY2hlY2soKSB7XG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdGhpcy5fcHJvbWlzZTtcbiAgICB0aGlzLl9pZCA9IHJlc3VsdC5pZDtcbiAgICByZXR1cm4gYXdhaXQgdGhpcy5fbWV0YS5jaGVja1N0YXR1cyhyZXN1bHQuaWQpO1xuICB9XG5cbiAgLyoqXG4gICAqIFBvbGxpbmcgdW50aWwgYXN5bmMgY2FsbCBzdGF0dXMgYmVjb21lcyBjb21wbGV0ZSBvciBlcnJvclxuICAgKi9cbiAgcG9sbChpbnRlcnZhbDogbnVtYmVyLCB0aW1lb3V0OiBudW1iZXIpIHtcbiAgICBjb25zdCBzdGFydFRpbWUgPSBuZXcgRGF0ZSgpLmdldFRpbWUoKTtcbiAgICBjb25zdCBwb2xsID0gYXN5bmMgKCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XG4gICAgICAgIGlmIChzdGFydFRpbWUgKyB0aW1lb3V0IDwgbm93KSB7XG4gICAgICAgICAgbGV0IGVyck1zZyA9ICdQb2xsaW5nIHRpbWUgb3V0Lic7XG4gICAgICAgICAgaWYgKHRoaXMuX2lkKSB7XG4gICAgICAgICAgICBlcnJNc2cgKz0gJyBQcm9jZXNzIElkID0gJyArIHRoaXMuX2lkO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgbmV3IEVycm9yKGVyck1zZykpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB0aGlzLmNoZWNrKCk7XG4gICAgICAgIGlmIChyZXN1bHQuZG9uZSkge1xuICAgICAgICAgIHRoaXMuZW1pdCgnY29tcGxldGUnLCByZXN1bHQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRoaXMuZW1pdCgncHJvZ3Jlc3MnLCByZXN1bHQpO1xuICAgICAgICAgIHNldFRpbWVvdXQocG9sbCwgaW50ZXJ2YWwpO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycik7XG4gICAgICB9XG4gICAgfTtcbiAgICBzZXRUaW1lb3V0KHBvbGwsIGludGVydmFsKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDaGVjayBhbmQgd2FpdCB1bnRpbCB0aGUgYXN5bmMgcmVxdWVzdHMgYmVjb21lIGluIGNvbXBsZXRlZCBzdGF0dXNcbiAgICovXG4gIGNvbXBsZXRlKCkge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZTxSPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICB0aGlzLm9uKCdjb21wbGV0ZScsIHJlc29sdmUpO1xuICAgICAgdGhpcy5vbignZXJyb3InLCByZWplY3QpO1xuICAgICAgdGhpcy5wb2xsKHRoaXMuX21ldGEucG9sbEludGVydmFsLCB0aGlzLl9tZXRhLnBvbGxUaW1lb3V0KTtcbiAgICB9KTtcbiAgfVxufVxuXG4vKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cbi8qKlxuICogVGhlIGxvY2F0b3IgY2xhc3MgdG8gdHJhY2sgcmV0cmVpdmUoKSBNZXRhZGF0YSBBUEkgY2FsbCByZXN1bHRcbiAqL1xuZXhwb3J0IGNsYXNzIFJldHJpZXZlUmVzdWx0TG9jYXRvcjxTIGV4dGVuZHMgU2NoZW1hPiBleHRlbmRzIEFzeW5jUmVzdWx0TG9jYXRvcjxcbiAgUyxcbiAgUmV0cmlldmVSZXN1bHRcbj4ge1xuICAvKipcbiAgICogQ2hlY2sgYW5kIHdhaXQgdW50aWwgdGhlIGFzeW5jIHJlcXVlc3QgYmVjb21lcyBpbiBjb21wbGV0ZWQgc3RhdHVzLFxuICAgKiBhbmQgcmV0cmlldmUgdGhlIHJlc3VsdCBkYXRhLlxuICAgKi9cbiAgYXN5bmMgY29tcGxldGUoKSB7XG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgc3VwZXIuY29tcGxldGUoKTtcbiAgICByZXR1cm4gdGhpcy5fbWV0YS5jaGVja1JldHJpZXZlU3RhdHVzKHJlc3VsdC5pZCk7XG4gIH1cblxuICAvKipcbiAgICogQ2hhbmdlIHRoZSByZXRyaWV2ZWQgcmVzdWx0IHRvIE5vZGUuanMgcmVhZGFibGUgc3RyZWFtXG4gICAqL1xuICBzdHJlYW0oKSB7XG4gICAgY29uc3QgcmVzdWx0U3RyZWFtID0gbmV3IFJlYWRhYmxlKCk7XG4gICAgbGV0IHJlYWRpbmcgPSBmYWxzZTtcbiAgICByZXN1bHRTdHJlYW0uX3JlYWQgPSBhc3luYyAoKSA9PiB7XG4gICAgICBpZiAocmVhZGluZykge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICByZWFkaW5nID0gdHJ1ZTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHRoaXMuY29tcGxldGUoKTtcbiAgICAgICAgcmVzdWx0U3RyZWFtLnB1c2goQnVmZmVyLmZyb20ocmVzdWx0LnppcEZpbGUsICdiYXNlNjQnKSk7XG4gICAgICAgIHJlc3VsdFN0cmVhbS5wdXNoKG51bGwpO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICByZXN1bHRTdHJlYW0uZW1pdCgnZXJyb3InLCBlKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIHJldHVybiByZXN1bHRTdHJlYW07XG4gIH1cbn1cblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG4vKipcbiAqIFRoZSBsb2NhdG9yIGNsYXNzIHRvIHRyYWNrIGRlcGxveSgpIE1ldGFkYXRhIEFQSSBjYWxsIHJlc3VsdFxuICpcbiAqIEBwcm90ZWN0ZWRcbiAqIEBjbGFzcyBNZXRhZGF0YX5EZXBsb3lSZXN1bHRMb2NhdG9yXG4gKiBAZXh0ZW5kcyBNZXRhZGF0YX5Bc3luY1Jlc3VsdExvY2F0b3JcbiAqIEBwYXJhbSB7TWV0YWRhdGF9IG1ldGEgLSBNZXRhZGF0YSBBUEkgb2JqZWN0XG4gKiBAcGFyYW0ge1Byb21pc2UuPE1ldGFkYXRhfkFzeW5jUmVzdWx0Pn0gcmVzdWx0IC0gUHJvbWlzZSBvYmplY3QgZm9yIGFzeW5jIHJlc3VsdCBvZiBkZXBsb3koKSBjYWxsXG4gKi9cbmV4cG9ydCBjbGFzcyBEZXBsb3lSZXN1bHRMb2NhdG9yPFMgZXh0ZW5kcyBTY2hlbWE+IGV4dGVuZHMgQXN5bmNSZXN1bHRMb2NhdG9yPFxuICBTLFxuICBEZXBsb3lSZXN1bHRcbj4ge1xuICAvKipcbiAgICogQ2hlY2sgYW5kIHdhaXQgdW50aWwgdGhlIGFzeW5jIHJlcXVlc3QgYmVjb21lcyBpbiBjb21wbGV0ZWQgc3RhdHVzLFxuICAgKiBhbmQgcmV0cmlldmUgdGhlIHJlc3VsdCBkYXRhLlxuICAgKi9cbiAgYXN5bmMgY29tcGxldGUoaW5jbHVkZURldGFpbHM/OiBib29sZWFuKSB7XG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgc3VwZXIuY29tcGxldGUoKTtcbiAgICByZXR1cm4gdGhpcy5fbWV0YS5jaGVja0RlcGxveVN0YXR1cyhyZXN1bHQuaWQsIGluY2x1ZGVEZXRhaWxzKTtcbiAgfVxufVxuXG4vKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cbi8qXG4gKiBSZWdpc3RlciBob29rIGluIGNvbm5lY3Rpb24gaW5zdGFudGlhdGlvbiBmb3IgZHluYW1pY2FsbHkgYWRkaW5nIHRoaXMgQVBJIG1vZHVsZSBmZWF0dXJlc1xuICovXG5yZWdpc3Rlck1vZHVsZSgnbWV0YWRhdGEnLCAoY29ubikgPT4gbmV3IE1ldGFkYXRhQXBpKGNvbm4pKTtcblxuZXhwb3J0IGRlZmF1bHQgTWV0YWRhdGFBcGk7XG4iXX0=