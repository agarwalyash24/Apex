import _getIterator from "@babel/runtime-corejs3/core-js/get-iterator";
import _getIteratorMethod from "@babel/runtime-corejs3/core-js/get-iterator-method";
import _Symbol from "@babel/runtime-corejs3/core-js-stable/symbol";
import _Array$from from "@babel/runtime-corejs3/core-js-stable/array/from";
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import "core-js/modules/es.array.iterator";
import "core-js/modules/es.array.join";
import "core-js/modules/es.function.name";
import "core-js/modules/es.object.to-string";
import "core-js/modules/es.promise";
import "core-js/modules/es.regexp.exec";
import "core-js/modules/es.string.iterator";
import "core-js/modules/es.string.match";
import "core-js/modules/es.string.replace";
import "core-js/modules/web.dom-collections.iterator";
import _WeakMap from "@babel/runtime-corejs3/core-js-stable/weak-map";
import _slicedToArray from "@babel/runtime-corejs3/helpers/slicedToArray";
import _Date$now from "@babel/runtime-corejs3/core-js-stable/date/now";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _classPrivateFieldGet from "@babel/runtime-corejs3/helpers/classPrivateFieldGet";
import _classPrivateFieldSet from "@babel/runtime-corejs3/helpers/classPrivateFieldSet";
import _typeof from "@babel/runtime-corejs3/helpers/typeof";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _setTimeout from "@babel/runtime-corejs3/core-js-stable/set-timeout";
import _parseInt from "@babel/runtime-corejs3/core-js-stable/parse-int";
import _Object$keys2 from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _objectWithoutProperties from "@babel/runtime-corejs3/helpers/objectWithoutProperties";
import _wrapNativeSuper from "@babel/runtime-corejs3/helpers/wrapNativeSuper";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import "regenerator-runtime/runtime";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _trimInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/trim";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _assertThisInitialized from "@babel/runtime-corejs3/helpers/assertThisInitialized";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof _Symbol === "undefined" || _getIteratorMethod(o) == null) { if (_Array$isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = _getIterator(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { var _context43; if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = _sliceInstanceProperty(_context43 = Object.prototype.toString.call(o)).call(_context43, 8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return _Array$from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function ownKeys(object, enumerableOnly) { var keys = _Object$keys2(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context41; _forEachInstanceProperty(_context41 = ownKeys(Object(source), true)).call(_context41, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context42; _forEachInstanceProperty(_context42 = ownKeys(Object(source))).call(_context42, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = _Reflect$construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !_Reflect$construct) return false; if (_Reflect$construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(_Reflect$construct(Date, [], function () {})); return true; } catch (e) { return false; } }

/**
 * @file Manages Salesforce Bulk API related operations
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { EventEmitter } from 'events';
import { Writable } from 'stream';
import joinStreams from 'multistream';
import { Serializable, Parsable } from '../record-stream';
import HttpApi from '../http-api';
import { registerModule } from '../jsforce';
import { concatStreamsAsDuplex } from '../util/stream';
import { isFunction, isObject } from '../util/function';
/*--------------------------------------------*/

/**
 * Class for Bulk API Job
 */
export var Job = /*#__PURE__*/function (_EventEmitter) {
  _inherits(Job, _EventEmitter);

  var _super = _createSuper(Job);

  /**
   *
   */
  function Job(bulk, type, operation, options, jobId) {
    var _this;

    _classCallCheck(this, Job);

    _this = _super.call(this);

    _defineProperty(_assertThisInitialized(_this), "type", void 0);

    _defineProperty(_assertThisInitialized(_this), "operation", void 0);

    _defineProperty(_assertThisInitialized(_this), "options", void 0);

    _defineProperty(_assertThisInitialized(_this), "id", void 0);

    _defineProperty(_assertThisInitialized(_this), "state", void 0);

    _defineProperty(_assertThisInitialized(_this), "_bulk", void 0);

    _defineProperty(_assertThisInitialized(_this), "_batches", void 0);

    _defineProperty(_assertThisInitialized(_this), "_jobInfo", void 0);

    _defineProperty(_assertThisInitialized(_this), "_error", void 0);

    _this._bulk = bulk;
    _this.type = type;
    _this.operation = operation;
    _this.options = options || {};
    _this.id = jobId !== null && jobId !== void 0 ? jobId : null;
    _this.state = _this.id ? 'Open' : 'Unknown';
    _this._batches = {}; // default error handler to keep the latest error

    _this.on('error', function (error) {
      return _this._error = error;
    });

    return _this;
  }
  /**
   * Return latest jobInfo from cache
   */


  _createClass(Job, [{
    key: "info",
    value: function info() {
      // if cache is not available, check the latest
      if (!this._jobInfo) {
        this._jobInfo = this.check();
      }

      return this._jobInfo;
    }
    /**
     * Open new job and get jobinfo
     */

  }, {
    key: "open",
    value: function open() {
      var _this2 = this;

      var bulk = this._bulk;
      var options = this.options; // if sobject type / operation is not provided

      if (!this.type || !this.operation) {
        throw new Error('type / operation is required to open a new job');
      } // if not requested opening job


      if (!this._jobInfo) {
        var _context, _context2, _context3, _context4, _context5;

        var _operation = this.operation.toLowerCase();

        if (_operation === 'harddelete') {
          _operation = 'hardDelete';
        }

        if (_operation === 'queryall') {
          _operation = 'queryAll';
        }

        var body = _trimInstanceProperty(_context = _concatInstanceProperty(_context2 = _concatInstanceProperty(_context3 = _concatInstanceProperty(_context4 = _concatInstanceProperty(_context5 = "\n<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<jobInfo  xmlns=\"http://www.force.com/2009/06/asyncapi/dataload\">\n  <operation>".concat(_operation, "</operation>\n  <object>")).call(_context5, this.type, "</object>\n  ")).call(_context4, options.extIdField ? "<externalIdFieldName>".concat(options.extIdField, "</externalIdFieldName>") : '', "\n  ")).call(_context3, options.concurrencyMode ? "<concurrencyMode>".concat(options.concurrencyMode, "</concurrencyMode>") : '', "\n  ")).call(_context2, options.assignmentRuleId ? "<assignmentRuleId>".concat(options.assignmentRuleId, "</assignmentRuleId>") : '', "\n  <contentType>CSV</contentType>\n</jobInfo>\n      ")).call(_context);

        this._jobInfo = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee() {
          var _res;

          return _regeneratorRuntime.wrap(function _callee$(_context6) {
            while (1) {
              switch (_context6.prev = _context6.next) {
                case 0:
                  _context6.prev = 0;
                  _context6.next = 3;
                  return bulk._request({
                    method: 'POST',
                    path: '/job',
                    body: body,
                    headers: {
                      'Content-Type': 'application/xml; charset=utf-8'
                    },
                    responseType: 'application/xml'
                  });

                case 3:
                  _res = _context6.sent;

                  _this2.emit('open', _res.jobInfo);

                  _this2.id = _res.jobInfo.id;
                  _this2.state = _res.jobInfo.state;
                  return _context6.abrupt("return", _res.jobInfo);

                case 10:
                  _context6.prev = 10;
                  _context6.t0 = _context6["catch"](0);

                  _this2.emit('error', _context6.t0);

                  throw _context6.t0;

                case 14:
                case "end":
                  return _context6.stop();
              }
            }
          }, _callee, null, [[0, 10]]);
        }))();
      }

      return this._jobInfo;
    }
    /**
     * Create a new batch instance in the job
     */

  }, {
    key: "createBatch",
    value: function createBatch() {
      var _this3 = this;

      var batch = new Batch(this);
      batch.on('queue', function () {
        _this3._batches[batch.id] = batch;
      });
      return batch;
    }
    /**
     * Get a batch instance specified by given batch ID
     */

  }, {
    key: "batch",
    value: function batch(batchId) {
      var batch = this._batches[batchId];

      if (!batch) {
        batch = new Batch(this, batchId);
        this._batches[batchId] = batch;
      }

      return batch;
    }
    /**
     * Check the latest job status from server
     */

  }, {
    key: "check",
    value: function check() {
      var _this4 = this;

      var bulk = this._bulk;
      var logger = bulk._logger;
      this._jobInfo = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee2() {
        var jobId, res;
        return _regeneratorRuntime.wrap(function _callee2$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                _context7.next = 2;
                return _this4.ready();

              case 2:
                jobId = _context7.sent;
                _context7.next = 5;
                return bulk._request({
                  method: 'GET',
                  path: '/job/' + jobId,
                  responseType: 'application/xml'
                });

              case 5:
                res = _context7.sent;
                logger.debug(res.jobInfo);
                _this4.id = res.jobInfo.id;
                _this4.type = res.jobInfo.object;
                _this4.operation = res.jobInfo.operation;
                _this4.state = res.jobInfo.state;
                return _context7.abrupt("return", res.jobInfo);

              case 12:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee2);
      }))();
      return this._jobInfo;
    }
    /**
     * Wait till the job is assigned to server
     */

  }, {
    key: "ready",
    value: function ready() {
      return this.id ? _Promise.resolve(this.id) : this.open().then(function (_ref3) {
        var id = _ref3.id;
        return id;
      });
    }
    /**
     * List all registered batch info in job
     */

  }, {
    key: "list",
    value: function () {
      var _list = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee3() {
        var bulk, logger, jobId, res, batchInfoList;
        return _regeneratorRuntime.wrap(function _callee3$(_context8) {
          while (1) {
            switch (_context8.prev = _context8.next) {
              case 0:
                bulk = this._bulk;
                logger = bulk._logger;
                _context8.next = 4;
                return this.ready();

              case 4:
                jobId = _context8.sent;
                _context8.next = 7;
                return bulk._request({
                  method: 'GET',
                  path: '/job/' + jobId + '/batch',
                  responseType: 'application/xml'
                });

              case 7:
                res = _context8.sent;
                logger.debug(res.batchInfoList.batchInfo);
                batchInfoList = _Array$isArray(res.batchInfoList.batchInfo) ? res.batchInfoList.batchInfo : [res.batchInfoList.batchInfo];
                return _context8.abrupt("return", batchInfoList);

              case 11:
              case "end":
                return _context8.stop();
            }
          }
        }, _callee3, this);
      }));

      function list() {
        return _list.apply(this, arguments);
      }

      return list;
    }()
    /**
     * Close opened job
     */

  }, {
    key: "close",
    value: function () {
      var _close = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee4() {
        var jobInfo;
        return _regeneratorRuntime.wrap(function _callee4$(_context9) {
          while (1) {
            switch (_context9.prev = _context9.next) {
              case 0:
                if (this.id) {
                  _context9.next = 2;
                  break;
                }

                return _context9.abrupt("return");

              case 2:
                _context9.prev = 2;
                _context9.next = 5;
                return this._changeState('Closed');

              case 5:
                jobInfo = _context9.sent;
                this.id = null;
                this.emit('close', jobInfo);
                return _context9.abrupt("return", jobInfo);

              case 11:
                _context9.prev = 11;
                _context9.t0 = _context9["catch"](2);
                this.emit('error', _context9.t0);
                throw _context9.t0;

              case 15:
              case "end":
                return _context9.stop();
            }
          }
        }, _callee4, this, [[2, 11]]);
      }));

      function close() {
        return _close.apply(this, arguments);
      }

      return close;
    }()
    /**
     * Set the status to abort
     */

  }, {
    key: "abort",
    value: function () {
      var _abort = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee5() {
        var jobInfo;
        return _regeneratorRuntime.wrap(function _callee5$(_context10) {
          while (1) {
            switch (_context10.prev = _context10.next) {
              case 0:
                if (this.id) {
                  _context10.next = 2;
                  break;
                }

                return _context10.abrupt("return");

              case 2:
                _context10.prev = 2;
                _context10.next = 5;
                return this._changeState('Aborted');

              case 5:
                jobInfo = _context10.sent;
                this.id = null;
                this.emit('abort', jobInfo);
                return _context10.abrupt("return", jobInfo);

              case 11:
                _context10.prev = 11;
                _context10.t0 = _context10["catch"](2);
                this.emit('error', _context10.t0);
                throw _context10.t0;

              case 15:
              case "end":
                return _context10.stop();
            }
          }
        }, _callee5, this, [[2, 11]]);
      }));

      function abort() {
        return _abort.apply(this, arguments);
      }

      return abort;
    }()
    /**
     * @private
     */

  }, {
    key: "_changeState",
    value: function () {
      var _changeState2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee7(state) {
        var _this5 = this;

        var bulk, logger;
        return _regeneratorRuntime.wrap(function _callee7$(_context13) {
          while (1) {
            switch (_context13.prev = _context13.next) {
              case 0:
                bulk = this._bulk;
                logger = bulk._logger;
                this._jobInfo = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee6() {
                  var _context11;

                  var jobId, body, res;
                  return _regeneratorRuntime.wrap(function _callee6$(_context12) {
                    while (1) {
                      switch (_context12.prev = _context12.next) {
                        case 0:
                          _context12.next = 2;
                          return _this5.ready();

                        case 2:
                          jobId = _context12.sent;
                          body = _trimInstanceProperty(_context11 = " \n<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n  <jobInfo xmlns=\"http://www.force.com/2009/06/asyncapi/dataload\">\n  <state>".concat(state, "</state>\n</jobInfo>\n      ")).call(_context11);
                          _context12.next = 6;
                          return bulk._request({
                            method: 'POST',
                            path: '/job/' + jobId,
                            body: body,
                            headers: {
                              'Content-Type': 'application/xml; charset=utf-8'
                            },
                            responseType: 'application/xml'
                          });

                        case 6:
                          res = _context12.sent;
                          logger.debug(res.jobInfo);
                          _this5.state = res.jobInfo.state;
                          return _context12.abrupt("return", res.jobInfo);

                        case 10:
                        case "end":
                          return _context12.stop();
                      }
                    }
                  }, _callee6);
                }))();
                return _context13.abrupt("return", this._jobInfo);

              case 4:
              case "end":
                return _context13.stop();
            }
          }
        }, _callee7, this);
      }));

      function _changeState(_x) {
        return _changeState2.apply(this, arguments);
      }

      return _changeState;
    }()
  }]);

  return Job;
}(EventEmitter);
/*--------------------------------------------*/

var PollingTimeoutError = /*#__PURE__*/function (_Error) {
  _inherits(PollingTimeoutError, _Error);

  var _super2 = _createSuper(PollingTimeoutError);

  /**
   *
   */
  function PollingTimeoutError(message, jobId, batchId) {
    var _this6;

    _classCallCheck(this, PollingTimeoutError);

    _this6 = _super2.call(this, message);

    _defineProperty(_assertThisInitialized(_this6), "jobId", void 0);

    _defineProperty(_assertThisInitialized(_this6), "batchId", void 0);

    _this6.name = 'PollingTimeout';
    _this6.jobId = jobId;
    _this6.batchId = batchId;
    return _this6;
  }

  return PollingTimeoutError;
}( /*#__PURE__*/_wrapNativeSuper(Error));

var JobPollingTimeoutError = /*#__PURE__*/function (_Error2) {
  _inherits(JobPollingTimeoutError, _Error2);

  var _super3 = _createSuper(JobPollingTimeoutError);

  /**
   *
   */
  function JobPollingTimeoutError(message, jobId) {
    var _this7;

    _classCallCheck(this, JobPollingTimeoutError);

    _this7 = _super3.call(this, message);

    _defineProperty(_assertThisInitialized(_this7), "jobId", void 0);

    _this7.name = 'JobPollingTimeout';
    _this7.jobId = jobId;
    return _this7;
  }

  return JobPollingTimeoutError;
}( /*#__PURE__*/_wrapNativeSuper(Error));
/*--------------------------------------------*/

/**
 * Batch (extends Writable)
 */


export var Batch = /*#__PURE__*/function (_Writable) {
  _inherits(Batch, _Writable);

  var _super4 = _createSuper(Batch);

  /**
   *
   */
  function Batch(job, id) {
    var _this8;

    _classCallCheck(this, Batch);

    _this8 = _super4.call(this, {
      objectMode: true
    });

    _defineProperty(_assertThisInitialized(_this8), "job", void 0);

    _defineProperty(_assertThisInitialized(_this8), "id", void 0);

    _defineProperty(_assertThisInitialized(_this8), "_bulk", void 0);

    _defineProperty(_assertThisInitialized(_this8), "_uploadStream", void 0);

    _defineProperty(_assertThisInitialized(_this8), "_downloadStream", void 0);

    _defineProperty(_assertThisInitialized(_this8), "_dataStream", void 0);

    _defineProperty(_assertThisInitialized(_this8), "_result", void 0);

    _defineProperty(_assertThisInitialized(_this8), "_error", void 0);

    _defineProperty(_assertThisInitialized(_this8), "run", _this8.execute);

    _defineProperty(_assertThisInitialized(_this8), "exec", _this8.execute);

    _this8.job = job;
    _this8.id = id;
    _this8._bulk = job._bulk; // default error handler to keep the latest error

    _this8.on('error', function (error) {
      return _this8._error = error;
    }); //
    // setup data streams
    //


    var converterOptions = {
      nullValue: '#N/A'
    };
    var uploadStream = _this8._uploadStream = new Serializable();
    var uploadDataStream = uploadStream.stream('csv', converterOptions);
    var downloadStream = _this8._downloadStream = new Parsable();
    var downloadDataStream = downloadStream.stream('csv', converterOptions);

    _this8.on('finish', function () {
      return uploadStream.end();
    });

    uploadDataStream.once('readable', /*#__PURE__*/_asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee8() {
      return _regeneratorRuntime.wrap(function _callee8$(_context14) {
        while (1) {
          switch (_context14.prev = _context14.next) {
            case 0:
              _context14.prev = 0;
              _context14.next = 3;
              return _this8.job.ready();

            case 3:
              // pipe upload data to batch API request stream
              uploadDataStream.pipe(_this8._createRequestStream());
              _context14.next = 9;
              break;

            case 6:
              _context14.prev = 6;
              _context14.t0 = _context14["catch"](0);

              _this8.emit('error', _context14.t0);

            case 9:
            case "end":
              return _context14.stop();
          }
        }
      }, _callee8, null, [[0, 6]]);
    }))); // duplex data stream, opened access to API programmers by Batch#stream()

    _this8._dataStream = concatStreamsAsDuplex(uploadDataStream, downloadDataStream);
    return _this8;
  }
  /**
   * Connect batch API and create stream instance of request/response
   *
   * @private
   */


  _createClass(Batch, [{
    key: "_createRequestStream",
    value: function _createRequestStream() {
      var _this9 = this;

      var bulk = this._bulk;
      var logger = bulk._logger;

      var req = bulk._request({
        method: 'POST',
        path: '/job/' + this.job.id + '/batch',
        headers: {
          'Content-Type': 'text/csv'
        },
        responseType: 'application/xml'
      });

      _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee9() {
        var _res2;

        return _regeneratorRuntime.wrap(function _callee9$(_context15) {
          while (1) {
            switch (_context15.prev = _context15.next) {
              case 0:
                _context15.prev = 0;
                _context15.next = 3;
                return req;

              case 3:
                _res2 = _context15.sent;
                logger.debug(_res2.batchInfo);
                _this9.id = _res2.batchInfo.id;

                _this9.emit('queue', _res2.batchInfo);

                _context15.next = 12;
                break;

              case 9:
                _context15.prev = 9;
                _context15.t0 = _context15["catch"](0);

                _this9.emit('error', _context15.t0);

              case 12:
              case "end":
                return _context15.stop();
            }
          }
        }, _callee9, null, [[0, 9]]);
      }))();

      return req.stream();
    }
    /**
     * Implementation of Writable
     */

  }, {
    key: "_write",
    value: function _write(record_, enc, cb) {
      var Id = record_.Id,
          type = record_.type,
          attributes = record_.attributes,
          rrec = _objectWithoutProperties(record_, ["Id", "type", "attributes"]);

      var record;

      switch (this.job.operation) {
        case 'insert':
          record = rrec;
          break;

        case 'delete':
        case 'hardDelete':
          record = {
            Id: Id
          };
          break;

        default:
          record = _objectSpread({
            Id: Id
          }, rrec);
      }

      this._uploadStream.write(record, enc, cb);
    }
    /**
     * Returns duplex stream which accepts CSV data input and batch result output
     */

  }, {
    key: "stream",
    value: function stream() {
      return this._dataStream;
    }
    /**
     * Execute batch operation
     */

  }, {
    key: "execute",
    value: function execute(input) {
      var _this10 = this;

      // if batch is already executed
      if (this._result) {
        throw new Error('Batch already executed.');
      }

      this._result = new _Promise(function (resolve, reject) {
        _this10.once('response', resolve);

        _this10.once('error', reject);
      });

      if (isObject(input) && 'pipe' in input && isFunction(input.pipe)) {
        // if input has stream.Readable interface
        input.pipe(this._dataStream);
      } else {
        if (_Array$isArray(input)) {
          var _iterator = _createForOfIteratorHelper(input),
              _step;

          try {
            for (_iterator.s(); !(_step = _iterator.n()).done;) {
              var record = _step.value;

              for (var _i = 0, _Object$keys = _Object$keys2(record); _i < _Object$keys.length; _i++) {
                var key = _Object$keys[_i];

                if (typeof record[key] === 'boolean') {
                  record[key] = String(record[key]);
                }
              }

              this.write(record);
            }
          } catch (err) {
            _iterator.e(err);
          } finally {
            _iterator.f();
          }

          this.end();
        } else if (typeof input === 'string') {
          this._dataStream.write(input, 'utf8');

          this._dataStream.end();
        }
      } // return Batch instance for chaining


      return this;
    }
  }, {
    key: "then",

    /**
     * Promise/A+ interface
     * Delegate to promise, return promise instance for batch result
     */
    value: function then(onResolved, onReject) {
      if (!this._result) {
        this.execute();
      }

      return this._result.then(onResolved, onReject);
    }
    /**
     * Check the latest batch status in server
     */

  }, {
    key: "check",
    value: function () {
      var _check = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee10() {
        var bulk, logger, jobId, batchId, res;
        return _regeneratorRuntime.wrap(function _callee10$(_context16) {
          while (1) {
            switch (_context16.prev = _context16.next) {
              case 0:
                bulk = this._bulk;
                logger = bulk._logger;
                jobId = this.job.id;
                batchId = this.id;

                if (!(!jobId || !batchId)) {
                  _context16.next = 6;
                  break;
                }

                throw new Error('Batch not started.');

              case 6:
                _context16.next = 8;
                return bulk._request({
                  method: 'GET',
                  path: '/job/' + jobId + '/batch/' + batchId,
                  responseType: 'application/xml'
                });

              case 8:
                res = _context16.sent;
                logger.debug(res.batchInfo);
                return _context16.abrupt("return", res.batchInfo);

              case 11:
              case "end":
                return _context16.stop();
            }
          }
        }, _callee10, this);
      }));

      function check() {
        return _check.apply(this, arguments);
      }

      return check;
    }()
    /**
     * Polling the batch result and retrieve
     */

  }, {
    key: "poll",
    value: function poll(interval, timeout) {
      var _this11 = this;

      var jobId = this.job.id;
      var batchId = this.id;

      if (!jobId || !batchId) {
        throw new Error('Batch not started.');
      }

      var startTime = new Date().getTime();

      var poll = /*#__PURE__*/function () {
        var _ref7 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee11() {
          var now, _err, res;

          return _regeneratorRuntime.wrap(function _callee11$(_context17) {
            while (1) {
              switch (_context17.prev = _context17.next) {
                case 0:
                  now = new Date().getTime();

                  if (!(startTime + timeout < now)) {
                    _context17.next = 5;
                    break;
                  }

                  _err = new PollingTimeoutError('Polling time out. Job Id = ' + jobId + ' , batch Id = ' + batchId, jobId, batchId);

                  _this11.emit('error', _err);

                  return _context17.abrupt("return");

                case 5:
                  _context17.prev = 5;
                  _context17.next = 8;
                  return _this11.check();

                case 8:
                  res = _context17.sent;
                  _context17.next = 15;
                  break;

                case 11:
                  _context17.prev = 11;
                  _context17.t0 = _context17["catch"](5);

                  _this11.emit('error', _context17.t0);

                  return _context17.abrupt("return");

                case 15:
                  if (res.state === 'Failed') {
                    if (_parseInt(res.numberRecordsProcessed, 10) > 0) {
                      _this11.retrieve();
                    } else {
                      _this11.emit('error', new Error(res.stateMessage));
                    }
                  } else if (res.state === 'Completed') {
                    _this11.retrieve();
                  } else {
                    _this11.emit('progress', res);

                    _setTimeout(poll, interval);
                  }

                case 16:
                case "end":
                  return _context17.stop();
              }
            }
          }, _callee11, null, [[5, 11]]);
        }));

        return function poll() {
          return _ref7.apply(this, arguments);
        };
      }();

      _setTimeout(poll, interval);
    }
    /**
     * Retrieve batch result
     */

  }, {
    key: "retrieve",
    value: function () {
      var _retrieve = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee12() {
        var bulk, jobId, job, batchId, resp, results, _context18, _res3, resultId, _res4;

        return _regeneratorRuntime.wrap(function _callee12$(_context19) {
          while (1) {
            switch (_context19.prev = _context19.next) {
              case 0:
                bulk = this._bulk;
                jobId = this.job.id;
                job = this.job;
                batchId = this.id;

                if (!(!jobId || !batchId)) {
                  _context19.next = 6;
                  break;
                }

                throw new Error('Batch not started.');

              case 6:
                _context19.prev = 6;
                _context19.next = 9;
                return bulk._request({
                  method: 'GET',
                  path: '/job/' + jobId + '/batch/' + batchId + '/result'
                });

              case 9:
                resp = _context19.sent;

                if (job.operation === 'query' || job.operation === 'queryAll') {
                  _res3 = resp;
                  resultId = _res3['result-list'].result;
                  results = _mapInstanceProperty(_context18 = _Array$isArray(resultId) ? resultId : [resultId]).call(_context18, function (id) {
                    return {
                      id: id,
                      batchId: batchId,
                      jobId: jobId
                    };
                  });
                } else {
                  _res4 = resp;
                  results = _mapInstanceProperty(_res4).call(_res4, function (ret) {
                    return {
                      id: ret.Id || null,
                      success: ret.Success === 'true',
                      errors: ret.Error ? [ret.Error] : []
                    };
                  });
                }

                this.emit('response', results);
                return _context19.abrupt("return", results);

              case 15:
                _context19.prev = 15;
                _context19.t0 = _context19["catch"](6);
                this.emit('error', _context19.t0);
                throw _context19.t0;

              case 19:
              case "end":
                return _context19.stop();
            }
          }
        }, _callee12, this, [[6, 15]]);
      }));

      function retrieve() {
        return _retrieve.apply(this, arguments);
      }

      return retrieve;
    }()
    /**
     * Fetch query result as a record stream
     * @param {String} resultId - Result id
     * @returns {RecordStream} - Record stream, convertible to CSV data stream
     */

  }, {
    key: "result",
    value: function result(resultId) {
      var jobId = this.job.id;
      var batchId = this.id;

      if (!jobId || !batchId) {
        throw new Error('Batch not started.');
      }

      var resultStream = new Parsable();
      var resultDataStream = resultStream.stream('csv');

      this._bulk._request({
        method: 'GET',
        path: '/job/' + jobId + '/batch/' + batchId + '/result/' + resultId,
        responseType: 'application/octet-stream'
      }).stream().pipe(resultDataStream);

      return resultStream;
    }
  }]);

  return Batch;
}(Writable);
/*--------------------------------------------*/

/**
 *
 */

var BulkApi = /*#__PURE__*/function (_HttpApi) {
  _inherits(BulkApi, _HttpApi);

  var _super5 = _createSuper(BulkApi);

  function BulkApi() {
    _classCallCheck(this, BulkApi);

    return _super5.apply(this, arguments);
  }

  _createClass(BulkApi, [{
    key: "beforeSend",
    value: function beforeSend(request) {
      var _this$_conn$accessTok;

      request.headers = _objectSpread(_objectSpread({}, request.headers), {}, {
        'X-SFDC-SESSION': (_this$_conn$accessTok = this._conn.accessToken) !== null && _this$_conn$accessTok !== void 0 ? _this$_conn$accessTok : ''
      });
    }
  }, {
    key: "isSessionExpired",
    value: function isSessionExpired(response) {
      return response.statusCode === 400 && /<exceptionCode>InvalidSessionId<\/exceptionCode>/.test(response.body);
    }
  }, {
    key: "hasErrorInResponseBody",
    value: function hasErrorInResponseBody(body) {
      return !!body.error;
    }
  }, {
    key: "parseError",
    value: function parseError(body) {
      return {
        errorCode: body.error.exceptionCode,
        message: body.error.exceptionMessage
      };
    }
  }]);

  return BulkApi;
}(HttpApi);

var BulkApiV2 = /*#__PURE__*/function (_HttpApi2) {
  _inherits(BulkApiV2, _HttpApi2);

  var _super6 = _createSuper(BulkApiV2);

  function BulkApiV2() {
    _classCallCheck(this, BulkApiV2);

    return _super6.apply(this, arguments);
  }

  _createClass(BulkApiV2, [{
    key: "hasErrorInResponseBody",
    value: function hasErrorInResponseBody(body) {
      return _Array$isArray(body) && _typeof(body[0]) === 'object' && 'errorCode' in body[0];
    }
  }, {
    key: "isSessionExpired",
    value: function isSessionExpired(response) {
      return response.statusCode === 401 && /INVALID_SESSION_ID/.test(response.body);
    }
  }, {
    key: "parseError",
    value: function parseError(body) {
      return {
        errorCode: body[0].errorCode,
        message: body[0].message
      };
    }
  }]);

  return BulkApiV2;
}(HttpApi);
/*--------------------------------------------*/

/**
 * Class for Bulk API
 *
 * @class
 */


export var Bulk = /*#__PURE__*/function () {
  /**
   * Polling interval in milliseconds
   */

  /**
   * Polling timeout in milliseconds
   * @type {Number}
   */

  /**
   *
   */
  function Bulk(conn) {
    _classCallCheck(this, Bulk);

    _defineProperty(this, "_conn", void 0);

    _defineProperty(this, "_logger", void 0);

    _defineProperty(this, "pollInterval", 1000);

    _defineProperty(this, "pollTimeout", 10000);

    this._conn = conn;
    this._logger = conn._logger;
  }
  /**
   *
   */


  _createClass(Bulk, [{
    key: "_request",
    value: function _request(request_) {
      var conn = this._conn;

      var path = request_.path,
          responseType = request_.responseType,
          rreq = _objectWithoutProperties(request_, ["path", "responseType"]);

      var baseUrl = [conn.instanceUrl, 'services/async', conn.version].join('/');

      var request = _objectSpread(_objectSpread({}, rreq), {}, {
        url: baseUrl + path
      });

      return new BulkApi(this._conn, {
        responseType: responseType
      }).request(request);
    }
    /**
     * Create and start bulkload job and batch
     */

  }, {
    key: "load",
    value: function load(type, operation, optionsOrInput, input) {
      var _this12 = this;

      var options = {};

      if (typeof optionsOrInput === 'string' || _Array$isArray(optionsOrInput) || isObject(optionsOrInput) && 'pipe' in optionsOrInput && typeof optionsOrInput.pipe === 'function') {
        // when options is not plain hash object, it is omitted
        input = optionsOrInput;
      } else {
        options = optionsOrInput;
      }

      var job = this.createJob(type, operation, options);
      var batch = job.createBatch();

      var cleanup = function cleanup() {
        return job.close();
      };

      var cleanupOnError = function cleanupOnError(err) {
        if (err.name !== 'PollingTimeout') {
          cleanup();
        }
      };

      batch.on('response', cleanup);
      batch.on('error', cleanupOnError);
      batch.on('queue', function () {
        batch === null || batch === void 0 ? void 0 : batch.poll(_this12.pollInterval, _this12.pollTimeout);
      });
      return batch.execute(input);
    }
    /**
     * Execute bulk query and get record stream
     */

  }, {
    key: "query",
    value: function query(soql) {
      var _this13 = this;

      var m = soql.replace(/\([\s\S]+\)/g, '').match(/FROM\s+(\w+)/i);

      if (!m) {
        throw new Error('No sobject type found in query, maybe caused by invalid SOQL.');
      }

      var type = m[1];
      var recordStream = new Parsable();
      var dataStream = recordStream.stream('csv');

      _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee13() {
        var results, streams;
        return _regeneratorRuntime.wrap(function _callee13$(_context20) {
          while (1) {
            switch (_context20.prev = _context20.next) {
              case 0:
                _context20.prev = 0;
                _context20.next = 3;
                return _this13.load(type, 'query', soql);

              case 3:
                results = _context20.sent;
                streams = _mapInstanceProperty(results).call(results, function (result) {
                  return _this13.job(result.jobId).batch(result.batchId).result(result.id).stream();
                });
                joinStreams(streams).pipe(dataStream);
                _context20.next = 11;
                break;

              case 8:
                _context20.prev = 8;
                _context20.t0 = _context20["catch"](0);
                recordStream.emit('error', _context20.t0);

              case 11:
              case "end":
                return _context20.stop();
            }
          }
        }, _callee13, null, [[0, 8]]);
      }))();

      return recordStream;
    }
    /**
     * Create a new job instance
     */

  }, {
    key: "createJob",
    value: function createJob(type, operation) {
      var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
      return new Job(this, type, operation, options);
    }
    /**
     * Get a job instance specified by given job ID
     *
     * @param {String} jobId - Job ID
     * @returns {Bulk~Job}
     */

  }, {
    key: "job",
    value: function job(jobId) {
      return new Job(this, null, null, null, jobId);
    }
  }]);

  return Bulk;
}();

var _connection = new _WeakMap();

export var BulkV2 = /*#__PURE__*/function () {
  /**
   * Polling interval in milliseconds
   */

  /**
   * Polling timeout in milliseconds
   * @type {Number}
   */
  function BulkV2(connection) {
    _classCallCheck(this, BulkV2);

    _connection.set(this, {
      writable: true,
      value: void 0
    });

    _defineProperty(this, "pollInterval", 1000);

    _defineProperty(this, "pollTimeout", 10000);

    _classPrivateFieldSet(this, _connection, connection);
  }
  /**
   * Create a new job instance
   */


  _createClass(BulkV2, [{
    key: "createJob",
    value: function createJob(options) {
      return new IngestJobV2({
        connection: _classPrivateFieldGet(this, _connection),
        jobInfo: options,
        pollingOptions: this
      });
    }
  }, {
    key: "job",
    value: function job(options) {
      return new IngestJobV2({
        connection: _classPrivateFieldGet(this, _connection),
        jobInfo: options,
        pollingOptions: this
      });
    }
    /**
     * Create, upload, and start bulkload job
     */

  }, {
    key: "loadAndWaitForResults",
    value: function () {
      var _loadAndWaitForResults = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee14(options) {
        var job;
        return _regeneratorRuntime.wrap(function _callee14$(_context21) {
          while (1) {
            switch (_context21.prev = _context21.next) {
              case 0:
                job = this.createJob(options);
                _context21.prev = 1;
                _context21.next = 4;
                return job.open();

              case 4:
                _context21.next = 6;
                return job.uploadData(options.input);

              case 6:
                _context21.next = 8;
                return job.close();

              case 8:
                _context21.next = 10;
                return job.poll(options.pollInterval, options.pollTimeout);

              case 10:
                _context21.next = 12;
                return job.getAllResults();

              case 12:
                return _context21.abrupt("return", _context21.sent);

              case 15:
                _context21.prev = 15;
                _context21.t0 = _context21["catch"](1);

                if (_context21.t0.name !== 'JobPollingTimeoutError') {
                  // fires off one last attempt to clean up and ignores the result | error
                  job.delete().catch(function (ignored) {
                    return ignored;
                  });
                }

                throw _context21.t0;

              case 19:
              case "end":
                return _context21.stop();
            }
          }
        }, _callee14, this, [[1, 15]]);
      }));

      function loadAndWaitForResults(_x2) {
        return _loadAndWaitForResults.apply(this, arguments);
      }

      return loadAndWaitForResults;
    }()
    /**
     * Execute bulk query and get record stream
     */

  }, {
    key: "query",
    value: function () {
      var _query = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee15(soql, options) {
        var queryJob;
        return _regeneratorRuntime.wrap(function _callee15$(_context22) {
          while (1) {
            switch (_context22.prev = _context22.next) {
              case 0:
                queryJob = new QueryJobV2({
                  connection: _classPrivateFieldGet(this, _connection),
                  operation: 'query',
                  query: soql,
                  pollingOptions: this
                });
                _context22.prev = 1;
                _context22.next = 4;
                return queryJob.open();

              case 4:
                _context22.next = 6;
                return queryJob.poll(options === null || options === void 0 ? void 0 : options.pollInterval, options === null || options === void 0 ? void 0 : options.pollTimeout);

              case 6:
                _context22.next = 8;
                return queryJob.getResults();

              case 8:
                return _context22.abrupt("return", _context22.sent);

              case 11:
                _context22.prev = 11;
                _context22.t0 = _context22["catch"](1);

                if (_context22.t0.name !== 'JobPollingTimeoutError') {
                  // fires off one last attempt to clean up and ignores the result | error
                  queryJob.delete().catch(function (ignored) {
                    return ignored;
                  });
                }

                throw _context22.t0;

              case 15:
              case "end":
                return _context22.stop();
            }
          }
        }, _callee15, this, [[1, 11]]);
      }));

      function query(_x3, _x4) {
        return _query.apply(this, arguments);
      }

      return query;
    }()
  }]);

  return BulkV2;
}();

var _connection2 = new _WeakMap();

var _operation2 = new _WeakMap();

var _query2 = new _WeakMap();

var _pollingOptions = new _WeakMap();

var _queryResults = new _WeakMap();

var _error = new _WeakMap();

export var QueryJobV2 = /*#__PURE__*/function (_EventEmitter2) {
  _inherits(QueryJobV2, _EventEmitter2);

  var _super7 = _createSuper(QueryJobV2);

  function QueryJobV2(options) {
    var _this14;

    _classCallCheck(this, QueryJobV2);

    _this14 = _super7.call(this);

    _connection2.set(_assertThisInitialized(_this14), {
      writable: true,
      value: void 0
    });

    _operation2.set(_assertThisInitialized(_this14), {
      writable: true,
      value: void 0
    });

    _query2.set(_assertThisInitialized(_this14), {
      writable: true,
      value: void 0
    });

    _pollingOptions.set(_assertThisInitialized(_this14), {
      writable: true,
      value: void 0
    });

    _queryResults.set(_assertThisInitialized(_this14), {
      writable: true,
      value: void 0
    });

    _error.set(_assertThisInitialized(_this14), {
      writable: true,
      value: void 0
    });

    _defineProperty(_assertThisInitialized(_this14), "jobInfo", void 0);

    _classPrivateFieldSet(_assertThisInitialized(_this14), _connection2, options.connection);

    _classPrivateFieldSet(_assertThisInitialized(_this14), _operation2, options.operation);

    _classPrivateFieldSet(_assertThisInitialized(_this14), _query2, options.query);

    _classPrivateFieldSet(_assertThisInitialized(_this14), _pollingOptions, options.pollingOptions); // default error handler to keep the latest error


    _this14.on('error', function (error) {
      return _classPrivateFieldSet(_assertThisInitialized(_this14), _error, error);
    });

    return _this14;
  }

  _createClass(QueryJobV2, [{
    key: "open",
    value: function () {
      var _open = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee16() {
        return _regeneratorRuntime.wrap(function _callee16$(_context23) {
          while (1) {
            switch (_context23.prev = _context23.next) {
              case 0:
                _context23.prev = 0;
                _context23.next = 3;
                return this.createQueryRequest({
                  method: 'POST',
                  path: '',
                  body: _JSON$stringify({
                    operation: _classPrivateFieldGet(this, _operation2),
                    query: _classPrivateFieldGet(this, _query2)
                  }),
                  headers: {
                    'Content-Type': 'application/json; charset=utf-8'
                  },
                  responseType: 'application/json'
                });

              case 3:
                this.jobInfo = _context23.sent;
                this.emit('open');
                _context23.next = 11;
                break;

              case 7:
                _context23.prev = 7;
                _context23.t0 = _context23["catch"](0);
                this.emit('error', _context23.t0);
                throw _context23.t0;

              case 11:
              case "end":
                return _context23.stop();
            }
          }
        }, _callee16, this, [[0, 7]]);
      }));

      function open() {
        return _open.apply(this, arguments);
      }

      return open;
    }()
    /**
     * Set the status to abort
     */

  }, {
    key: "abort",
    value: function () {
      var _abort2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee17() {
        var _this$jobInfo, state;

        return _regeneratorRuntime.wrap(function _callee17$(_context24) {
          while (1) {
            switch (_context24.prev = _context24.next) {
              case 0:
                _context24.prev = 0;
                state = 'Aborted';
                _context24.next = 4;
                return this.createQueryRequest({
                  method: 'PATCH',
                  path: "/".concat((_this$jobInfo = this.jobInfo) === null || _this$jobInfo === void 0 ? void 0 : _this$jobInfo.id),
                  body: _JSON$stringify({
                    state: state
                  }),
                  headers: {
                    'Content-Type': 'application/json; charset=utf-8'
                  },
                  responseType: 'application/json'
                });

              case 4:
                this.jobInfo = _context24.sent;
                this.emit('aborted');
                _context24.next = 12;
                break;

              case 8:
                _context24.prev = 8;
                _context24.t0 = _context24["catch"](0);
                this.emit('error', _context24.t0);
                throw _context24.t0;

              case 12:
              case "end":
                return _context24.stop();
            }
          }
        }, _callee17, this, [[0, 8]]);
      }));

      function abort() {
        return _abort2.apply(this, arguments);
      }

      return abort;
    }()
  }, {
    key: "poll",
    value: function () {
      var _poll = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee18() {
        var interval,
            timeout,
            jobId,
            startTime,
            _res5,
            timeoutError,
            _args18 = arguments;

        return _regeneratorRuntime.wrap(function _callee18$(_context25) {
          while (1) {
            switch (_context25.prev = _context25.next) {
              case 0:
                interval = _args18.length > 0 && _args18[0] !== undefined ? _args18[0] : _classPrivateFieldGet(this, _pollingOptions).pollInterval;
                timeout = _args18.length > 1 && _args18[1] !== undefined ? _args18[1] : _classPrivateFieldGet(this, _pollingOptions).pollTimeout;
                jobId = getJobIdOrError(this.jobInfo);
                startTime = _Date$now();

              case 4:
                if (!(startTime + timeout > _Date$now())) {
                  _context25.next = 29;
                  break;
                }

                _context25.prev = 5;
                _context25.next = 8;
                return this.check();

              case 8:
                _res5 = _context25.sent;
                _context25.t0 = _res5.state;
                _context25.next = _context25.t0 === 'Open' ? 12 : _context25.t0 === 'Aborted' ? 13 : _context25.t0 === 'UploadComplete' ? 14 : _context25.t0 === 'InProgress' ? 14 : _context25.t0 === 'Failed' ? 17 : _context25.t0 === 'JobComplete' ? 19 : 21;
                break;

              case 12:
                throw new Error('Job has not been started');

              case 13:
                throw new Error('Job has been aborted');

              case 14:
                _context25.next = 16;
                return delay(interval);

              case 16:
                return _context25.abrupt("break", 21);

              case 17:
                this.emit('failed');
                return _context25.abrupt("return");

              case 19:
                this.emit('jobcomplete');
                return _context25.abrupt("return");

              case 21:
                _context25.next = 27;
                break;

              case 23:
                _context25.prev = 23;
                _context25.t1 = _context25["catch"](5);
                this.emit('error', _context25.t1);
                throw _context25.t1;

              case 27:
                _context25.next = 4;
                break;

              case 29:
                timeoutError = new JobPollingTimeoutError("Polling time out. Job Id = ".concat(jobId), jobId);
                this.emit('error', timeoutError);
                throw timeoutError;

              case 32:
              case "end":
                return _context25.stop();
            }
          }
        }, _callee18, this, [[5, 23]]);
      }));

      function poll() {
        return _poll.apply(this, arguments);
      }

      return poll;
    }()
    /**
     * Check the latest batch status in server
     */

  }, {
    key: "check",
    value: function () {
      var _check2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee19() {
        var jobInfo;
        return _regeneratorRuntime.wrap(function _callee19$(_context26) {
          while (1) {
            switch (_context26.prev = _context26.next) {
              case 0:
                _context26.prev = 0;
                _context26.next = 3;
                return this.createQueryRequest({
                  method: 'GET',
                  path: "/".concat(getJobIdOrError(this.jobInfo)),
                  responseType: 'application/json'
                });

              case 3:
                jobInfo = _context26.sent;
                this.jobInfo = jobInfo;
                return _context26.abrupt("return", jobInfo);

              case 8:
                _context26.prev = 8;
                _context26.t0 = _context26["catch"](0);
                this.emit('error', _context26.t0);
                throw _context26.t0;

              case 12:
              case "end":
                return _context26.stop();
            }
          }
        }, _callee19, this, [[0, 8]]);
      }));

      function check() {
        return _check2.apply(this, arguments);
      }

      return check;
    }()
  }, {
    key: "getResults",
    value: function () {
      var _getResults = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee20() {
        var results;
        return _regeneratorRuntime.wrap(function _callee20$(_context27) {
          while (1) {
            switch (_context27.prev = _context27.next) {
              case 0:
                _context27.prev = 0;

                if (!_classPrivateFieldGet(this, _queryResults)) {
                  _context27.next = 3;
                  break;
                }

                return _context27.abrupt("return", _classPrivateFieldGet(this, _queryResults));

              case 3:
                _context27.next = 5;
                return this.createQueryRequest({
                  method: 'GET',
                  path: "/".concat(getJobIdOrError(this.jobInfo), "/results"),
                  responseType: 'text/csv'
                });

              case 5:
                results = _context27.sent;

                _classPrivateFieldSet(this, _queryResults, results !== null && results !== void 0 ? results : []);

                return _context27.abrupt("return", _classPrivateFieldGet(this, _queryResults));

              case 10:
                _context27.prev = 10;
                _context27.t0 = _context27["catch"](0);
                this.emit('error', _context27.t0);
                throw _context27.t0;

              case 14:
              case "end":
                return _context27.stop();
            }
          }
        }, _callee20, this, [[0, 10]]);
      }));

      function getResults() {
        return _getResults.apply(this, arguments);
      }

      return getResults;
    }()
  }, {
    key: "delete",
    value: function () {
      var _delete2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee21() {
        return _regeneratorRuntime.wrap(function _callee21$(_context28) {
          while (1) {
            switch (_context28.prev = _context28.next) {
              case 0:
                return _context28.abrupt("return", this.createQueryRequest({
                  method: 'DELETE',
                  path: "/".concat(getJobIdOrError(this.jobInfo))
                }));

              case 1:
              case "end":
                return _context28.stop();
            }
          }
        }, _callee21, this);
      }));

      function _delete() {
        return _delete2.apply(this, arguments);
      }

      return _delete;
    }()
  }, {
    key: "createQueryRequest",
    value: function createQueryRequest(request) {
      var path = request.path,
          responseType = request.responseType;
      var baseUrl = [_classPrivateFieldGet(this, _connection2).instanceUrl, 'services/data', "v".concat(_classPrivateFieldGet(this, _connection2).version), 'jobs/query'].join('/');
      return new BulkApiV2(_classPrivateFieldGet(this, _connection2), {
        responseType: responseType
      }).request(_objectSpread(_objectSpread({}, request), {}, {
        url: baseUrl + path
      }));
    }
  }]);

  return QueryJobV2;
}(EventEmitter);
/**
 * Class for Bulk API V2 Ingest Job
 */

var _connection3 = new _WeakMap();

var _pollingOptions2 = new _WeakMap();

var _jobData = new _WeakMap();

var _bulkJobSuccessfulResults = new _WeakMap();

var _bulkJobFailedResults = new _WeakMap();

var _bulkJobUnprocessedRecords = new _WeakMap();

var _error2 = new _WeakMap();

export var IngestJobV2 = /*#__PURE__*/function (_EventEmitter3) {
  _inherits(IngestJobV2, _EventEmitter3);

  var _super8 = _createSuper(IngestJobV2);

  /**
   *
   */
  function IngestJobV2(options) {
    var _this15;

    _classCallCheck(this, IngestJobV2);

    _this15 = _super8.call(this);

    _connection3.set(_assertThisInitialized(_this15), {
      writable: true,
      value: void 0
    });

    _pollingOptions2.set(_assertThisInitialized(_this15), {
      writable: true,
      value: void 0
    });

    _jobData.set(_assertThisInitialized(_this15), {
      writable: true,
      value: void 0
    });

    _bulkJobSuccessfulResults.set(_assertThisInitialized(_this15), {
      writable: true,
      value: void 0
    });

    _bulkJobFailedResults.set(_assertThisInitialized(_this15), {
      writable: true,
      value: void 0
    });

    _bulkJobUnprocessedRecords.set(_assertThisInitialized(_this15), {
      writable: true,
      value: void 0
    });

    _error2.set(_assertThisInitialized(_this15), {
      writable: true,
      value: void 0
    });

    _defineProperty(_assertThisInitialized(_this15), "jobInfo", void 0);

    _classPrivateFieldSet(_assertThisInitialized(_this15), _connection3, options.connection);

    _classPrivateFieldSet(_assertThisInitialized(_this15), _pollingOptions2, options.pollingOptions);

    _this15.jobInfo = options.jobInfo;

    _classPrivateFieldSet(_assertThisInitialized(_this15), _jobData, new JobDataV2({
      createRequest: function createRequest(request) {
        return _this15.createIngestRequest(request);
      },
      job: _assertThisInitialized(_this15)
    })); // default error handler to keep the latest error


    _this15.on('error', function (error) {
      return _classPrivateFieldSet(_assertThisInitialized(_this15), _error2, error);
    });

    return _this15;
  }

  _createClass(IngestJobV2, [{
    key: "open",
    value: function () {
      var _open2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee22() {
        var _this$jobInfo2, _this$jobInfo3, _this$jobInfo4, _this$jobInfo5;

        return _regeneratorRuntime.wrap(function _callee22$(_context29) {
          while (1) {
            switch (_context29.prev = _context29.next) {
              case 0:
                _context29.prev = 0;
                _context29.next = 3;
                return this.createIngestRequest({
                  method: 'POST',
                  path: '',
                  body: _JSON$stringify({
                    assignmentRuleId: (_this$jobInfo2 = this.jobInfo) === null || _this$jobInfo2 === void 0 ? void 0 : _this$jobInfo2.assignmentRuleId,
                    externalIdFieldName: (_this$jobInfo3 = this.jobInfo) === null || _this$jobInfo3 === void 0 ? void 0 : _this$jobInfo3.externalIdFieldName,
                    object: (_this$jobInfo4 = this.jobInfo) === null || _this$jobInfo4 === void 0 ? void 0 : _this$jobInfo4.object,
                    operation: (_this$jobInfo5 = this.jobInfo) === null || _this$jobInfo5 === void 0 ? void 0 : _this$jobInfo5.operation
                  }),
                  headers: {
                    'Content-Type': 'application/json; charset=utf-8'
                  },
                  responseType: 'application/json'
                });

              case 3:
                this.jobInfo = _context29.sent;
                this.emit('open');
                _context29.next = 11;
                break;

              case 7:
                _context29.prev = 7;
                _context29.t0 = _context29["catch"](0);
                this.emit('error', _context29.t0);
                throw _context29.t0;

              case 11:
              case "end":
                return _context29.stop();
            }
          }
        }, _callee22, this, [[0, 7]]);
      }));

      function open() {
        return _open2.apply(this, arguments);
      }

      return open;
    }()
  }, {
    key: "uploadData",
    value: function () {
      var _uploadData = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee23(input) {
        return _regeneratorRuntime.wrap(function _callee23$(_context30) {
          while (1) {
            switch (_context30.prev = _context30.next) {
              case 0:
                _context30.next = 2;
                return _classPrivateFieldGet(this, _jobData).execute(input);

              case 2:
              case "end":
                return _context30.stop();
            }
          }
        }, _callee23, this);
      }));

      function uploadData(_x5) {
        return _uploadData.apply(this, arguments);
      }

      return uploadData;
    }()
  }, {
    key: "getAllResults",
    value: function () {
      var _getAllResults = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee24() {
        var _yield$Promise$all, _yield$Promise$all2, successfulResults, failedResults, unprocessedRecords;

        return _regeneratorRuntime.wrap(function _callee24$(_context31) {
          while (1) {
            switch (_context31.prev = _context31.next) {
              case 0:
                _context31.next = 2;
                return _Promise.all([this.getSuccessfulResults(), this.getFailedResults(), this.getUnprocessedRecords()]);

              case 2:
                _yield$Promise$all = _context31.sent;
                _yield$Promise$all2 = _slicedToArray(_yield$Promise$all, 3);
                successfulResults = _yield$Promise$all2[0];
                failedResults = _yield$Promise$all2[1];
                unprocessedRecords = _yield$Promise$all2[2];
                return _context31.abrupt("return", {
                  successfulResults: successfulResults,
                  failedResults: failedResults,
                  unprocessedRecords: unprocessedRecords
                });

              case 8:
              case "end":
                return _context31.stop();
            }
          }
        }, _callee24, this);
      }));

      function getAllResults() {
        return _getAllResults.apply(this, arguments);
      }

      return getAllResults;
    }()
    /**
     * Close opened job
     */

  }, {
    key: "close",
    value: function () {
      var _close2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee25() {
        var state;
        return _regeneratorRuntime.wrap(function _callee25$(_context32) {
          while (1) {
            switch (_context32.prev = _context32.next) {
              case 0:
                _context32.prev = 0;
                state = 'UploadComplete';
                _context32.next = 4;
                return this.createIngestRequest({
                  method: 'PATCH',
                  path: "/".concat(this.jobInfo.id),
                  body: _JSON$stringify({
                    state: state
                  }),
                  headers: {
                    'Content-Type': 'application/json; charset=utf-8'
                  },
                  responseType: 'application/json'
                });

              case 4:
                this.jobInfo = _context32.sent;
                this.emit('uploadcomplete');
                _context32.next = 12;
                break;

              case 8:
                _context32.prev = 8;
                _context32.t0 = _context32["catch"](0);
                this.emit('error', _context32.t0);
                throw _context32.t0;

              case 12:
              case "end":
                return _context32.stop();
            }
          }
        }, _callee25, this, [[0, 8]]);
      }));

      function close() {
        return _close2.apply(this, arguments);
      }

      return close;
    }()
    /**
     * Set the status to abort
     */

  }, {
    key: "abort",
    value: function () {
      var _abort3 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee26() {
        var state;
        return _regeneratorRuntime.wrap(function _callee26$(_context33) {
          while (1) {
            switch (_context33.prev = _context33.next) {
              case 0:
                _context33.prev = 0;
                state = 'Aborted';
                _context33.next = 4;
                return this.createIngestRequest({
                  method: 'PATCH',
                  path: "/".concat(this.jobInfo.id),
                  body: _JSON$stringify({
                    state: state
                  }),
                  headers: {
                    'Content-Type': 'application/json; charset=utf-8'
                  },
                  responseType: 'application/json'
                });

              case 4:
                this.jobInfo = _context33.sent;
                this.emit('aborted');
                _context33.next = 12;
                break;

              case 8:
                _context33.prev = 8;
                _context33.t0 = _context33["catch"](0);
                this.emit('error', _context33.t0);
                throw _context33.t0;

              case 12:
              case "end":
                return _context33.stop();
            }
          }
        }, _callee26, this, [[0, 8]]);
      }));

      function abort() {
        return _abort3.apply(this, arguments);
      }

      return abort;
    }()
  }, {
    key: "poll",
    value: function () {
      var _poll2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee27() {
        var interval,
            timeout,
            jobId,
            startTime,
            _res6,
            timeoutError,
            _args27 = arguments;

        return _regeneratorRuntime.wrap(function _callee27$(_context34) {
          while (1) {
            switch (_context34.prev = _context34.next) {
              case 0:
                interval = _args27.length > 0 && _args27[0] !== undefined ? _args27[0] : _classPrivateFieldGet(this, _pollingOptions2).pollInterval;
                timeout = _args27.length > 1 && _args27[1] !== undefined ? _args27[1] : _classPrivateFieldGet(this, _pollingOptions2).pollTimeout;
                jobId = getJobIdOrError(this.jobInfo);
                startTime = _Date$now();

              case 4:
                if (!(startTime + timeout > _Date$now())) {
                  _context34.next = 29;
                  break;
                }

                _context34.prev = 5;
                _context34.next = 8;
                return this.check();

              case 8:
                _res6 = _context34.sent;
                _context34.t0 = _res6.state;
                _context34.next = _context34.t0 === 'Open' ? 12 : _context34.t0 === 'Aborted' ? 13 : _context34.t0 === 'UploadComplete' ? 14 : _context34.t0 === 'InProgress' ? 14 : _context34.t0 === 'Failed' ? 17 : _context34.t0 === 'JobComplete' ? 19 : 21;
                break;

              case 12:
                throw new Error('Job has not been started');

              case 13:
                throw new Error('Job has been aborted');

              case 14:
                _context34.next = 16;
                return delay(interval);

              case 16:
                return _context34.abrupt("break", 21);

              case 17:
                this.emit('failed');
                return _context34.abrupt("return");

              case 19:
                this.emit('jobcomplete');
                return _context34.abrupt("return");

              case 21:
                _context34.next = 27;
                break;

              case 23:
                _context34.prev = 23;
                _context34.t1 = _context34["catch"](5);
                this.emit('error', _context34.t1);
                throw _context34.t1;

              case 27:
                _context34.next = 4;
                break;

              case 29:
                timeoutError = new JobPollingTimeoutError("Polling time out. Job Id = ".concat(jobId), jobId);
                this.emit('error', timeoutError);
                throw timeoutError;

              case 32:
              case "end":
                return _context34.stop();
            }
          }
        }, _callee27, this, [[5, 23]]);
      }));

      function poll() {
        return _poll2.apply(this, arguments);
      }

      return poll;
    }()
    /**
     * Check the latest batch status in server
     */

  }, {
    key: "check",
    value: function () {
      var _check3 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee28() {
        var jobInfo;
        return _regeneratorRuntime.wrap(function _callee28$(_context35) {
          while (1) {
            switch (_context35.prev = _context35.next) {
              case 0:
                _context35.prev = 0;
                _context35.next = 3;
                return this.createIngestRequest({
                  method: 'GET',
                  path: "/".concat(getJobIdOrError(this.jobInfo)),
                  responseType: 'application/json'
                });

              case 3:
                jobInfo = _context35.sent;
                this.jobInfo = jobInfo;
                return _context35.abrupt("return", jobInfo);

              case 8:
                _context35.prev = 8;
                _context35.t0 = _context35["catch"](0);
                this.emit('error', _context35.t0);
                throw _context35.t0;

              case 12:
              case "end":
                return _context35.stop();
            }
          }
        }, _callee28, this, [[0, 8]]);
      }));

      function check() {
        return _check3.apply(this, arguments);
      }

      return check;
    }()
  }, {
    key: "getSuccessfulResults",
    value: function () {
      var _getSuccessfulResults = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee29() {
        var results;
        return _regeneratorRuntime.wrap(function _callee29$(_context36) {
          while (1) {
            switch (_context36.prev = _context36.next) {
              case 0:
                if (!_classPrivateFieldGet(this, _bulkJobSuccessfulResults)) {
                  _context36.next = 2;
                  break;
                }

                return _context36.abrupt("return", _classPrivateFieldGet(this, _bulkJobSuccessfulResults));

              case 2:
                _context36.next = 4;
                return this.createIngestRequest({
                  method: 'GET',
                  path: "/".concat(getJobIdOrError(this.jobInfo), "/successfulResults"),
                  responseType: 'text/csv'
                });

              case 4:
                results = _context36.sent;

                _classPrivateFieldSet(this, _bulkJobSuccessfulResults, results !== null && results !== void 0 ? results : []);

                return _context36.abrupt("return", _classPrivateFieldGet(this, _bulkJobSuccessfulResults));

              case 7:
              case "end":
                return _context36.stop();
            }
          }
        }, _callee29, this);
      }));

      function getSuccessfulResults() {
        return _getSuccessfulResults.apply(this, arguments);
      }

      return getSuccessfulResults;
    }()
  }, {
    key: "getFailedResults",
    value: function () {
      var _getFailedResults = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee30() {
        var results;
        return _regeneratorRuntime.wrap(function _callee30$(_context37) {
          while (1) {
            switch (_context37.prev = _context37.next) {
              case 0:
                if (!_classPrivateFieldGet(this, _bulkJobFailedResults)) {
                  _context37.next = 2;
                  break;
                }

                return _context37.abrupt("return", _classPrivateFieldGet(this, _bulkJobFailedResults));

              case 2:
                _context37.next = 4;
                return this.createIngestRequest({
                  method: 'GET',
                  path: "/".concat(getJobIdOrError(this.jobInfo), "/failedResults"),
                  responseType: 'text/csv'
                });

              case 4:
                results = _context37.sent;

                _classPrivateFieldSet(this, _bulkJobFailedResults, results !== null && results !== void 0 ? results : []);

                return _context37.abrupt("return", _classPrivateFieldGet(this, _bulkJobFailedResults));

              case 7:
              case "end":
                return _context37.stop();
            }
          }
        }, _callee30, this);
      }));

      function getFailedResults() {
        return _getFailedResults.apply(this, arguments);
      }

      return getFailedResults;
    }()
  }, {
    key: "getUnprocessedRecords",
    value: function () {
      var _getUnprocessedRecords = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee31() {
        var results;
        return _regeneratorRuntime.wrap(function _callee31$(_context38) {
          while (1) {
            switch (_context38.prev = _context38.next) {
              case 0:
                if (!_classPrivateFieldGet(this, _bulkJobUnprocessedRecords)) {
                  _context38.next = 2;
                  break;
                }

                return _context38.abrupt("return", _classPrivateFieldGet(this, _bulkJobUnprocessedRecords));

              case 2:
                _context38.next = 4;
                return this.createIngestRequest({
                  method: 'GET',
                  path: "/".concat(getJobIdOrError(this.jobInfo), "/unprocessedrecords"),
                  responseType: 'text/csv'
                });

              case 4:
                results = _context38.sent;

                _classPrivateFieldSet(this, _bulkJobUnprocessedRecords, results !== null && results !== void 0 ? results : []);

                return _context38.abrupt("return", _classPrivateFieldGet(this, _bulkJobUnprocessedRecords));

              case 7:
              case "end":
                return _context38.stop();
            }
          }
        }, _callee31, this);
      }));

      function getUnprocessedRecords() {
        return _getUnprocessedRecords.apply(this, arguments);
      }

      return getUnprocessedRecords;
    }()
  }, {
    key: "delete",
    value: function () {
      var _delete3 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee32() {
        return _regeneratorRuntime.wrap(function _callee32$(_context39) {
          while (1) {
            switch (_context39.prev = _context39.next) {
              case 0:
                return _context39.abrupt("return", this.createIngestRequest({
                  method: 'DELETE',
                  path: "/".concat(getJobIdOrError(this.jobInfo))
                }));

              case 1:
              case "end":
                return _context39.stop();
            }
          }
        }, _callee32, this);
      }));

      function _delete() {
        return _delete3.apply(this, arguments);
      }

      return _delete;
    }()
  }, {
    key: "createIngestRequest",
    value: function createIngestRequest(request) {
      var path = request.path,
          responseType = request.responseType;
      var baseUrl = [_classPrivateFieldGet(this, _connection3).instanceUrl, 'services/data', "v".concat(_classPrivateFieldGet(this, _connection3).version), 'jobs/ingest'].join('/');
      return new BulkApiV2(_classPrivateFieldGet(this, _connection3), {
        responseType: responseType
      }).request(_objectSpread(_objectSpread({}, request), {}, {
        url: baseUrl + path
      }));
    }
  }, {
    key: "id",
    get: function get() {
      return this.jobInfo.id;
    }
  }]);

  return IngestJobV2;
}(EventEmitter);

var _job = new _WeakMap();

var _uploadStream = new _WeakMap();

var _downloadStream = new _WeakMap();

var _dataStream = new _WeakMap();

var _result = new _WeakMap();

var JobDataV2 = /*#__PURE__*/function (_Writable2) {
  _inherits(JobDataV2, _Writable2);

  var _super9 = _createSuper(JobDataV2);

  /**
   *
   */
  function JobDataV2(options) {
    var _this16;

    _classCallCheck(this, JobDataV2);

    _this16 = _super9.call(this, {
      objectMode: true
    });

    _job.set(_assertThisInitialized(_this16), {
      writable: true,
      value: void 0
    });

    _uploadStream.set(_assertThisInitialized(_this16), {
      writable: true,
      value: void 0
    });

    _downloadStream.set(_assertThisInitialized(_this16), {
      writable: true,
      value: void 0
    });

    _dataStream.set(_assertThisInitialized(_this16), {
      writable: true,
      value: void 0
    });

    _result.set(_assertThisInitialized(_this16), {
      writable: true,
      value: void 0
    });

    var createRequest = options.createRequest;

    _classPrivateFieldSet(_assertThisInitialized(_this16), _job, options.job);

    _classPrivateFieldSet(_assertThisInitialized(_this16), _uploadStream, new Serializable());

    _classPrivateFieldSet(_assertThisInitialized(_this16), _downloadStream, new Parsable());

    var converterOptions = {
      nullValue: '#N/A'
    };

    var uploadDataStream = _classPrivateFieldGet(_assertThisInitialized(_this16), _uploadStream).stream('csv', converterOptions);

    var downloadDataStream = _classPrivateFieldGet(_assertThisInitialized(_this16), _downloadStream).stream('csv', converterOptions);

    _classPrivateFieldSet(_assertThisInitialized(_this16), _dataStream, concatStreamsAsDuplex(uploadDataStream, downloadDataStream));

    _this16.on('finish', function () {
      return _classPrivateFieldGet(_assertThisInitialized(_this16), _uploadStream).end();
    });

    uploadDataStream.once('readable', function () {
      try {
        var _classPrivateFieldGet2;

        // pipe upload data to batch API request stream
        var req = createRequest({
          method: 'PUT',
          path: "/".concat((_classPrivateFieldGet2 = _classPrivateFieldGet(_assertThisInitialized(_this16), _job).jobInfo) === null || _classPrivateFieldGet2 === void 0 ? void 0 : _classPrivateFieldGet2.id, "/batches"),
          headers: {
            'Content-Type': 'text/csv'
          },
          responseType: 'application/json'
        });

        _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee33() {
          var _res7;

          return _regeneratorRuntime.wrap(function _callee33$(_context40) {
            while (1) {
              switch (_context40.prev = _context40.next) {
                case 0:
                  _context40.prev = 0;
                  _context40.next = 3;
                  return req;

                case 3:
                  _res7 = _context40.sent;

                  _this16.emit('response', _res7);

                  _context40.next = 10;
                  break;

                case 7:
                  _context40.prev = 7;
                  _context40.t0 = _context40["catch"](0);

                  _this16.emit('error', _context40.t0);

                case 10:
                case "end":
                  return _context40.stop();
              }
            }
          }, _callee33, null, [[0, 7]]);
        }))();

        uploadDataStream.pipe(req.stream());
      } catch (err) {
        _this16.emit('error', err);
      }
    });
    return _this16;
  }

  _createClass(JobDataV2, [{
    key: "_write",
    value: function _write(record_, enc, cb) {
      var Id = record_.Id,
          type = record_.type,
          attributes = record_.attributes,
          rrec = _objectWithoutProperties(record_, ["Id", "type", "attributes"]);

      var record;

      switch (_classPrivateFieldGet(this, _job).jobInfo.operation) {
        case 'insert':
          record = rrec;
          break;

        case 'delete':
        case 'hardDelete':
          record = {
            Id: Id
          };
          break;

        default:
          record = _objectSpread({
            Id: Id
          }, rrec);
      }

      _classPrivateFieldGet(this, _uploadStream).write(record, enc, cb);
    }
    /**
     * Returns duplex stream which accepts CSV data input and batch result output
     */

  }, {
    key: "stream",
    value: function stream() {
      return _classPrivateFieldGet(this, _dataStream);
    }
    /**
     * Execute batch operation
     */

  }, {
    key: "execute",
    value: function execute(input) {
      var _this17 = this;

      if (_classPrivateFieldGet(this, _result)) {
        throw new Error('Data can only be uploaded to a job once.');
      }

      _classPrivateFieldSet(this, _result, new _Promise(function (resolve, reject) {
        _this17.once('response', function () {
          return resolve();
        });

        _this17.once('error', reject);
      }));

      if (isObject(input) && 'pipe' in input && isFunction(input.pipe)) {
        // if input has stream.Readable interface
        input.pipe(_classPrivateFieldGet(this, _dataStream));
      } else {
        if (_Array$isArray(input)) {
          var _iterator2 = _createForOfIteratorHelper(input),
              _step2;

          try {
            for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
              var record = _step2.value;

              for (var _i2 = 0, _Object$keys3 = _Object$keys2(record); _i2 < _Object$keys3.length; _i2++) {
                var key = _Object$keys3[_i2];

                if (typeof record[key] === 'boolean') {
                  record[key] = String(record[key]);
                }
              }

              this.write(record);
            }
          } catch (err) {
            _iterator2.e(err);
          } finally {
            _iterator2.f();
          }

          this.end();
        } else if (typeof input === 'string') {
          _classPrivateFieldGet(this, _dataStream).write(input, 'utf8');

          _classPrivateFieldGet(this, _dataStream).end();
        }
      }

      return this;
    }
    /**
     * Promise/A+ interface
     * Delegate to promise, return promise instance for batch result
     */

  }, {
    key: "then",
    value: function then(onResolved, onReject) {
      if (_classPrivateFieldGet(this, _result) === undefined) {
        this.execute();
      }

      return _classPrivateFieldGet(this, _result).then(onResolved, onReject);
    }
  }]);

  return JobDataV2;
}(Writable);

function getJobIdOrError(jobInfo) {
  var jobId = jobInfo === null || jobInfo === void 0 ? void 0 : jobInfo.id;

  if (jobId === undefined) {
    throw new Error('No job id, maybe you need to call `job.open()` first.');
  }

  return jobId;
}

function delay(ms) {
  return new _Promise(function (resolve) {
    return _setTimeout(resolve, ms);
  });
}
/*--------------------------------------------*/

/*
 * Register hook in connection instantiation for dynamically adding this API module features
 */


registerModule('bulk', function (conn) {
  return new Bulk(conn);
});
registerModule('bulk2', function (conn) {
  return new BulkV2(conn);
});
export default Bulk;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9hcGkvYnVsay50cyJdLCJuYW1lcyI6WyJFdmVudEVtaXR0ZXIiLCJXcml0YWJsZSIsImpvaW5TdHJlYW1zIiwiU2VyaWFsaXphYmxlIiwiUGFyc2FibGUiLCJIdHRwQXBpIiwicmVnaXN0ZXJNb2R1bGUiLCJjb25jYXRTdHJlYW1zQXNEdXBsZXgiLCJpc0Z1bmN0aW9uIiwiaXNPYmplY3QiLCJKb2IiLCJidWxrIiwidHlwZSIsIm9wZXJhdGlvbiIsIm9wdGlvbnMiLCJqb2JJZCIsIl9idWxrIiwiaWQiLCJzdGF0ZSIsIl9iYXRjaGVzIiwib24iLCJlcnJvciIsIl9lcnJvciIsIl9qb2JJbmZvIiwiY2hlY2siLCJFcnJvciIsInRvTG93ZXJDYXNlIiwiYm9keSIsImV4dElkRmllbGQiLCJjb25jdXJyZW5jeU1vZGUiLCJhc3NpZ25tZW50UnVsZUlkIiwiX3JlcXVlc3QiLCJtZXRob2QiLCJwYXRoIiwiaGVhZGVycyIsInJlc3BvbnNlVHlwZSIsInJlcyIsImVtaXQiLCJqb2JJbmZvIiwiYmF0Y2giLCJCYXRjaCIsImJhdGNoSWQiLCJsb2dnZXIiLCJfbG9nZ2VyIiwicmVhZHkiLCJkZWJ1ZyIsIm9iamVjdCIsInJlc29sdmUiLCJvcGVuIiwidGhlbiIsImJhdGNoSW5mb0xpc3QiLCJiYXRjaEluZm8iLCJfY2hhbmdlU3RhdGUiLCJQb2xsaW5nVGltZW91dEVycm9yIiwibWVzc2FnZSIsIm5hbWUiLCJKb2JQb2xsaW5nVGltZW91dEVycm9yIiwiam9iIiwib2JqZWN0TW9kZSIsImV4ZWN1dGUiLCJjb252ZXJ0ZXJPcHRpb25zIiwibnVsbFZhbHVlIiwidXBsb2FkU3RyZWFtIiwiX3VwbG9hZFN0cmVhbSIsInVwbG9hZERhdGFTdHJlYW0iLCJzdHJlYW0iLCJkb3dubG9hZFN0cmVhbSIsIl9kb3dubG9hZFN0cmVhbSIsImRvd25sb2FkRGF0YVN0cmVhbSIsImVuZCIsIm9uY2UiLCJwaXBlIiwiX2NyZWF0ZVJlcXVlc3RTdHJlYW0iLCJfZGF0YVN0cmVhbSIsInJlcSIsInJlY29yZF8iLCJlbmMiLCJjYiIsIklkIiwiYXR0cmlidXRlcyIsInJyZWMiLCJyZWNvcmQiLCJ3cml0ZSIsImlucHV0IiwiX3Jlc3VsdCIsInJlamVjdCIsImtleSIsIlN0cmluZyIsIm9uUmVzb2x2ZWQiLCJvblJlamVjdCIsImludGVydmFsIiwidGltZW91dCIsInN0YXJ0VGltZSIsIkRhdGUiLCJnZXRUaW1lIiwicG9sbCIsIm5vdyIsImVyciIsIm51bWJlclJlY29yZHNQcm9jZXNzZWQiLCJyZXRyaWV2ZSIsInN0YXRlTWVzc2FnZSIsInJlc3AiLCJyZXN1bHRJZCIsInJlc3VsdCIsInJlc3VsdHMiLCJyZXQiLCJzdWNjZXNzIiwiU3VjY2VzcyIsImVycm9ycyIsInJlc3VsdFN0cmVhbSIsInJlc3VsdERhdGFTdHJlYW0iLCJCdWxrQXBpIiwicmVxdWVzdCIsIl9jb25uIiwiYWNjZXNzVG9rZW4iLCJyZXNwb25zZSIsInN0YXR1c0NvZGUiLCJ0ZXN0IiwiZXJyb3JDb2RlIiwiZXhjZXB0aW9uQ29kZSIsImV4Y2VwdGlvbk1lc3NhZ2UiLCJCdWxrQXBpVjIiLCJCdWxrIiwiY29ubiIsInJlcXVlc3RfIiwicnJlcSIsImJhc2VVcmwiLCJpbnN0YW5jZVVybCIsInZlcnNpb24iLCJqb2luIiwidXJsIiwib3B0aW9uc09ySW5wdXQiLCJjcmVhdGVKb2IiLCJjcmVhdGVCYXRjaCIsImNsZWFudXAiLCJjbG9zZSIsImNsZWFudXBPbkVycm9yIiwicG9sbEludGVydmFsIiwicG9sbFRpbWVvdXQiLCJzb3FsIiwibSIsInJlcGxhY2UiLCJtYXRjaCIsInJlY29yZFN0cmVhbSIsImRhdGFTdHJlYW0iLCJsb2FkIiwic3RyZWFtcyIsIkJ1bGtWMiIsImNvbm5lY3Rpb24iLCJJbmdlc3RKb2JWMiIsInBvbGxpbmdPcHRpb25zIiwidXBsb2FkRGF0YSIsImdldEFsbFJlc3VsdHMiLCJkZWxldGUiLCJjYXRjaCIsImlnbm9yZWQiLCJxdWVyeUpvYiIsIlF1ZXJ5Sm9iVjIiLCJxdWVyeSIsImdldFJlc3VsdHMiLCJjcmVhdGVRdWVyeVJlcXVlc3QiLCJnZXRKb2JJZE9yRXJyb3IiLCJkZWxheSIsInRpbWVvdXRFcnJvciIsIkpvYkRhdGFWMiIsImNyZWF0ZVJlcXVlc3QiLCJjcmVhdGVJbmdlc3RSZXF1ZXN0IiwiZXh0ZXJuYWxJZEZpZWxkTmFtZSIsImFsbCIsImdldFN1Y2Nlc3NmdWxSZXN1bHRzIiwiZ2V0RmFpbGVkUmVzdWx0cyIsImdldFVucHJvY2Vzc2VkUmVjb3JkcyIsInN1Y2Nlc3NmdWxSZXN1bHRzIiwiZmFpbGVkUmVzdWx0cyIsInVucHJvY2Vzc2VkUmVjb3JkcyIsInVuZGVmaW5lZCIsIm1zIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU0EsWUFBVCxRQUE2QixRQUE3QjtBQUNBLFNBQTJCQyxRQUEzQixRQUEyQyxRQUEzQztBQUNBLE9BQU9DLFdBQVAsTUFBd0IsYUFBeEI7QUFFQSxTQUFTQyxZQUFULEVBQXVCQyxRQUF2QixRQUF1QyxrQkFBdkM7QUFDQSxPQUFPQyxPQUFQLE1BQW9CLGFBQXBCO0FBRUEsU0FBU0MsY0FBVCxRQUErQixZQUEvQjtBQUVBLFNBQVNDLHFCQUFULFFBQXNDLGdCQUF0QztBQVFBLFNBQVNDLFVBQVQsRUFBcUJDLFFBQXJCLFFBQXFDLGtCQUFyQztBQUVBOztBQXdMQTtBQUNBO0FBQ0E7QUFDQSxXQUFhQyxHQUFiO0FBQUE7O0FBQUE7O0FBY0U7QUFDRjtBQUNBO0FBQ0UsZUFDRUMsSUFERixFQUVFQyxJQUZGLEVBR0VDLFNBSEYsRUFJRUMsT0FKRixFQUtFQyxLQUxGLEVBTUU7QUFBQTs7QUFBQTs7QUFDQTs7QUFEQTs7QUFBQTs7QUFBQTs7QUFBQTs7QUFBQTs7QUFBQTs7QUFBQTs7QUFBQTs7QUFBQTs7QUFFQSxVQUFLQyxLQUFMLEdBQWFMLElBQWI7QUFDQSxVQUFLQyxJQUFMLEdBQVlBLElBQVo7QUFDQSxVQUFLQyxTQUFMLEdBQWlCQSxTQUFqQjtBQUNBLFVBQUtDLE9BQUwsR0FBZUEsT0FBTyxJQUFJLEVBQTFCO0FBQ0EsVUFBS0csRUFBTCxHQUFVRixLQUFWLGFBQVVBLEtBQVYsY0FBVUEsS0FBVixHQUFtQixJQUFuQjtBQUNBLFVBQUtHLEtBQUwsR0FBYSxNQUFLRCxFQUFMLEdBQVUsTUFBVixHQUFtQixTQUFoQztBQUNBLFVBQUtFLFFBQUwsR0FBZ0IsRUFBaEIsQ0FSQSxDQVNBOztBQUNBLFVBQUtDLEVBQUwsQ0FBUSxPQUFSLEVBQWlCLFVBQUNDLEtBQUQ7QUFBQSxhQUFZLE1BQUtDLE1BQUwsR0FBY0QsS0FBMUI7QUFBQSxLQUFqQjs7QUFWQTtBQVdEO0FBRUQ7QUFDRjtBQUNBOzs7QUF0Q0E7QUFBQTtBQUFBLDJCQXVDUztBQUNMO0FBQ0EsVUFBSSxDQUFDLEtBQUtFLFFBQVYsRUFBb0I7QUFDbEIsYUFBS0EsUUFBTCxHQUFnQixLQUFLQyxLQUFMLEVBQWhCO0FBQ0Q7O0FBQ0QsYUFBTyxLQUFLRCxRQUFaO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBakRBO0FBQUE7QUFBQSwyQkFrRDJCO0FBQUE7O0FBQ3ZCLFVBQU1aLElBQUksR0FBRyxLQUFLSyxLQUFsQjtBQUNBLFVBQU1GLE9BQU8sR0FBRyxLQUFLQSxPQUFyQixDQUZ1QixDQUl2Qjs7QUFDQSxVQUFJLENBQUMsS0FBS0YsSUFBTixJQUFjLENBQUMsS0FBS0MsU0FBeEIsRUFBbUM7QUFDakMsY0FBTSxJQUFJWSxLQUFKLENBQVUsZ0RBQVYsQ0FBTjtBQUNELE9BUHNCLENBU3ZCOzs7QUFDQSxVQUFJLENBQUMsS0FBS0YsUUFBVixFQUFvQjtBQUFBOztBQUNsQixZQUFJVixVQUFTLEdBQUcsS0FBS0EsU0FBTCxDQUFlYSxXQUFmLEVBQWhCOztBQUNBLFlBQUliLFVBQVMsS0FBSyxZQUFsQixFQUFnQztBQUM5QkEsVUFBQUEsVUFBUyxHQUFHLFlBQVo7QUFDRDs7QUFDRCxZQUFJQSxVQUFTLEtBQUssVUFBbEIsRUFBOEI7QUFDNUJBLFVBQUFBLFVBQVMsR0FBRyxVQUFaO0FBQ0Q7O0FBQ0QsWUFBTWMsSUFBSSxHQUFHLDJUQUdKZCxVQUhJLCtDQUlQLEtBQUtELElBSkUsb0NBTWZFLE9BQU8sQ0FBQ2MsVUFBUixrQ0FDNEJkLE9BQU8sQ0FBQ2MsVUFEcEMsOEJBRUksRUFSVywyQkFXZmQsT0FBTyxDQUFDZSxlQUFSLDhCQUN3QmYsT0FBTyxDQUFDZSxlQURoQywwQkFFSSxFQWJXLDJCQWdCZmYsT0FBTyxDQUFDZ0IsZ0JBQVIsK0JBQ3lCaEIsT0FBTyxDQUFDZ0IsZ0JBRGpDLDJCQUVJLEVBbEJXLDJFQUFiOztBQXdCQSxhQUFLUCxRQUFMLEdBQWdCLHlEQUFDO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUtaLElBQUksQ0FBQ29CLFFBQUwsQ0FBK0I7QUFDL0NDLG9CQUFBQSxNQUFNLEVBQUUsTUFEdUM7QUFFL0NDLG9CQUFBQSxJQUFJLEVBQUUsTUFGeUM7QUFHL0NOLG9CQUFBQSxJQUFJLEVBQUpBLElBSCtDO0FBSS9DTyxvQkFBQUEsT0FBTyxFQUFFO0FBQ1Asc0NBQWdCO0FBRFQscUJBSnNDO0FBTy9DQyxvQkFBQUEsWUFBWSxFQUFFO0FBUGlDLG1CQUEvQixDQUZMOztBQUFBO0FBRVBDLGtCQUFBQSxJQUZPOztBQVdiLGtCQUFBLE1BQUksQ0FBQ0MsSUFBTCxDQUFVLE1BQVYsRUFBa0JELElBQUcsQ0FBQ0UsT0FBdEI7O0FBQ0Esa0JBQUEsTUFBSSxDQUFDckIsRUFBTCxHQUFVbUIsSUFBRyxDQUFDRSxPQUFKLENBQVlyQixFQUF0QjtBQUNBLGtCQUFBLE1BQUksQ0FBQ0MsS0FBTCxHQUFha0IsSUFBRyxDQUFDRSxPQUFKLENBQVlwQixLQUF6QjtBQWJhLG9EQWNOa0IsSUFBRyxDQUFDRSxPQWRFOztBQUFBO0FBQUE7QUFBQTs7QUFnQmIsa0JBQUEsTUFBSSxDQUFDRCxJQUFMLENBQVUsT0FBVjs7QUFoQmE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBRCxJQUFoQjtBQW9CRDs7QUFDRCxhQUFPLEtBQUtkLFFBQVo7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUF0SEE7QUFBQTtBQUFBLGtDQXVIK0I7QUFBQTs7QUFDM0IsVUFBTWdCLEtBQUssR0FBRyxJQUFJQyxLQUFKLENBQVUsSUFBVixDQUFkO0FBQ0FELE1BQUFBLEtBQUssQ0FBQ25CLEVBQU4sQ0FBUyxPQUFULEVBQWtCLFlBQU07QUFDdEIsUUFBQSxNQUFJLENBQUNELFFBQUwsQ0FBY29CLEtBQUssQ0FBQ3RCLEVBQXBCLElBQTJCc0IsS0FBM0I7QUFDRCxPQUZEO0FBR0EsYUFBT0EsS0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQWpJQTtBQUFBO0FBQUEsMEJBa0lRRSxPQWxJUixFQWtJd0M7QUFDcEMsVUFBSUYsS0FBSyxHQUFHLEtBQUtwQixRQUFMLENBQWNzQixPQUFkLENBQVo7O0FBQ0EsVUFBSSxDQUFDRixLQUFMLEVBQVk7QUFDVkEsUUFBQUEsS0FBSyxHQUFHLElBQUlDLEtBQUosQ0FBVSxJQUFWLEVBQWdCQyxPQUFoQixDQUFSO0FBQ0EsYUFBS3RCLFFBQUwsQ0FBY3NCLE9BQWQsSUFBeUJGLEtBQXpCO0FBQ0Q7O0FBQ0QsYUFBT0EsS0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQTdJQTtBQUFBO0FBQUEsNEJBOElVO0FBQUE7O0FBQ04sVUFBTTVCLElBQUksR0FBRyxLQUFLSyxLQUFsQjtBQUNBLFVBQU0wQixNQUFNLEdBQUcvQixJQUFJLENBQUNnQyxPQUFwQjtBQUVBLFdBQUtwQixRQUFMLEdBQWdCLHlEQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQ0ssTUFBSSxDQUFDcUIsS0FBTCxFQURMOztBQUFBO0FBQ1Q3QixnQkFBQUEsS0FEUztBQUFBO0FBQUEsdUJBRUdKLElBQUksQ0FBQ29CLFFBQUwsQ0FBK0I7QUFDL0NDLGtCQUFBQSxNQUFNLEVBQUUsS0FEdUM7QUFFL0NDLGtCQUFBQSxJQUFJLEVBQUUsVUFBVWxCLEtBRitCO0FBRy9Db0Isa0JBQUFBLFlBQVksRUFBRTtBQUhpQyxpQkFBL0IsQ0FGSDs7QUFBQTtBQUVUQyxnQkFBQUEsR0FGUztBQU9mTSxnQkFBQUEsTUFBTSxDQUFDRyxLQUFQLENBQWFULEdBQUcsQ0FBQ0UsT0FBakI7QUFDQSxnQkFBQSxNQUFJLENBQUNyQixFQUFMLEdBQVVtQixHQUFHLENBQUNFLE9BQUosQ0FBWXJCLEVBQXRCO0FBQ0EsZ0JBQUEsTUFBSSxDQUFDTCxJQUFMLEdBQVl3QixHQUFHLENBQUNFLE9BQUosQ0FBWVEsTUFBeEI7QUFDQSxnQkFBQSxNQUFJLENBQUNqQyxTQUFMLEdBQWlCdUIsR0FBRyxDQUFDRSxPQUFKLENBQVl6QixTQUE3QjtBQUNBLGdCQUFBLE1BQUksQ0FBQ0ssS0FBTCxHQUFha0IsR0FBRyxDQUFDRSxPQUFKLENBQVlwQixLQUF6QjtBQVhlLGtEQVlSa0IsR0FBRyxDQUFDRSxPQVpJOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BQUQsSUFBaEI7QUFlQSxhQUFPLEtBQUtmLFFBQVo7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUF0S0E7QUFBQTtBQUFBLDRCQXVLMkI7QUFDdkIsYUFBTyxLQUFLTixFQUFMLEdBQ0gsU0FBUThCLE9BQVIsQ0FBZ0IsS0FBSzlCLEVBQXJCLENBREcsR0FFSCxLQUFLK0IsSUFBTCxHQUFZQyxJQUFaLENBQWlCO0FBQUEsWUFBR2hDLEVBQUgsU0FBR0EsRUFBSDtBQUFBLGVBQVlBLEVBQVo7QUFBQSxPQUFqQixDQUZKO0FBR0Q7QUFFRDtBQUNGO0FBQ0E7O0FBL0tBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWlMVU4sZ0JBQUFBLElBakxWLEdBaUxpQixLQUFLSyxLQWpMdEI7QUFrTFUwQixnQkFBQUEsTUFsTFYsR0FrTG1CL0IsSUFBSSxDQUFDZ0MsT0FsTHhCO0FBQUE7QUFBQSx1QkFtTHdCLEtBQUtDLEtBQUwsRUFuTHhCOztBQUFBO0FBbUxVN0IsZ0JBQUFBLEtBbkxWO0FBQUE7QUFBQSx1QkFvTHNCSixJQUFJLENBQUNvQixRQUFMLENBQXFDO0FBQ3JEQyxrQkFBQUEsTUFBTSxFQUFFLEtBRDZDO0FBRXJEQyxrQkFBQUEsSUFBSSxFQUFFLFVBQVVsQixLQUFWLEdBQWtCLFFBRjZCO0FBR3JEb0Isa0JBQUFBLFlBQVksRUFBRTtBQUh1QyxpQkFBckMsQ0FwTHRCOztBQUFBO0FBb0xVQyxnQkFBQUEsR0FwTFY7QUF5TElNLGdCQUFBQSxNQUFNLENBQUNHLEtBQVAsQ0FBYVQsR0FBRyxDQUFDYyxhQUFKLENBQWtCQyxTQUEvQjtBQUNNRCxnQkFBQUEsYUExTFYsR0EwTDBCLGVBQWNkLEdBQUcsQ0FBQ2MsYUFBSixDQUFrQkMsU0FBaEMsSUFDbEJmLEdBQUcsQ0FBQ2MsYUFBSixDQUFrQkMsU0FEQSxHQUVsQixDQUFDZixHQUFHLENBQUNjLGFBQUosQ0FBa0JDLFNBQW5CLENBNUxSO0FBQUEsa0RBNkxXRCxhQTdMWDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQWdNRTtBQUNGO0FBQ0E7O0FBbE1BO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQW9NUyxLQUFLakMsRUFwTWQ7QUFBQTtBQUFBO0FBQUE7O0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBd000QixLQUFLbUMsWUFBTCxDQUFrQixRQUFsQixDQXhNNUI7O0FBQUE7QUF3TVlkLGdCQUFBQSxPQXhNWjtBQXlNTSxxQkFBS3JCLEVBQUwsR0FBVSxJQUFWO0FBQ0EscUJBQUtvQixJQUFMLENBQVUsT0FBVixFQUFtQkMsT0FBbkI7QUExTU4sa0RBMk1hQSxPQTNNYjs7QUFBQTtBQUFBO0FBQUE7QUE2TU0scUJBQUtELElBQUwsQ0FBVSxPQUFWO0FBN01OOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBa05FO0FBQ0Y7QUFDQTs7QUFwTkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBc05TLEtBQUtwQixFQXROZDtBQUFBO0FBQUE7QUFBQTs7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkEwTjRCLEtBQUttQyxZQUFMLENBQWtCLFNBQWxCLENBMU41Qjs7QUFBQTtBQTBOWWQsZ0JBQUFBLE9BMU5aO0FBMk5NLHFCQUFLckIsRUFBTCxHQUFVLElBQVY7QUFDQSxxQkFBS29CLElBQUwsQ0FBVSxPQUFWLEVBQW1CQyxPQUFuQjtBQTVOTixtREE2TmFBLE9BN05iOztBQUFBO0FBQUE7QUFBQTtBQStOTSxxQkFBS0QsSUFBTCxDQUFVLE9BQVY7QUEvTk47O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFvT0U7QUFDRjtBQUNBOztBQXRPQTtBQUFBO0FBQUE7QUFBQSxxR0F1T3FCbkIsS0F2T3JCO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQXdPVVAsZ0JBQUFBLElBeE9WLEdBd09pQixLQUFLSyxLQXhPdEI7QUF5T1UwQixnQkFBQUEsTUF6T1YsR0F5T21CL0IsSUFBSSxDQUFDZ0MsT0F6T3hCO0FBMk9JLHFCQUFLcEIsUUFBTCxHQUFnQix5REFBQztBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUNLLE1BQUksQ0FBQ3FCLEtBQUwsRUFETDs7QUFBQTtBQUNUN0IsMEJBQUFBLEtBRFM7QUFFVFksMEJBQUFBLElBRlMsR0FFRiwyS0FHUlQsS0FIUSxtREFGRTtBQUFBO0FBQUEsaUNBUUdQLElBQUksQ0FBQ29CLFFBQUwsQ0FBK0I7QUFDL0NDLDRCQUFBQSxNQUFNLEVBQUUsTUFEdUM7QUFFL0NDLDRCQUFBQSxJQUFJLEVBQUUsVUFBVWxCLEtBRitCO0FBRy9DWSw0QkFBQUEsSUFBSSxFQUFFQSxJQUh5QztBQUkvQ08sNEJBQUFBLE9BQU8sRUFBRTtBQUNQLDhDQUFnQjtBQURULDZCQUpzQztBQU8vQ0MsNEJBQUFBLFlBQVksRUFBRTtBQVBpQywyQkFBL0IsQ0FSSDs7QUFBQTtBQVFUQywwQkFBQUEsR0FSUztBQWlCZk0sMEJBQUFBLE1BQU0sQ0FBQ0csS0FBUCxDQUFhVCxHQUFHLENBQUNFLE9BQWpCO0FBQ0EsMEJBQUEsTUFBSSxDQUFDcEIsS0FBTCxHQUFha0IsR0FBRyxDQUFDRSxPQUFKLENBQVlwQixLQUF6QjtBQWxCZSw2REFtQlJrQixHQUFHLENBQUNFLE9BbkJJOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFELElBQWhCO0FBM09KLG1EQWdRVyxLQUFLZixRQWhRaEI7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLEVBR1V2QixZQUhWO0FBb1FBOztJQUNNcUQsbUI7Ozs7O0FBSUo7QUFDRjtBQUNBO0FBQ0UsK0JBQVlDLE9BQVosRUFBNkJ2QyxLQUE3QixFQUE0QzBCLE9BQTVDLEVBQTZEO0FBQUE7O0FBQUE7O0FBQzNELGdDQUFNYSxPQUFOOztBQUQyRDs7QUFBQTs7QUFFM0QsV0FBS0MsSUFBTCxHQUFZLGdCQUFaO0FBQ0EsV0FBS3hDLEtBQUwsR0FBYUEsS0FBYjtBQUNBLFdBQUswQixPQUFMLEdBQWVBLE9BQWY7QUFKMkQ7QUFLNUQ7OztpQ0FaK0JoQixLOztJQWU1QitCLHNCOzs7OztBQUdKO0FBQ0Y7QUFDQTtBQUNFLGtDQUFZRixPQUFaLEVBQTZCdkMsS0FBN0IsRUFBNEM7QUFBQTs7QUFBQTs7QUFDMUMsZ0NBQU11QyxPQUFOOztBQUQwQzs7QUFFMUMsV0FBS0MsSUFBTCxHQUFZLG1CQUFaO0FBQ0EsV0FBS3hDLEtBQUwsR0FBYUEsS0FBYjtBQUgwQztBQUkzQzs7O2lDQVZrQ1UsSztBQWFyQzs7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLFdBQWFlLEtBQWI7QUFBQTs7QUFBQTs7QUFhRTtBQUNGO0FBQ0E7QUFDRSxpQkFBWWlCLEdBQVosRUFBOEJ4QyxFQUE5QixFQUEyQztBQUFBOztBQUFBOztBQUN6QyxnQ0FBTTtBQUFFeUMsTUFBQUEsVUFBVSxFQUFFO0FBQWQsS0FBTjs7QUFEeUM7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUEsMkRBbUlyQyxPQUFLQyxPQW5JZ0M7O0FBQUEsNERBcUlwQyxPQUFLQSxPQXJJK0I7O0FBRXpDLFdBQUtGLEdBQUwsR0FBV0EsR0FBWDtBQUNBLFdBQUt4QyxFQUFMLEdBQVVBLEVBQVY7QUFDQSxXQUFLRCxLQUFMLEdBQWF5QyxHQUFHLENBQUN6QyxLQUFqQixDQUp5QyxDQU16Qzs7QUFDQSxXQUFLSSxFQUFMLENBQVEsT0FBUixFQUFpQixVQUFDQyxLQUFEO0FBQUEsYUFBWSxPQUFLQyxNQUFMLEdBQWNELEtBQTFCO0FBQUEsS0FBakIsRUFQeUMsQ0FTekM7QUFDQTtBQUNBOzs7QUFDQSxRQUFNdUMsZ0JBQWdCLEdBQUc7QUFBRUMsTUFBQUEsU0FBUyxFQUFFO0FBQWIsS0FBekI7QUFDQSxRQUFNQyxZQUFZLEdBQUksT0FBS0MsYUFBTCxHQUFxQixJQUFJNUQsWUFBSixFQUEzQztBQUNBLFFBQU02RCxnQkFBZ0IsR0FBR0YsWUFBWSxDQUFDRyxNQUFiLENBQW9CLEtBQXBCLEVBQTJCTCxnQkFBM0IsQ0FBekI7QUFDQSxRQUFNTSxjQUFjLEdBQUksT0FBS0MsZUFBTCxHQUF1QixJQUFJL0QsUUFBSixFQUEvQztBQUNBLFFBQU1nRSxrQkFBa0IsR0FBR0YsY0FBYyxDQUFDRCxNQUFmLENBQXNCLEtBQXRCLEVBQTZCTCxnQkFBN0IsQ0FBM0I7O0FBRUEsV0FBS3hDLEVBQUwsQ0FBUSxRQUFSLEVBQWtCO0FBQUEsYUFBTTBDLFlBQVksQ0FBQ08sR0FBYixFQUFOO0FBQUEsS0FBbEI7O0FBQ0FMLElBQUFBLGdCQUFnQixDQUFDTSxJQUFqQixDQUFzQixVQUF0Qix3RUFBa0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHeEIsT0FBS2IsR0FBTCxDQUFTYixLQUFULEVBSHdCOztBQUFBO0FBSTlCO0FBQ0FvQixjQUFBQSxnQkFBZ0IsQ0FBQ08sSUFBakIsQ0FBc0IsT0FBS0Msb0JBQUwsRUFBdEI7QUFMOEI7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBTzlCLHFCQUFLbkMsSUFBTCxDQUFVLE9BQVY7O0FBUDhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQWxDLElBbkJ5QyxDQThCekM7O0FBQ0EsV0FBS29DLFdBQUwsR0FBbUJsRSxxQkFBcUIsQ0FDdEN5RCxnQkFEc0MsRUFFdENJLGtCQUZzQyxDQUF4QztBQS9CeUM7QUFtQzFDO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTs7O0FBekRBO0FBQUE7QUFBQSwyQ0EwRHlCO0FBQUE7O0FBQ3JCLFVBQU16RCxJQUFJLEdBQUcsS0FBS0ssS0FBbEI7QUFDQSxVQUFNMEIsTUFBTSxHQUFHL0IsSUFBSSxDQUFDZ0MsT0FBcEI7O0FBQ0EsVUFBTStCLEdBQUcsR0FBRy9ELElBQUksQ0FBQ29CLFFBQUwsQ0FBaUM7QUFDM0NDLFFBQUFBLE1BQU0sRUFBRSxNQURtQztBQUUzQ0MsUUFBQUEsSUFBSSxFQUFFLFVBQVUsS0FBS3dCLEdBQUwsQ0FBU3hDLEVBQW5CLEdBQXdCLFFBRmE7QUFHM0NpQixRQUFBQSxPQUFPLEVBQUU7QUFDUCwwQkFBZ0I7QUFEVCxTQUhrQztBQU0zQ0MsUUFBQUEsWUFBWSxFQUFFO0FBTjZCLE9BQWpDLENBQVo7O0FBUUEsK0RBQUM7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFcUJ1QyxHQUZyQjs7QUFBQTtBQUVTdEMsZ0JBQUFBLEtBRlQ7QUFHR00sZ0JBQUFBLE1BQU0sQ0FBQ0csS0FBUCxDQUFhVCxLQUFHLENBQUNlLFNBQWpCO0FBQ0EsZ0JBQUEsTUFBSSxDQUFDbEMsRUFBTCxHQUFVbUIsS0FBRyxDQUFDZSxTQUFKLENBQWNsQyxFQUF4Qjs7QUFDQSxnQkFBQSxNQUFJLENBQUNvQixJQUFMLENBQVUsT0FBVixFQUFtQkQsS0FBRyxDQUFDZSxTQUF2Qjs7QUFMSDtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFPRyxnQkFBQSxNQUFJLENBQUNkLElBQUwsQ0FBVSxPQUFWOztBQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BQUQ7O0FBVUEsYUFBT3FDLEdBQUcsQ0FBQ1QsTUFBSixFQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBcEZBO0FBQUE7QUFBQSwyQkFxRlNVLE9BckZULEVBcUYwQkMsR0FyRjFCLEVBcUZ1Q0MsRUFyRnZDLEVBcUZ1RDtBQUFBLFVBQzNDQyxFQUQyQyxHQUNUSCxPQURTLENBQzNDRyxFQUQyQztBQUFBLFVBQ3ZDbEUsSUFEdUMsR0FDVCtELE9BRFMsQ0FDdkMvRCxJQUR1QztBQUFBLFVBQ2pDbUUsVUFEaUMsR0FDVEosT0FEUyxDQUNqQ0ksVUFEaUM7QUFBQSxVQUNsQkMsSUFEa0IsNEJBQ1RMLE9BRFM7O0FBRW5ELFVBQUlNLE1BQUo7O0FBQ0EsY0FBUSxLQUFLeEIsR0FBTCxDQUFTNUMsU0FBakI7QUFDRSxhQUFLLFFBQUw7QUFDRW9FLFVBQUFBLE1BQU0sR0FBR0QsSUFBVDtBQUNBOztBQUNGLGFBQUssUUFBTDtBQUNBLGFBQUssWUFBTDtBQUNFQyxVQUFBQSxNQUFNLEdBQUc7QUFBRUgsWUFBQUEsRUFBRSxFQUFGQTtBQUFGLFdBQVQ7QUFDQTs7QUFDRjtBQUNFRyxVQUFBQSxNQUFNO0FBQUtILFlBQUFBLEVBQUUsRUFBRkE7QUFBTCxhQUFZRSxJQUFaLENBQU47QUFUSjs7QUFXQSxXQUFLakIsYUFBTCxDQUFtQm1CLEtBQW5CLENBQXlCRCxNQUF6QixFQUFpQ0wsR0FBakMsRUFBc0NDLEVBQXRDO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBeEdBO0FBQUE7QUFBQSw2QkF5R1c7QUFDUCxhQUFPLEtBQUtKLFdBQVo7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUEvR0E7QUFBQTtBQUFBLDRCQWdIVVUsS0FoSFYsRUFnSGdEO0FBQUE7O0FBQzVDO0FBQ0EsVUFBSSxLQUFLQyxPQUFULEVBQWtCO0FBQ2hCLGNBQU0sSUFBSTNELEtBQUosQ0FBVSx5QkFBVixDQUFOO0FBQ0Q7O0FBRUQsV0FBSzJELE9BQUwsR0FBZSxhQUFZLFVBQUNyQyxPQUFELEVBQVVzQyxNQUFWLEVBQXFCO0FBQzlDLFFBQUEsT0FBSSxDQUFDZixJQUFMLENBQVUsVUFBVixFQUFzQnZCLE9BQXRCOztBQUNBLFFBQUEsT0FBSSxDQUFDdUIsSUFBTCxDQUFVLE9BQVYsRUFBbUJlLE1BQW5CO0FBQ0QsT0FIYyxDQUFmOztBQUtBLFVBQUk1RSxRQUFRLENBQUMwRSxLQUFELENBQVIsSUFBbUIsVUFBVUEsS0FBN0IsSUFBc0MzRSxVQUFVLENBQUMyRSxLQUFLLENBQUNaLElBQVAsQ0FBcEQsRUFBa0U7QUFDaEU7QUFDQVksUUFBQUEsS0FBSyxDQUFDWixJQUFOLENBQVcsS0FBS0UsV0FBaEI7QUFDRCxPQUhELE1BR087QUFDTCxZQUFJLGVBQWNVLEtBQWQsQ0FBSixFQUEwQjtBQUFBLHFEQUNIQSxLQURHO0FBQUE7O0FBQUE7QUFDeEIsZ0VBQTRCO0FBQUEsa0JBQWpCRixNQUFpQjs7QUFDMUIsOENBQWtCLGNBQVlBLE1BQVosQ0FBbEIsa0NBQXVDO0FBQWxDLG9CQUFNSyxHQUFHLG1CQUFUOztBQUNILG9CQUFJLE9BQU9MLE1BQU0sQ0FBQ0ssR0FBRCxDQUFiLEtBQXVCLFNBQTNCLEVBQXNDO0FBQ3BDTCxrQkFBQUEsTUFBTSxDQUFDSyxHQUFELENBQU4sR0FBY0MsTUFBTSxDQUFDTixNQUFNLENBQUNLLEdBQUQsQ0FBUCxDQUFwQjtBQUNEO0FBQ0Y7O0FBQ0QsbUJBQUtKLEtBQUwsQ0FBV0QsTUFBWDtBQUNEO0FBUnVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBU3hCLGVBQUtaLEdBQUw7QUFDRCxTQVZELE1BVU8sSUFBSSxPQUFPYyxLQUFQLEtBQWlCLFFBQXJCLEVBQStCO0FBQ3BDLGVBQUtWLFdBQUwsQ0FBaUJTLEtBQWpCLENBQXVCQyxLQUF2QixFQUE4QixNQUE5Qjs7QUFDQSxlQUFLVixXQUFMLENBQWlCSixHQUFqQjtBQUNEO0FBQ0YsT0E3QjJDLENBK0I1Qzs7O0FBQ0EsYUFBTyxJQUFQO0FBQ0Q7QUFqSkg7QUFBQTs7QUF1SkU7QUFDRjtBQUNBO0FBQ0E7QUExSkEseUJBNEpJbUIsVUE1SkosRUE2SklDLFFBN0pKLEVBOEpJO0FBQ0EsVUFBSSxDQUFDLEtBQUtMLE9BQVYsRUFBbUI7QUFDakIsYUFBS3pCLE9BQUw7QUFDRDs7QUFDRCxhQUFPLEtBQUt5QixPQUFMLENBQWNuQyxJQUFkLENBQW1CdUMsVUFBbkIsRUFBK0JDLFFBQS9CLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUF2S0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBeUtVOUUsZ0JBQUFBLElBektWLEdBeUtpQixLQUFLSyxLQXpLdEI7QUEwS1UwQixnQkFBQUEsTUExS1YsR0EwS21CL0IsSUFBSSxDQUFDZ0MsT0ExS3hCO0FBMktVNUIsZ0JBQUFBLEtBM0tWLEdBMktrQixLQUFLMEMsR0FBTCxDQUFTeEMsRUEzSzNCO0FBNEtVd0IsZ0JBQUFBLE9BNUtWLEdBNEtvQixLQUFLeEIsRUE1S3pCOztBQUFBLHNCQThLUSxDQUFDRixLQUFELElBQVUsQ0FBQzBCLE9BOUtuQjtBQUFBO0FBQUE7QUFBQTs7QUFBQSxzQkErS1ksSUFBSWhCLEtBQUosQ0FBVSxvQkFBVixDQS9LWjs7QUFBQTtBQUFBO0FBQUEsdUJBaUxzQmQsSUFBSSxDQUFDb0IsUUFBTCxDQUFpQztBQUNqREMsa0JBQUFBLE1BQU0sRUFBRSxLQUR5QztBQUVqREMsa0JBQUFBLElBQUksRUFBRSxVQUFVbEIsS0FBVixHQUFrQixTQUFsQixHQUE4QjBCLE9BRmE7QUFHakROLGtCQUFBQSxZQUFZLEVBQUU7QUFIbUMsaUJBQWpDLENBakx0Qjs7QUFBQTtBQWlMVUMsZ0JBQUFBLEdBakxWO0FBc0xJTSxnQkFBQUEsTUFBTSxDQUFDRyxLQUFQLENBQWFULEdBQUcsQ0FBQ2UsU0FBakI7QUF0TEosbURBdUxXZixHQUFHLENBQUNlLFNBdkxmOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBMExFO0FBQ0Y7QUFDQTs7QUE1TEE7QUFBQTtBQUFBLHlCQTZMT3VDLFFBN0xQLEVBNkx5QkMsT0E3THpCLEVBNkwwQztBQUFBOztBQUN0QyxVQUFNNUUsS0FBSyxHQUFHLEtBQUswQyxHQUFMLENBQVN4QyxFQUF2QjtBQUNBLFVBQU13QixPQUFPLEdBQUcsS0FBS3hCLEVBQXJCOztBQUVBLFVBQUksQ0FBQ0YsS0FBRCxJQUFVLENBQUMwQixPQUFmLEVBQXdCO0FBQ3RCLGNBQU0sSUFBSWhCLEtBQUosQ0FBVSxvQkFBVixDQUFOO0FBQ0Q7O0FBQ0QsVUFBTW1FLFNBQVMsR0FBRyxJQUFJQyxJQUFKLEdBQVdDLE9BQVgsRUFBbEI7O0FBQ0EsVUFBTUMsSUFBSTtBQUFBLDZFQUFHO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDTEMsa0JBQUFBLEdBREssR0FDQyxJQUFJSCxJQUFKLEdBQVdDLE9BQVgsRUFERDs7QUFBQSx3QkFFUEYsU0FBUyxHQUFHRCxPQUFaLEdBQXNCSyxHQUZmO0FBQUE7QUFBQTtBQUFBOztBQUdIQyxrQkFBQUEsSUFIRyxHQUdHLElBQUk1QyxtQkFBSixDQUNWLGdDQUFnQ3RDLEtBQWhDLEdBQXdDLGdCQUF4QyxHQUEyRDBCLE9BRGpELEVBRVYxQixLQUZVLEVBR1YwQixPQUhVLENBSEg7O0FBUVQsa0JBQUEsT0FBSSxDQUFDSixJQUFMLENBQVUsT0FBVixFQUFtQjRELElBQW5COztBQVJTOztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWFHLE9BQUksQ0FBQ3pFLEtBQUwsRUFiSDs7QUFBQTtBQWFUWSxrQkFBQUEsR0FiUztBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQWVULGtCQUFBLE9BQUksQ0FBQ0MsSUFBTCxDQUFVLE9BQVY7O0FBZlM7O0FBQUE7QUFrQlgsc0JBQUlELEdBQUcsQ0FBQ2xCLEtBQUosS0FBYyxRQUFsQixFQUE0QjtBQUMxQix3QkFBSSxVQUFTa0IsR0FBRyxDQUFDOEQsc0JBQWIsRUFBcUMsRUFBckMsSUFBMkMsQ0FBL0MsRUFBa0Q7QUFDaEQsc0JBQUEsT0FBSSxDQUFDQyxRQUFMO0FBQ0QscUJBRkQsTUFFTztBQUNMLHNCQUFBLE9BQUksQ0FBQzlELElBQUwsQ0FBVSxPQUFWLEVBQW1CLElBQUlaLEtBQUosQ0FBVVcsR0FBRyxDQUFDZ0UsWUFBZCxDQUFuQjtBQUNEO0FBQ0YsbUJBTkQsTUFNTyxJQUFJaEUsR0FBRyxDQUFDbEIsS0FBSixLQUFjLFdBQWxCLEVBQStCO0FBQ3BDLG9CQUFBLE9BQUksQ0FBQ2lGLFFBQUw7QUFDRCxtQkFGTSxNQUVBO0FBQ0wsb0JBQUEsT0FBSSxDQUFDOUQsSUFBTCxDQUFVLFVBQVYsRUFBc0JELEdBQXRCOztBQUNBLGdDQUFXMkQsSUFBWCxFQUFpQkwsUUFBakI7QUFDRDs7QUE3QlU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBSDs7QUFBQSx3QkFBSkssSUFBSTtBQUFBO0FBQUE7QUFBQSxTQUFWOztBQStCQSxrQkFBV0EsSUFBWCxFQUFpQkwsUUFBakI7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUF6T0E7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQTJPVS9FLGdCQUFBQSxJQTNPVixHQTJPaUIsS0FBS0ssS0EzT3RCO0FBNE9VRCxnQkFBQUEsS0E1T1YsR0E0T2tCLEtBQUswQyxHQUFMLENBQVN4QyxFQTVPM0I7QUE2T1V3QyxnQkFBQUEsR0E3T1YsR0E2T2dCLEtBQUtBLEdBN09yQjtBQThPVWhCLGdCQUFBQSxPQTlPVixHQThPb0IsS0FBS3hCLEVBOU96Qjs7QUFBQSxzQkFnUFEsQ0FBQ0YsS0FBRCxJQUFVLENBQUMwQixPQWhQbkI7QUFBQTtBQUFBO0FBQUE7O0FBQUEsc0JBaVBZLElBQUloQixLQUFKLENBQVUsb0JBQVYsQ0FqUFo7O0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBcVB5QmQsSUFBSSxDQUFDb0IsUUFBTCxDQUVqQjtBQUNBQyxrQkFBQUEsTUFBTSxFQUFFLEtBRFI7QUFFQUMsa0JBQUFBLElBQUksRUFBRSxVQUFVbEIsS0FBVixHQUFrQixTQUFsQixHQUE4QjBCLE9BQTlCLEdBQXdDO0FBRjlDLGlCQUZpQixDQXJQekI7O0FBQUE7QUFxUFk0RCxnQkFBQUEsSUFyUFo7O0FBNFBNLG9CQUFJNUMsR0FBRyxDQUFDNUMsU0FBSixLQUFrQixPQUFsQixJQUE2QjRDLEdBQUcsQ0FBQzVDLFNBQUosS0FBa0IsVUFBbkQsRUFBK0Q7QUFDdkR1QixrQkFBQUEsS0FEdUQsR0FDakRpRSxJQURpRDtBQUV6REMsa0JBQUFBLFFBRnlELEdBRTlDbEUsS0FBRyxDQUFDLGFBQUQsQ0FBSCxDQUFtQm1FLE1BRjJCO0FBRzdEQyxrQkFBQUEsT0FBTyxHQUFHLGtDQUFDLGVBQWNGLFFBQWQsSUFDUEEsUUFETyxHQUVQLENBQUNBLFFBQUQsQ0FGTSxtQkFHSixVQUFDckYsRUFBRDtBQUFBLDJCQUFTO0FBQUVBLHNCQUFBQSxFQUFFLEVBQUZBLEVBQUY7QUFBTXdCLHNCQUFBQSxPQUFPLEVBQVBBLE9BQU47QUFBZTFCLHNCQUFBQSxLQUFLLEVBQUxBO0FBQWYscUJBQVQ7QUFBQSxtQkFISSxDQUFWO0FBSUQsaUJBUEQsTUFPTztBQUNDcUIsa0JBQUFBLEtBREQsR0FDT2lFLElBRFA7QUFFTEcsa0JBQUFBLE9BQU8sR0FBRyxxQkFBQXBFLEtBQUcsTUFBSCxDQUFBQSxLQUFHLEVBQUssVUFBQ3FFLEdBQUQ7QUFBQSwyQkFBVTtBQUMxQnhGLHNCQUFBQSxFQUFFLEVBQUV3RixHQUFHLENBQUMzQixFQUFKLElBQVUsSUFEWTtBQUUxQjRCLHNCQUFBQSxPQUFPLEVBQUVELEdBQUcsQ0FBQ0UsT0FBSixLQUFnQixNQUZDO0FBRzFCQyxzQkFBQUEsTUFBTSxFQUFFSCxHQUFHLENBQUNoRixLQUFKLEdBQVksQ0FBQ2dGLEdBQUcsQ0FBQ2hGLEtBQUwsQ0FBWixHQUEwQjtBQUhSLHFCQUFWO0FBQUEsbUJBQUwsQ0FBYjtBQUtEOztBQUNELHFCQUFLWSxJQUFMLENBQVUsVUFBVixFQUFzQm1FLE9BQXRCO0FBM1FOLG1EQTRRYUEsT0E1UWI7O0FBQUE7QUFBQTtBQUFBO0FBOFFNLHFCQUFLbkUsSUFBTCxDQUFVLE9BQVY7QUE5UU47O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFtUkU7QUFDRjtBQUNBO0FBQ0E7QUFDQTs7QUF2UkE7QUFBQTtBQUFBLDJCQXdSU2lFLFFBeFJULEVBd1IyQjtBQUN2QixVQUFNdkYsS0FBSyxHQUFHLEtBQUswQyxHQUFMLENBQVN4QyxFQUF2QjtBQUNBLFVBQU13QixPQUFPLEdBQUcsS0FBS3hCLEVBQXJCOztBQUNBLFVBQUksQ0FBQ0YsS0FBRCxJQUFVLENBQUMwQixPQUFmLEVBQXdCO0FBQ3RCLGNBQU0sSUFBSWhCLEtBQUosQ0FBVSxvQkFBVixDQUFOO0FBQ0Q7O0FBQ0QsVUFBTW9GLFlBQVksR0FBRyxJQUFJekcsUUFBSixFQUFyQjtBQUNBLFVBQU0wRyxnQkFBZ0IsR0FBR0QsWUFBWSxDQUFDNUMsTUFBYixDQUFvQixLQUFwQixDQUF6Qjs7QUFDQSxXQUFLakQsS0FBTCxDQUNHZSxRQURILENBQ1k7QUFDUkMsUUFBQUEsTUFBTSxFQUFFLEtBREE7QUFFUkMsUUFBQUEsSUFBSSxFQUFFLFVBQVVsQixLQUFWLEdBQWtCLFNBQWxCLEdBQThCMEIsT0FBOUIsR0FBd0MsVUFBeEMsR0FBcUQ2RCxRQUZuRDtBQUdSbkUsUUFBQUEsWUFBWSxFQUFFO0FBSE4sT0FEWixFQU1HOEIsTUFOSCxHQU9HTSxJQVBILENBT1F1QyxnQkFQUjs7QUFRQSxhQUFPRCxZQUFQO0FBQ0Q7QUF6U0g7O0FBQUE7QUFBQSxFQUdVNUcsUUFIVjtBQTRTQTs7QUFDQTtBQUNBO0FBQ0E7O0lBQ004RyxPOzs7Ozs7Ozs7Ozs7OytCQUNPQyxPLEVBQXNCO0FBQUE7O0FBQy9CQSxNQUFBQSxPQUFPLENBQUM5RSxPQUFSLG1DQUNLOEUsT0FBTyxDQUFDOUUsT0FEYjtBQUVFLG1EQUFrQixLQUFLK0UsS0FBTCxDQUFXQyxXQUE3Qix5RUFBNEM7QUFGOUM7QUFJRDs7O3FDQUVnQkMsUSxFQUF3QjtBQUN2QyxhQUNFQSxRQUFRLENBQUNDLFVBQVQsS0FBd0IsR0FBeEIsSUFDQSxtREFBbURDLElBQW5ELENBQXdERixRQUFRLENBQUN4RixJQUFqRSxDQUZGO0FBSUQ7OzsyQ0FFc0JBLEksRUFBVztBQUNoQyxhQUFPLENBQUMsQ0FBQ0EsSUFBSSxDQUFDTixLQUFkO0FBQ0Q7OzsrQkFFVU0sSSxFQUFXO0FBQ3BCLGFBQU87QUFDTDJGLFFBQUFBLFNBQVMsRUFBRTNGLElBQUksQ0FBQ04sS0FBTCxDQUFXa0csYUFEakI7QUFFTGpFLFFBQUFBLE9BQU8sRUFBRTNCLElBQUksQ0FBQ04sS0FBTCxDQUFXbUc7QUFGZixPQUFQO0FBSUQ7Ozs7RUF4QnFDbkgsTzs7SUEyQmxDb0gsUzs7Ozs7Ozs7Ozs7OzsyQ0FDbUI5RixJLEVBQVc7QUFDaEMsYUFDRSxlQUFjQSxJQUFkLEtBQ0EsUUFBT0EsSUFBSSxDQUFDLENBQUQsQ0FBWCxNQUFtQixRQURuQixJQUVBLGVBQWVBLElBQUksQ0FBQyxDQUFELENBSHJCO0FBS0Q7OztxQ0FFZ0J3RixRLEVBQWlDO0FBQ2hELGFBQ0VBLFFBQVEsQ0FBQ0MsVUFBVCxLQUF3QixHQUF4QixJQUErQixxQkFBcUJDLElBQXJCLENBQTBCRixRQUFRLENBQUN4RixJQUFuQyxDQURqQztBQUdEOzs7K0JBRVVBLEksRUFBVztBQUNwQixhQUFPO0FBQ0wyRixRQUFBQSxTQUFTLEVBQUUzRixJQUFJLENBQUMsQ0FBRCxDQUFKLENBQVEyRixTQURkO0FBRUxoRSxRQUFBQSxPQUFPLEVBQUUzQixJQUFJLENBQUMsQ0FBRCxDQUFKLENBQVEyQjtBQUZaLE9BQVA7QUFJRDs7OztFQXBCdUNqRCxPO0FBdUIxQzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxXQUFhcUgsSUFBYjtBQUlFO0FBQ0Y7QUFDQTs7QUFHRTtBQUNGO0FBQ0E7QUFDQTs7QUFHRTtBQUNGO0FBQ0E7QUFDRSxnQkFBWUMsSUFBWixFQUFpQztBQUFBOztBQUFBOztBQUFBOztBQUFBLDBDQVhsQixJQVdrQjs7QUFBQSx5Q0FMbkIsS0FLbUI7O0FBQy9CLFNBQUtWLEtBQUwsR0FBYVUsSUFBYjtBQUNBLFNBQUtoRixPQUFMLEdBQWVnRixJQUFJLENBQUNoRixPQUFwQjtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUF6QkE7QUFBQTtBQUFBLDZCQTBCY2lGLFFBMUJkLEVBMEJxQztBQUNqQyxVQUFNRCxJQUFJLEdBQUcsS0FBS1YsS0FBbEI7O0FBRGlDLFVBRXpCaEYsSUFGeUIsR0FFTzJGLFFBRlAsQ0FFekIzRixJQUZ5QjtBQUFBLFVBRW5CRSxZQUZtQixHQUVPeUYsUUFGUCxDQUVuQnpGLFlBRm1CO0FBQUEsVUFFRjBGLElBRkUsNEJBRU9ELFFBRlA7O0FBR2pDLFVBQU1FLE9BQU8sR0FBRyxDQUFDSCxJQUFJLENBQUNJLFdBQU4sRUFBbUIsZ0JBQW5CLEVBQXFDSixJQUFJLENBQUNLLE9BQTFDLEVBQW1EQyxJQUFuRCxDQUNkLEdBRGMsQ0FBaEI7O0FBR0EsVUFBTWpCLE9BQU8sbUNBQ1JhLElBRFE7QUFFWEssUUFBQUEsR0FBRyxFQUFFSixPQUFPLEdBQUc3RjtBQUZKLFFBQWI7O0FBSUEsYUFBTyxJQUFJOEUsT0FBSixDQUFZLEtBQUtFLEtBQWpCLEVBQXdCO0FBQUU5RSxRQUFBQSxZQUFZLEVBQVpBO0FBQUYsT0FBeEIsRUFBMEM2RSxPQUExQyxDQUFxREEsT0FBckQsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQXpDQTtBQUFBO0FBQUEseUJBc0RJcEcsSUF0REosRUF1RElDLFNBdkRKLEVBd0RJc0gsY0F4REosRUF5REloRCxLQXpESixFQTBESTtBQUFBOztBQUNBLFVBQUlyRSxPQUFvQixHQUFHLEVBQTNCOztBQUNBLFVBQ0UsT0FBT3FILGNBQVAsS0FBMEIsUUFBMUIsSUFDQSxlQUFjQSxjQUFkLENBREEsSUFFQzFILFFBQVEsQ0FBQzBILGNBQUQsQ0FBUixJQUNDLFVBQVVBLGNBRFgsSUFFQyxPQUFPQSxjQUFjLENBQUM1RCxJQUF0QixLQUErQixVQUxuQyxFQU1FO0FBQ0E7QUFDQVksUUFBQUEsS0FBSyxHQUFHZ0QsY0FBUjtBQUNELE9BVEQsTUFTTztBQUNMckgsUUFBQUEsT0FBTyxHQUFHcUgsY0FBVjtBQUNEOztBQUNELFVBQU0xRSxHQUFHLEdBQUcsS0FBSzJFLFNBQUwsQ0FBZXhILElBQWYsRUFBcUJDLFNBQXJCLEVBQWdDQyxPQUFoQyxDQUFaO0FBQ0EsVUFBTXlCLEtBQUssR0FBR2tCLEdBQUcsQ0FBQzRFLFdBQUosRUFBZDs7QUFDQSxVQUFNQyxPQUFPLEdBQUcsU0FBVkEsT0FBVTtBQUFBLGVBQU03RSxHQUFHLENBQUM4RSxLQUFKLEVBQU47QUFBQSxPQUFoQjs7QUFDQSxVQUFNQyxjQUFjLEdBQUcsU0FBakJBLGNBQWlCLENBQUN2QyxHQUFELEVBQWdCO0FBQ3JDLFlBQUlBLEdBQUcsQ0FBQzFDLElBQUosS0FBYSxnQkFBakIsRUFBbUM7QUFDakMrRSxVQUFBQSxPQUFPO0FBQ1I7QUFDRixPQUpEOztBQUtBL0YsTUFBQUEsS0FBSyxDQUFDbkIsRUFBTixDQUFTLFVBQVQsRUFBcUJrSCxPQUFyQjtBQUNBL0YsTUFBQUEsS0FBSyxDQUFDbkIsRUFBTixDQUFTLE9BQVQsRUFBa0JvSCxjQUFsQjtBQUNBakcsTUFBQUEsS0FBSyxDQUFDbkIsRUFBTixDQUFTLE9BQVQsRUFBa0IsWUFBTTtBQUN0Qm1CLFFBQUFBLEtBQUssU0FBTCxJQUFBQSxLQUFLLFdBQUwsWUFBQUEsS0FBSyxDQUFFd0QsSUFBUCxDQUFZLE9BQUksQ0FBQzBDLFlBQWpCLEVBQStCLE9BQUksQ0FBQ0MsV0FBcEM7QUFDRCxPQUZEO0FBR0EsYUFBT25HLEtBQUssQ0FBQ29CLE9BQU4sQ0FBY3dCLEtBQWQsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQTFGQTtBQUFBO0FBQUEsMEJBMkZRd0QsSUEzRlIsRUEyRnNCO0FBQUE7O0FBQ2xCLFVBQU1DLENBQUMsR0FBR0QsSUFBSSxDQUFDRSxPQUFMLENBQWEsY0FBYixFQUE2QixFQUE3QixFQUFpQ0MsS0FBakMsQ0FBdUMsZUFBdkMsQ0FBVjs7QUFDQSxVQUFJLENBQUNGLENBQUwsRUFBUTtBQUNOLGNBQU0sSUFBSW5ILEtBQUosQ0FDSiwrREFESSxDQUFOO0FBR0Q7O0FBQ0QsVUFBTWIsSUFBSSxHQUFHZ0ksQ0FBQyxDQUFDLENBQUQsQ0FBZDtBQUNBLFVBQU1HLFlBQVksR0FBRyxJQUFJM0ksUUFBSixFQUFyQjtBQUNBLFVBQU00SSxVQUFVLEdBQUdELFlBQVksQ0FBQzlFLE1BQWIsQ0FBb0IsS0FBcEIsQ0FBbkI7O0FBQ0EsK0RBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUV5QixPQUFJLENBQUNnRixJQUFMLENBQVVySSxJQUFWLEVBQWdCLE9BQWhCLEVBQXlCK0gsSUFBekIsQ0FGekI7O0FBQUE7QUFFU25DLGdCQUFBQSxPQUZUO0FBR1MwQyxnQkFBQUEsT0FIVCxHQUdtQixxQkFBQTFDLE9BQU8sTUFBUCxDQUFBQSxPQUFPLEVBQUssVUFBQ0QsTUFBRDtBQUFBLHlCQUMxQixPQUFJLENBQUM5QyxHQUFMLENBQVM4QyxNQUFNLENBQUN4RixLQUFoQixFQUNHd0IsS0FESCxDQUNTZ0UsTUFBTSxDQUFDOUQsT0FEaEIsRUFFRzhELE1BRkgsQ0FFVUEsTUFBTSxDQUFDdEYsRUFGakIsRUFHR2dELE1BSEgsRUFEMEI7QUFBQSxpQkFBTCxDQUgxQjtBQVNHL0QsZ0JBQUFBLFdBQVcsQ0FBQ2dKLE9BQUQsQ0FBWCxDQUFxQjNFLElBQXJCLENBQTBCeUUsVUFBMUI7QUFUSDtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQVdHRCxnQkFBQUEsWUFBWSxDQUFDMUcsSUFBYixDQUFrQixPQUFsQjs7QUFYSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUFEOztBQWNBLGFBQU8wRyxZQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBeEhBO0FBQUE7QUFBQSw4QkEwSEluSSxJQTFISixFQTJISUMsU0EzSEosRUE2SEk7QUFBQSxVQURBQyxPQUNBLHVFQUR1QixFQUN2QjtBQUNBLGFBQU8sSUFBSUosR0FBSixDQUFRLElBQVIsRUFBY0UsSUFBZCxFQUFvQkMsU0FBcEIsRUFBK0JDLE9BQS9CLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUF0SUE7QUFBQTtBQUFBLHdCQXVJaUNDLEtBdklqQyxFQXVJZ0Q7QUFDNUMsYUFBTyxJQUFJTCxHQUFKLENBQWdCLElBQWhCLEVBQXNCLElBQXRCLEVBQTRCLElBQTVCLEVBQWtDLElBQWxDLEVBQXdDSyxLQUF4QyxDQUFQO0FBQ0Q7QUF6SUg7O0FBQUE7QUFBQTs7OztBQTRJQSxXQUFhb0ksTUFBYjtBQUdFO0FBQ0Y7QUFDQTs7QUFHRTtBQUNGO0FBQ0E7QUFDQTtBQUdFLGtCQUFZQyxVQUFaLEVBQXVDO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUEsMENBUnhCLElBUXdCOztBQUFBLHlDQUZ6QixLQUV5Qjs7QUFDckMsNkNBQW1CQSxVQUFuQjtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFwQkE7QUFBQTtBQUFBLDhCQXNCSXRJLE9BdEJKLEVBdUJ5QjtBQUNyQixhQUFPLElBQUl1SSxXQUFKLENBQWdCO0FBQ3JCRCxRQUFBQSxVQUFVLHdCQUFFLElBQUYsY0FEVztBQUVyQjlHLFFBQUFBLE9BQU8sRUFBRXhCLE9BRlk7QUFHckJ3SSxRQUFBQSxjQUFjLEVBQUU7QUFISyxPQUFoQixDQUFQO0FBS0Q7QUE3Qkg7QUFBQTtBQUFBLHdCQWdDSXhJLE9BaENKLEVBaUN5QjtBQUNyQixhQUFPLElBQUl1SSxXQUFKLENBQWdCO0FBQ3JCRCxRQUFBQSxVQUFVLHdCQUFFLElBQUYsY0FEVztBQUVyQjlHLFFBQUFBLE9BQU8sRUFBRXhCLE9BRlk7QUFHckJ3SSxRQUFBQSxjQUFjLEVBQUU7QUFISyxPQUFoQixDQUFQO0FBS0Q7QUFFRDtBQUNGO0FBQ0E7O0FBM0NBO0FBQUE7QUFBQTtBQUFBLCtHQTZDSXhJLE9BN0NKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWtEVTJDLGdCQUFBQSxHQWxEVixHQWtEZ0IsS0FBSzJFLFNBQUwsQ0FBZXRILE9BQWYsQ0FsRGhCO0FBQUE7QUFBQTtBQUFBLHVCQW9EWTJDLEdBQUcsQ0FBQ1QsSUFBSixFQXBEWjs7QUFBQTtBQUFBO0FBQUEsdUJBcURZUyxHQUFHLENBQUM4RixVQUFKLENBQWV6SSxPQUFPLENBQUNxRSxLQUF2QixDQXJEWjs7QUFBQTtBQUFBO0FBQUEsdUJBc0RZMUIsR0FBRyxDQUFDOEUsS0FBSixFQXREWjs7QUFBQTtBQUFBO0FBQUEsdUJBdURZOUUsR0FBRyxDQUFDc0MsSUFBSixDQUFTakYsT0FBTyxDQUFDMkgsWUFBakIsRUFBK0IzSCxPQUFPLENBQUM0SCxXQUF2QyxDQXZEWjs7QUFBQTtBQUFBO0FBQUEsdUJBd0RtQmpGLEdBQUcsQ0FBQytGLGFBQUosRUF4RG5COztBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQTBETSxvQkFBSSxjQUFJakcsSUFBSixLQUFhLHdCQUFqQixFQUEyQztBQUN6QztBQUNBRSxrQkFBQUEsR0FBRyxDQUFDZ0csTUFBSixHQUFhQyxLQUFiLENBQW1CLFVBQUNDLE9BQUQ7QUFBQSwyQkFBYUEsT0FBYjtBQUFBLG1CQUFuQjtBQUNEOztBQTdEUDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQWtFRTtBQUNGO0FBQ0E7O0FBcEVBO0FBQUE7QUFBQTtBQUFBLCtGQXNFSWhCLElBdEVKLEVBdUVJN0gsT0F2RUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBeUVVOEksZ0JBQUFBLFFBekVWLEdBeUVxQixJQUFJQyxVQUFKLENBQWU7QUFDOUJULGtCQUFBQSxVQUFVLHdCQUFFLElBQUYsY0FEb0I7QUFFOUJ2SSxrQkFBQUEsU0FBUyxFQUFFLE9BRm1CO0FBRzlCaUosa0JBQUFBLEtBQUssRUFBRW5CLElBSHVCO0FBSTlCVyxrQkFBQUEsY0FBYyxFQUFFO0FBSmMsaUJBQWYsQ0F6RXJCO0FBQUE7QUFBQTtBQUFBLHVCQWdGWU0sUUFBUSxDQUFDNUcsSUFBVCxFQWhGWjs7QUFBQTtBQUFBO0FBQUEsdUJBaUZZNEcsUUFBUSxDQUFDN0QsSUFBVCxDQUFjakYsT0FBZCxhQUFjQSxPQUFkLHVCQUFjQSxPQUFPLENBQUUySCxZQUF2QixFQUFxQzNILE9BQXJDLGFBQXFDQSxPQUFyQyx1QkFBcUNBLE9BQU8sQ0FBRTRILFdBQTlDLENBakZaOztBQUFBO0FBQUE7QUFBQSx1QkFrRm1Ca0IsUUFBUSxDQUFDRyxVQUFULEVBbEZuQjs7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFvRk0sb0JBQUksY0FBSXhHLElBQUosS0FBYSx3QkFBakIsRUFBMkM7QUFDekM7QUFDQXFHLGtCQUFBQSxRQUFRLENBQUNILE1BQVQsR0FBa0JDLEtBQWxCLENBQXdCLFVBQUNDLE9BQUQ7QUFBQSwyQkFBYUEsT0FBYjtBQUFBLG1CQUF4QjtBQUNEOztBQXZGUDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7Ozs7Ozs7Ozs7Ozs7O0FBNkZBLFdBQWFFLFVBQWI7QUFBQTs7QUFBQTs7QUFTRSxzQkFBWS9JLE9BQVosRUFBaUQ7QUFBQTs7QUFBQTs7QUFDL0M7O0FBRCtDO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBOztBQUUvQyx5RUFBbUJBLE9BQU8sQ0FBQ3NJLFVBQTNCOztBQUNBLHdFQUFrQnRJLE9BQU8sQ0FBQ0QsU0FBMUI7O0FBQ0Esb0VBQWNDLE9BQU8sQ0FBQ2dKLEtBQXRCOztBQUNBLDRFQUF1QmhKLE9BQU8sQ0FBQ3dJLGNBQS9CLEVBTCtDLENBTS9DOzs7QUFDQSxZQUFLbEksRUFBTCxDQUFRLE9BQVIsRUFBaUIsVUFBQ0MsS0FBRDtBQUFBLDRFQUEwQkEsS0FBMUI7QUFBQSxLQUFqQjs7QUFQK0M7QUFRaEQ7O0FBakJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBcUIyQixLQUFLMkksa0JBQUwsQ0FBbUM7QUFDdERoSSxrQkFBQUEsTUFBTSxFQUFFLE1BRDhDO0FBRXREQyxrQkFBQUEsSUFBSSxFQUFFLEVBRmdEO0FBR3RETixrQkFBQUEsSUFBSSxFQUFFLGdCQUFlO0FBQ25CZCxvQkFBQUEsU0FBUyx3QkFBRSxJQUFGLGNBRFU7QUFFbkJpSixvQkFBQUEsS0FBSyx3QkFBRSxJQUFGO0FBRmMsbUJBQWYsQ0FIZ0Q7QUFPdEQ1SCxrQkFBQUEsT0FBTyxFQUFFO0FBQ1Asb0NBQWdCO0FBRFQsbUJBUDZDO0FBVXREQyxrQkFBQUEsWUFBWSxFQUFFO0FBVndDLGlCQUFuQyxDQXJCM0I7O0FBQUE7QUFxQk0scUJBQUtHLE9BckJYO0FBaUNNLHFCQUFLRCxJQUFMLENBQVUsTUFBVjtBQWpDTjtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQW1DTSxxQkFBS0EsSUFBTCxDQUFVLE9BQVY7QUFuQ047O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUF3Q0U7QUFDRjtBQUNBOztBQTFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUE2Q1luQixnQkFBQUEsS0E3Q1osR0E2Q2dDLFNBN0NoQztBQUFBO0FBQUEsdUJBOEMyQixLQUFLOEksa0JBQUwsQ0FBbUM7QUFDdERoSSxrQkFBQUEsTUFBTSxFQUFFLE9BRDhDO0FBRXREQyxrQkFBQUEsSUFBSSw4QkFBTSxLQUFLSyxPQUFYLGtEQUFNLGNBQWNyQixFQUFwQixDQUZrRDtBQUd0RFUsa0JBQUFBLElBQUksRUFBRSxnQkFBZTtBQUFFVCxvQkFBQUEsS0FBSyxFQUFMQTtBQUFGLG1CQUFmLENBSGdEO0FBSXREZ0Isa0JBQUFBLE9BQU8sRUFBRTtBQUFFLG9DQUFnQjtBQUFsQixtQkFKNkM7QUFLdERDLGtCQUFBQSxZQUFZLEVBQUU7QUFMd0MsaUJBQW5DLENBOUMzQjs7QUFBQTtBQThDTSxxQkFBS0csT0E5Q1g7QUFxRE0scUJBQUtELElBQUwsQ0FBVSxTQUFWO0FBckROO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBdURNLHFCQUFLQSxJQUFMLENBQVUsT0FBVjtBQXZETjs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUE2RElxRCxnQkFBQUEsUUE3REosaUVBNkR1Qiw2Q0FBcUIrQyxZQTdENUM7QUE4REk5QyxnQkFBQUEsT0E5REosaUVBOERzQiw2Q0FBcUIrQyxXQTlEM0M7QUFnRVUzSCxnQkFBQUEsS0FoRVYsR0FnRWtCa0osZUFBZSxDQUFDLEtBQUszSCxPQUFOLENBaEVqQztBQWlFVXNELGdCQUFBQSxTQWpFVixHQWlFc0IsV0FqRXRCOztBQUFBO0FBQUEsc0JBbUVXQSxTQUFTLEdBQUdELE9BQVosR0FBc0IsV0FuRWpDO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQSx1QkFxRTBCLEtBQUtuRSxLQUFMLEVBckUxQjs7QUFBQTtBQXFFY1ksZ0JBQUFBLEtBckVkO0FBQUEsZ0NBc0VnQkEsS0FBRyxDQUFDbEIsS0F0RXBCO0FBQUEsb0RBdUVlLE1BdkVmLDBCQXlFZSxTQXpFZiwwQkEyRWUsZ0JBM0VmLDBCQTRFZSxZQTVFZiwwQkErRWUsUUEvRWYsMEJBa0ZlLGFBbEZmO0FBQUE7O0FBQUE7QUFBQSxzQkF3RWtCLElBQUlPLEtBQUosQ0FBVSwwQkFBVixDQXhFbEI7O0FBQUE7QUFBQSxzQkEwRWtCLElBQUlBLEtBQUosQ0FBVSxzQkFBVixDQTFFbEI7O0FBQUE7QUFBQTtBQUFBLHVCQTZFa0J5SSxLQUFLLENBQUN4RSxRQUFELENBN0V2Qjs7QUFBQTtBQUFBOztBQUFBO0FBZ0ZZLHFCQUFLckQsSUFBTCxDQUFVLFFBQVY7QUFoRlo7O0FBQUE7QUFtRlkscUJBQUtBLElBQUwsQ0FBVSxhQUFWO0FBbkZaOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUF1RlEscUJBQUtBLElBQUwsQ0FBVSxPQUFWO0FBdkZSOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQTRGVThILGdCQUFBQSxZQTVGVixHQTRGeUIsSUFBSTNHLHNCQUFKLHNDQUNXekMsS0FEWCxHQUVuQkEsS0FGbUIsQ0E1RnpCO0FBZ0dJLHFCQUFLc0IsSUFBTCxDQUFVLE9BQVYsRUFBbUI4SCxZQUFuQjtBQWhHSixzQkFpR1VBLFlBakdWOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBb0dFO0FBQ0Y7QUFDQTs7QUF0R0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXlHNEIsS0FBS0gsa0JBQUwsQ0FBbUM7QUFDdkRoSSxrQkFBQUEsTUFBTSxFQUFFLEtBRCtDO0FBRXZEQyxrQkFBQUEsSUFBSSxhQUFNZ0ksZUFBZSxDQUFDLEtBQUszSCxPQUFOLENBQXJCLENBRm1EO0FBR3ZESCxrQkFBQUEsWUFBWSxFQUFFO0FBSHlDLGlCQUFuQyxDQXpHNUI7O0FBQUE7QUF5R1lHLGdCQUFBQSxPQXpHWjtBQThHTSxxQkFBS0EsT0FBTCxHQUFlQSxPQUFmO0FBOUdOLG1EQStHYUEsT0EvR2I7O0FBQUE7QUFBQTtBQUFBO0FBaUhNLHFCQUFLRCxJQUFMLENBQVUsT0FBVjtBQWpITjs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBLDJDQXdIVSxJQXhIVjtBQUFBO0FBQUE7QUFBQTs7QUFBQSx5RUF5SGUsSUF6SGY7O0FBQUE7QUFBQTtBQUFBLHVCQTRINEIsS0FBSzJILGtCQUFMLENBQThDO0FBQ2xFaEksa0JBQUFBLE1BQU0sRUFBRSxLQUQwRDtBQUVsRUMsa0JBQUFBLElBQUksYUFBTWdJLGVBQWUsQ0FBQyxLQUFLM0gsT0FBTixDQUFyQixhQUY4RDtBQUdsRUgsa0JBQUFBLFlBQVksRUFBRTtBQUhvRCxpQkFBOUMsQ0E1SDVCOztBQUFBO0FBNEhZcUUsZ0JBQUFBLE9BNUhaOztBQWtJTSwyREFBcUJBLE9BQXJCLGFBQXFCQSxPQUFyQixjQUFxQkEsT0FBckIsR0FBZ0MsRUFBaEM7O0FBbElOLHlFQW9JYSxJQXBJYjs7QUFBQTtBQUFBO0FBQUE7QUFzSU0scUJBQUtuRSxJQUFMLENBQVUsT0FBVjtBQXRJTjs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtREE0SVcsS0FBSzJILGtCQUFMLENBQThCO0FBQ25DaEksa0JBQUFBLE1BQU0sRUFBRSxRQUQyQjtBQUVuQ0Msa0JBQUFBLElBQUksYUFBTWdJLGVBQWUsQ0FBQyxLQUFLM0gsT0FBTixDQUFyQjtBQUYrQixpQkFBOUIsQ0E1SVg7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBa0pnQzBFLE9BbEpoQyxFQWtKc0Q7QUFBQSxVQUMxQy9FLElBRDBDLEdBQ25CK0UsT0FEbUIsQ0FDMUMvRSxJQUQwQztBQUFBLFVBQ3BDRSxZQURvQyxHQUNuQjZFLE9BRG1CLENBQ3BDN0UsWUFEb0M7QUFFbEQsVUFBTTJGLE9BQU8sR0FBRyxDQUNkLDBDQUFpQkMsV0FESCxFQUVkLGVBRmMsYUFHViwwQ0FBaUJDLE9BSFAsR0FJZCxZQUpjLEVBS2RDLElBTGMsQ0FLVCxHQUxTLENBQWhCO0FBT0EsYUFBTyxJQUFJUixTQUFKLHVCQUFjLElBQWQsaUJBQWdDO0FBQUV0RixRQUFBQSxZQUFZLEVBQVpBO0FBQUYsT0FBaEMsRUFBa0Q2RSxPQUFsRCxpQ0FDRkEsT0FERTtBQUVMa0IsUUFBQUEsR0FBRyxFQUFFSixPQUFPLEdBQUc3RjtBQUZWLFNBQVA7QUFJRDtBQS9KSDs7QUFBQTtBQUFBLEVBQWtEakMsWUFBbEQ7QUFrS0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FBQ0EsV0FBYXFKLFdBQWI7QUFBQTs7QUFBQTs7QUFhRTtBQUNGO0FBQ0E7QUFDRSx1QkFBWXZJLE9BQVosRUFBa0Q7QUFBQTs7QUFBQTs7QUFDaEQ7O0FBRGdEO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBOztBQUdoRCx5RUFBbUJBLE9BQU8sQ0FBQ3NJLFVBQTNCOztBQUNBLDZFQUF1QnRJLE9BQU8sQ0FBQ3dJLGNBQS9COztBQUNBLFlBQUtoSCxPQUFMLEdBQWV4QixPQUFPLENBQUN3QixPQUF2Qjs7QUFDQSxxRUFBZ0IsSUFBSThILFNBQUosQ0FBc0I7QUFDcENDLE1BQUFBLGFBQWEsRUFBRSx1QkFBQ3JELE9BQUQ7QUFBQSxlQUFhLFFBQUtzRCxtQkFBTCxDQUF5QnRELE9BQXpCLENBQWI7QUFBQSxPQURxQjtBQUVwQ3ZELE1BQUFBLEdBQUc7QUFGaUMsS0FBdEIsQ0FBaEIsRUFOZ0QsQ0FVaEQ7OztBQUNBLFlBQUtyQyxFQUFMLENBQVEsT0FBUixFQUFpQixVQUFDQyxLQUFEO0FBQUEsNkVBQTBCQSxLQUExQjtBQUFBLEtBQWpCOztBQVhnRDtBQVlqRDs7QUE1Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFvQzJCLEtBQUtpSixtQkFBTCxDQUFvQztBQUN2RHRJLGtCQUFBQSxNQUFNLEVBQUUsTUFEK0M7QUFFdkRDLGtCQUFBQSxJQUFJLEVBQUUsRUFGaUQ7QUFHdkROLGtCQUFBQSxJQUFJLEVBQUUsZ0JBQWU7QUFDbkJHLG9CQUFBQSxnQkFBZ0Isb0JBQUUsS0FBS1EsT0FBUCxtREFBRSxlQUFjUixnQkFEYjtBQUVuQnlJLG9CQUFBQSxtQkFBbUIsb0JBQUUsS0FBS2pJLE9BQVAsbURBQUUsZUFBY2lJLG1CQUZoQjtBQUduQnpILG9CQUFBQSxNQUFNLG9CQUFFLEtBQUtSLE9BQVAsbURBQUUsZUFBY1EsTUFISDtBQUluQmpDLG9CQUFBQSxTQUFTLG9CQUFFLEtBQUt5QixPQUFQLG1EQUFFLGVBQWN6QjtBQUpOLG1CQUFmLENBSGlEO0FBU3ZEcUIsa0JBQUFBLE9BQU8sRUFBRTtBQUNQLG9DQUFnQjtBQURULG1CQVQ4QztBQVl2REMsa0JBQUFBLFlBQVksRUFBRTtBQVp5QyxpQkFBcEMsQ0FwQzNCOztBQUFBO0FBb0NNLHFCQUFLRyxPQXBDWDtBQWtETSxxQkFBS0QsSUFBTCxDQUFVLE1BQVY7QUFsRE47QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFvRE0scUJBQUtBLElBQUwsQ0FBVSxPQUFWO0FBcEROOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0dBeURtQjhDLEtBekRuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkEwRFUsc0NBQWN4QixPQUFkLENBQXNCd0IsS0FBdEIsQ0ExRFY7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFrRWMsU0FBUXFGLEdBQVIsQ0FBWSxDQUNwQixLQUFLQyxvQkFBTCxFQURvQixFQUVwQixLQUFLQyxnQkFBTCxFQUZvQixFQUdwQixLQUFLQyxxQkFBTCxFQUhvQixDQUFaLENBbEVkOztBQUFBO0FBQUE7QUFBQTtBQStETUMsZ0JBQUFBLGlCQS9ETjtBQWdFTUMsZ0JBQUFBLGFBaEVOO0FBaUVNQyxnQkFBQUEsa0JBakVOO0FBQUEsbURBdUVXO0FBQUVGLGtCQUFBQSxpQkFBaUIsRUFBakJBLGlCQUFGO0FBQXFCQyxrQkFBQUEsYUFBYSxFQUFiQSxhQUFyQjtBQUFvQ0Msa0JBQUFBLGtCQUFrQixFQUFsQkE7QUFBcEMsaUJBdkVYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBMEVFO0FBQ0Y7QUFDQTs7QUE1RUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUErRVk1SixnQkFBQUEsS0EvRVosR0ErRWdDLGdCQS9FaEM7QUFBQTtBQUFBLHVCQWdGMkIsS0FBS29KLG1CQUFMLENBQW9DO0FBQ3ZEdEksa0JBQUFBLE1BQU0sRUFBRSxPQUQrQztBQUV2REMsa0JBQUFBLElBQUksYUFBTSxLQUFLSyxPQUFMLENBQWFyQixFQUFuQixDQUZtRDtBQUd2RFUsa0JBQUFBLElBQUksRUFBRSxnQkFBZTtBQUFFVCxvQkFBQUEsS0FBSyxFQUFMQTtBQUFGLG1CQUFmLENBSGlEO0FBSXZEZ0Isa0JBQUFBLE9BQU8sRUFBRTtBQUFFLG9DQUFnQjtBQUFsQixtQkFKOEM7QUFLdkRDLGtCQUFBQSxZQUFZLEVBQUU7QUFMeUMsaUJBQXBDLENBaEYzQjs7QUFBQTtBQWdGTSxxQkFBS0csT0FoRlg7QUF1Rk0scUJBQUtELElBQUwsQ0FBVSxnQkFBVjtBQXZGTjtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQXlGTSxxQkFBS0EsSUFBTCxDQUFVLE9BQVY7QUF6Rk47O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUE4RkU7QUFDRjtBQUNBOztBQWhHQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQW1HWW5CLGdCQUFBQSxLQW5HWixHQW1HZ0MsU0FuR2hDO0FBQUE7QUFBQSx1QkFvRzJCLEtBQUtvSixtQkFBTCxDQUFvQztBQUN2RHRJLGtCQUFBQSxNQUFNLEVBQUUsT0FEK0M7QUFFdkRDLGtCQUFBQSxJQUFJLGFBQU0sS0FBS0ssT0FBTCxDQUFhckIsRUFBbkIsQ0FGbUQ7QUFHdkRVLGtCQUFBQSxJQUFJLEVBQUUsZ0JBQWU7QUFBRVQsb0JBQUFBLEtBQUssRUFBTEE7QUFBRixtQkFBZixDQUhpRDtBQUl2RGdCLGtCQUFBQSxPQUFPLEVBQUU7QUFBRSxvQ0FBZ0I7QUFBbEIsbUJBSjhDO0FBS3ZEQyxrQkFBQUEsWUFBWSxFQUFFO0FBTHlDLGlCQUFwQyxDQXBHM0I7O0FBQUE7QUFvR00scUJBQUtHLE9BcEdYO0FBMkdNLHFCQUFLRCxJQUFMLENBQVUsU0FBVjtBQTNHTjtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQTZHTSxxQkFBS0EsSUFBTCxDQUFVLE9BQVY7QUE3R047O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBbUhJcUQsZ0JBQUFBLFFBbkhKLGlFQW1IdUIsOENBQXFCK0MsWUFuSDVDO0FBb0hJOUMsZ0JBQUFBLE9BcEhKLGlFQW9Ic0IsOENBQXFCK0MsV0FwSDNDO0FBc0hVM0gsZ0JBQUFBLEtBdEhWLEdBc0hrQmtKLGVBQWUsQ0FBQyxLQUFLM0gsT0FBTixDQXRIakM7QUF1SFVzRCxnQkFBQUEsU0F2SFYsR0F1SHNCLFdBdkh0Qjs7QUFBQTtBQUFBLHNCQXlIV0EsU0FBUyxHQUFHRCxPQUFaLEdBQXNCLFdBekhqQztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsdUJBMkgwQixLQUFLbkUsS0FBTCxFQTNIMUI7O0FBQUE7QUEySGNZLGdCQUFBQSxLQTNIZDtBQUFBLGdDQTRIZ0JBLEtBQUcsQ0FBQ2xCLEtBNUhwQjtBQUFBLG9EQTZIZSxNQTdIZiwwQkErSGUsU0EvSGYsMEJBaUllLGdCQWpJZiwwQkFrSWUsWUFsSWYsMEJBcUllLFFBcklmLDBCQXdJZSxhQXhJZjtBQUFBOztBQUFBO0FBQUEsc0JBOEhrQixJQUFJTyxLQUFKLENBQVUsMEJBQVYsQ0E5SGxCOztBQUFBO0FBQUEsc0JBZ0lrQixJQUFJQSxLQUFKLENBQVUsc0JBQVYsQ0FoSWxCOztBQUFBO0FBQUE7QUFBQSx1QkFtSWtCeUksS0FBSyxDQUFDeEUsUUFBRCxDQW5JdkI7O0FBQUE7QUFBQTs7QUFBQTtBQXNJWSxxQkFBS3JELElBQUwsQ0FBVSxRQUFWO0FBdElaOztBQUFBO0FBeUlZLHFCQUFLQSxJQUFMLENBQVUsYUFBVjtBQXpJWjs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBNklRLHFCQUFLQSxJQUFMLENBQVUsT0FBVjtBQTdJUjs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFrSlU4SCxnQkFBQUEsWUFsSlYsR0FrSnlCLElBQUkzRyxzQkFBSixzQ0FDV3pDLEtBRFgsR0FFbkJBLEtBRm1CLENBbEp6QjtBQXNKSSxxQkFBS3NCLElBQUwsQ0FBVSxPQUFWLEVBQW1COEgsWUFBbkI7QUF0Skosc0JBdUpVQSxZQXZKVjs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQTBKRTtBQUNGO0FBQ0E7O0FBNUpBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkErSjRCLEtBQUtHLG1CQUFMLENBQW9DO0FBQ3hEdEksa0JBQUFBLE1BQU0sRUFBRSxLQURnRDtBQUV4REMsa0JBQUFBLElBQUksYUFBTWdJLGVBQWUsQ0FBQyxLQUFLM0gsT0FBTixDQUFyQixDQUZvRDtBQUd4REgsa0JBQUFBLFlBQVksRUFBRTtBQUgwQyxpQkFBcEMsQ0EvSjVCOztBQUFBO0FBK0pZRyxnQkFBQUEsT0EvSlo7QUFvS00scUJBQUtBLE9BQUwsR0FBZUEsT0FBZjtBQXBLTixtREFxS2FBLE9BcktiOztBQUFBO0FBQUE7QUFBQTtBQXVLTSxxQkFBS0QsSUFBTCxDQUFVLE9BQVY7QUF2S047O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQ0E2S1EsSUE3S1I7QUFBQTtBQUFBO0FBQUE7O0FBQUEseUVBOEthLElBOUtiOztBQUFBO0FBQUE7QUFBQSx1QkFpTDBCLEtBQUtpSSxtQkFBTCxDQUVwQjtBQUNBdEksa0JBQUFBLE1BQU0sRUFBRSxLQURSO0FBRUFDLGtCQUFBQSxJQUFJLGFBQU1nSSxlQUFlLENBQUMsS0FBSzNILE9BQU4sQ0FBckIsdUJBRko7QUFHQUgsa0JBQUFBLFlBQVksRUFBRTtBQUhkLGlCQUZvQixDQWpMMUI7O0FBQUE7QUFpTFVxRSxnQkFBQUEsT0FqTFY7O0FBeUxJLHVFQUFpQ0EsT0FBakMsYUFBaUNBLE9BQWpDLGNBQWlDQSxPQUFqQyxHQUE0QyxFQUE1Qzs7QUF6TEoseUVBMkxXLElBM0xYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkNBK0xRLElBL0xSO0FBQUE7QUFBQTtBQUFBOztBQUFBLHlFQWdNYSxJQWhNYjs7QUFBQTtBQUFBO0FBQUEsdUJBbU0wQixLQUFLOEQsbUJBQUwsQ0FFcEI7QUFDQXRJLGtCQUFBQSxNQUFNLEVBQUUsS0FEUjtBQUVBQyxrQkFBQUEsSUFBSSxhQUFNZ0ksZUFBZSxDQUFDLEtBQUszSCxPQUFOLENBQXJCLG1CQUZKO0FBR0FILGtCQUFBQSxZQUFZLEVBQUU7QUFIZCxpQkFGb0IsQ0FuTTFCOztBQUFBO0FBbU1VcUUsZ0JBQUFBLE9Bbk1WOztBQTJNSSxtRUFBNkJBLE9BQTdCLGFBQTZCQSxPQUE3QixjQUE2QkEsT0FBN0IsR0FBd0MsRUFBeEM7O0FBM01KLHlFQTZNVyxJQTdNWDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJDQWlOUSxJQWpOUjtBQUFBO0FBQUE7QUFBQTs7QUFBQSx5RUFrTmEsSUFsTmI7O0FBQUE7QUFBQTtBQUFBLHVCQXFOMEIsS0FBSzhELG1CQUFMLENBRXBCO0FBQ0F0SSxrQkFBQUEsTUFBTSxFQUFFLEtBRFI7QUFFQUMsa0JBQUFBLElBQUksYUFBTWdJLGVBQWUsQ0FBQyxLQUFLM0gsT0FBTixDQUFyQix3QkFGSjtBQUdBSCxrQkFBQUEsWUFBWSxFQUFFO0FBSGQsaUJBRm9CLENBck4xQjs7QUFBQTtBQXFOVXFFLGdCQUFBQSxPQXJOVjs7QUE2Tkksd0VBQWtDQSxPQUFsQyxhQUFrQ0EsT0FBbEMsY0FBa0NBLE9BQWxDLEdBQTZDLEVBQTdDOztBQTdOSix5RUErTlcsSUEvTlg7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbURBbU9XLEtBQUs4RCxtQkFBTCxDQUErQjtBQUNwQ3RJLGtCQUFBQSxNQUFNLEVBQUUsUUFENEI7QUFFcENDLGtCQUFBQSxJQUFJLGFBQU1nSSxlQUFlLENBQUMsS0FBSzNILE9BQU4sQ0FBckI7QUFGZ0MsaUJBQS9CLENBbk9YOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdDQXlPaUMwRSxPQXpPakMsRUF5T3VEO0FBQUEsVUFDM0MvRSxJQUQyQyxHQUNwQitFLE9BRG9CLENBQzNDL0UsSUFEMkM7QUFBQSxVQUNyQ0UsWUFEcUMsR0FDcEI2RSxPQURvQixDQUNyQzdFLFlBRHFDO0FBRW5ELFVBQU0yRixPQUFPLEdBQUcsQ0FDZCwwQ0FBaUJDLFdBREgsRUFFZCxlQUZjLGFBR1YsMENBQWlCQyxPQUhQLEdBSWQsYUFKYyxFQUtkQyxJQUxjLENBS1QsR0FMUyxDQUFoQjtBQU9BLGFBQU8sSUFBSVIsU0FBSix1QkFBYyxJQUFkLGlCQUFnQztBQUFFdEYsUUFBQUEsWUFBWSxFQUFaQTtBQUFGLE9BQWhDLEVBQWtENkUsT0FBbEQsaUNBQ0ZBLE9BREU7QUFFTGtCLFFBQUFBLEdBQUcsRUFBRUosT0FBTyxHQUFHN0Y7QUFGVixTQUFQO0FBSUQ7QUF0UEg7QUFBQTtBQUFBLHdCQThCVztBQUNQLGFBQU8sS0FBS0ssT0FBTCxDQUFhckIsRUFBcEI7QUFDRDtBQWhDSDs7QUFBQTtBQUFBLEVBR1VqQixZQUhWOzs7Ozs7Ozs7Ozs7SUF5UE1vSyxTOzs7OztBQVVKO0FBQ0Y7QUFDQTtBQUNFLHFCQUFZdEosT0FBWixFQUFxRDtBQUFBOztBQUFBOztBQUNuRCxpQ0FBTTtBQUFFNEMsTUFBQUEsVUFBVSxFQUFFO0FBQWQsS0FBTjs7QUFEbUQ7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBR25ELFFBQU0yRyxhQUFhLEdBQUd2SixPQUFPLENBQUN1SixhQUE5Qjs7QUFFQSxpRUFBWXZKLE9BQU8sQ0FBQzJDLEdBQXBCOztBQUNBLDBFQUFxQixJQUFJdEQsWUFBSixFQUFyQjs7QUFDQSw0RUFBdUIsSUFBSUMsUUFBSixFQUF2Qjs7QUFFQSxRQUFNd0QsZ0JBQWdCLEdBQUc7QUFBRUMsTUFBQUEsU0FBUyxFQUFFO0FBQWIsS0FBekI7O0FBQ0EsUUFBTUcsZ0JBQWdCLEdBQUcsc0VBQW1CQyxNQUFuQixDQUEwQixLQUExQixFQUFpQ0wsZ0JBQWpDLENBQXpCOztBQUNBLFFBQU1RLGtCQUFrQixHQUFHLHdFQUFxQkgsTUFBckIsQ0FDekIsS0FEeUIsRUFFekJMLGdCQUZ5QixDQUEzQjs7QUFLQSx3RUFBbUJyRCxxQkFBcUIsQ0FDdEN5RCxnQkFEc0MsRUFFdENJLGtCQUZzQyxDQUF4Qzs7QUFLQSxZQUFLaEQsRUFBTCxDQUFRLFFBQVIsRUFBa0I7QUFBQSxhQUFNLHNFQUFtQmlELEdBQW5CLEVBQU47QUFBQSxLQUFsQjs7QUFFQUwsSUFBQUEsZ0JBQWdCLENBQUNNLElBQWpCLENBQXNCLFVBQXRCLEVBQWtDLFlBQU07QUFDdEMsVUFBSTtBQUFBOztBQUNGO0FBQ0EsWUFBTUksR0FBRyxHQUFHMkYsYUFBYSxDQUFDO0FBQ3hCckksVUFBQUEsTUFBTSxFQUFFLEtBRGdCO0FBRXhCQyxVQUFBQSxJQUFJLHVDQUFNLDZEQUFVSyxPQUFoQiwyREFBTSx1QkFBbUJyQixFQUF6QixhQUZvQjtBQUd4QmlCLFVBQUFBLE9BQU8sRUFBRTtBQUNQLDRCQUFnQjtBQURULFdBSGU7QUFNeEJDLFVBQUFBLFlBQVksRUFBRTtBQU5VLFNBQUQsQ0FBekI7O0FBU0EsaUVBQUM7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFcUJ1QyxHQUZyQjs7QUFBQTtBQUVTdEMsa0JBQUFBLEtBRlQ7O0FBR0csMEJBQUtDLElBQUwsQ0FBVSxVQUFWLEVBQXNCRCxLQUF0Qjs7QUFISDtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFLRywwQkFBS0MsSUFBTCxDQUFVLE9BQVY7O0FBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBRDs7QUFTQTJCLFFBQUFBLGdCQUFnQixDQUFDTyxJQUFqQixDQUFzQkcsR0FBRyxDQUFDVCxNQUFKLEVBQXRCO0FBQ0QsT0FyQkQsQ0FxQkUsT0FBT2dDLEdBQVAsRUFBWTtBQUNaLGdCQUFLNUQsSUFBTCxDQUFVLE9BQVYsRUFBbUI0RCxHQUFuQjtBQUNEO0FBQ0YsS0F6QkQ7QUF2Qm1EO0FBaURwRDs7OzsyQkFFTXRCLE8sRUFBaUJDLEcsRUFBYUMsRSxFQUFnQjtBQUFBLFVBQzNDQyxFQUQyQyxHQUNUSCxPQURTLENBQzNDRyxFQUQyQztBQUFBLFVBQ3ZDbEUsSUFEdUMsR0FDVCtELE9BRFMsQ0FDdkMvRCxJQUR1QztBQUFBLFVBQ2pDbUUsVUFEaUMsR0FDVEosT0FEUyxDQUNqQ0ksVUFEaUM7QUFBQSxVQUNsQkMsSUFEa0IsNEJBQ1RMLE9BRFM7O0FBRW5ELFVBQUlNLE1BQUo7O0FBQ0EsY0FBUSxrQ0FBVTNDLE9BQVYsQ0FBa0J6QixTQUExQjtBQUNFLGFBQUssUUFBTDtBQUNFb0UsVUFBQUEsTUFBTSxHQUFHRCxJQUFUO0FBQ0E7O0FBQ0YsYUFBSyxRQUFMO0FBQ0EsYUFBSyxZQUFMO0FBQ0VDLFVBQUFBLE1BQU0sR0FBRztBQUFFSCxZQUFBQSxFQUFFLEVBQUZBO0FBQUYsV0FBVDtBQUNBOztBQUNGO0FBQ0VHLFVBQUFBLE1BQU07QUFBS0gsWUFBQUEsRUFBRSxFQUFGQTtBQUFMLGFBQVlFLElBQVosQ0FBTjtBQVRKOztBQVdBLGlEQUFtQkUsS0FBbkIsQ0FBeUJELE1BQXpCLEVBQWlDTCxHQUFqQyxFQUFzQ0MsRUFBdEM7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7Ozs2QkFDVztBQUNQLG1DQUFPLElBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7Ozs0QkFDVU0sSyxFQUFzQztBQUFBOztBQUM1QyxnQ0FBSSxJQUFKLFlBQWtCO0FBQ2hCLGNBQU0sSUFBSTFELEtBQUosQ0FBVSwwQ0FBVixDQUFOO0FBQ0Q7O0FBRUQsMkNBQWUsYUFBa0IsVUFBQ3NCLE9BQUQsRUFBVXNDLE1BQVYsRUFBcUI7QUFDcEQsUUFBQSxPQUFJLENBQUNmLElBQUwsQ0FBVSxVQUFWLEVBQXNCO0FBQUEsaUJBQU12QixPQUFPLEVBQWI7QUFBQSxTQUF0Qjs7QUFDQSxRQUFBLE9BQUksQ0FBQ3VCLElBQUwsQ0FBVSxPQUFWLEVBQW1CZSxNQUFuQjtBQUNELE9BSGMsQ0FBZjs7QUFLQSxVQUFJNUUsUUFBUSxDQUFDMEUsS0FBRCxDQUFSLElBQW1CLFVBQVVBLEtBQTdCLElBQXNDM0UsVUFBVSxDQUFDMkUsS0FBSyxDQUFDWixJQUFQLENBQXBELEVBQWtFO0FBQ2hFO0FBQ0FZLFFBQUFBLEtBQUssQ0FBQ1osSUFBTix1QkFBVyxJQUFYO0FBQ0QsT0FIRCxNQUdPO0FBQ0wsWUFBSSxlQUFjWSxLQUFkLENBQUosRUFBMEI7QUFBQSxzREFDSEEsS0FERztBQUFBOztBQUFBO0FBQ3hCLG1FQUE0QjtBQUFBLGtCQUFqQkYsTUFBaUI7O0FBQzFCLGdEQUFrQixjQUFZQSxNQUFaLENBQWxCLHFDQUF1QztBQUFsQyxvQkFBTUssR0FBRyxxQkFBVDs7QUFDSCxvQkFBSSxPQUFPTCxNQUFNLENBQUNLLEdBQUQsQ0FBYixLQUF1QixTQUEzQixFQUFzQztBQUNwQ0wsa0JBQUFBLE1BQU0sQ0FBQ0ssR0FBRCxDQUFOLEdBQWNDLE1BQU0sQ0FBQ04sTUFBTSxDQUFDSyxHQUFELENBQVAsQ0FBcEI7QUFDRDtBQUNGOztBQUNELG1CQUFLSixLQUFMLENBQVdELE1BQVg7QUFDRDtBQVJ1QjtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQVN4QixlQUFLWixHQUFMO0FBQ0QsU0FWRCxNQVVPLElBQUksT0FBT2MsS0FBUCxLQUFpQixRQUFyQixFQUErQjtBQUNwQyxtREFBaUJELEtBQWpCLENBQXVCQyxLQUF2QixFQUE4QixNQUE5Qjs7QUFDQSxtREFBaUJkLEdBQWpCO0FBQ0Q7QUFDRjs7QUFFRCxhQUFPLElBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBOzs7O3lCQUNPbUIsVSxFQUF3QkMsUSxFQUE4QjtBQUN6RCxVQUFJLHlDQUFpQnNGLFNBQXJCLEVBQWdDO0FBQzlCLGFBQUtwSCxPQUFMO0FBQ0Q7O0FBQ0QsYUFBTyxxQ0FBY1YsSUFBZCxDQUFtQnVDLFVBQW5CLEVBQStCQyxRQUEvQixDQUFQO0FBQ0Q7Ozs7RUFsSU94RixROztBQXFJVixTQUFTZ0ssZUFBVCxDQUF5QjNILE9BQXpCLEVBQTBFO0FBQ3hFLE1BQU12QixLQUFLLEdBQUd1QixPQUFILGFBQUdBLE9BQUgsdUJBQUdBLE9BQU8sQ0FBRXJCLEVBQXZCOztBQUNBLE1BQUlGLEtBQUssS0FBS2dLLFNBQWQsRUFBeUI7QUFDdkIsVUFBTSxJQUFJdEosS0FBSixDQUFVLHVEQUFWLENBQU47QUFDRDs7QUFDRCxTQUFPVixLQUFQO0FBQ0Q7O0FBRUQsU0FBU21KLEtBQVQsQ0FBZWMsRUFBZixFQUEwQztBQUN4QyxTQUFPLGFBQVksVUFBQ2pJLE9BQUQ7QUFBQSxXQUFhLFlBQVdBLE9BQVgsRUFBb0JpSSxFQUFwQixDQUFiO0FBQUEsR0FBWixDQUFQO0FBQ0Q7QUFFRDs7QUFDQTtBQUNBO0FBQ0E7OztBQUNBMUssY0FBYyxDQUFDLE1BQUQsRUFBUyxVQUFDcUgsSUFBRDtBQUFBLFNBQVUsSUFBSUQsSUFBSixDQUFTQyxJQUFULENBQVY7QUFBQSxDQUFULENBQWQ7QUFDQXJILGNBQWMsQ0FBQyxPQUFELEVBQVUsVUFBQ3FILElBQUQ7QUFBQSxTQUFVLElBQUl3QixNQUFKLENBQVd4QixJQUFYLENBQVY7QUFBQSxDQUFWLENBQWQ7QUFFQSxlQUFlRCxJQUFmIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAZmlsZSBNYW5hZ2VzIFNhbGVzZm9yY2UgQnVsayBBUEkgcmVsYXRlZCBvcGVyYXRpb25zXG4gKiBAYXV0aG9yIFNoaW5pY2hpIFRvbWl0YSA8c2hpbmljaGkudG9taXRhQGdtYWlsLmNvbT5cbiAqL1xuaW1wb3J0IHsgRXZlbnRFbWl0dGVyIH0gZnJvbSAnZXZlbnRzJztcbmltcG9ydCB7IER1cGxleCwgUmVhZGFibGUsIFdyaXRhYmxlIH0gZnJvbSAnc3RyZWFtJztcbmltcG9ydCBqb2luU3RyZWFtcyBmcm9tICdtdWx0aXN0cmVhbSc7XG5pbXBvcnQgQ29ubmVjdGlvbiBmcm9tICcuLi9jb25uZWN0aW9uJztcbmltcG9ydCB7IFNlcmlhbGl6YWJsZSwgUGFyc2FibGUgfSBmcm9tICcuLi9yZWNvcmQtc3RyZWFtJztcbmltcG9ydCBIdHRwQXBpIGZyb20gJy4uL2h0dHAtYXBpJztcbmltcG9ydCB7IFN0cmVhbVByb21pc2UgfSBmcm9tICcuLi91dGlsL3Byb21pc2UnO1xuaW1wb3J0IHsgcmVnaXN0ZXJNb2R1bGUgfSBmcm9tICcuLi9qc2ZvcmNlJztcbmltcG9ydCB7IExvZ2dlciB9IGZyb20gJy4uL3V0aWwvbG9nZ2VyJztcbmltcG9ydCB7IGNvbmNhdFN0cmVhbXNBc0R1cGxleCB9IGZyb20gJy4uL3V0aWwvc3RyZWFtJztcbmltcG9ydCB7XG4gIEh0dHBNZXRob2RzLFxuICBIdHRwUmVxdWVzdCxcbiAgSHR0cFJlc3BvbnNlLFxuICBSZWNvcmQsXG4gIFNjaGVtYSxcbn0gZnJvbSAnLi4vdHlwZXMnO1xuaW1wb3J0IHsgaXNGdW5jdGlvbiwgaXNPYmplY3QgfSBmcm9tICcuLi91dGlsL2Z1bmN0aW9uJztcblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbmV4cG9ydCB0eXBlIEJ1bGtPcGVyYXRpb24gPVxuICB8ICdpbnNlcnQnXG4gIHwgJ3VwZGF0ZSdcbiAgfCAndXBzZXJ0J1xuICB8ICdkZWxldGUnXG4gIHwgJ2hhcmREZWxldGUnXG4gIHwgJ3F1ZXJ5J1xuICB8ICdxdWVyeUFsbCc7XG5cbmV4cG9ydCB0eXBlIEluZ2VzdE9wZXJhdGlvbiA9IEV4Y2x1ZGU8QnVsa09wZXJhdGlvbiwgJ3F1ZXJ5JyB8ICdxdWVyeUFsbCc+O1xuXG5leHBvcnQgdHlwZSBRdWVyeU9wZXJhdGlvbiA9IEV4dHJhY3Q8QnVsa09wZXJhdGlvbiwgJ3F1ZXJ5JyB8ICdxdWVyeUFsbCc+O1xuXG5leHBvcnQgdHlwZSBCdWxrT3B0aW9ucyA9IHtcbiAgZXh0SWRGaWVsZD86IHN0cmluZztcbiAgY29uY3VycmVuY3lNb2RlPzogJ1NlcmlhbCcgfCAnUGFyYWxsZWwnO1xuICBhc3NpZ25tZW50UnVsZUlkPzogc3RyaW5nO1xufTtcblxuZXhwb3J0IHR5cGUgSm9iU3RhdGUgPSAnT3BlbicgfCAnQ2xvc2VkJyB8ICdBYm9ydGVkJyB8ICdGYWlsZWQnIHwgJ1Vua25vd24nO1xuXG5leHBvcnQgdHlwZSBKb2JTdGF0ZVYyID1cbiAgfCBFeGNsdWRlPEpvYlN0YXRlLCAnQ2xvc2VkJyB8ICdVbmtub3duJz5cbiAgfCAnVXBsb2FkQ29tcGxldGUnXG4gIHwgJ0luUHJvZ3Jlc3MnXG4gIHwgJ0pvYkNvbXBsZXRlJztcblxuZXhwb3J0IHR5cGUgSm9iSW5mbyA9IHtcbiAgaWQ6IHN0cmluZztcbiAgb2JqZWN0OiBzdHJpbmc7XG4gIG9wZXJhdGlvbjogQnVsa09wZXJhdGlvbjtcbiAgc3RhdGU6IEpvYlN0YXRlO1xufTtcblxuZXhwb3J0IHR5cGUgSm9iSW5mb1YyID0ge1xuICBhcGlWZXJzaW9uOiBzdHJpbmc7XG4gIGFzc2lnbm1lbnRSdWxlSWQ/OiBzdHJpbmc7XG4gIGNvbHVtbkRlbGltaXRlcjpcbiAgICB8ICdCQUNLUVVPVEUnXG4gICAgfCAnQ0FSRVQnXG4gICAgfCAnQ09NTUEnXG4gICAgfCAnUElQRSdcbiAgICB8ICdTRU1JQ09MT04nXG4gICAgfCAnVEFCJztcbiAgY29uY3VycmVuY3lNb2RlOiAnUGFyYWxsZWwnO1xuICBjb250ZW50VHlwZTogJ0NTVic7XG4gIGNvbnRlbnRVcmw6IHN0cmluZztcbiAgY3JlYXRlZEJ5SWQ6IHN0cmluZztcbiAgY3JlYXRlZERhdGU6IHN0cmluZztcbiAgZXh0ZXJuYWxJZEZpZWxkTmFtZT86IHN0cmluZztcbiAgaWQ6IHN0cmluZztcbiAgam9iVHlwZTogJ0JpZ09iamVjdEluZ2VzdCcgfCAnQ2xhc3NpYycgfCAnVjJJbmdlc3QnO1xuICBsaW5lRW5kaW5nOiAnTEYnIHwgJ0NSTEYnO1xuICBvYmplY3Q6IHN0cmluZztcbiAgb3BlcmF0aW9uOiBCdWxrT3BlcmF0aW9uO1xuICBzdGF0ZTogSm9iU3RhdGVWMjtcbiAgc3lzdGVtTW9kc3RhbXA6IHN0cmluZztcbiAgbnVtYmVyUmVjb3Jkc1Byb2Nlc3NlZD86IG51bWJlcjtcbiAgbnVtYmVyUmVjb3Jkc0ZhaWxlZD86IG51bWJlcjtcbn07XG5cbnR5cGUgSm9iSW5mb1Jlc3BvbnNlID0ge1xuICBqb2JJbmZvOiBKb2JJbmZvO1xufTtcblxuZXhwb3J0IHR5cGUgQmF0Y2hTdGF0ZSA9XG4gIHwgJ1F1ZXVlZCdcbiAgfCAnSW5Qcm9ncmVzcydcbiAgfCAnQ29tcGxldGVkJ1xuICB8ICdGYWlsZWQnXG4gIHwgJ05vdFByb2Nlc3NlZCc7XG5cbmV4cG9ydCB0eXBlIEJhdGNoSW5mbyA9IHtcbiAgaWQ6IHN0cmluZztcbiAgam9iSWQ6IHN0cmluZztcbiAgc3RhdGU6IEJhdGNoU3RhdGU7XG4gIHN0YXRlTWVzc2FnZTogc3RyaW5nO1xuICBudW1iZXJSZWNvcmRzUHJvY2Vzc2VkOiBzdHJpbmc7XG4gIG51bWJlclJlY29yZHNGYWlsZWQ6IHN0cmluZztcbiAgdG90YWxQcm9jZXNzaW5nVGltZTogc3RyaW5nO1xufTtcblxudHlwZSBCYXRjaEluZm9SZXNwb25zZSA9IHtcbiAgYmF0Y2hJbmZvOiBCYXRjaEluZm87XG59O1xuXG50eXBlIEJhdGNoSW5mb0xpc3RSZXNwb25zZSA9IHtcbiAgYmF0Y2hJbmZvTGlzdDoge1xuICAgIGJhdGNoSW5mbzogQmF0Y2hJbmZvIHwgQmF0Y2hJbmZvW107XG4gIH07XG59O1xuXG5leHBvcnQgdHlwZSBCdWxrUXVlcnlCYXRjaFJlc3VsdCA9IEFycmF5PHtcbiAgaWQ6IHN0cmluZztcbiAgYmF0Y2hJZDogc3RyaW5nO1xuICBqb2JJZDogc3RyaW5nO1xufT47XG5cbmV4cG9ydCB0eXBlIEJ1bGtJbmdlc3RCYXRjaFJlc3VsdCA9IEFycmF5PHtcbiAgaWQ6IHN0cmluZyB8IG51bGw7XG4gIHN1Y2Nlc3M6IGJvb2xlYW47XG4gIGVycm9yczogc3RyaW5nW107XG59PjtcblxuZXhwb3J0IHR5cGUgQmF0Y2hSZXN1bHQ8T3ByIGV4dGVuZHMgQnVsa09wZXJhdGlvbj4gPSBPcHIgZXh0ZW5kc1xuICB8ICdxdWVyeSdcbiAgfCAncXVlcnlBbGwnXG4gID8gQnVsa1F1ZXJ5QmF0Y2hSZXN1bHRcbiAgOiBCdWxrSW5nZXN0QmF0Y2hSZXN1bHQ7XG5cbnR5cGUgQnVsa0luZ2VzdFJlc3VsdFJlc3BvbnNlID0gQXJyYXk8e1xuICBJZDogc3RyaW5nO1xuICBTdWNjZXNzOiBzdHJpbmc7XG4gIEVycm9yOiBzdHJpbmc7XG59PjtcblxudHlwZSBCdWxrUXVlcnlSZXN1bHRSZXNwb25zZSA9IHtcbiAgJ3Jlc3VsdC1saXN0Jzoge1xuICAgIHJlc3VsdDogc3RyaW5nIHwgc3RyaW5nW107XG4gIH07XG59O1xuXG50eXBlIEJ1bGtSZXF1ZXN0ID0ge1xuICBtZXRob2Q6IEh0dHBNZXRob2RzO1xuICBwYXRoOiBzdHJpbmc7XG4gIGJvZHk/OiBzdHJpbmc7XG4gIGhlYWRlcnM/OiB7IFtuYW1lOiBzdHJpbmddOiBzdHJpbmcgfTtcbiAgcmVzcG9uc2VUeXBlPzogc3RyaW5nO1xufTtcblxuZXhwb3J0IHR5cGUgSW5nZXN0Sm9iVjJTdWNjZXNzZnVsUmVzdWx0czxTIGV4dGVuZHMgU2NoZW1hPiA9IEFycmF5PFxuICB7XG4gICAgc2ZfX0NyZWF0ZWQ6ICd0cnVlJyB8ICdmYWxzZSc7XG4gICAgc2ZfX0lkOiBzdHJpbmc7XG4gIH0gJiBTXG4+O1xuXG5leHBvcnQgdHlwZSBJbmdlc3RKb2JWMkZhaWxlZFJlc3VsdHM8UyBleHRlbmRzIFNjaGVtYT4gPSBBcnJheTxcbiAge1xuICAgIHNmX19FcnJvcjogc3RyaW5nO1xuICAgIHNmX19JZDogc3RyaW5nO1xuICB9ICYgU1xuPjtcblxuZXhwb3J0IHR5cGUgSW5nZXN0Sm9iVjJVbnByb2Nlc3NlZFJlY29yZHM8UyBleHRlbmRzIFNjaGVtYT4gPSBBcnJheTxTPjtcblxuZXhwb3J0IHR5cGUgSW5nZXN0Sm9iVjJSZXN1bHRzPFMgZXh0ZW5kcyBTY2hlbWE+ID0ge1xuICBzdWNjZXNzZnVsUmVzdWx0czogSW5nZXN0Sm9iVjJTdWNjZXNzZnVsUmVzdWx0czxTPjtcbiAgZmFpbGVkUmVzdWx0czogSW5nZXN0Sm9iVjJGYWlsZWRSZXN1bHRzPFM+O1xuICB1bnByb2Nlc3NlZFJlY29yZHM6IEluZ2VzdEpvYlYyVW5wcm9jZXNzZWRSZWNvcmRzPFM+O1xufTtcblxudHlwZSBOZXdJbmdlc3RKb2JPcHRpb25zID0gUmVxdWlyZWQ8UGljazxKb2JJbmZvVjIsICdvYmplY3QnIHwgJ29wZXJhdGlvbic+PiAmXG4gIFBhcnRpYWw8UGljazxKb2JJbmZvVjIsICdhc3NpZ25tZW50UnVsZUlkJyB8ICdleHRlcm5hbElkRmllbGROYW1lJz4+O1xuXG50eXBlIEV4aXN0aW5nSW5nZXN0Sm9iT3B0aW9ucyA9IFBpY2s8Sm9iSW5mb1YyLCAnaWQnPjtcblxudHlwZSBDcmVhdGVJbmdlc3RKb2JWMlJlcXVlc3QgPSA8VD4ocmVxdWVzdDogQnVsa1JlcXVlc3QpID0+IFN0cmVhbVByb21pc2U8VD47XG5cbnR5cGUgQ3JlYXRlSW5nZXN0Sm9iVjJPcHRpb25zPFMgZXh0ZW5kcyBTY2hlbWE+ID0ge1xuICBjb25uZWN0aW9uOiBDb25uZWN0aW9uPFM+O1xuICBqb2JJbmZvOiBOZXdJbmdlc3RKb2JPcHRpb25zIHwgRXhpc3RpbmdJbmdlc3RKb2JPcHRpb25zO1xuICBwb2xsaW5nT3B0aW9uczogQnVsa1YyUG9sbGluZ09wdGlvbnM7XG59O1xuXG50eXBlIENyZWF0ZUpvYkRhdGFWMk9wdGlvbnM8UyBleHRlbmRzIFNjaGVtYSwgT3ByIGV4dGVuZHMgSW5nZXN0T3BlcmF0aW9uPiA9IHtcbiAgam9iOiBJbmdlc3RKb2JWMjxTLCBPcHI+O1xuICBjcmVhdGVSZXF1ZXN0OiBDcmVhdGVJbmdlc3RKb2JWMlJlcXVlc3Q7XG59O1xuXG50eXBlIENyZWF0ZVF1ZXJ5Sm9iVjJPcHRpb25zPFMgZXh0ZW5kcyBTY2hlbWE+ID0ge1xuICBjb25uZWN0aW9uOiBDb25uZWN0aW9uPFM+O1xuICBvcGVyYXRpb246IFF1ZXJ5T3BlcmF0aW9uO1xuICBxdWVyeTogc3RyaW5nO1xuICBwb2xsaW5nT3B0aW9uczogQnVsa1YyUG9sbGluZ09wdGlvbnM7XG59O1xuXG50eXBlIEJ1bGtWMlBvbGxpbmdPcHRpb25zID0ge1xuICBwb2xsSW50ZXJ2YWw6IG51bWJlcjtcbiAgcG9sbFRpbWVvdXQ6IG51bWJlcjtcbn07XG5cbi8qKlxuICogQ2xhc3MgZm9yIEJ1bGsgQVBJIEpvYlxuICovXG5leHBvcnQgY2xhc3MgSm9iPFxuICBTIGV4dGVuZHMgU2NoZW1hLFxuICBPcHIgZXh0ZW5kcyBCdWxrT3BlcmF0aW9uXG4+IGV4dGVuZHMgRXZlbnRFbWl0dGVyIHtcbiAgdHlwZTogc3RyaW5nIHwgbnVsbDtcbiAgb3BlcmF0aW9uOiBPcHIgfCBudWxsO1xuICBvcHRpb25zOiBCdWxrT3B0aW9ucztcbiAgaWQ6IHN0cmluZyB8IG51bGw7XG4gIHN0YXRlOiBKb2JTdGF0ZTtcbiAgX2J1bGs6IEJ1bGs8Uz47XG4gIF9iYXRjaGVzOiB7IFtpZDogc3RyaW5nXTogQmF0Y2g8UywgT3ByPiB9O1xuICBfam9iSW5mbzogUHJvbWlzZTxKb2JJbmZvPiB8IHVuZGVmaW5lZDtcbiAgX2Vycm9yOiBFcnJvciB8IHVuZGVmaW5lZDtcblxuICAvKipcbiAgICpcbiAgICovXG4gIGNvbnN0cnVjdG9yKFxuICAgIGJ1bGs6IEJ1bGs8Uz4sXG4gICAgdHlwZTogc3RyaW5nIHwgbnVsbCxcbiAgICBvcGVyYXRpb246IE9wciB8IG51bGwsXG4gICAgb3B0aW9uczogQnVsa09wdGlvbnMgfCBudWxsLFxuICAgIGpvYklkPzogc3RyaW5nLFxuICApIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuX2J1bGsgPSBidWxrO1xuICAgIHRoaXMudHlwZSA9IHR5cGU7XG4gICAgdGhpcy5vcGVyYXRpb24gPSBvcGVyYXRpb247XG4gICAgdGhpcy5vcHRpb25zID0gb3B0aW9ucyB8fCB7fTtcbiAgICB0aGlzLmlkID0gam9iSWQgPz8gbnVsbDtcbiAgICB0aGlzLnN0YXRlID0gdGhpcy5pZCA/ICdPcGVuJyA6ICdVbmtub3duJztcbiAgICB0aGlzLl9iYXRjaGVzID0ge307XG4gICAgLy8gZGVmYXVsdCBlcnJvciBoYW5kbGVyIHRvIGtlZXAgdGhlIGxhdGVzdCBlcnJvclxuICAgIHRoaXMub24oJ2Vycm9yJywgKGVycm9yKSA9PiAodGhpcy5fZXJyb3IgPSBlcnJvcikpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybiBsYXRlc3Qgam9iSW5mbyBmcm9tIGNhY2hlXG4gICAqL1xuICBpbmZvKCkge1xuICAgIC8vIGlmIGNhY2hlIGlzIG5vdCBhdmFpbGFibGUsIGNoZWNrIHRoZSBsYXRlc3RcbiAgICBpZiAoIXRoaXMuX2pvYkluZm8pIHtcbiAgICAgIHRoaXMuX2pvYkluZm8gPSB0aGlzLmNoZWNrKCk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9qb2JJbmZvO1xuICB9XG5cbiAgLyoqXG4gICAqIE9wZW4gbmV3IGpvYiBhbmQgZ2V0IGpvYmluZm9cbiAgICovXG4gIG9wZW4oKTogUHJvbWlzZTxKb2JJbmZvPiB7XG4gICAgY29uc3QgYnVsayA9IHRoaXMuX2J1bGs7XG4gICAgY29uc3Qgb3B0aW9ucyA9IHRoaXMub3B0aW9ucztcblxuICAgIC8vIGlmIHNvYmplY3QgdHlwZSAvIG9wZXJhdGlvbiBpcyBub3QgcHJvdmlkZWRcbiAgICBpZiAoIXRoaXMudHlwZSB8fCAhdGhpcy5vcGVyYXRpb24pIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcigndHlwZSAvIG9wZXJhdGlvbiBpcyByZXF1aXJlZCB0byBvcGVuIGEgbmV3IGpvYicpO1xuICAgIH1cblxuICAgIC8vIGlmIG5vdCByZXF1ZXN0ZWQgb3BlbmluZyBqb2JcbiAgICBpZiAoIXRoaXMuX2pvYkluZm8pIHtcbiAgICAgIGxldCBvcGVyYXRpb24gPSB0aGlzLm9wZXJhdGlvbi50b0xvd2VyQ2FzZSgpO1xuICAgICAgaWYgKG9wZXJhdGlvbiA9PT0gJ2hhcmRkZWxldGUnKSB7XG4gICAgICAgIG9wZXJhdGlvbiA9ICdoYXJkRGVsZXRlJztcbiAgICAgIH1cbiAgICAgIGlmIChvcGVyYXRpb24gPT09ICdxdWVyeWFsbCcpIHtcbiAgICAgICAgb3BlcmF0aW9uID0gJ3F1ZXJ5QWxsJztcbiAgICAgIH1cbiAgICAgIGNvbnN0IGJvZHkgPSBgXG48P3htbCB2ZXJzaW9uPVwiMS4wXCIgZW5jb2Rpbmc9XCJVVEYtOFwiPz5cbjxqb2JJbmZvICB4bWxucz1cImh0dHA6Ly93d3cuZm9yY2UuY29tLzIwMDkvMDYvYXN5bmNhcGkvZGF0YWxvYWRcIj5cbiAgPG9wZXJhdGlvbj4ke29wZXJhdGlvbn08L29wZXJhdGlvbj5cbiAgPG9iamVjdD4ke3RoaXMudHlwZX08L29iamVjdD5cbiAgJHtcbiAgICBvcHRpb25zLmV4dElkRmllbGRcbiAgICAgID8gYDxleHRlcm5hbElkRmllbGROYW1lPiR7b3B0aW9ucy5leHRJZEZpZWxkfTwvZXh0ZXJuYWxJZEZpZWxkTmFtZT5gXG4gICAgICA6ICcnXG4gIH1cbiAgJHtcbiAgICBvcHRpb25zLmNvbmN1cnJlbmN5TW9kZVxuICAgICAgPyBgPGNvbmN1cnJlbmN5TW9kZT4ke29wdGlvbnMuY29uY3VycmVuY3lNb2RlfTwvY29uY3VycmVuY3lNb2RlPmBcbiAgICAgIDogJydcbiAgfVxuICAke1xuICAgIG9wdGlvbnMuYXNzaWdubWVudFJ1bGVJZFxuICAgICAgPyBgPGFzc2lnbm1lbnRSdWxlSWQ+JHtvcHRpb25zLmFzc2lnbm1lbnRSdWxlSWR9PC9hc3NpZ25tZW50UnVsZUlkPmBcbiAgICAgIDogJydcbiAgfVxuICA8Y29udGVudFR5cGU+Q1NWPC9jb250ZW50VHlwZT5cbjwvam9iSW5mbz5cbiAgICAgIGAudHJpbSgpO1xuXG4gICAgICB0aGlzLl9qb2JJbmZvID0gKGFzeW5jICgpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBidWxrLl9yZXF1ZXN0PEpvYkluZm9SZXNwb25zZT4oe1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICBwYXRoOiAnL2pvYicsXG4gICAgICAgICAgICBib2R5LFxuICAgICAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL3htbDsgY2hhcnNldD11dGYtOCcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmVzcG9uc2VUeXBlOiAnYXBwbGljYXRpb24veG1sJyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgICB0aGlzLmVtaXQoJ29wZW4nLCByZXMuam9iSW5mbyk7XG4gICAgICAgICAgdGhpcy5pZCA9IHJlcy5qb2JJbmZvLmlkO1xuICAgICAgICAgIHRoaXMuc3RhdGUgPSByZXMuam9iSW5mby5zdGF0ZTtcbiAgICAgICAgICByZXR1cm4gcmVzLmpvYkluZm87XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgfVxuICAgICAgfSkoKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX2pvYkluZm87XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlIGEgbmV3IGJhdGNoIGluc3RhbmNlIGluIHRoZSBqb2JcbiAgICovXG4gIGNyZWF0ZUJhdGNoKCk6IEJhdGNoPFMsIE9wcj4ge1xuICAgIGNvbnN0IGJhdGNoID0gbmV3IEJhdGNoKHRoaXMpO1xuICAgIGJhdGNoLm9uKCdxdWV1ZScsICgpID0+IHtcbiAgICAgIHRoaXMuX2JhdGNoZXNbYmF0Y2guaWQhXSA9IGJhdGNoO1xuICAgIH0pO1xuICAgIHJldHVybiBiYXRjaDtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgYSBiYXRjaCBpbnN0YW5jZSBzcGVjaWZpZWQgYnkgZ2l2ZW4gYmF0Y2ggSURcbiAgICovXG4gIGJhdGNoKGJhdGNoSWQ6IHN0cmluZyk6IEJhdGNoPFMsIE9wcj4ge1xuICAgIGxldCBiYXRjaCA9IHRoaXMuX2JhdGNoZXNbYmF0Y2hJZF07XG4gICAgaWYgKCFiYXRjaCkge1xuICAgICAgYmF0Y2ggPSBuZXcgQmF0Y2godGhpcywgYmF0Y2hJZCk7XG4gICAgICB0aGlzLl9iYXRjaGVzW2JhdGNoSWRdID0gYmF0Y2g7XG4gICAgfVxuICAgIHJldHVybiBiYXRjaDtcbiAgfVxuXG4gIC8qKlxuICAgKiBDaGVjayB0aGUgbGF0ZXN0IGpvYiBzdGF0dXMgZnJvbSBzZXJ2ZXJcbiAgICovXG4gIGNoZWNrKCkge1xuICAgIGNvbnN0IGJ1bGsgPSB0aGlzLl9idWxrO1xuICAgIGNvbnN0IGxvZ2dlciA9IGJ1bGsuX2xvZ2dlcjtcblxuICAgIHRoaXMuX2pvYkluZm8gPSAoYXN5bmMgKCkgPT4ge1xuICAgICAgY29uc3Qgam9iSWQgPSBhd2FpdCB0aGlzLnJlYWR5KCk7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBidWxrLl9yZXF1ZXN0PEpvYkluZm9SZXNwb25zZT4oe1xuICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICBwYXRoOiAnL2pvYi8nICsgam9iSWQsXG4gICAgICAgIHJlc3BvbnNlVHlwZTogJ2FwcGxpY2F0aW9uL3htbCcsXG4gICAgICB9KTtcbiAgICAgIGxvZ2dlci5kZWJ1ZyhyZXMuam9iSW5mbyk7XG4gICAgICB0aGlzLmlkID0gcmVzLmpvYkluZm8uaWQ7XG4gICAgICB0aGlzLnR5cGUgPSByZXMuam9iSW5mby5vYmplY3Q7XG4gICAgICB0aGlzLm9wZXJhdGlvbiA9IHJlcy5qb2JJbmZvLm9wZXJhdGlvbiBhcyBPcHI7XG4gICAgICB0aGlzLnN0YXRlID0gcmVzLmpvYkluZm8uc3RhdGU7XG4gICAgICByZXR1cm4gcmVzLmpvYkluZm87XG4gICAgfSkoKTtcblxuICAgIHJldHVybiB0aGlzLl9qb2JJbmZvO1xuICB9XG5cbiAgLyoqXG4gICAqIFdhaXQgdGlsbCB0aGUgam9iIGlzIGFzc2lnbmVkIHRvIHNlcnZlclxuICAgKi9cbiAgcmVhZHkoKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICByZXR1cm4gdGhpcy5pZFxuICAgICAgPyBQcm9taXNlLnJlc29sdmUodGhpcy5pZClcbiAgICAgIDogdGhpcy5vcGVuKCkudGhlbigoeyBpZCB9KSA9PiBpZCk7XG4gIH1cblxuICAvKipcbiAgICogTGlzdCBhbGwgcmVnaXN0ZXJlZCBiYXRjaCBpbmZvIGluIGpvYlxuICAgKi9cbiAgYXN5bmMgbGlzdCgpIHtcbiAgICBjb25zdCBidWxrID0gdGhpcy5fYnVsaztcbiAgICBjb25zdCBsb2dnZXIgPSBidWxrLl9sb2dnZXI7XG4gICAgY29uc3Qgam9iSWQgPSBhd2FpdCB0aGlzLnJlYWR5KCk7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgYnVsay5fcmVxdWVzdDxCYXRjaEluZm9MaXN0UmVzcG9uc2U+KHtcbiAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICBwYXRoOiAnL2pvYi8nICsgam9iSWQgKyAnL2JhdGNoJyxcbiAgICAgIHJlc3BvbnNlVHlwZTogJ2FwcGxpY2F0aW9uL3htbCcsXG4gICAgfSk7XG4gICAgbG9nZ2VyLmRlYnVnKHJlcy5iYXRjaEluZm9MaXN0LmJhdGNoSW5mbyk7XG4gICAgY29uc3QgYmF0Y2hJbmZvTGlzdCA9IEFycmF5LmlzQXJyYXkocmVzLmJhdGNoSW5mb0xpc3QuYmF0Y2hJbmZvKVxuICAgICAgPyByZXMuYmF0Y2hJbmZvTGlzdC5iYXRjaEluZm9cbiAgICAgIDogW3Jlcy5iYXRjaEluZm9MaXN0LmJhdGNoSW5mb107XG4gICAgcmV0dXJuIGJhdGNoSW5mb0xpc3Q7XG4gIH1cblxuICAvKipcbiAgICogQ2xvc2Ugb3BlbmVkIGpvYlxuICAgKi9cbiAgYXN5bmMgY2xvc2UoKSB7XG4gICAgaWYgKCF0aGlzLmlkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICBjb25zdCBqb2JJbmZvID0gYXdhaXQgdGhpcy5fY2hhbmdlU3RhdGUoJ0Nsb3NlZCcpO1xuICAgICAgdGhpcy5pZCA9IG51bGw7XG4gICAgICB0aGlzLmVtaXQoJ2Nsb3NlJywgam9iSW5mbyk7XG4gICAgICByZXR1cm4gam9iSW5mbztcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBTZXQgdGhlIHN0YXR1cyB0byBhYm9ydFxuICAgKi9cbiAgYXN5bmMgYWJvcnQoKSB7XG4gICAgaWYgKCF0aGlzLmlkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICBjb25zdCBqb2JJbmZvID0gYXdhaXQgdGhpcy5fY2hhbmdlU3RhdGUoJ0Fib3J0ZWQnKTtcbiAgICAgIHRoaXMuaWQgPSBudWxsO1xuICAgICAgdGhpcy5lbWl0KCdhYm9ydCcsIGpvYkluZm8pO1xuICAgICAgcmV0dXJuIGpvYkluZm87XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogQHByaXZhdGVcbiAgICovXG4gIGFzeW5jIF9jaGFuZ2VTdGF0ZShzdGF0ZTogSm9iU3RhdGUpIHtcbiAgICBjb25zdCBidWxrID0gdGhpcy5fYnVsaztcbiAgICBjb25zdCBsb2dnZXIgPSBidWxrLl9sb2dnZXI7XG5cbiAgICB0aGlzLl9qb2JJbmZvID0gKGFzeW5jICgpID0+IHtcbiAgICAgIGNvbnN0IGpvYklkID0gYXdhaXQgdGhpcy5yZWFkeSgpO1xuICAgICAgY29uc3QgYm9keSA9IGAgXG48P3htbCB2ZXJzaW9uPVwiMS4wXCIgZW5jb2Rpbmc9XCJVVEYtOFwiPz5cbiAgPGpvYkluZm8geG1sbnM9XCJodHRwOi8vd3d3LmZvcmNlLmNvbS8yMDA5LzA2L2FzeW5jYXBpL2RhdGFsb2FkXCI+XG4gIDxzdGF0ZT4ke3N0YXRlfTwvc3RhdGU+XG48L2pvYkluZm8+XG4gICAgICBgLnRyaW0oKTtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGJ1bGsuX3JlcXVlc3Q8Sm9iSW5mb1Jlc3BvbnNlPih7XG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICBwYXRoOiAnL2pvYi8nICsgam9iSWQsXG4gICAgICAgIGJvZHk6IGJvZHksXG4gICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL3htbDsgY2hhcnNldD11dGYtOCcsXG4gICAgICAgIH0sXG4gICAgICAgIHJlc3BvbnNlVHlwZTogJ2FwcGxpY2F0aW9uL3htbCcsXG4gICAgICB9KTtcbiAgICAgIGxvZ2dlci5kZWJ1ZyhyZXMuam9iSW5mbyk7XG4gICAgICB0aGlzLnN0YXRlID0gcmVzLmpvYkluZm8uc3RhdGU7XG4gICAgICByZXR1cm4gcmVzLmpvYkluZm87XG4gICAgfSkoKTtcbiAgICByZXR1cm4gdGhpcy5fam9iSW5mbztcbiAgfVxufVxuXG4vKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cbmNsYXNzIFBvbGxpbmdUaW1lb3V0RXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gIGpvYklkOiBzdHJpbmc7XG4gIGJhdGNoSWQ6IHN0cmluZztcblxuICAvKipcbiAgICpcbiAgICovXG4gIGNvbnN0cnVjdG9yKG1lc3NhZ2U6IHN0cmluZywgam9iSWQ6IHN0cmluZywgYmF0Y2hJZDogc3RyaW5nKSB7XG4gICAgc3VwZXIobWVzc2FnZSk7XG4gICAgdGhpcy5uYW1lID0gJ1BvbGxpbmdUaW1lb3V0JztcbiAgICB0aGlzLmpvYklkID0gam9iSWQ7XG4gICAgdGhpcy5iYXRjaElkID0gYmF0Y2hJZDtcbiAgfVxufVxuXG5jbGFzcyBKb2JQb2xsaW5nVGltZW91dEVycm9yIGV4dGVuZHMgRXJyb3Ige1xuICBqb2JJZDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgY29uc3RydWN0b3IobWVzc2FnZTogc3RyaW5nLCBqb2JJZDogc3RyaW5nKSB7XG4gICAgc3VwZXIobWVzc2FnZSk7XG4gICAgdGhpcy5uYW1lID0gJ0pvYlBvbGxpbmdUaW1lb3V0JztcbiAgICB0aGlzLmpvYklkID0gam9iSWQ7XG4gIH1cbn1cblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG4vKipcbiAqIEJhdGNoIChleHRlbmRzIFdyaXRhYmxlKVxuICovXG5leHBvcnQgY2xhc3MgQmF0Y2g8XG4gIFMgZXh0ZW5kcyBTY2hlbWEsXG4gIE9wciBleHRlbmRzIEJ1bGtPcGVyYXRpb25cbj4gZXh0ZW5kcyBXcml0YWJsZSB7XG4gIGpvYjogSm9iPFMsIE9wcj47XG4gIGlkOiBzdHJpbmcgfCB1bmRlZmluZWQ7XG4gIF9idWxrOiBCdWxrPFM+O1xuICBfdXBsb2FkU3RyZWFtOiBTZXJpYWxpemFibGU7XG4gIF9kb3dubG9hZFN0cmVhbTogUGFyc2FibGU7XG4gIF9kYXRhU3RyZWFtOiBEdXBsZXg7XG4gIF9yZXN1bHQ6IFByb21pc2U8QmF0Y2hSZXN1bHQ8T3ByPj4gfCB1bmRlZmluZWQ7XG4gIF9lcnJvcjogRXJyb3IgfCB1bmRlZmluZWQ7XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBjb25zdHJ1Y3Rvcihqb2I6IEpvYjxTLCBPcHI+LCBpZD86IHN0cmluZykge1xuICAgIHN1cGVyKHsgb2JqZWN0TW9kZTogdHJ1ZSB9KTtcbiAgICB0aGlzLmpvYiA9IGpvYjtcbiAgICB0aGlzLmlkID0gaWQ7XG4gICAgdGhpcy5fYnVsayA9IGpvYi5fYnVsaztcblxuICAgIC8vIGRlZmF1bHQgZXJyb3IgaGFuZGxlciB0byBrZWVwIHRoZSBsYXRlc3QgZXJyb3JcbiAgICB0aGlzLm9uKCdlcnJvcicsIChlcnJvcikgPT4gKHRoaXMuX2Vycm9yID0gZXJyb3IpKTtcblxuICAgIC8vXG4gICAgLy8gc2V0dXAgZGF0YSBzdHJlYW1zXG4gICAgLy9cbiAgICBjb25zdCBjb252ZXJ0ZXJPcHRpb25zID0geyBudWxsVmFsdWU6ICcjTi9BJyB9O1xuICAgIGNvbnN0IHVwbG9hZFN0cmVhbSA9ICh0aGlzLl91cGxvYWRTdHJlYW0gPSBuZXcgU2VyaWFsaXphYmxlKCkpO1xuICAgIGNvbnN0IHVwbG9hZERhdGFTdHJlYW0gPSB1cGxvYWRTdHJlYW0uc3RyZWFtKCdjc3YnLCBjb252ZXJ0ZXJPcHRpb25zKTtcbiAgICBjb25zdCBkb3dubG9hZFN0cmVhbSA9ICh0aGlzLl9kb3dubG9hZFN0cmVhbSA9IG5ldyBQYXJzYWJsZSgpKTtcbiAgICBjb25zdCBkb3dubG9hZERhdGFTdHJlYW0gPSBkb3dubG9hZFN0cmVhbS5zdHJlYW0oJ2NzdicsIGNvbnZlcnRlck9wdGlvbnMpO1xuXG4gICAgdGhpcy5vbignZmluaXNoJywgKCkgPT4gdXBsb2FkU3RyZWFtLmVuZCgpKTtcbiAgICB1cGxvYWREYXRhU3RyZWFtLm9uY2UoJ3JlYWRhYmxlJywgYXN5bmMgKCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgLy8gZW5zdXJlIHRoZSBqb2IgaXMgb3BlbmVkIGluIHNlcnZlciBvciBqb2IgaWQgaXMgYWxyZWFkeSBhc3NpZ25lZFxuICAgICAgICBhd2FpdCB0aGlzLmpvYi5yZWFkeSgpO1xuICAgICAgICAvLyBwaXBlIHVwbG9hZCBkYXRhIHRvIGJhdGNoIEFQSSByZXF1ZXN0IHN0cmVhbVxuICAgICAgICB1cGxvYWREYXRhU3RyZWFtLnBpcGUodGhpcy5fY3JlYXRlUmVxdWVzdFN0cmVhbSgpKTtcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIC8vIGR1cGxleCBkYXRhIHN0cmVhbSwgb3BlbmVkIGFjY2VzcyB0byBBUEkgcHJvZ3JhbW1lcnMgYnkgQmF0Y2gjc3RyZWFtKClcbiAgICB0aGlzLl9kYXRhU3RyZWFtID0gY29uY2F0U3RyZWFtc0FzRHVwbGV4KFxuICAgICAgdXBsb2FkRGF0YVN0cmVhbSxcbiAgICAgIGRvd25sb2FkRGF0YVN0cmVhbSxcbiAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIENvbm5lY3QgYmF0Y2ggQVBJIGFuZCBjcmVhdGUgc3RyZWFtIGluc3RhbmNlIG9mIHJlcXVlc3QvcmVzcG9uc2VcbiAgICpcbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9jcmVhdGVSZXF1ZXN0U3RyZWFtKCkge1xuICAgIGNvbnN0IGJ1bGsgPSB0aGlzLl9idWxrO1xuICAgIGNvbnN0IGxvZ2dlciA9IGJ1bGsuX2xvZ2dlcjtcbiAgICBjb25zdCByZXEgPSBidWxrLl9yZXF1ZXN0PEJhdGNoSW5mb1Jlc3BvbnNlPih7XG4gICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgIHBhdGg6ICcvam9iLycgKyB0aGlzLmpvYi5pZCArICcvYmF0Y2gnLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICAnQ29udGVudC1UeXBlJzogJ3RleHQvY3N2JyxcbiAgICAgIH0sXG4gICAgICByZXNwb25zZVR5cGU6ICdhcHBsaWNhdGlvbi94bWwnLFxuICAgIH0pO1xuICAgIChhc3luYyAoKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCByZXE7XG4gICAgICAgIGxvZ2dlci5kZWJ1ZyhyZXMuYmF0Y2hJbmZvKTtcbiAgICAgICAgdGhpcy5pZCA9IHJlcy5iYXRjaEluZm8uaWQ7XG4gICAgICAgIHRoaXMuZW1pdCgncXVldWUnLCByZXMuYmF0Y2hJbmZvKTtcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgIH1cbiAgICB9KSgpO1xuICAgIHJldHVybiByZXEuc3RyZWFtKCk7XG4gIH1cblxuICAvKipcbiAgICogSW1wbGVtZW50YXRpb24gb2YgV3JpdGFibGVcbiAgICovXG4gIF93cml0ZShyZWNvcmRfOiBSZWNvcmQsIGVuYzogc3RyaW5nLCBjYjogKCkgPT4gdm9pZCkge1xuICAgIGNvbnN0IHsgSWQsIHR5cGUsIGF0dHJpYnV0ZXMsIC4uLnJyZWMgfSA9IHJlY29yZF87XG4gICAgbGV0IHJlY29yZDtcbiAgICBzd2l0Y2ggKHRoaXMuam9iLm9wZXJhdGlvbikge1xuICAgICAgY2FzZSAnaW5zZXJ0JzpcbiAgICAgICAgcmVjb3JkID0gcnJlYztcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICdkZWxldGUnOlxuICAgICAgY2FzZSAnaGFyZERlbGV0ZSc6XG4gICAgICAgIHJlY29yZCA9IHsgSWQgfTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICByZWNvcmQgPSB7IElkLCAuLi5ycmVjIH07XG4gICAgfVxuICAgIHRoaXMuX3VwbG9hZFN0cmVhbS53cml0ZShyZWNvcmQsIGVuYywgY2IpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgZHVwbGV4IHN0cmVhbSB3aGljaCBhY2NlcHRzIENTViBkYXRhIGlucHV0IGFuZCBiYXRjaCByZXN1bHQgb3V0cHV0XG4gICAqL1xuICBzdHJlYW0oKSB7XG4gICAgcmV0dXJuIHRoaXMuX2RhdGFTdHJlYW07XG4gIH1cblxuICAvKipcbiAgICogRXhlY3V0ZSBiYXRjaCBvcGVyYXRpb25cbiAgICovXG4gIGV4ZWN1dGUoaW5wdXQ/OiBzdHJpbmcgfCBSZWNvcmRbXSB8IFJlYWRhYmxlKSB7XG4gICAgLy8gaWYgYmF0Y2ggaXMgYWxyZWFkeSBleGVjdXRlZFxuICAgIGlmICh0aGlzLl9yZXN1bHQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignQmF0Y2ggYWxyZWFkeSBleGVjdXRlZC4nKTtcbiAgICB9XG5cbiAgICB0aGlzLl9yZXN1bHQgPSBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICB0aGlzLm9uY2UoJ3Jlc3BvbnNlJywgcmVzb2x2ZSk7XG4gICAgICB0aGlzLm9uY2UoJ2Vycm9yJywgcmVqZWN0KTtcbiAgICB9KTtcblxuICAgIGlmIChpc09iamVjdChpbnB1dCkgJiYgJ3BpcGUnIGluIGlucHV0ICYmIGlzRnVuY3Rpb24oaW5wdXQucGlwZSkpIHtcbiAgICAgIC8vIGlmIGlucHV0IGhhcyBzdHJlYW0uUmVhZGFibGUgaW50ZXJmYWNlXG4gICAgICBpbnB1dC5waXBlKHRoaXMuX2RhdGFTdHJlYW0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBpZiAoQXJyYXkuaXNBcnJheShpbnB1dCkpIHtcbiAgICAgICAgZm9yIChjb25zdCByZWNvcmQgb2YgaW5wdXQpIHtcbiAgICAgICAgICBmb3IgKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyhyZWNvcmQpKSB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIHJlY29yZFtrZXldID09PSAnYm9vbGVhbicpIHtcbiAgICAgICAgICAgICAgcmVjb3JkW2tleV0gPSBTdHJpbmcocmVjb3JkW2tleV0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICB0aGlzLndyaXRlKHJlY29yZCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5lbmQoKTtcbiAgICAgIH0gZWxzZSBpZiAodHlwZW9mIGlucHV0ID09PSAnc3RyaW5nJykge1xuICAgICAgICB0aGlzLl9kYXRhU3RyZWFtLndyaXRlKGlucHV0LCAndXRmOCcpO1xuICAgICAgICB0aGlzLl9kYXRhU3RyZWFtLmVuZCgpO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIHJldHVybiBCYXRjaCBpbnN0YW5jZSBmb3IgY2hhaW5pbmdcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuXG4gIHJ1biA9IHRoaXMuZXhlY3V0ZTtcblxuICBleGVjID0gdGhpcy5leGVjdXRlO1xuXG4gIC8qKlxuICAgKiBQcm9taXNlL0ErIGludGVyZmFjZVxuICAgKiBEZWxlZ2F0ZSB0byBwcm9taXNlLCByZXR1cm4gcHJvbWlzZSBpbnN0YW5jZSBmb3IgYmF0Y2ggcmVzdWx0XG4gICAqL1xuICB0aGVuKFxuICAgIG9uUmVzb2x2ZWQ6IChyZXM6IEJhdGNoUmVzdWx0PE9wcj4pID0+IHZvaWQsXG4gICAgb25SZWplY3Q6IChlcnI6IGFueSkgPT4gdm9pZCxcbiAgKSB7XG4gICAgaWYgKCF0aGlzLl9yZXN1bHQpIHtcbiAgICAgIHRoaXMuZXhlY3V0ZSgpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5fcmVzdWx0IS50aGVuKG9uUmVzb2x2ZWQsIG9uUmVqZWN0KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDaGVjayB0aGUgbGF0ZXN0IGJhdGNoIHN0YXR1cyBpbiBzZXJ2ZXJcbiAgICovXG4gIGFzeW5jIGNoZWNrKCkge1xuICAgIGNvbnN0IGJ1bGsgPSB0aGlzLl9idWxrO1xuICAgIGNvbnN0IGxvZ2dlciA9IGJ1bGsuX2xvZ2dlcjtcbiAgICBjb25zdCBqb2JJZCA9IHRoaXMuam9iLmlkO1xuICAgIGNvbnN0IGJhdGNoSWQgPSB0aGlzLmlkO1xuXG4gICAgaWYgKCFqb2JJZCB8fCAhYmF0Y2hJZCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdCYXRjaCBub3Qgc3RhcnRlZC4nKTtcbiAgICB9XG4gICAgY29uc3QgcmVzID0gYXdhaXQgYnVsay5fcmVxdWVzdDxCYXRjaEluZm9SZXNwb25zZT4oe1xuICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgIHBhdGg6ICcvam9iLycgKyBqb2JJZCArICcvYmF0Y2gvJyArIGJhdGNoSWQsXG4gICAgICByZXNwb25zZVR5cGU6ICdhcHBsaWNhdGlvbi94bWwnLFxuICAgIH0pO1xuICAgIGxvZ2dlci5kZWJ1ZyhyZXMuYmF0Y2hJbmZvKTtcbiAgICByZXR1cm4gcmVzLmJhdGNoSW5mbztcbiAgfVxuXG4gIC8qKlxuICAgKiBQb2xsaW5nIHRoZSBiYXRjaCByZXN1bHQgYW5kIHJldHJpZXZlXG4gICAqL1xuICBwb2xsKGludGVydmFsOiBudW1iZXIsIHRpbWVvdXQ6IG51bWJlcikge1xuICAgIGNvbnN0IGpvYklkID0gdGhpcy5qb2IuaWQ7XG4gICAgY29uc3QgYmF0Y2hJZCA9IHRoaXMuaWQ7XG5cbiAgICBpZiAoIWpvYklkIHx8ICFiYXRjaElkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0JhdGNoIG5vdCBzdGFydGVkLicpO1xuICAgIH1cbiAgICBjb25zdCBzdGFydFRpbWUgPSBuZXcgRGF0ZSgpLmdldFRpbWUoKTtcbiAgICBjb25zdCBwb2xsID0gYXN5bmMgKCkgPT4ge1xuICAgICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XG4gICAgICBpZiAoc3RhcnRUaW1lICsgdGltZW91dCA8IG5vdykge1xuICAgICAgICBjb25zdCBlcnIgPSBuZXcgUG9sbGluZ1RpbWVvdXRFcnJvcihcbiAgICAgICAgICAnUG9sbGluZyB0aW1lIG91dC4gSm9iIElkID0gJyArIGpvYklkICsgJyAsIGJhdGNoIElkID0gJyArIGJhdGNoSWQsXG4gICAgICAgICAgam9iSWQsXG4gICAgICAgICAgYmF0Y2hJZCxcbiAgICAgICAgKTtcbiAgICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycik7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGxldCByZXM7XG4gICAgICB0cnkge1xuICAgICAgICByZXMgPSBhd2FpdCB0aGlzLmNoZWNrKCk7XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycik7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChyZXMuc3RhdGUgPT09ICdGYWlsZWQnKSB7XG4gICAgICAgIGlmIChwYXJzZUludChyZXMubnVtYmVyUmVjb3Jkc1Byb2Nlc3NlZCwgMTApID4gMCkge1xuICAgICAgICAgIHRoaXMucmV0cmlldmUoKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgbmV3IEVycm9yKHJlcy5zdGF0ZU1lc3NhZ2UpKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChyZXMuc3RhdGUgPT09ICdDb21wbGV0ZWQnKSB7XG4gICAgICAgIHRoaXMucmV0cmlldmUoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuZW1pdCgncHJvZ3Jlc3MnLCByZXMpO1xuICAgICAgICBzZXRUaW1lb3V0KHBvbGwsIGludGVydmFsKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIHNldFRpbWVvdXQocG9sbCwgaW50ZXJ2YWwpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHJpZXZlIGJhdGNoIHJlc3VsdFxuICAgKi9cbiAgYXN5bmMgcmV0cmlldmUoKSB7XG4gICAgY29uc3QgYnVsayA9IHRoaXMuX2J1bGs7XG4gICAgY29uc3Qgam9iSWQgPSB0aGlzLmpvYi5pZDtcbiAgICBjb25zdCBqb2IgPSB0aGlzLmpvYjtcbiAgICBjb25zdCBiYXRjaElkID0gdGhpcy5pZDtcblxuICAgIGlmICgham9iSWQgfHwgIWJhdGNoSWQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignQmF0Y2ggbm90IHN0YXJ0ZWQuJyk7XG4gICAgfVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3AgPSBhd2FpdCBidWxrLl9yZXF1ZXN0PFxuICAgICAgICBCdWxrSW5nZXN0UmVzdWx0UmVzcG9uc2UgfCBCdWxrUXVlcnlSZXN1bHRSZXNwb25zZVxuICAgICAgPih7XG4gICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgIHBhdGg6ICcvam9iLycgKyBqb2JJZCArICcvYmF0Y2gvJyArIGJhdGNoSWQgKyAnL3Jlc3VsdCcsXG4gICAgICB9KTtcbiAgICAgIGxldCByZXN1bHRzOiBCdWxrSW5nZXN0QmF0Y2hSZXN1bHQgfCBCdWxrUXVlcnlCYXRjaFJlc3VsdDtcbiAgICAgIGlmIChqb2Iub3BlcmF0aW9uID09PSAncXVlcnknIHx8IGpvYi5vcGVyYXRpb24gPT09ICdxdWVyeUFsbCcpIHtcbiAgICAgICAgY29uc3QgcmVzID0gcmVzcCBhcyBCdWxrUXVlcnlSZXN1bHRSZXNwb25zZTtcbiAgICAgICAgbGV0IHJlc3VsdElkID0gcmVzWydyZXN1bHQtbGlzdCddLnJlc3VsdDtcbiAgICAgICAgcmVzdWx0cyA9IChBcnJheS5pc0FycmF5KHJlc3VsdElkKVxuICAgICAgICAgID8gcmVzdWx0SWRcbiAgICAgICAgICA6IFtyZXN1bHRJZF1cbiAgICAgICAgKS5tYXAoKGlkKSA9PiAoeyBpZCwgYmF0Y2hJZCwgam9iSWQgfSkpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3QgcmVzID0gcmVzcCBhcyBCdWxrSW5nZXN0UmVzdWx0UmVzcG9uc2U7XG4gICAgICAgIHJlc3VsdHMgPSByZXMubWFwKChyZXQpID0+ICh7XG4gICAgICAgICAgaWQ6IHJldC5JZCB8fCBudWxsLFxuICAgICAgICAgIHN1Y2Nlc3M6IHJldC5TdWNjZXNzID09PSAndHJ1ZScsXG4gICAgICAgICAgZXJyb3JzOiByZXQuRXJyb3IgPyBbcmV0LkVycm9yXSA6IFtdLFxuICAgICAgICB9KSk7XG4gICAgICB9XG4gICAgICB0aGlzLmVtaXQoJ3Jlc3BvbnNlJywgcmVzdWx0cyk7XG4gICAgICByZXR1cm4gcmVzdWx0cztcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBGZXRjaCBxdWVyeSByZXN1bHQgYXMgYSByZWNvcmQgc3RyZWFtXG4gICAqIEBwYXJhbSB7U3RyaW5nfSByZXN1bHRJZCAtIFJlc3VsdCBpZFxuICAgKiBAcmV0dXJucyB7UmVjb3JkU3RyZWFtfSAtIFJlY29yZCBzdHJlYW0sIGNvbnZlcnRpYmxlIHRvIENTViBkYXRhIHN0cmVhbVxuICAgKi9cbiAgcmVzdWx0KHJlc3VsdElkOiBzdHJpbmcpIHtcbiAgICBjb25zdCBqb2JJZCA9IHRoaXMuam9iLmlkO1xuICAgIGNvbnN0IGJhdGNoSWQgPSB0aGlzLmlkO1xuICAgIGlmICgham9iSWQgfHwgIWJhdGNoSWQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignQmF0Y2ggbm90IHN0YXJ0ZWQuJyk7XG4gICAgfVxuICAgIGNvbnN0IHJlc3VsdFN0cmVhbSA9IG5ldyBQYXJzYWJsZSgpO1xuICAgIGNvbnN0IHJlc3VsdERhdGFTdHJlYW0gPSByZXN1bHRTdHJlYW0uc3RyZWFtKCdjc3YnKTtcbiAgICB0aGlzLl9idWxrXG4gICAgICAuX3JlcXVlc3Qoe1xuICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICBwYXRoOiAnL2pvYi8nICsgam9iSWQgKyAnL2JhdGNoLycgKyBiYXRjaElkICsgJy9yZXN1bHQvJyArIHJlc3VsdElkLFxuICAgICAgICByZXNwb25zZVR5cGU6ICdhcHBsaWNhdGlvbi9vY3RldC1zdHJlYW0nLFxuICAgICAgfSlcbiAgICAgIC5zdHJlYW0oKVxuICAgICAgLnBpcGUocmVzdWx0RGF0YVN0cmVhbSk7XG4gICAgcmV0dXJuIHJlc3VsdFN0cmVhbTtcbiAgfVxufVxuXG4vKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cbi8qKlxuICpcbiAqL1xuY2xhc3MgQnVsa0FwaTxTIGV4dGVuZHMgU2NoZW1hPiBleHRlbmRzIEh0dHBBcGk8Uz4ge1xuICBiZWZvcmVTZW5kKHJlcXVlc3Q6IEh0dHBSZXF1ZXN0KSB7XG4gICAgcmVxdWVzdC5oZWFkZXJzID0ge1xuICAgICAgLi4ucmVxdWVzdC5oZWFkZXJzLFxuICAgICAgJ1gtU0ZEQy1TRVNTSU9OJzogdGhpcy5fY29ubi5hY2Nlc3NUb2tlbiA/PyAnJyxcbiAgICB9O1xuICB9XG5cbiAgaXNTZXNzaW9uRXhwaXJlZChyZXNwb25zZTogSHR0cFJlc3BvbnNlKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIHJlc3BvbnNlLnN0YXR1c0NvZGUgPT09IDQwMCAmJlxuICAgICAgLzxleGNlcHRpb25Db2RlPkludmFsaWRTZXNzaW9uSWQ8XFwvZXhjZXB0aW9uQ29kZT4vLnRlc3QocmVzcG9uc2UuYm9keSlcbiAgICApO1xuICB9XG5cbiAgaGFzRXJyb3JJblJlc3BvbnNlQm9keShib2R5OiBhbnkpIHtcbiAgICByZXR1cm4gISFib2R5LmVycm9yO1xuICB9XG5cbiAgcGFyc2VFcnJvcihib2R5OiBhbnkpIHtcbiAgICByZXR1cm4ge1xuICAgICAgZXJyb3JDb2RlOiBib2R5LmVycm9yLmV4Y2VwdGlvbkNvZGUsXG4gICAgICBtZXNzYWdlOiBib2R5LmVycm9yLmV4Y2VwdGlvbk1lc3NhZ2UsXG4gICAgfTtcbiAgfVxufVxuXG5jbGFzcyBCdWxrQXBpVjI8UyBleHRlbmRzIFNjaGVtYT4gZXh0ZW5kcyBIdHRwQXBpPFM+IHtcbiAgaGFzRXJyb3JJblJlc3BvbnNlQm9keShib2R5OiBhbnkpIHtcbiAgICByZXR1cm4gKFxuICAgICAgQXJyYXkuaXNBcnJheShib2R5KSAmJlxuICAgICAgdHlwZW9mIGJvZHlbMF0gPT09ICdvYmplY3QnICYmXG4gICAgICAnZXJyb3JDb2RlJyBpbiBib2R5WzBdXG4gICAgKTtcbiAgfVxuXG4gIGlzU2Vzc2lvbkV4cGlyZWQocmVzcG9uc2U6IEh0dHBSZXNwb25zZSk6IGJvb2xlYW4ge1xuICAgIHJldHVybiAoXG4gICAgICByZXNwb25zZS5zdGF0dXNDb2RlID09PSA0MDEgJiYgL0lOVkFMSURfU0VTU0lPTl9JRC8udGVzdChyZXNwb25zZS5ib2R5KVxuICAgICk7XG4gIH1cblxuICBwYXJzZUVycm9yKGJvZHk6IGFueSkge1xuICAgIHJldHVybiB7XG4gICAgICBlcnJvckNvZGU6IGJvZHlbMF0uZXJyb3JDb2RlLFxuICAgICAgbWVzc2FnZTogYm9keVswXS5tZXNzYWdlLFxuICAgIH07XG4gIH1cbn1cblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbi8qKlxuICogQ2xhc3MgZm9yIEJ1bGsgQVBJXG4gKlxuICogQGNsYXNzXG4gKi9cbmV4cG9ydCBjbGFzcyBCdWxrPFMgZXh0ZW5kcyBTY2hlbWE+IHtcbiAgX2Nvbm46IENvbm5lY3Rpb248Uz47XG4gIF9sb2dnZXI6IExvZ2dlcjtcblxuICAvKipcbiAgICogUG9sbGluZyBpbnRlcnZhbCBpbiBtaWxsaXNlY29uZHNcbiAgICovXG4gIHBvbGxJbnRlcnZhbCA9IDEwMDA7XG5cbiAgLyoqXG4gICAqIFBvbGxpbmcgdGltZW91dCBpbiBtaWxsaXNlY29uZHNcbiAgICogQHR5cGUge051bWJlcn1cbiAgICovXG4gIHBvbGxUaW1lb3V0ID0gMTAwMDA7XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBjb25zdHJ1Y3Rvcihjb25uOiBDb25uZWN0aW9uPFM+KSB7XG4gICAgdGhpcy5fY29ubiA9IGNvbm47XG4gICAgdGhpcy5fbG9nZ2VyID0gY29ubi5fbG9nZ2VyO1xuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBfcmVxdWVzdDxUPihyZXF1ZXN0XzogQnVsa1JlcXVlc3QpIHtcbiAgICBjb25zdCBjb25uID0gdGhpcy5fY29ubjtcbiAgICBjb25zdCB7IHBhdGgsIHJlc3BvbnNlVHlwZSwgLi4ucnJlcSB9ID0gcmVxdWVzdF87XG4gICAgY29uc3QgYmFzZVVybCA9IFtjb25uLmluc3RhbmNlVXJsLCAnc2VydmljZXMvYXN5bmMnLCBjb25uLnZlcnNpb25dLmpvaW4oXG4gICAgICAnLycsXG4gICAgKTtcbiAgICBjb25zdCByZXF1ZXN0ID0ge1xuICAgICAgLi4ucnJlcSxcbiAgICAgIHVybDogYmFzZVVybCArIHBhdGgsXG4gICAgfTtcbiAgICByZXR1cm4gbmV3IEJ1bGtBcGkodGhpcy5fY29ubiwgeyByZXNwb25zZVR5cGUgfSkucmVxdWVzdDxUPihyZXF1ZXN0KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGUgYW5kIHN0YXJ0IGJ1bGtsb2FkIGpvYiBhbmQgYmF0Y2hcbiAgICovXG4gIGxvYWQ8T3ByIGV4dGVuZHMgQnVsa09wZXJhdGlvbj4oXG4gICAgdHlwZTogc3RyaW5nLFxuICAgIG9wZXJhdGlvbjogT3ByLFxuICAgIGlucHV0PzogUmVjb3JkW10gfCBSZWFkYWJsZSB8IHN0cmluZyxcbiAgKTogQmF0Y2g8UywgT3ByPjtcbiAgbG9hZDxPcHIgZXh0ZW5kcyBCdWxrT3BlcmF0aW9uPihcbiAgICB0eXBlOiBzdHJpbmcsXG4gICAgb3BlcmF0aW9uOiBPcHIsXG4gICAgb3B0aW9uc09ySW5wdXQ/OiBCdWxrT3B0aW9ucyB8IFJlY29yZFtdIHwgUmVhZGFibGUgfCBzdHJpbmcsXG4gICAgaW5wdXQ/OiBSZWNvcmRbXSB8IFJlYWRhYmxlIHwgc3RyaW5nLFxuICApOiBCYXRjaDxTLCBPcHI+O1xuICBsb2FkPE9wciBleHRlbmRzIEJ1bGtPcGVyYXRpb24+KFxuICAgIHR5cGU6IHN0cmluZyxcbiAgICBvcGVyYXRpb246IE9wcixcbiAgICBvcHRpb25zT3JJbnB1dD86IEJ1bGtPcHRpb25zIHwgUmVjb3JkW10gfCBSZWFkYWJsZSB8IHN0cmluZyxcbiAgICBpbnB1dD86IFJlY29yZFtdIHwgUmVhZGFibGUgfCBzdHJpbmcsXG4gICkge1xuICAgIGxldCBvcHRpb25zOiBCdWxrT3B0aW9ucyA9IHt9O1xuICAgIGlmIChcbiAgICAgIHR5cGVvZiBvcHRpb25zT3JJbnB1dCA9PT0gJ3N0cmluZycgfHxcbiAgICAgIEFycmF5LmlzQXJyYXkob3B0aW9uc09ySW5wdXQpIHx8XG4gICAgICAoaXNPYmplY3Qob3B0aW9uc09ySW5wdXQpICYmXG4gICAgICAgICdwaXBlJyBpbiBvcHRpb25zT3JJbnB1dCAmJlxuICAgICAgICB0eXBlb2Ygb3B0aW9uc09ySW5wdXQucGlwZSA9PT0gJ2Z1bmN0aW9uJylcbiAgICApIHtcbiAgICAgIC8vIHdoZW4gb3B0aW9ucyBpcyBub3QgcGxhaW4gaGFzaCBvYmplY3QsIGl0IGlzIG9taXR0ZWRcbiAgICAgIGlucHV0ID0gb3B0aW9uc09ySW5wdXQ7XG4gICAgfSBlbHNlIHtcbiAgICAgIG9wdGlvbnMgPSBvcHRpb25zT3JJbnB1dCBhcyBCdWxrT3B0aW9ucztcbiAgICB9XG4gICAgY29uc3Qgam9iID0gdGhpcy5jcmVhdGVKb2IodHlwZSwgb3BlcmF0aW9uLCBvcHRpb25zKTtcbiAgICBjb25zdCBiYXRjaCA9IGpvYi5jcmVhdGVCYXRjaCgpO1xuICAgIGNvbnN0IGNsZWFudXAgPSAoKSA9PiBqb2IuY2xvc2UoKTtcbiAgICBjb25zdCBjbGVhbnVwT25FcnJvciA9IChlcnI6IEVycm9yKSA9PiB7XG4gICAgICBpZiAoZXJyLm5hbWUgIT09ICdQb2xsaW5nVGltZW91dCcpIHtcbiAgICAgICAgY2xlYW51cCgpO1xuICAgICAgfVxuICAgIH07XG4gICAgYmF0Y2gub24oJ3Jlc3BvbnNlJywgY2xlYW51cCk7XG4gICAgYmF0Y2gub24oJ2Vycm9yJywgY2xlYW51cE9uRXJyb3IpO1xuICAgIGJhdGNoLm9uKCdxdWV1ZScsICgpID0+IHtcbiAgICAgIGJhdGNoPy5wb2xsKHRoaXMucG9sbEludGVydmFsLCB0aGlzLnBvbGxUaW1lb3V0KTtcbiAgICB9KTtcbiAgICByZXR1cm4gYmF0Y2guZXhlY3V0ZShpbnB1dCk7XG4gIH1cblxuICAvKipcbiAgICogRXhlY3V0ZSBidWxrIHF1ZXJ5IGFuZCBnZXQgcmVjb3JkIHN0cmVhbVxuICAgKi9cbiAgcXVlcnkoc29xbDogc3RyaW5nKSB7XG4gICAgY29uc3QgbSA9IHNvcWwucmVwbGFjZSgvXFwoW1xcc1xcU10rXFwpL2csICcnKS5tYXRjaCgvRlJPTVxccysoXFx3KykvaSk7XG4gICAgaWYgKCFtKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICdObyBzb2JqZWN0IHR5cGUgZm91bmQgaW4gcXVlcnksIG1heWJlIGNhdXNlZCBieSBpbnZhbGlkIFNPUUwuJyxcbiAgICAgICk7XG4gICAgfVxuICAgIGNvbnN0IHR5cGUgPSBtWzFdO1xuICAgIGNvbnN0IHJlY29yZFN0cmVhbSA9IG5ldyBQYXJzYWJsZSgpO1xuICAgIGNvbnN0IGRhdGFTdHJlYW0gPSByZWNvcmRTdHJlYW0uc3RyZWFtKCdjc3YnKTtcbiAgICAoYXN5bmMgKCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzdWx0cyA9IGF3YWl0IHRoaXMubG9hZCh0eXBlLCAncXVlcnknLCBzb3FsKTtcbiAgICAgICAgY29uc3Qgc3RyZWFtcyA9IHJlc3VsdHMubWFwKChyZXN1bHQpID0+XG4gICAgICAgICAgdGhpcy5qb2IocmVzdWx0LmpvYklkKVxuICAgICAgICAgICAgLmJhdGNoKHJlc3VsdC5iYXRjaElkKVxuICAgICAgICAgICAgLnJlc3VsdChyZXN1bHQuaWQpXG4gICAgICAgICAgICAuc3RyZWFtKCksXG4gICAgICAgICk7XG4gICAgICAgIGpvaW5TdHJlYW1zKHN0cmVhbXMpLnBpcGUoZGF0YVN0cmVhbSk7XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgcmVjb3JkU3RyZWFtLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgIH1cbiAgICB9KSgpO1xuICAgIHJldHVybiByZWNvcmRTdHJlYW07XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlIGEgbmV3IGpvYiBpbnN0YW5jZVxuICAgKi9cbiAgY3JlYXRlSm9iPE9wciBleHRlbmRzIEJ1bGtPcGVyYXRpb24+KFxuICAgIHR5cGU6IHN0cmluZyxcbiAgICBvcGVyYXRpb246IE9wcixcbiAgICBvcHRpb25zOiBCdWxrT3B0aW9ucyA9IHt9LFxuICApIHtcbiAgICByZXR1cm4gbmV3IEpvYih0aGlzLCB0eXBlLCBvcGVyYXRpb24sIG9wdGlvbnMpO1xuICB9XG5cbiAgLyoqXG4gICAqIEdldCBhIGpvYiBpbnN0YW5jZSBzcGVjaWZpZWQgYnkgZ2l2ZW4gam9iIElEXG4gICAqXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBqb2JJZCAtIEpvYiBJRFxuICAgKiBAcmV0dXJucyB7QnVsa35Kb2J9XG4gICAqL1xuICBqb2I8T3ByIGV4dGVuZHMgQnVsa09wZXJhdGlvbj4oam9iSWQ6IHN0cmluZykge1xuICAgIHJldHVybiBuZXcgSm9iPFMsIE9wcj4odGhpcywgbnVsbCwgbnVsbCwgbnVsbCwgam9iSWQpO1xuICB9XG59XG5cbmV4cG9ydCBjbGFzcyBCdWxrVjI8UyBleHRlbmRzIFNjaGVtYT4ge1xuICAjY29ubmVjdGlvbjogQ29ubmVjdGlvbjxTPjtcblxuICAvKipcbiAgICogUG9sbGluZyBpbnRlcnZhbCBpbiBtaWxsaXNlY29uZHNcbiAgICovXG4gIHBvbGxJbnRlcnZhbCA9IDEwMDA7XG5cbiAgLyoqXG4gICAqIFBvbGxpbmcgdGltZW91dCBpbiBtaWxsaXNlY29uZHNcbiAgICogQHR5cGUge051bWJlcn1cbiAgICovXG4gIHBvbGxUaW1lb3V0ID0gMTAwMDA7XG5cbiAgY29uc3RydWN0b3IoY29ubmVjdGlvbjogQ29ubmVjdGlvbjxTPikge1xuICAgIHRoaXMuI2Nvbm5lY3Rpb24gPSBjb25uZWN0aW9uO1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhIG5ldyBqb2IgaW5zdGFuY2VcbiAgICovXG4gIGNyZWF0ZUpvYjxPcHIgZXh0ZW5kcyBJbmdlc3RPcGVyYXRpb24+KFxuICAgIG9wdGlvbnM6IE5ld0luZ2VzdEpvYk9wdGlvbnMsXG4gICk6IEluZ2VzdEpvYlYyPFMsIE9wcj4ge1xuICAgIHJldHVybiBuZXcgSW5nZXN0Sm9iVjIoe1xuICAgICAgY29ubmVjdGlvbjogdGhpcy4jY29ubmVjdGlvbixcbiAgICAgIGpvYkluZm86IG9wdGlvbnMsXG4gICAgICBwb2xsaW5nT3B0aW9uczogdGhpcyxcbiAgICB9KTtcbiAgfVxuXG4gIGpvYjxPcHIgZXh0ZW5kcyBJbmdlc3RPcGVyYXRpb24+KFxuICAgIG9wdGlvbnM6IEV4aXN0aW5nSW5nZXN0Sm9iT3B0aW9ucyxcbiAgKTogSW5nZXN0Sm9iVjI8UywgT3ByPiB7XG4gICAgcmV0dXJuIG5ldyBJbmdlc3RKb2JWMih7XG4gICAgICBjb25uZWN0aW9uOiB0aGlzLiNjb25uZWN0aW9uLFxuICAgICAgam9iSW5mbzogb3B0aW9ucyxcbiAgICAgIHBvbGxpbmdPcHRpb25zOiB0aGlzLFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZSwgdXBsb2FkLCBhbmQgc3RhcnQgYnVsa2xvYWQgam9iXG4gICAqL1xuICBhc3luYyBsb2FkQW5kV2FpdEZvclJlc3VsdHMoXG4gICAgb3B0aW9uczogTmV3SW5nZXN0Sm9iT3B0aW9ucyAmXG4gICAgICBQYXJ0aWFsPEJ1bGtWMlBvbGxpbmdPcHRpb25zPiAmIHtcbiAgICAgICAgaW5wdXQ6IFJlY29yZFtdIHwgUmVhZGFibGUgfCBzdHJpbmc7XG4gICAgICB9LFxuICApOiBQcm9taXNlPEluZ2VzdEpvYlYyUmVzdWx0czxTPj4ge1xuICAgIGNvbnN0IGpvYiA9IHRoaXMuY3JlYXRlSm9iKG9wdGlvbnMpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBqb2Iub3BlbigpO1xuICAgICAgYXdhaXQgam9iLnVwbG9hZERhdGEob3B0aW9ucy5pbnB1dCk7XG4gICAgICBhd2FpdCBqb2IuY2xvc2UoKTtcbiAgICAgIGF3YWl0IGpvYi5wb2xsKG9wdGlvbnMucG9sbEludGVydmFsLCBvcHRpb25zLnBvbGxUaW1lb3V0KTtcbiAgICAgIHJldHVybiBhd2FpdCBqb2IuZ2V0QWxsUmVzdWx0cygpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKGVyci5uYW1lICE9PSAnSm9iUG9sbGluZ1RpbWVvdXRFcnJvcicpIHtcbiAgICAgICAgLy8gZmlyZXMgb2ZmIG9uZSBsYXN0IGF0dGVtcHQgdG8gY2xlYW4gdXAgYW5kIGlnbm9yZXMgdGhlIHJlc3VsdCB8IGVycm9yXG4gICAgICAgIGpvYi5kZWxldGUoKS5jYXRjaCgoaWdub3JlZCkgPT4gaWdub3JlZCk7XG4gICAgICB9XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEV4ZWN1dGUgYnVsayBxdWVyeSBhbmQgZ2V0IHJlY29yZCBzdHJlYW1cbiAgICovXG4gIGFzeW5jIHF1ZXJ5KFxuICAgIHNvcWw6IHN0cmluZyxcbiAgICBvcHRpb25zPzogUGFydGlhbDxCdWxrVjJQb2xsaW5nT3B0aW9ucz4sXG4gICk6IFByb21pc2U8UmVjb3JkW10+IHtcbiAgICBjb25zdCBxdWVyeUpvYiA9IG5ldyBRdWVyeUpvYlYyKHtcbiAgICAgIGNvbm5lY3Rpb246IHRoaXMuI2Nvbm5lY3Rpb24sXG4gICAgICBvcGVyYXRpb246ICdxdWVyeScsXG4gICAgICBxdWVyeTogc29xbCxcbiAgICAgIHBvbGxpbmdPcHRpb25zOiB0aGlzLFxuICAgIH0pO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBxdWVyeUpvYi5vcGVuKCk7XG4gICAgICBhd2FpdCBxdWVyeUpvYi5wb2xsKG9wdGlvbnM/LnBvbGxJbnRlcnZhbCwgb3B0aW9ucz8ucG9sbFRpbWVvdXQpO1xuICAgICAgcmV0dXJuIGF3YWl0IHF1ZXJ5Sm9iLmdldFJlc3VsdHMoKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmIChlcnIubmFtZSAhPT0gJ0pvYlBvbGxpbmdUaW1lb3V0RXJyb3InKSB7XG4gICAgICAgIC8vIGZpcmVzIG9mZiBvbmUgbGFzdCBhdHRlbXB0IHRvIGNsZWFuIHVwIGFuZCBpZ25vcmVzIHRoZSByZXN1bHQgfCBlcnJvclxuICAgICAgICBxdWVyeUpvYi5kZWxldGUoKS5jYXRjaCgoaWdub3JlZCkgPT4gaWdub3JlZCk7XG4gICAgICB9XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9XG59XG5cbmV4cG9ydCBjbGFzcyBRdWVyeUpvYlYyPFMgZXh0ZW5kcyBTY2hlbWE+IGV4dGVuZHMgRXZlbnRFbWl0dGVyIHtcbiAgcmVhZG9ubHkgI2Nvbm5lY3Rpb246IENvbm5lY3Rpb248Uz47XG4gIHJlYWRvbmx5ICNvcGVyYXRpb246IFF1ZXJ5T3BlcmF0aW9uO1xuICByZWFkb25seSAjcXVlcnk6IHN0cmluZztcbiAgcmVhZG9ubHkgI3BvbGxpbmdPcHRpb25zOiBCdWxrVjJQb2xsaW5nT3B0aW9ucztcbiAgI3F1ZXJ5UmVzdWx0czogUmVjb3JkW10gfCB1bmRlZmluZWQ7XG4gICNlcnJvcjogRXJyb3IgfCB1bmRlZmluZWQ7XG4gIGpvYkluZm86IFBhcnRpYWw8Sm9iSW5mb1YyPiB8IHVuZGVmaW5lZDtcblxuICBjb25zdHJ1Y3RvcihvcHRpb25zOiBDcmVhdGVRdWVyeUpvYlYyT3B0aW9uczxTPikge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy4jY29ubmVjdGlvbiA9IG9wdGlvbnMuY29ubmVjdGlvbjtcbiAgICB0aGlzLiNvcGVyYXRpb24gPSBvcHRpb25zLm9wZXJhdGlvbjtcbiAgICB0aGlzLiNxdWVyeSA9IG9wdGlvbnMucXVlcnk7XG4gICAgdGhpcy4jcG9sbGluZ09wdGlvbnMgPSBvcHRpb25zLnBvbGxpbmdPcHRpb25zO1xuICAgIC8vIGRlZmF1bHQgZXJyb3IgaGFuZGxlciB0byBrZWVwIHRoZSBsYXRlc3QgZXJyb3JcbiAgICB0aGlzLm9uKCdlcnJvcicsIChlcnJvcikgPT4gKHRoaXMuI2Vycm9yID0gZXJyb3IpKTtcbiAgfVxuXG4gIGFzeW5jIG9wZW4oKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdHJ5IHtcbiAgICAgIHRoaXMuam9iSW5mbyA9IGF3YWl0IHRoaXMuY3JlYXRlUXVlcnlSZXF1ZXN0PEpvYkluZm9WMj4oe1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgcGF0aDogJycsXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBvcGVyYXRpb246IHRoaXMuI29wZXJhdGlvbixcbiAgICAgICAgICBxdWVyeTogdGhpcy4jcXVlcnksXG4gICAgICAgIH0pLFxuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uOyBjaGFyc2V0PXV0Zi04JyxcbiAgICAgICAgfSxcbiAgICAgICAgcmVzcG9uc2VUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICB9KTtcbiAgICAgIHRoaXMuZW1pdCgnb3BlbicpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycik7XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFNldCB0aGUgc3RhdHVzIHRvIGFib3J0XG4gICAqL1xuICBhc3luYyBhYm9ydCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3Qgc3RhdGU6IEpvYlN0YXRlVjIgPSAnQWJvcnRlZCc7XG4gICAgICB0aGlzLmpvYkluZm8gPSBhd2FpdCB0aGlzLmNyZWF0ZVF1ZXJ5UmVxdWVzdDxKb2JJbmZvVjI+KHtcbiAgICAgICAgbWV0aG9kOiAnUEFUQ0gnLFxuICAgICAgICBwYXRoOiBgLyR7dGhpcy5qb2JJbmZvPy5pZH1gLFxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IHN0YXRlIH0pLFxuICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbjsgY2hhcnNldD11dGYtOCcgfSxcbiAgICAgICAgcmVzcG9uc2VUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICB9KTtcbiAgICAgIHRoaXMuZW1pdCgnYWJvcnRlZCcpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycik7XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgcG9sbChcbiAgICBpbnRlcnZhbDogbnVtYmVyID0gdGhpcy4jcG9sbGluZ09wdGlvbnMucG9sbEludGVydmFsLFxuICAgIHRpbWVvdXQ6IG51bWJlciA9IHRoaXMuI3BvbGxpbmdPcHRpb25zLnBvbGxUaW1lb3V0LFxuICApOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBqb2JJZCA9IGdldEpvYklkT3JFcnJvcih0aGlzLmpvYkluZm8pO1xuICAgIGNvbnN0IHN0YXJ0VGltZSA9IERhdGUubm93KCk7XG5cbiAgICB3aGlsZSAoc3RhcnRUaW1lICsgdGltZW91dCA+IERhdGUubm93KCkpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuY2hlY2soKTtcbiAgICAgICAgc3dpdGNoIChyZXMuc3RhdGUpIHtcbiAgICAgICAgICBjYXNlICdPcGVuJzpcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignSm9iIGhhcyBub3QgYmVlbiBzdGFydGVkJyk7XG4gICAgICAgICAgY2FzZSAnQWJvcnRlZCc6XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0pvYiBoYXMgYmVlbiBhYm9ydGVkJyk7XG4gICAgICAgICAgY2FzZSAnVXBsb2FkQ29tcGxldGUnOlxuICAgICAgICAgIGNhc2UgJ0luUHJvZ3Jlc3MnOlxuICAgICAgICAgICAgYXdhaXQgZGVsYXkoaW50ZXJ2YWwpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgY2FzZSAnRmFpbGVkJzpcbiAgICAgICAgICAgIHRoaXMuZW1pdCgnZmFpbGVkJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgY2FzZSAnSm9iQ29tcGxldGUnOlxuICAgICAgICAgICAgdGhpcy5lbWl0KCdqb2Jjb21wbGV0ZScpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycik7XG4gICAgICAgIHRocm93IGVycjtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zdCB0aW1lb3V0RXJyb3IgPSBuZXcgSm9iUG9sbGluZ1RpbWVvdXRFcnJvcihcbiAgICAgIGBQb2xsaW5nIHRpbWUgb3V0LiBKb2IgSWQgPSAke2pvYklkfWAsXG4gICAgICBqb2JJZCxcbiAgICApO1xuICAgIHRoaXMuZW1pdCgnZXJyb3InLCB0aW1lb3V0RXJyb3IpO1xuICAgIHRocm93IHRpbWVvdXRFcnJvcjtcbiAgfVxuXG4gIC8qKlxuICAgKiBDaGVjayB0aGUgbGF0ZXN0IGJhdGNoIHN0YXR1cyBpbiBzZXJ2ZXJcbiAgICovXG4gIGFzeW5jIGNoZWNrKCk6IFByb21pc2U8Sm9iSW5mb1YyPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGpvYkluZm8gPSBhd2FpdCB0aGlzLmNyZWF0ZVF1ZXJ5UmVxdWVzdDxKb2JJbmZvVjI+KHtcbiAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgcGF0aDogYC8ke2dldEpvYklkT3JFcnJvcih0aGlzLmpvYkluZm8pfWAsXG4gICAgICAgIHJlc3BvbnNlVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgfSk7XG4gICAgICB0aGlzLmpvYkluZm8gPSBqb2JJbmZvO1xuICAgICAgcmV0dXJuIGpvYkluZm87XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cblxuICBhc3luYyBnZXRSZXN1bHRzKCk6IFByb21pc2U8UmVjb3JkW10+IHtcbiAgICB0cnkge1xuICAgICAgaWYgKHRoaXMuI3F1ZXJ5UmVzdWx0cykge1xuICAgICAgICByZXR1cm4gdGhpcy4jcXVlcnlSZXN1bHRzO1xuICAgICAgfVxuXG4gICAgICBjb25zdCByZXN1bHRzID0gYXdhaXQgdGhpcy5jcmVhdGVRdWVyeVJlcXVlc3Q8UmVjb3JkW10gfCB1bmRlZmluZWQ+KHtcbiAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgcGF0aDogYC8ke2dldEpvYklkT3JFcnJvcih0aGlzLmpvYkluZm8pfS9yZXN1bHRzYCxcbiAgICAgICAgcmVzcG9uc2VUeXBlOiAndGV4dC9jc3YnLFxuICAgICAgfSk7XG5cbiAgICAgIHRoaXMuI3F1ZXJ5UmVzdWx0cyA9IHJlc3VsdHMgPz8gW107XG5cbiAgICAgIHJldHVybiB0aGlzLiNxdWVyeVJlc3VsdHM7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cblxuICBhc3luYyBkZWxldGUoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgcmV0dXJuIHRoaXMuY3JlYXRlUXVlcnlSZXF1ZXN0PHZvaWQ+KHtcbiAgICAgIG1ldGhvZDogJ0RFTEVURScsXG4gICAgICBwYXRoOiBgLyR7Z2V0Sm9iSWRPckVycm9yKHRoaXMuam9iSW5mbyl9YCxcbiAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgY3JlYXRlUXVlcnlSZXF1ZXN0PFQ+KHJlcXVlc3Q6IEJ1bGtSZXF1ZXN0KSB7XG4gICAgY29uc3QgeyBwYXRoLCByZXNwb25zZVR5cGUgfSA9IHJlcXVlc3Q7XG4gICAgY29uc3QgYmFzZVVybCA9IFtcbiAgICAgIHRoaXMuI2Nvbm5lY3Rpb24uaW5zdGFuY2VVcmwsXG4gICAgICAnc2VydmljZXMvZGF0YScsXG4gICAgICBgdiR7dGhpcy4jY29ubmVjdGlvbi52ZXJzaW9ufWAsXG4gICAgICAnam9icy9xdWVyeScsXG4gICAgXS5qb2luKCcvJyk7XG5cbiAgICByZXR1cm4gbmV3IEJ1bGtBcGlWMih0aGlzLiNjb25uZWN0aW9uLCB7IHJlc3BvbnNlVHlwZSB9KS5yZXF1ZXN0PFQ+KHtcbiAgICAgIC4uLnJlcXVlc3QsXG4gICAgICB1cmw6IGJhc2VVcmwgKyBwYXRoLFxuICAgIH0pO1xuICB9XG59XG5cbi8qKlxuICogQ2xhc3MgZm9yIEJ1bGsgQVBJIFYyIEluZ2VzdCBKb2JcbiAqL1xuZXhwb3J0IGNsYXNzIEluZ2VzdEpvYlYyPFxuICBTIGV4dGVuZHMgU2NoZW1hLFxuICBPcHIgZXh0ZW5kcyBJbmdlc3RPcGVyYXRpb25cbj4gZXh0ZW5kcyBFdmVudEVtaXR0ZXIge1xuICByZWFkb25seSAjY29ubmVjdGlvbjogQ29ubmVjdGlvbjxTPjtcbiAgcmVhZG9ubHkgI3BvbGxpbmdPcHRpb25zOiBCdWxrVjJQb2xsaW5nT3B0aW9ucztcbiAgcmVhZG9ubHkgI2pvYkRhdGE6IEpvYkRhdGFWMjxTLCBPcHI+O1xuICAjYnVsa0pvYlN1Y2Nlc3NmdWxSZXN1bHRzOiBJbmdlc3RKb2JWMlN1Y2Nlc3NmdWxSZXN1bHRzPFM+IHwgdW5kZWZpbmVkO1xuICAjYnVsa0pvYkZhaWxlZFJlc3VsdHM6IEluZ2VzdEpvYlYyRmFpbGVkUmVzdWx0czxTPiB8IHVuZGVmaW5lZDtcbiAgI2J1bGtKb2JVbnByb2Nlc3NlZFJlY29yZHM6IEluZ2VzdEpvYlYyVW5wcm9jZXNzZWRSZWNvcmRzPFM+IHwgdW5kZWZpbmVkO1xuICAjZXJyb3I6IEVycm9yIHwgdW5kZWZpbmVkO1xuICBqb2JJbmZvOiBQYXJ0aWFsPEpvYkluZm9WMj47XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBjb25zdHJ1Y3RvcihvcHRpb25zOiBDcmVhdGVJbmdlc3RKb2JWMk9wdGlvbnM8Uz4pIHtcbiAgICBzdXBlcigpO1xuXG4gICAgdGhpcy4jY29ubmVjdGlvbiA9IG9wdGlvbnMuY29ubmVjdGlvbjtcbiAgICB0aGlzLiNwb2xsaW5nT3B0aW9ucyA9IG9wdGlvbnMucG9sbGluZ09wdGlvbnM7XG4gICAgdGhpcy5qb2JJbmZvID0gb3B0aW9ucy5qb2JJbmZvO1xuICAgIHRoaXMuI2pvYkRhdGEgPSBuZXcgSm9iRGF0YVYyPFMsIE9wcj4oe1xuICAgICAgY3JlYXRlUmVxdWVzdDogKHJlcXVlc3QpID0+IHRoaXMuY3JlYXRlSW5nZXN0UmVxdWVzdChyZXF1ZXN0KSxcbiAgICAgIGpvYjogdGhpcyxcbiAgICB9KTtcbiAgICAvLyBkZWZhdWx0IGVycm9yIGhhbmRsZXIgdG8ga2VlcCB0aGUgbGF0ZXN0IGVycm9yXG4gICAgdGhpcy5vbignZXJyb3InLCAoZXJyb3IpID0+ICh0aGlzLiNlcnJvciA9IGVycm9yKSk7XG4gIH1cblxuICBnZXQgaWQoKSB7XG4gICAgcmV0dXJuIHRoaXMuam9iSW5mby5pZDtcbiAgfVxuXG4gIGFzeW5jIG9wZW4oKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdHJ5IHtcbiAgICAgIHRoaXMuam9iSW5mbyA9IGF3YWl0IHRoaXMuY3JlYXRlSW5nZXN0UmVxdWVzdDxKb2JJbmZvVjI+KHtcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgIHBhdGg6ICcnLFxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgYXNzaWdubWVudFJ1bGVJZDogdGhpcy5qb2JJbmZvPy5hc3NpZ25tZW50UnVsZUlkLFxuICAgICAgICAgIGV4dGVybmFsSWRGaWVsZE5hbWU6IHRoaXMuam9iSW5mbz8uZXh0ZXJuYWxJZEZpZWxkTmFtZSxcbiAgICAgICAgICBvYmplY3Q6IHRoaXMuam9iSW5mbz8ub2JqZWN0LFxuICAgICAgICAgIG9wZXJhdGlvbjogdGhpcy5qb2JJbmZvPy5vcGVyYXRpb24sXG4gICAgICAgIH0pLFxuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uOyBjaGFyc2V0PXV0Zi04JyxcbiAgICAgICAgfSxcbiAgICAgICAgcmVzcG9uc2VUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICB9KTtcbiAgICAgIHRoaXMuZW1pdCgnb3BlbicpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycik7XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgdXBsb2FkRGF0YShpbnB1dDogc3RyaW5nIHwgUmVjb3JkW10gfCBSZWFkYWJsZSk6IFByb21pc2U8dm9pZD4ge1xuICAgIGF3YWl0IHRoaXMuI2pvYkRhdGEuZXhlY3V0ZShpbnB1dCk7XG4gIH1cblxuICBhc3luYyBnZXRBbGxSZXN1bHRzKCk6IFByb21pc2U8SW5nZXN0Sm9iVjJSZXN1bHRzPFM+PiB7XG4gICAgY29uc3QgW1xuICAgICAgc3VjY2Vzc2Z1bFJlc3VsdHMsXG4gICAgICBmYWlsZWRSZXN1bHRzLFxuICAgICAgdW5wcm9jZXNzZWRSZWNvcmRzLFxuICAgIF0gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgICB0aGlzLmdldFN1Y2Nlc3NmdWxSZXN1bHRzKCksXG4gICAgICB0aGlzLmdldEZhaWxlZFJlc3VsdHMoKSxcbiAgICAgIHRoaXMuZ2V0VW5wcm9jZXNzZWRSZWNvcmRzKCksXG4gICAgXSk7XG4gICAgcmV0dXJuIHsgc3VjY2Vzc2Z1bFJlc3VsdHMsIGZhaWxlZFJlc3VsdHMsIHVucHJvY2Vzc2VkUmVjb3JkcyB9O1xuICB9XG5cbiAgLyoqXG4gICAqIENsb3NlIG9wZW5lZCBqb2JcbiAgICovXG4gIGFzeW5jIGNsb3NlKCk6IFByb21pc2U8dm9pZD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBzdGF0ZTogSm9iU3RhdGVWMiA9ICdVcGxvYWRDb21wbGV0ZSc7XG4gICAgICB0aGlzLmpvYkluZm8gPSBhd2FpdCB0aGlzLmNyZWF0ZUluZ2VzdFJlcXVlc3Q8Sm9iSW5mb1YyPih7XG4gICAgICAgIG1ldGhvZDogJ1BBVENIJyxcbiAgICAgICAgcGF0aDogYC8ke3RoaXMuam9iSW5mby5pZH1gLFxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IHN0YXRlIH0pLFxuICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbjsgY2hhcnNldD11dGYtOCcgfSxcbiAgICAgICAgcmVzcG9uc2VUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICB9KTtcbiAgICAgIHRoaXMuZW1pdCgndXBsb2FkY29tcGxldGUnKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBTZXQgdGhlIHN0YXR1cyB0byBhYm9ydFxuICAgKi9cbiAgYXN5bmMgYWJvcnQoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHN0YXRlOiBKb2JTdGF0ZVYyID0gJ0Fib3J0ZWQnO1xuICAgICAgdGhpcy5qb2JJbmZvID0gYXdhaXQgdGhpcy5jcmVhdGVJbmdlc3RSZXF1ZXN0PEpvYkluZm9WMj4oe1xuICAgICAgICBtZXRob2Q6ICdQQVRDSCcsXG4gICAgICAgIHBhdGg6IGAvJHt0aGlzLmpvYkluZm8uaWR9YCxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBzdGF0ZSB9KSxcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb247IGNoYXJzZXQ9dXRmLTgnIH0sXG4gICAgICAgIHJlc3BvbnNlVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgfSk7XG4gICAgICB0aGlzLmVtaXQoJ2Fib3J0ZWQnKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIHBvbGwoXG4gICAgaW50ZXJ2YWw6IG51bWJlciA9IHRoaXMuI3BvbGxpbmdPcHRpb25zLnBvbGxJbnRlcnZhbCxcbiAgICB0aW1lb3V0OiBudW1iZXIgPSB0aGlzLiNwb2xsaW5nT3B0aW9ucy5wb2xsVGltZW91dCxcbiAgKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3Qgam9iSWQgPSBnZXRKb2JJZE9yRXJyb3IodGhpcy5qb2JJbmZvKTtcbiAgICBjb25zdCBzdGFydFRpbWUgPSBEYXRlLm5vdygpO1xuXG4gICAgd2hpbGUgKHN0YXJ0VGltZSArIHRpbWVvdXQgPiBEYXRlLm5vdygpKSB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLmNoZWNrKCk7XG4gICAgICAgIHN3aXRjaCAocmVzLnN0YXRlKSB7XG4gICAgICAgICAgY2FzZSAnT3Blbic6XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0pvYiBoYXMgbm90IGJlZW4gc3RhcnRlZCcpO1xuICAgICAgICAgIGNhc2UgJ0Fib3J0ZWQnOlxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdKb2IgaGFzIGJlZW4gYWJvcnRlZCcpO1xuICAgICAgICAgIGNhc2UgJ1VwbG9hZENvbXBsZXRlJzpcbiAgICAgICAgICBjYXNlICdJblByb2dyZXNzJzpcbiAgICAgICAgICAgIGF3YWl0IGRlbGF5KGludGVydmFsKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGNhc2UgJ0ZhaWxlZCc6XG4gICAgICAgICAgICB0aGlzLmVtaXQoJ2ZhaWxlZCcpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIGNhc2UgJ0pvYkNvbXBsZXRlJzpcbiAgICAgICAgICAgIHRoaXMuZW1pdCgnam9iY29tcGxldGUnKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgICB0aHJvdyBlcnI7XG4gICAgICB9XG4gICAgfVxuXG4gICAgY29uc3QgdGltZW91dEVycm9yID0gbmV3IEpvYlBvbGxpbmdUaW1lb3V0RXJyb3IoXG4gICAgICBgUG9sbGluZyB0aW1lIG91dC4gSm9iIElkID0gJHtqb2JJZH1gLFxuICAgICAgam9iSWQsXG4gICAgKTtcbiAgICB0aGlzLmVtaXQoJ2Vycm9yJywgdGltZW91dEVycm9yKTtcbiAgICB0aHJvdyB0aW1lb3V0RXJyb3I7XG4gIH1cblxuICAvKipcbiAgICogQ2hlY2sgdGhlIGxhdGVzdCBiYXRjaCBzdGF0dXMgaW4gc2VydmVyXG4gICAqL1xuICBhc3luYyBjaGVjaygpOiBQcm9taXNlPEpvYkluZm9WMj4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBqb2JJbmZvID0gYXdhaXQgdGhpcy5jcmVhdGVJbmdlc3RSZXF1ZXN0PEpvYkluZm9WMj4oe1xuICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICBwYXRoOiBgLyR7Z2V0Sm9iSWRPckVycm9yKHRoaXMuam9iSW5mbyl9YCxcbiAgICAgICAgcmVzcG9uc2VUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICB9KTtcbiAgICAgIHRoaXMuam9iSW5mbyA9IGpvYkluZm87XG4gICAgICByZXR1cm4gam9iSW5mbztcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGdldFN1Y2Nlc3NmdWxSZXN1bHRzKCk6IFByb21pc2U8SW5nZXN0Sm9iVjJTdWNjZXNzZnVsUmVzdWx0czxTPj4ge1xuICAgIGlmICh0aGlzLiNidWxrSm9iU3VjY2Vzc2Z1bFJlc3VsdHMpIHtcbiAgICAgIHJldHVybiB0aGlzLiNidWxrSm9iU3VjY2Vzc2Z1bFJlc3VsdHM7XG4gICAgfVxuXG4gICAgY29uc3QgcmVzdWx0cyA9IGF3YWl0IHRoaXMuY3JlYXRlSW5nZXN0UmVxdWVzdDxcbiAgICAgIEluZ2VzdEpvYlYyU3VjY2Vzc2Z1bFJlc3VsdHM8Uz4gfCB1bmRlZmluZWRcbiAgICA+KHtcbiAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICBwYXRoOiBgLyR7Z2V0Sm9iSWRPckVycm9yKHRoaXMuam9iSW5mbyl9L3N1Y2Nlc3NmdWxSZXN1bHRzYCxcbiAgICAgIHJlc3BvbnNlVHlwZTogJ3RleHQvY3N2JyxcbiAgICB9KTtcblxuICAgIHRoaXMuI2J1bGtKb2JTdWNjZXNzZnVsUmVzdWx0cyA9IHJlc3VsdHMgPz8gW107XG5cbiAgICByZXR1cm4gdGhpcy4jYnVsa0pvYlN1Y2Nlc3NmdWxSZXN1bHRzO1xuICB9XG5cbiAgYXN5bmMgZ2V0RmFpbGVkUmVzdWx0cygpOiBQcm9taXNlPEluZ2VzdEpvYlYyRmFpbGVkUmVzdWx0czxTPj4ge1xuICAgIGlmICh0aGlzLiNidWxrSm9iRmFpbGVkUmVzdWx0cykge1xuICAgICAgcmV0dXJuIHRoaXMuI2J1bGtKb2JGYWlsZWRSZXN1bHRzO1xuICAgIH1cblxuICAgIGNvbnN0IHJlc3VsdHMgPSBhd2FpdCB0aGlzLmNyZWF0ZUluZ2VzdFJlcXVlc3Q8XG4gICAgICBJbmdlc3RKb2JWMkZhaWxlZFJlc3VsdHM8Uz4gfCB1bmRlZmluZWRcbiAgICA+KHtcbiAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICBwYXRoOiBgLyR7Z2V0Sm9iSWRPckVycm9yKHRoaXMuam9iSW5mbyl9L2ZhaWxlZFJlc3VsdHNgLFxuICAgICAgcmVzcG9uc2VUeXBlOiAndGV4dC9jc3YnLFxuICAgIH0pO1xuXG4gICAgdGhpcy4jYnVsa0pvYkZhaWxlZFJlc3VsdHMgPSByZXN1bHRzID8/IFtdO1xuXG4gICAgcmV0dXJuIHRoaXMuI2J1bGtKb2JGYWlsZWRSZXN1bHRzO1xuICB9XG5cbiAgYXN5bmMgZ2V0VW5wcm9jZXNzZWRSZWNvcmRzKCk6IFByb21pc2U8SW5nZXN0Sm9iVjJVbnByb2Nlc3NlZFJlY29yZHM8Uz4+IHtcbiAgICBpZiAodGhpcy4jYnVsa0pvYlVucHJvY2Vzc2VkUmVjb3Jkcykge1xuICAgICAgcmV0dXJuIHRoaXMuI2J1bGtKb2JVbnByb2Nlc3NlZFJlY29yZHM7XG4gICAgfVxuXG4gICAgY29uc3QgcmVzdWx0cyA9IGF3YWl0IHRoaXMuY3JlYXRlSW5nZXN0UmVxdWVzdDxcbiAgICAgIEluZ2VzdEpvYlYyVW5wcm9jZXNzZWRSZWNvcmRzPFM+IHwgdW5kZWZpbmVkXG4gICAgPih7XG4gICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgcGF0aDogYC8ke2dldEpvYklkT3JFcnJvcih0aGlzLmpvYkluZm8pfS91bnByb2Nlc3NlZHJlY29yZHNgLFxuICAgICAgcmVzcG9uc2VUeXBlOiAndGV4dC9jc3YnLFxuICAgIH0pO1xuXG4gICAgdGhpcy4jYnVsa0pvYlVucHJvY2Vzc2VkUmVjb3JkcyA9IHJlc3VsdHMgPz8gW107XG5cbiAgICByZXR1cm4gdGhpcy4jYnVsa0pvYlVucHJvY2Vzc2VkUmVjb3JkcztcbiAgfVxuXG4gIGFzeW5jIGRlbGV0ZSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICByZXR1cm4gdGhpcy5jcmVhdGVJbmdlc3RSZXF1ZXN0PHZvaWQ+KHtcbiAgICAgIG1ldGhvZDogJ0RFTEVURScsXG4gICAgICBwYXRoOiBgLyR7Z2V0Sm9iSWRPckVycm9yKHRoaXMuam9iSW5mbyl9YCxcbiAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgY3JlYXRlSW5nZXN0UmVxdWVzdDxUPihyZXF1ZXN0OiBCdWxrUmVxdWVzdCkge1xuICAgIGNvbnN0IHsgcGF0aCwgcmVzcG9uc2VUeXBlIH0gPSByZXF1ZXN0O1xuICAgIGNvbnN0IGJhc2VVcmwgPSBbXG4gICAgICB0aGlzLiNjb25uZWN0aW9uLmluc3RhbmNlVXJsLFxuICAgICAgJ3NlcnZpY2VzL2RhdGEnLFxuICAgICAgYHYke3RoaXMuI2Nvbm5lY3Rpb24udmVyc2lvbn1gLFxuICAgICAgJ2pvYnMvaW5nZXN0JyxcbiAgICBdLmpvaW4oJy8nKTtcblxuICAgIHJldHVybiBuZXcgQnVsa0FwaVYyKHRoaXMuI2Nvbm5lY3Rpb24sIHsgcmVzcG9uc2VUeXBlIH0pLnJlcXVlc3Q8VD4oe1xuICAgICAgLi4ucmVxdWVzdCxcbiAgICAgIHVybDogYmFzZVVybCArIHBhdGgsXG4gICAgfSk7XG4gIH1cbn1cblxuY2xhc3MgSm9iRGF0YVYyPFxuICBTIGV4dGVuZHMgU2NoZW1hLFxuICBPcHIgZXh0ZW5kcyBJbmdlc3RPcGVyYXRpb25cbj4gZXh0ZW5kcyBXcml0YWJsZSB7XG4gIHJlYWRvbmx5ICNqb2I6IEluZ2VzdEpvYlYyPFMsIE9wcj47XG4gIHJlYWRvbmx5ICN1cGxvYWRTdHJlYW06IFNlcmlhbGl6YWJsZTtcbiAgcmVhZG9ubHkgI2Rvd25sb2FkU3RyZWFtOiBQYXJzYWJsZTtcbiAgcmVhZG9ubHkgI2RhdGFTdHJlYW06IER1cGxleDtcbiAgI3Jlc3VsdDogYW55O1xuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgY29uc3RydWN0b3Iob3B0aW9uczogQ3JlYXRlSm9iRGF0YVYyT3B0aW9uczxTLCBPcHI+KSB7XG4gICAgc3VwZXIoeyBvYmplY3RNb2RlOiB0cnVlIH0pO1xuXG4gICAgY29uc3QgY3JlYXRlUmVxdWVzdCA9IG9wdGlvbnMuY3JlYXRlUmVxdWVzdDtcblxuICAgIHRoaXMuI2pvYiA9IG9wdGlvbnMuam9iO1xuICAgIHRoaXMuI3VwbG9hZFN0cmVhbSA9IG5ldyBTZXJpYWxpemFibGUoKTtcbiAgICB0aGlzLiNkb3dubG9hZFN0cmVhbSA9IG5ldyBQYXJzYWJsZSgpO1xuXG4gICAgY29uc3QgY29udmVydGVyT3B0aW9ucyA9IHsgbnVsbFZhbHVlOiAnI04vQScgfTtcbiAgICBjb25zdCB1cGxvYWREYXRhU3RyZWFtID0gdGhpcy4jdXBsb2FkU3RyZWFtLnN0cmVhbSgnY3N2JywgY29udmVydGVyT3B0aW9ucyk7XG4gICAgY29uc3QgZG93bmxvYWREYXRhU3RyZWFtID0gdGhpcy4jZG93bmxvYWRTdHJlYW0uc3RyZWFtKFxuICAgICAgJ2NzdicsXG4gICAgICBjb252ZXJ0ZXJPcHRpb25zLFxuICAgICk7XG5cbiAgICB0aGlzLiNkYXRhU3RyZWFtID0gY29uY2F0U3RyZWFtc0FzRHVwbGV4KFxuICAgICAgdXBsb2FkRGF0YVN0cmVhbSxcbiAgICAgIGRvd25sb2FkRGF0YVN0cmVhbSxcbiAgICApO1xuXG4gICAgdGhpcy5vbignZmluaXNoJywgKCkgPT4gdGhpcy4jdXBsb2FkU3RyZWFtLmVuZCgpKTtcblxuICAgIHVwbG9hZERhdGFTdHJlYW0ub25jZSgncmVhZGFibGUnLCAoKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICAvLyBwaXBlIHVwbG9hZCBkYXRhIHRvIGJhdGNoIEFQSSByZXF1ZXN0IHN0cmVhbVxuICAgICAgICBjb25zdCByZXEgPSBjcmVhdGVSZXF1ZXN0KHtcbiAgICAgICAgICBtZXRob2Q6ICdQVVQnLFxuICAgICAgICAgIHBhdGg6IGAvJHt0aGlzLiNqb2Iuam9iSW5mbz8uaWR9L2JhdGNoZXNgLFxuICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAndGV4dC9jc3YnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgcmVzcG9uc2VUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIChhc3luYyAoKSA9PiB7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHJlcTtcbiAgICAgICAgICAgIHRoaXMuZW1pdCgncmVzcG9uc2UnLCByZXMpO1xuICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycik7XG4gICAgICAgICAgfVxuICAgICAgICB9KSgpO1xuXG4gICAgICAgIHVwbG9hZERhdGFTdHJlYW0ucGlwZShyZXEuc3RyZWFtKCkpO1xuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgX3dyaXRlKHJlY29yZF86IFJlY29yZCwgZW5jOiBzdHJpbmcsIGNiOiAoKSA9PiB2b2lkKSB7XG4gICAgY29uc3QgeyBJZCwgdHlwZSwgYXR0cmlidXRlcywgLi4ucnJlYyB9ID0gcmVjb3JkXztcbiAgICBsZXQgcmVjb3JkO1xuICAgIHN3aXRjaCAodGhpcy4jam9iLmpvYkluZm8ub3BlcmF0aW9uKSB7XG4gICAgICBjYXNlICdpbnNlcnQnOlxuICAgICAgICByZWNvcmQgPSBycmVjO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ2RlbGV0ZSc6XG4gICAgICBjYXNlICdoYXJkRGVsZXRlJzpcbiAgICAgICAgcmVjb3JkID0geyBJZCB9O1xuICAgICAgICBicmVhaztcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHJlY29yZCA9IHsgSWQsIC4uLnJyZWMgfTtcbiAgICB9XG4gICAgdGhpcy4jdXBsb2FkU3RyZWFtLndyaXRlKHJlY29yZCwgZW5jLCBjYik7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyBkdXBsZXggc3RyZWFtIHdoaWNoIGFjY2VwdHMgQ1NWIGRhdGEgaW5wdXQgYW5kIGJhdGNoIHJlc3VsdCBvdXRwdXRcbiAgICovXG4gIHN0cmVhbSgpIHtcbiAgICByZXR1cm4gdGhpcy4jZGF0YVN0cmVhbTtcbiAgfVxuXG4gIC8qKlxuICAgKiBFeGVjdXRlIGJhdGNoIG9wZXJhdGlvblxuICAgKi9cbiAgZXhlY3V0ZShpbnB1dD86IHN0cmluZyB8IFJlY29yZFtdIHwgUmVhZGFibGUpIHtcbiAgICBpZiAodGhpcy4jcmVzdWx0KSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0RhdGEgY2FuIG9ubHkgYmUgdXBsb2FkZWQgdG8gYSBqb2Igb25jZS4nKTtcbiAgICB9XG5cbiAgICB0aGlzLiNyZXN1bHQgPSBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICB0aGlzLm9uY2UoJ3Jlc3BvbnNlJywgKCkgPT4gcmVzb2x2ZSgpKTtcbiAgICAgIHRoaXMub25jZSgnZXJyb3InLCByZWplY3QpO1xuICAgIH0pO1xuXG4gICAgaWYgKGlzT2JqZWN0KGlucHV0KSAmJiAncGlwZScgaW4gaW5wdXQgJiYgaXNGdW5jdGlvbihpbnB1dC5waXBlKSkge1xuICAgICAgLy8gaWYgaW5wdXQgaGFzIHN0cmVhbS5SZWFkYWJsZSBpbnRlcmZhY2VcbiAgICAgIGlucHV0LnBpcGUodGhpcy4jZGF0YVN0cmVhbSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmIChBcnJheS5pc0FycmF5KGlucHV0KSkge1xuICAgICAgICBmb3IgKGNvbnN0IHJlY29yZCBvZiBpbnB1dCkge1xuICAgICAgICAgIGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKHJlY29yZCkpIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgcmVjb3JkW2tleV0gPT09ICdib29sZWFuJykge1xuICAgICAgICAgICAgICByZWNvcmRba2V5XSA9IFN0cmluZyhyZWNvcmRba2V5XSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIHRoaXMud3JpdGUocmVjb3JkKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmVuZCgpO1xuICAgICAgfSBlbHNlIGlmICh0eXBlb2YgaW5wdXQgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIHRoaXMuI2RhdGFTdHJlYW0ud3JpdGUoaW5wdXQsICd1dGY4Jyk7XG4gICAgICAgIHRoaXMuI2RhdGFTdHJlYW0uZW5kKCk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICAvKipcbiAgICogUHJvbWlzZS9BKyBpbnRlcmZhY2VcbiAgICogRGVsZWdhdGUgdG8gcHJvbWlzZSwgcmV0dXJuIHByb21pc2UgaW5zdGFuY2UgZm9yIGJhdGNoIHJlc3VsdFxuICAgKi9cbiAgdGhlbihvblJlc29sdmVkOiAoKSA9PiB2b2lkLCBvblJlamVjdDogKGVycjogYW55KSA9PiB2b2lkKSB7XG4gICAgaWYgKHRoaXMuI3Jlc3VsdCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICB0aGlzLmV4ZWN1dGUoKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuI3Jlc3VsdCEudGhlbihvblJlc29sdmVkLCBvblJlamVjdCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gZ2V0Sm9iSWRPckVycm9yKGpvYkluZm86IFBhcnRpYWw8Sm9iSW5mb1YyPiB8IHVuZGVmaW5lZCk6IHN0cmluZyB7XG4gIGNvbnN0IGpvYklkID0gam9iSW5mbz8uaWQ7XG4gIGlmIChqb2JJZCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdObyBqb2IgaWQsIG1heWJlIHlvdSBuZWVkIHRvIGNhbGwgYGpvYi5vcGVuKClgIGZpcnN0LicpO1xuICB9XG4gIHJldHVybiBqb2JJZDtcbn1cblxuZnVuY3Rpb24gZGVsYXkobXM6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHNldFRpbWVvdXQocmVzb2x2ZSwgbXMpKTtcbn1cblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG4vKlxuICogUmVnaXN0ZXIgaG9vayBpbiBjb25uZWN0aW9uIGluc3RhbnRpYXRpb24gZm9yIGR5bmFtaWNhbGx5IGFkZGluZyB0aGlzIEFQSSBtb2R1bGUgZmVhdHVyZXNcbiAqL1xucmVnaXN0ZXJNb2R1bGUoJ2J1bGsnLCAoY29ubikgPT4gbmV3IEJ1bGsoY29ubikpO1xucmVnaXN0ZXJNb2R1bGUoJ2J1bGsyJywgKGNvbm4pID0+IG5ldyBCdWxrVjIoY29ubikpO1xuXG5leHBvcnQgZGVmYXVsdCBCdWxrO1xuIl19