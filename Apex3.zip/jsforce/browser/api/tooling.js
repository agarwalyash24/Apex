import _getIterator from "@babel/runtime-corejs3/core-js/get-iterator";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _getIteratorMethod from "@babel/runtime-corejs3/core-js/get-iterator-method";
import _Symbol from "@babel/runtime-corejs3/core-js-stable/symbol";
import _Array$from from "@babel/runtime-corejs3/core-js-stable/array/from";
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";
import "core-js/modules/es.function.name";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof _Symbol === "undefined" || _getIteratorMethod(o) == null) { if (_Array$isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = _getIterator(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { var _context; if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = _sliceInstanceProperty(_context = Object.prototype.toString.call(o)).call(_context, 8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return _Array$from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

/**
 * @file Manages Tooling APIs
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { registerModule } from '../jsforce';
import Connection from '../connection';
import Cache from '../cache';

/**
 *
 */
var _Connection$prototype = Connection.prototype,
    query = _Connection$prototype.query,
    queryMore = _Connection$prototype.queryMore,
    create = _Connection$prototype.create,
    _createSingle = _Connection$prototype._createSingle,
    _createMany = _Connection$prototype._createMany,
    _createParallel = _Connection$prototype._createParallel,
    retrieve = _Connection$prototype.retrieve,
    _retrieveSingle = _Connection$prototype._retrieveSingle,
    _retrieveParallel = _Connection$prototype._retrieveParallel,
    _retrieveMany = _Connection$prototype._retrieveMany,
    update = _Connection$prototype.update,
    _updateSingle = _Connection$prototype._updateSingle,
    _updateParallel = _Connection$prototype._updateParallel,
    _updateMany = _Connection$prototype._updateMany,
    upsert = _Connection$prototype.upsert,
    destroy = _Connection$prototype.destroy,
    _destroySingle = _Connection$prototype._destroySingle,
    _destroyParallel = _Connection$prototype._destroyParallel,
    _destroyMany = _Connection$prototype._destroyMany,
    describe = _Connection$prototype.describe,
    describeGlobal = _Connection$prototype.describeGlobal,
    sobject = _Connection$prototype.sobject;

var describeCacheKey = function describeCacheKey(type) {
  return type ? "describe.".concat(type) : 'describe';
};
/**
 * API class for Tooling API call
 */


export var Tooling = /*#__PURE__*/function () {
  /**
   * Execute query by using SOQL
   */

  /**
   * Query next record set by using query locator
   */

  /**
   * Create records
   */

  /**
   * Synonym of Tooling#create()
   */

  /**
   * Retrieve specified records
   */

  /**
   * Update records
   */

  /**
   * Upsert records
   */

  /**
   * Delete records
   */

  /**
   * Synonym of Tooling#destroy()
   */

  /**
   * Synonym of Tooling#destroy()
   */

  /**
   * Describe SObject metadata
   */

  /**
   * Synonym of Tooling#describe()
   */

  /**
   * Describe global SObjects
   */

  /**
   * Get SObject instance
   */

  /**
   *
   */
  function Tooling(conn) {
    _classCallCheck(this, Tooling);

    _defineProperty(this, "_conn", void 0);

    _defineProperty(this, "query", query);

    _defineProperty(this, "queryMore", queryMore);

    _defineProperty(this, "create", create);

    _defineProperty(this, "_createSingle", _createSingle);

    _defineProperty(this, "_createParallel", _createParallel);

    _defineProperty(this, "_createMany", _createMany);

    _defineProperty(this, "insert", create);

    _defineProperty(this, "retrieve", retrieve);

    _defineProperty(this, "_retrieveSingle", _retrieveSingle);

    _defineProperty(this, "_retrieveParallel", _retrieveParallel);

    _defineProperty(this, "_retrieveMany", _retrieveMany);

    _defineProperty(this, "update", update);

    _defineProperty(this, "_updateSingle", _updateSingle);

    _defineProperty(this, "_updateParallel", _updateParallel);

    _defineProperty(this, "_updateMany", _updateMany);

    _defineProperty(this, "upsert", upsert);

    _defineProperty(this, "destroy", destroy);

    _defineProperty(this, "_destroySingle", _destroySingle);

    _defineProperty(this, "_destroyParallel", _destroyParallel);

    _defineProperty(this, "_destroyMany", _destroyMany);

    _defineProperty(this, "delete", destroy);

    _defineProperty(this, "del", destroy);

    _defineProperty(this, "cache", new Cache());

    _defineProperty(this, "describe", this.cache.createCachedFunction(describe, this, {
      key: describeCacheKey,
      strategy: 'NOCACHE'
    }));

    _defineProperty(this, "describe$", this.cache.createCachedFunction(describe, this, {
      key: describeCacheKey,
      strategy: 'HIT'
    }));

    _defineProperty(this, "describe$$", this.cache.createCachedFunction(describe, this, {
      key: describeCacheKey,
      strategy: 'IMMEDIATE'
    }));

    _defineProperty(this, "describeSObject", this.describe);

    _defineProperty(this, "describeSObject$", this.describe$);

    _defineProperty(this, "describeSObject$$", this.describe$$);

    _defineProperty(this, "describeGlobal", this.cache.createCachedFunction(describeGlobal, this, {
      key: 'describeGlobal',
      strategy: 'NOCACHE'
    }));

    _defineProperty(this, "describeGlobal$", this.cache.createCachedFunction(describeGlobal, this, {
      key: 'describeGlobal',
      strategy: 'HIT'
    }));

    _defineProperty(this, "describeGlobal$$", this.cache.createCachedFunction(describeGlobal, this, {
      key: 'describeGlobal',
      strategy: 'IMMEDIATE'
    }));

    _defineProperty(this, "sobject", sobject);

    _defineProperty(this, "sobjects", {});

    this._conn = conn;
  }
  /**
   * @private
   */


  _createClass(Tooling, [{
    key: "_establish",
    value: function _establish() {
      var _this = this;

      this.sobjects = {};
      this.cache.clear();
      this.cache.get('describeGlobal').removeAllListeners('value');
      this.cache.get('describeGlobal').on('value', function (res) {
        if (res.result) {
          var _iterator = _createForOfIteratorHelper(res.result.sobjects),
              _step;

          try {
            for (_iterator.s(); !(_step = _iterator.n()).done;) {
              var type = _step.value.name;

              _this.sobject(type);
            }
          } catch (err) {
            _iterator.e(err);
          } finally {
            _iterator.f();
          }
        }
      });
    }
    /**
     * @private
     */

  }, {
    key: "_baseUrl",
    value: function _baseUrl() {
      return this._conn._baseUrl() + '/tooling';
    }
    /**
     * @private
     */

  }, {
    key: "_supports",
    value: function _supports(feature) {
      return this._conn._supports(feature);
    }
    /**
     *
     */

  }, {
    key: "request",
    value: function request(_request, options) {
      return this._conn.request(_request, options);
    }
    /**
     * Executes Apex code anonymously
     */

  }, {
    key: "executeAnonymous",
    value: function executeAnonymous(body) {
      var url = this._baseUrl() + '/executeAnonymous?anonymousBody=' + encodeURIComponent(body);
      return this.request(url);
    }
    /**
     * Executes Apex tests asynchronously
     */

  }, {
    key: "runTestsAsynchronous",
    value: function runTestsAsynchronous(req) {
      var url = this._baseUrl() + '/runTestsAsynchronous/';
      return this._conn.requestPost(url, req);
    }
    /**
     * Executes Apex tests synchronously
     */

  }, {
    key: "runTestsSynchronous",
    value: function runTestsSynchronous(req) {
      var url = this._baseUrl() + '/runTestsSynchronous/';
      return this._conn.requestPost(url, req);
    }
    /**
     * Retrieves available code completions of the referenced type
     */

  }, {
    key: "completions",
    value: function completions() {
      var type = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'apex';
      var url = this._baseUrl() + '/completions?type=' + encodeURIComponent(type);
      return this.request({
        method: 'GET',
        url: url,
        headers: {
          Accept: 'application/json'
        }
      });
    }
  }]);

  return Tooling;
}();
/*--------------------------------------------*/

/*
 * Register hook in connection instantiation for dynamically adding this API module features
 */

registerModule('tooling', function (conn) {
  return new Tooling(conn);
});
export default Tooling;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9hcGkvdG9vbGluZy50cyJdLCJuYW1lcyI6WyJyZWdpc3Rlck1vZHVsZSIsIkNvbm5lY3Rpb24iLCJDYWNoZSIsInByb3RvdHlwZSIsInF1ZXJ5IiwicXVlcnlNb3JlIiwiY3JlYXRlIiwiX2NyZWF0ZVNpbmdsZSIsIl9jcmVhdGVNYW55IiwiX2NyZWF0ZVBhcmFsbGVsIiwicmV0cmlldmUiLCJfcmV0cmlldmVTaW5nbGUiLCJfcmV0cmlldmVQYXJhbGxlbCIsIl9yZXRyaWV2ZU1hbnkiLCJ1cGRhdGUiLCJfdXBkYXRlU2luZ2xlIiwiX3VwZGF0ZVBhcmFsbGVsIiwiX3VwZGF0ZU1hbnkiLCJ1cHNlcnQiLCJkZXN0cm95IiwiX2Rlc3Ryb3lTaW5nbGUiLCJfZGVzdHJveVBhcmFsbGVsIiwiX2Rlc3Ryb3lNYW55IiwiZGVzY3JpYmUiLCJkZXNjcmliZUdsb2JhbCIsInNvYmplY3QiLCJkZXNjcmliZUNhY2hlS2V5IiwidHlwZSIsIlRvb2xpbmciLCJjb25uIiwiY2FjaGUiLCJjcmVhdGVDYWNoZWRGdW5jdGlvbiIsImtleSIsInN0cmF0ZWd5IiwiZGVzY3JpYmUkIiwiZGVzY3JpYmUkJCIsIl9jb25uIiwic29iamVjdHMiLCJjbGVhciIsImdldCIsInJlbW92ZUFsbExpc3RlbmVycyIsIm9uIiwicmVzIiwicmVzdWx0IiwibmFtZSIsIl9iYXNlVXJsIiwiZmVhdHVyZSIsIl9zdXBwb3J0cyIsInJlcXVlc3QiLCJvcHRpb25zIiwiYm9keSIsInVybCIsImVuY29kZVVSSUNvbXBvbmVudCIsInJlcSIsInJlcXVlc3RQb3N0IiwibWV0aG9kIiwiaGVhZGVycyIsIkFjY2VwdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVNBLGNBQVQsUUFBK0IsWUFBL0I7QUFDQSxPQUFPQyxVQUFQLE1BQXVCLGVBQXZCO0FBQ0EsT0FBT0MsS0FBUCxNQUFzQyxVQUF0Qzs7QUEyS0E7QUFDQTtBQUNBOzRCQXdCSUQsVUFBVSxDQUFDRSxTO0lBdEJiQyxLLHlCQUFBQSxLO0lBQ0FDLFMseUJBQUFBLFM7SUFDQUMsTSx5QkFBQUEsTTtJQUNBQyxhLHlCQUFBQSxhO0lBQ0FDLFcseUJBQUFBLFc7SUFDQUMsZSx5QkFBQUEsZTtJQUNBQyxRLHlCQUFBQSxRO0lBQ0FDLGUseUJBQUFBLGU7SUFDQUMsaUIseUJBQUFBLGlCO0lBQ0FDLGEseUJBQUFBLGE7SUFDQUMsTSx5QkFBQUEsTTtJQUNBQyxhLHlCQUFBQSxhO0lBQ0FDLGUseUJBQUFBLGU7SUFDQUMsVyx5QkFBQUEsVztJQUNBQyxNLHlCQUFBQSxNO0lBQ0FDLE8seUJBQUFBLE87SUFDQUMsYyx5QkFBQUEsYztJQUNBQyxnQix5QkFBQUEsZ0I7SUFDQUMsWSx5QkFBQUEsWTtJQUNBQyxRLHlCQUFBQSxRO0lBQ0FDLGMseUJBQUFBLGM7SUFDQUMsTyx5QkFBQUEsTzs7QUFHRixJQUFNQyxnQkFBZ0IsR0FBRyxTQUFuQkEsZ0JBQW1CLENBQUNDLElBQUQ7QUFBQSxTQUN2QkEsSUFBSSxzQkFBZUEsSUFBZixJQUF3QixVQURMO0FBQUEsQ0FBekI7QUFHQTtBQUNBO0FBQ0E7OztBQUNBLFdBQWFDLE9BQWI7QUFHRTtBQUNGO0FBQ0E7O0FBR0U7QUFDRjtBQUNBOztBQUdFO0FBQ0Y7QUFDQTs7QUFNRTtBQUNGO0FBQ0E7O0FBR0U7QUFDRjtBQUNBOztBQU1FO0FBQ0Y7QUFDQTs7QUFNRTtBQUNGO0FBQ0E7O0FBR0U7QUFDRjtBQUNBOztBQU1FO0FBQ0Y7QUFDQTs7QUFHRTtBQUNGO0FBQ0E7O0FBS0U7QUFDRjtBQUNBOztBQWNFO0FBQ0Y7QUFDQTs7QUFLRTtBQUNGO0FBQ0E7O0FBY0U7QUFDRjtBQUNBOztBQUtFO0FBQ0Y7QUFDQTtBQUNFLG1CQUFZQyxJQUFaLEVBQWlDO0FBQUE7O0FBQUE7O0FBQUEsbUNBOUdEekIsS0E4R0M7O0FBQUEsdUNBekdPQyxTQXlHUDs7QUFBQSxvQ0FwR0NDLE1Bb0dEOztBQUFBLDJDQW5HakJDLGFBbUdpQjs7QUFBQSw2Q0FsR2ZFLGVBa0dlOztBQUFBLHlDQWpHbkJELFdBaUdtQjs7QUFBQSxvQ0E1RnhCRixNQTRGd0I7O0FBQUEsc0NBdkZLSSxRQXVGTDs7QUFBQSw2Q0F0RmZDLGVBc0ZlOztBQUFBLCtDQXJGYkMsaUJBcUZhOztBQUFBLDJDQXBGakJDLGFBb0ZpQjs7QUFBQSxvQ0EvRUNDLE1BK0VEOztBQUFBLDJDQTlFakJDLGFBOEVpQjs7QUFBQSw2Q0E3RWZDLGVBNkVlOztBQUFBLHlDQTVFbkJDLFdBNEVtQjs7QUFBQSxvQ0F2RUNDLE1BdUVEOztBQUFBLHFDQWxFR0MsT0FrRUg7O0FBQUEsNENBakVoQkMsY0FpRWdCOztBQUFBLDhDQWhFZEMsZ0JBZ0VjOztBQUFBLDBDQS9EbEJDLFlBK0RrQjs7QUFBQSxvQ0ExRHhCSCxPQTBEd0I7O0FBQUEsaUNBckQzQkEsT0FxRDJCOztBQUFBLG1DQW5EekIsSUFBSWpCLEtBQUosRUFtRHlCOztBQUFBLHNDQTlDdEIsS0FBSzRCLEtBQUwsQ0FBV0Msb0JBQVgsQ0FBZ0NSLFFBQWhDLEVBQTBDLElBQTFDLEVBQWdEO0FBQ3pEUyxNQUFBQSxHQUFHLEVBQUVOLGdCQURvRDtBQUV6RE8sTUFBQUEsUUFBUSxFQUFFO0FBRitDLEtBQWhELENBOENzQjs7QUFBQSx1Q0ExQ3JCLEtBQUtILEtBQUwsQ0FBV0Msb0JBQVgsQ0FBZ0NSLFFBQWhDLEVBQTBDLElBQTFDLEVBQWdEO0FBQzFEUyxNQUFBQSxHQUFHLEVBQUVOLGdCQURxRDtBQUUxRE8sTUFBQUEsUUFBUSxFQUFFO0FBRmdELEtBQWhELENBMENxQjs7QUFBQSx3Q0F0Q25CLEtBQUtILEtBQUwsQ0FBV0Msb0JBQVgsQ0FBZ0NSLFFBQWhDLEVBQTBDLElBQTFDLEVBQWdEO0FBQzVEUyxNQUFBQSxHQUFHLEVBQUVOLGdCQUR1RDtBQUU1RE8sTUFBQUEsUUFBUSxFQUFFO0FBRmtELEtBQWhELENBc0NtQjs7QUFBQSw2Q0E5QmYsS0FBS1YsUUE4QlU7O0FBQUEsOENBN0JkLEtBQUtXLFNBNkJTOztBQUFBLCtDQTVCYixLQUFLQyxVQTRCUTs7QUFBQSw0Q0F2QmhCLEtBQUtMLEtBQUwsQ0FBV0Msb0JBQVgsQ0FBZ0NQLGNBQWhDLEVBQWdELElBQWhELEVBQXNEO0FBQ3JFUSxNQUFBQSxHQUFHLEVBQUUsZ0JBRGdFO0FBRXJFQyxNQUFBQSxRQUFRLEVBQUU7QUFGMkQsS0FBdEQsQ0F1QmdCOztBQUFBLDZDQW5CZixLQUFLSCxLQUFMLENBQVdDLG9CQUFYLENBQWdDUCxjQUFoQyxFQUFnRCxJQUFoRCxFQUFzRDtBQUN0RVEsTUFBQUEsR0FBRyxFQUFFLGdCQURpRTtBQUV0RUMsTUFBQUEsUUFBUSxFQUFFO0FBRjRELEtBQXRELENBbUJlOztBQUFBLDhDQWZiLEtBQUtILEtBQUwsQ0FBV0Msb0JBQVgsQ0FBZ0NQLGNBQWhDLEVBQWdELElBQWhELEVBQXNEO0FBQ3hFUSxNQUFBQSxHQUFHLEVBQUUsZ0JBRG1FO0FBRXhFQyxNQUFBQSxRQUFRLEVBQUU7QUFGOEQsS0FBdEQsQ0FlYTs7QUFBQSxxQ0FQR1IsT0FPSDs7QUFBQSxzQ0FMc0IsRUFLdEI7O0FBQy9CLFNBQUtXLEtBQUwsR0FBYVAsSUFBYjtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUExSEE7QUFBQTtBQUFBLGlDQTJIZTtBQUFBOztBQUNYLFdBQUtRLFFBQUwsR0FBZ0IsRUFBaEI7QUFDQSxXQUFLUCxLQUFMLENBQVdRLEtBQVg7QUFDQSxXQUFLUixLQUFMLENBQVdTLEdBQVgsQ0FBZSxnQkFBZixFQUFpQ0Msa0JBQWpDLENBQW9ELE9BQXBEO0FBQ0EsV0FBS1YsS0FBTCxDQUFXUyxHQUFYLENBQWUsZ0JBQWYsRUFBaUNFLEVBQWpDLENBQW9DLE9BQXBDLEVBQTZDLFVBQUNDLEdBQUQsRUFBUztBQUNwRCxZQUFJQSxHQUFHLENBQUNDLE1BQVIsRUFBZ0I7QUFBQSxxREFDZUQsR0FBRyxDQUFDQyxNQUFKLENBQVdOLFFBRDFCO0FBQUE7O0FBQUE7QUFDZCxnRUFBa0Q7QUFBQSxrQkFBL0JWLElBQStCLGVBQXJDaUIsSUFBcUM7O0FBQ2hELGNBQUEsS0FBSSxDQUFDbkIsT0FBTCxDQUFhRSxJQUFiO0FBQ0Q7QUFIYTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSWY7QUFDRixPQU5EO0FBT0Q7QUFFRDtBQUNGO0FBQ0E7O0FBMUlBO0FBQUE7QUFBQSwrQkEySWE7QUFDVCxhQUFPLEtBQUtTLEtBQUwsQ0FBV1MsUUFBWCxLQUF3QixVQUEvQjtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQWpKQTtBQUFBO0FBQUEsOEJBa0pZQyxPQWxKWixFQWtKNkI7QUFDekIsYUFBTyxLQUFLVixLQUFMLENBQVdXLFNBQVgsQ0FBcUJELE9BQXJCLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUF4SkE7QUFBQTtBQUFBLDRCQXlKdUJFLFFBekp2QixFQXlKc0RDLE9Bekp0RCxFQXlKd0U7QUFDcEUsYUFBTyxLQUFLYixLQUFMLENBQVdZLE9BQVgsQ0FBc0JBLFFBQXRCLEVBQStCQyxPQUEvQixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBL0pBO0FBQUE7QUFBQSxxQ0FnS21CQyxJQWhLbkIsRUFnS2lDO0FBQzdCLFVBQU1DLEdBQUcsR0FDUCxLQUFLTixRQUFMLEtBQ0Esa0NBREEsR0FFQU8sa0JBQWtCLENBQUNGLElBQUQsQ0FIcEI7QUFJQSxhQUFPLEtBQUtGLE9BQUwsQ0FBcUNHLEdBQXJDLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTs7QUExS0E7QUFBQTtBQUFBLHlDQTJLdUJFLEdBM0t2QixFQTJLa0Q7QUFDOUMsVUFBTUYsR0FBRyxHQUFHLEtBQUtOLFFBQUwsS0FBa0Isd0JBQTlCO0FBQ0EsYUFBTyxLQUFLVCxLQUFMLENBQVdrQixXQUFYLENBQXNDSCxHQUF0QyxFQUEyQ0UsR0FBM0MsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBOztBQWxMQTtBQUFBO0FBQUEsd0NBbUxzQkEsR0FuTHRCLEVBbUw0QztBQUN4QyxVQUFNRixHQUFHLEdBQUcsS0FBS04sUUFBTCxLQUFrQix1QkFBOUI7QUFDQSxhQUFPLEtBQUtULEtBQUwsQ0FBV2tCLFdBQVgsQ0FBOENILEdBQTlDLEVBQW1ERSxHQUFuRCxDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7O0FBMUxBO0FBQUE7QUFBQSxrQ0EyTHFEO0FBQUEsVUFBdkMxQixJQUF1Qyx1RUFBUixNQUFRO0FBQ2pELFVBQU13QixHQUFHLEdBQ1AsS0FBS04sUUFBTCxLQUFrQixvQkFBbEIsR0FBeUNPLGtCQUFrQixDQUFDekIsSUFBRCxDQUQ3RDtBQUVBLGFBQU8sS0FBS3FCLE9BQUwsQ0FBZ0M7QUFDckNPLFFBQUFBLE1BQU0sRUFBRSxLQUQ2QjtBQUVyQ0osUUFBQUEsR0FBRyxFQUFIQSxHQUZxQztBQUdyQ0ssUUFBQUEsT0FBTyxFQUFFO0FBQUVDLFVBQUFBLE1BQU0sRUFBRTtBQUFWO0FBSDRCLE9BQWhDLENBQVA7QUFLRDtBQW5NSDs7QUFBQTtBQUFBO0FBc01BOztBQUNBO0FBQ0E7QUFDQTs7QUFDQXpELGNBQWMsQ0FBQyxTQUFELEVBQVksVUFBQzZCLElBQUQ7QUFBQSxTQUFVLElBQUlELE9BQUosQ0FBWUMsSUFBWixDQUFWO0FBQUEsQ0FBWixDQUFkO0FBRUEsZUFBZUQsT0FBZiIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGZpbGUgTWFuYWdlcyBUb29saW5nIEFQSXNcbiAqIEBhdXRob3IgU2hpbmljaGkgVG9taXRhIDxzaGluaWNoaS50b21pdGFAZ21haWwuY29tPlxuICovXG5pbXBvcnQgeyByZWdpc3Rlck1vZHVsZSB9IGZyb20gJy4uL2pzZm9yY2UnO1xuaW1wb3J0IENvbm5lY3Rpb24gZnJvbSAnLi4vY29ubmVjdGlvbic7XG5pbXBvcnQgQ2FjaGUsIHsgQ2FjaGVkRnVuY3Rpb24gfSBmcm9tICcuLi9jYWNoZSc7XG5pbXBvcnQgU09iamVjdCBmcm9tICcuLi9zb2JqZWN0JztcbmltcG9ydCB7XG4gIERlc2NyaWJlR2xvYmFsUmVzdWx0LFxuICBEZXNjcmliZVNPYmplY3RSZXN1bHQsXG4gIEh0dHBSZXF1ZXN0LFxuICBTY2hlbWEsXG4gIFNPYmplY3ROYW1lcyxcbn0gZnJvbSAnLi4vdHlwZXMnO1xuXG4vKipcbiAqXG4gKi9cbmV4cG9ydCB0eXBlIEV4ZWN1dGVBbm9ueW1vdXNSZXN1bHQgPSB7XG4gIGNvbXBpbGVkOiBib29sZWFuO1xuICBjb21waWxlUHJvYmxlbTogc3RyaW5nIHwgbnVsbDtcbiAgc3VjY2VzczogYm9vbGVhbjtcbiAgbGluZTogbnVtYmVyO1xuICBjb2x1bW46IG51bWJlcjtcbiAgZXhjZXB0aW9uTWVzc2FnZTogc3RyaW5nIHwgbnVsbDtcbiAgZXhjZXB0aW9uU3RhY2tUcmFjZTogc3RyaW5nIHwgbnVsbDtcbn07XG5cbmV4cG9ydCB0eXBlIFJ1blRlc3RMZXZlbCA9XG4gIHwgJ1J1blNwZWNpZmllZFRlc3RzJ1xuICB8ICdSdW5Mb2NhbFRlc3RzJ1xuICB8ICdSdW5BbGxUZXN0c0luT3JnJztcblxudHlwZSBUZXN0c05vZGUgPVxuICB8IHtcbiAgICAgIGNsYXNzSWQ6IHN0cmluZztcbiAgICAgIHRlc3RNZXRob2RzPzogc3RyaW5nW107XG4gICAgfVxuICB8IHtcbiAgICAgIGNsYXNzTmFtZTogc3RyaW5nO1xuICAgICAgdGVzdE1ldGhvZHM/OiBzdHJpbmdbXTtcbiAgICB9O1xuXG5leHBvcnQgdHlwZSBSdW5UZXN0c1JlcXVlc3QgPSB7XG4gIHRlc3RzOiBUZXN0c05vZGVbXTtcbiAgbWF4RmFpbGVkVGVzdHM/OiBudW1iZXI7XG4gIHRlc3RMZXZlbD86IFJ1blRlc3RMZXZlbDtcbiAgc2tpcENvZGVDb3ZlcmFnZT86IGJvb2xlYW47XG59O1xuXG5leHBvcnQgdHlwZSBSdW5UZXN0c0FzeW5jUmVxdWVzdCA9XG4gIHwge1xuICAgICAgY2xhc3NpZHM/OiBzdHJpbmc7XG4gICAgICBjbGFzc05hbWVzPzogc3RyaW5nO1xuICAgICAgc3VpdGVpZHM/OiBzdHJpbmc7XG4gICAgICBzdWl0ZU5hbWVzPzogc3RyaW5nO1xuICAgICAgbWF4RmFpbGVkVGVzdHM/OiBudW1iZXI7XG4gICAgICB0ZXN0TGV2ZWw/OiBSdW5UZXN0TGV2ZWw7XG4gICAgICBza2lwQ29kZUNvdmVyYWdlPzogYm9vbGVhbjtcbiAgICB9XG4gIHwge1xuICAgICAgdGVzdHM6IFRlc3RzTm9kZVtdO1xuICAgICAgbWF4RmFpbGVkVGVzdHM/OiBudW1iZXI7XG4gICAgICB0ZXN0TGV2ZWw/OiBSdW5UZXN0TGV2ZWw7XG4gICAgICBza2lwQ29kZUNvdmVyYWdlPzogYm9vbGVhbjtcbiAgICB9O1xuXG50eXBlIENvZGVDb3ZlcmFnZVJlc3VsdCA9IHtcbiAgaWQ6IHN0cmluZztcbiAgbG9jYXRpb25zTm90Q292ZXJlZDogYW55W107XG4gIG5hbWU6IHN0cmluZztcbiAgbmFtZXNwYWNlOiBzdHJpbmcgfCBudWxsO1xuICBudW1Mb2NhdGlvbnM6IG51bWJlcjtcbiAgbnVtTG9jYXRpb25zTm90Q292ZXJlZDogbnVtYmVyO1xuICB0eXBlOiBzdHJpbmc7XG59O1xuXG50eXBlIENvZGVDb3ZlcmFnZVdhcm5pbmcgPSB7XG4gIGlkOiBzdHJpbmc7XG4gIG1lc3NhZ2U6IHN0cmluZztcbiAgbmFtZTogc3RyaW5nIHwgbnVsbDtcbiAgbmFtZXNwYWNlOiBzdHJpbmcgfCBudWxsO1xufTtcblxudHlwZSBGbG93Q292ZXJhZ2VSZXN1bHQgPSB7XG4gIGVsZW1lbnRzTm90Q292ZXJlZDogc3RyaW5nW107XG4gIGZsb3dJZDogc3RyaW5nO1xuICBmbG93TmFtZTogc3RyaW5nO1xuICBmbG93TmFtZXNwYWNlOiBzdHJpbmcgfCBudWxsO1xuICBudW1FbGVtZW50czogbnVtYmVyO1xuICBudW1FbGVtZW50c05vdENvdmVyZWQ6IG51bWJlcjtcbiAgcHJvY2Vzc1R5cGU6IHN0cmluZztcbn07XG5cbnR5cGUgRmxvd0NvdmVyYWdlV2FybmluZyA9IHtcbiAgZmxvd0lkOiBzdHJpbmc7XG4gIGZsb3dOYW1lOiBzdHJpbmc7XG4gIGZsb3dOYW1lc3BhY2U6IHN0cmluZyB8IG51bGw7XG4gIG1lc3NhZ2U6IHN0cmluZztcbn07XG5cbnR5cGUgUnVuVGVzdFN1Y2Nlc3MgPSB7XG4gIGlkOiBzdHJpbmc7XG4gIG1ldGhvZE5hbWU6IHN0cmluZztcbiAgbmFtZTogc3RyaW5nO1xuICBuYW1lc3BhY2U6IHN0cmluZyB8IG51bGw7XG4gIHNlZUFsbERhdGE6IGJvb2xlYW47XG4gIHRpbWU6IG51bWJlcjtcbn07XG5cbnR5cGUgUnVuVGVzdEZhaWx1cmUgPSB7XG4gIGlkOiBzdHJpbmc7XG4gIG1lc3NhZ2U6IHN0cmluZztcbiAgbWV0aG9kTmFtZTogc3RyaW5nO1xuICBuYW1lOiBzdHJpbmc7XG4gIG5hbWVzcGFjZTogc3RyaW5nIHwgbnVsbDtcbiAgc2VlQWxsRGF0YTogYm9vbGVhbjtcbiAgc3RhY2tUcmFjZTogc3RyaW5nO1xuICB0aW1lOiBudW1iZXI7XG4gIHR5cGU6IHN0cmluZztcbn07XG5cbmV4cG9ydCB0eXBlIFJ1blRlc3RzUmVzdWx0ID0ge1xuICBhcGV4TG9nSWQ6IHN0cmluZztcbiAgY29kZUNvdmVyYWdlOiBDb2RlQ292ZXJhZ2VSZXN1bHRbXTtcbiAgY29kZUNvdmVyYWdlV2FybmluZ3M6IENvZGVDb3ZlcmFnZVdhcm5pbmdbXTtcbiAgZmxvd0NvdmVyYWdlOiBGbG93Q292ZXJhZ2VSZXN1bHRbXTtcbiAgZmxvd0NvdmVyYWdlV2FybmluZ3M6IEZsb3dDb3ZlcmFnZVdhcm5pbmdbXTtcbiAgbnVtRmFpbHVyZXM6IG51bWJlcjtcbiAgbnVtVGVzdHNSdW46IG51bWJlcjtcbiAgc3VjY2Vzc2VzOiBSdW5UZXN0U3VjY2Vzc1tdO1xuICBmYWlsdXJlczogUnVuVGVzdEZhaWx1cmVbXTtcbiAgdG90YWxUaW1lOiBudW1iZXI7XG59O1xuXG50eXBlIENvbnN0cnVjdG9yRGVjbGFyYXRpb24gPSB7XG4gIG1ldGhvZERvYzogc3RyaW5nIHwgbnVsbDtcbiAgbmFtZTogc3RyaW5nO1xuICBwYXJhbWV0ZXJzOiBBcnJheTx7XG4gICAgbmFtZTogc3RyaW5nO1xuICAgIHR5cGU6IHN0cmluZztcbiAgfT47XG4gIHJlZmVyZW5jZXM6IGFueVtdO1xufTtcblxudHlwZSBNZXRob2REZWNsYXJhdGlvbiA9IHtcbiAgYXJnVHlwZXM6IHN0cmluZ1tdO1xuICBpc1N0YXRpYzogYm9vbGVhbjtcbiAgbWV0aG9kRG9jOiBzdHJpbmcgfCBudWxsO1xuICBuYW1lOiBzdHJpbmc7XG4gIHBhcmFtZXRlcnM6IEFycmF5PHtcbiAgICBuYW1lOiBzdHJpbmc7XG4gICAgdHlwZTogc3RyaW5nO1xuICB9PjtcbiAgcmVmZXJlbmNlczogYW55W107XG59O1xuXG50eXBlIFByb3BlcnR5RGVjbGFyYXRpb24gPSB7XG4gIG5hbWU6IHN0cmluZztcbiAgcmVmZXJlbmNlczogYW55W107XG59O1xuXG50eXBlIENsYXNzRGVjbGFyYXRpb24gPSB7XG4gIGNvbnN0cnVjdG9yczogQ29uc3RydWN0b3JEZWNsYXJhdGlvbltdO1xuICBtZXRob2RzOiBNZXRob2REZWNsYXJhdGlvbltdO1xuICBwcm9wZXJ0aWVzOiBQcm9wZXJ0eURlY2xhcmF0aW9uW107XG59O1xuXG5leHBvcnQgdHlwZSBDb21wbGV0aW9uc1Jlc3VsdCA9IHtcbiAgcHVibGljRGVjbGFyYXRpb25zPzoge1xuICAgIFtuYW1lc3BhY2U6IHN0cmluZ106IHtcbiAgICAgIFtuYW1lOiBzdHJpbmddOiBDbGFzc0RlY2xhcmF0aW9uO1xuICAgIH07XG4gIH07XG59O1xuXG4vKipcbiAqXG4gKi9cbmNvbnN0IHtcbiAgcXVlcnksXG4gIHF1ZXJ5TW9yZSxcbiAgY3JlYXRlLFxuICBfY3JlYXRlU2luZ2xlLFxuICBfY3JlYXRlTWFueSxcbiAgX2NyZWF0ZVBhcmFsbGVsLFxuICByZXRyaWV2ZSxcbiAgX3JldHJpZXZlU2luZ2xlLFxuICBfcmV0cmlldmVQYXJhbGxlbCxcbiAgX3JldHJpZXZlTWFueSxcbiAgdXBkYXRlLFxuICBfdXBkYXRlU2luZ2xlLFxuICBfdXBkYXRlUGFyYWxsZWwsXG4gIF91cGRhdGVNYW55LFxuICB1cHNlcnQsXG4gIGRlc3Ryb3ksXG4gIF9kZXN0cm95U2luZ2xlLFxuICBfZGVzdHJveVBhcmFsbGVsLFxuICBfZGVzdHJveU1hbnksXG4gIGRlc2NyaWJlLFxuICBkZXNjcmliZUdsb2JhbCxcbiAgc29iamVjdCxcbn0gPSBDb25uZWN0aW9uLnByb3RvdHlwZTtcblxuY29uc3QgZGVzY3JpYmVDYWNoZUtleSA9ICh0eXBlPzogc3RyaW5nKSA9PlxuICB0eXBlID8gYGRlc2NyaWJlLiR7dHlwZX1gIDogJ2Rlc2NyaWJlJztcblxuLyoqXG4gKiBBUEkgY2xhc3MgZm9yIFRvb2xpbmcgQVBJIGNhbGxcbiAqL1xuZXhwb3J0IGNsYXNzIFRvb2xpbmc8UyBleHRlbmRzIFNjaGVtYT4ge1xuICBfY29ubjogQ29ubmVjdGlvbjxTPjtcblxuICAvKipcbiAgICogRXhlY3V0ZSBxdWVyeSBieSB1c2luZyBTT1FMXG4gICAqL1xuICBxdWVyeTogQ29ubmVjdGlvbjxTPlsncXVlcnknXSA9IHF1ZXJ5O1xuXG4gIC8qKlxuICAgKiBRdWVyeSBuZXh0IHJlY29yZCBzZXQgYnkgdXNpbmcgcXVlcnkgbG9jYXRvclxuICAgKi9cbiAgcXVlcnlNb3JlOiBDb25uZWN0aW9uPFM+WydxdWVyeU1vcmUnXSA9IHF1ZXJ5TW9yZTtcblxuICAvKipcbiAgICogQ3JlYXRlIHJlY29yZHNcbiAgICovXG4gIGNyZWF0ZTogQ29ubmVjdGlvbjxTPlsnY3JlYXRlJ10gPSBjcmVhdGU7XG4gIF9jcmVhdGVTaW5nbGUgPSBfY3JlYXRlU2luZ2xlO1xuICBfY3JlYXRlUGFyYWxsZWwgPSBfY3JlYXRlUGFyYWxsZWw7XG4gIF9jcmVhdGVNYW55ID0gX2NyZWF0ZU1hbnk7XG5cbiAgLyoqXG4gICAqIFN5bm9ueW0gb2YgVG9vbGluZyNjcmVhdGUoKVxuICAgKi9cbiAgaW5zZXJ0ID0gY3JlYXRlO1xuXG4gIC8qKlxuICAgKiBSZXRyaWV2ZSBzcGVjaWZpZWQgcmVjb3Jkc1xuICAgKi9cbiAgcmV0cmlldmU6IENvbm5lY3Rpb248Uz5bJ3JldHJpZXZlJ10gPSByZXRyaWV2ZTtcbiAgX3JldHJpZXZlU2luZ2xlID0gX3JldHJpZXZlU2luZ2xlO1xuICBfcmV0cmlldmVQYXJhbGxlbCA9IF9yZXRyaWV2ZVBhcmFsbGVsO1xuICBfcmV0cmlldmVNYW55ID0gX3JldHJpZXZlTWFueTtcblxuICAvKipcbiAgICogVXBkYXRlIHJlY29yZHNcbiAgICovXG4gIHVwZGF0ZTogQ29ubmVjdGlvbjxTPlsndXBkYXRlJ10gPSB1cGRhdGU7XG4gIF91cGRhdGVTaW5nbGUgPSBfdXBkYXRlU2luZ2xlO1xuICBfdXBkYXRlUGFyYWxsZWwgPSBfdXBkYXRlUGFyYWxsZWw7XG4gIF91cGRhdGVNYW55ID0gX3VwZGF0ZU1hbnk7XG5cbiAgLyoqXG4gICAqIFVwc2VydCByZWNvcmRzXG4gICAqL1xuICB1cHNlcnQ6IENvbm5lY3Rpb248Uz5bJ3Vwc2VydCddID0gdXBzZXJ0O1xuXG4gIC8qKlxuICAgKiBEZWxldGUgcmVjb3Jkc1xuICAgKi9cbiAgZGVzdHJveTogQ29ubmVjdGlvbjxTPlsnZGVzdHJveSddID0gZGVzdHJveTtcbiAgX2Rlc3Ryb3lTaW5nbGUgPSBfZGVzdHJveVNpbmdsZTtcbiAgX2Rlc3Ryb3lQYXJhbGxlbCA9IF9kZXN0cm95UGFyYWxsZWw7XG4gIF9kZXN0cm95TWFueSA9IF9kZXN0cm95TWFueTtcblxuICAvKipcbiAgICogU3lub255bSBvZiBUb29saW5nI2Rlc3Ryb3koKVxuICAgKi9cbiAgZGVsZXRlID0gZGVzdHJveTtcblxuICAvKipcbiAgICogU3lub255bSBvZiBUb29saW5nI2Rlc3Ryb3koKVxuICAgKi9cbiAgZGVsID0gZGVzdHJveTtcblxuICBjYWNoZSA9IG5ldyBDYWNoZSgpO1xuXG4gIC8qKlxuICAgKiBEZXNjcmliZSBTT2JqZWN0IG1ldGFkYXRhXG4gICAqL1xuICBkZXNjcmliZSA9IHRoaXMuY2FjaGUuY3JlYXRlQ2FjaGVkRnVuY3Rpb24oZGVzY3JpYmUsIHRoaXMsIHtcbiAgICBrZXk6IGRlc2NyaWJlQ2FjaGVLZXksXG4gICAgc3RyYXRlZ3k6ICdOT0NBQ0hFJyxcbiAgfSk7XG4gIGRlc2NyaWJlJCA9IHRoaXMuY2FjaGUuY3JlYXRlQ2FjaGVkRnVuY3Rpb24oZGVzY3JpYmUsIHRoaXMsIHtcbiAgICBrZXk6IGRlc2NyaWJlQ2FjaGVLZXksXG4gICAgc3RyYXRlZ3k6ICdISVQnLFxuICB9KTtcbiAgZGVzY3JpYmUkJCA9ICh0aGlzLmNhY2hlLmNyZWF0ZUNhY2hlZEZ1bmN0aW9uKGRlc2NyaWJlLCB0aGlzLCB7XG4gICAga2V5OiBkZXNjcmliZUNhY2hlS2V5LFxuICAgIHN0cmF0ZWd5OiAnSU1NRURJQVRFJyxcbiAgfSkgYXMgdW5rbm93bikgYXMgQ2FjaGVkRnVuY3Rpb248KG5hbWU6IHN0cmluZykgPT4gRGVzY3JpYmVTT2JqZWN0UmVzdWx0PjtcblxuICAvKipcbiAgICogU3lub255bSBvZiBUb29saW5nI2Rlc2NyaWJlKClcbiAgICovXG4gIGRlc2NyaWJlU09iamVjdCA9IHRoaXMuZGVzY3JpYmU7XG4gIGRlc2NyaWJlU09iamVjdCQgPSB0aGlzLmRlc2NyaWJlJDtcbiAgZGVzY3JpYmVTT2JqZWN0JCQgPSB0aGlzLmRlc2NyaWJlJCQ7XG5cbiAgLyoqXG4gICAqIERlc2NyaWJlIGdsb2JhbCBTT2JqZWN0c1xuICAgKi9cbiAgZGVzY3JpYmVHbG9iYWwgPSB0aGlzLmNhY2hlLmNyZWF0ZUNhY2hlZEZ1bmN0aW9uKGRlc2NyaWJlR2xvYmFsLCB0aGlzLCB7XG4gICAga2V5OiAnZGVzY3JpYmVHbG9iYWwnLFxuICAgIHN0cmF0ZWd5OiAnTk9DQUNIRScsXG4gIH0pO1xuICBkZXNjcmliZUdsb2JhbCQgPSB0aGlzLmNhY2hlLmNyZWF0ZUNhY2hlZEZ1bmN0aW9uKGRlc2NyaWJlR2xvYmFsLCB0aGlzLCB7XG4gICAga2V5OiAnZGVzY3JpYmVHbG9iYWwnLFxuICAgIHN0cmF0ZWd5OiAnSElUJyxcbiAgfSk7XG4gIGRlc2NyaWJlR2xvYmFsJCQgPSAodGhpcy5jYWNoZS5jcmVhdGVDYWNoZWRGdW5jdGlvbihkZXNjcmliZUdsb2JhbCwgdGhpcywge1xuICAgIGtleTogJ2Rlc2NyaWJlR2xvYmFsJyxcbiAgICBzdHJhdGVneTogJ0lNTUVESUFURScsXG4gIH0pIGFzIHVua25vd24pIGFzIENhY2hlZEZ1bmN0aW9uPChuYW1lOiBzdHJpbmcpID0+IERlc2NyaWJlR2xvYmFsUmVzdWx0PjtcblxuICAvKipcbiAgICogR2V0IFNPYmplY3QgaW5zdGFuY2VcbiAgICovXG4gIHNvYmplY3Q6IENvbm5lY3Rpb248Uz5bJ3NvYmplY3QnXSA9IHNvYmplY3Q7XG5cbiAgc29iamVjdHM6IHsgW04gaW4gU09iamVjdE5hbWVzPFM+XT86IFNPYmplY3Q8UywgTj4gfSA9IHt9O1xuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgY29uc3RydWN0b3IoY29ubjogQ29ubmVjdGlvbjxTPikge1xuICAgIHRoaXMuX2Nvbm4gPSBjb25uO1xuICB9XG5cbiAgLyoqXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfZXN0YWJsaXNoKCkge1xuICAgIHRoaXMuc29iamVjdHMgPSB7fTtcbiAgICB0aGlzLmNhY2hlLmNsZWFyKCk7XG4gICAgdGhpcy5jYWNoZS5nZXQoJ2Rlc2NyaWJlR2xvYmFsJykucmVtb3ZlQWxsTGlzdGVuZXJzKCd2YWx1ZScpO1xuICAgIHRoaXMuY2FjaGUuZ2V0KCdkZXNjcmliZUdsb2JhbCcpLm9uKCd2YWx1ZScsIChyZXMpID0+IHtcbiAgICAgIGlmIChyZXMucmVzdWx0KSB7XG4gICAgICAgIGZvciAoY29uc3QgeyBuYW1lOiB0eXBlIH0gb2YgcmVzLnJlc3VsdC5zb2JqZWN0cykge1xuICAgICAgICAgIHRoaXMuc29iamVjdCh0eXBlKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfYmFzZVVybCgpIHtcbiAgICByZXR1cm4gdGhpcy5fY29ubi5fYmFzZVVybCgpICsgJy90b29saW5nJztcbiAgfVxuXG4gIC8qKlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX3N1cHBvcnRzKGZlYXR1cmU6IHN0cmluZykge1xuICAgIHJldHVybiB0aGlzLl9jb25uLl9zdXBwb3J0cyhmZWF0dXJlKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgcmVxdWVzdDxSID0gdW5rbm93bj4ocmVxdWVzdDogc3RyaW5nIHwgSHR0cFJlcXVlc3QsIG9wdGlvbnM/OiBPYmplY3QpIHtcbiAgICByZXR1cm4gdGhpcy5fY29ubi5yZXF1ZXN0PFI+KHJlcXVlc3QsIG9wdGlvbnMpO1xuICB9XG5cbiAgLyoqXG4gICAqIEV4ZWN1dGVzIEFwZXggY29kZSBhbm9ueW1vdXNseVxuICAgKi9cbiAgZXhlY3V0ZUFub255bW91cyhib2R5OiBzdHJpbmcpIHtcbiAgICBjb25zdCB1cmwgPVxuICAgICAgdGhpcy5fYmFzZVVybCgpICtcbiAgICAgICcvZXhlY3V0ZUFub255bW91cz9hbm9ueW1vdXNCb2R5PScgK1xuICAgICAgZW5jb2RlVVJJQ29tcG9uZW50KGJvZHkpO1xuICAgIHJldHVybiB0aGlzLnJlcXVlc3Q8RXhlY3V0ZUFub255bW91c1Jlc3VsdD4odXJsKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBFeGVjdXRlcyBBcGV4IHRlc3RzIGFzeW5jaHJvbm91c2x5XG4gICAqL1xuICBydW5UZXN0c0FzeW5jaHJvbm91cyhyZXE6IFJ1blRlc3RzQXN5bmNSZXF1ZXN0KSB7XG4gICAgY29uc3QgdXJsID0gdGhpcy5fYmFzZVVybCgpICsgJy9ydW5UZXN0c0FzeW5jaHJvbm91cy8nO1xuICAgIHJldHVybiB0aGlzLl9jb25uLnJlcXVlc3RQb3N0PHN0cmluZyB8IG51bGw+KHVybCwgcmVxKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBFeGVjdXRlcyBBcGV4IHRlc3RzIHN5bmNocm9ub3VzbHlcbiAgICovXG4gIHJ1blRlc3RzU3luY2hyb25vdXMocmVxOiBSdW5UZXN0c1JlcXVlc3QpIHtcbiAgICBjb25zdCB1cmwgPSB0aGlzLl9iYXNlVXJsKCkgKyAnL3J1blRlc3RzU3luY2hyb25vdXMvJztcbiAgICByZXR1cm4gdGhpcy5fY29ubi5yZXF1ZXN0UG9zdDxSdW5UZXN0c1Jlc3VsdCB8IG51bGw+KHVybCwgcmVxKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXRyaWV2ZXMgYXZhaWxhYmxlIGNvZGUgY29tcGxldGlvbnMgb2YgdGhlIHJlZmVyZW5jZWQgdHlwZVxuICAgKi9cbiAgY29tcGxldGlvbnModHlwZTogJ2FwZXgnIHwgJ3Zpc3VhbGZvcmNlJyA9ICdhcGV4Jykge1xuICAgIGNvbnN0IHVybCA9XG4gICAgICB0aGlzLl9iYXNlVXJsKCkgKyAnL2NvbXBsZXRpb25zP3R5cGU9JyArIGVuY29kZVVSSUNvbXBvbmVudCh0eXBlKTtcbiAgICByZXR1cm4gdGhpcy5yZXF1ZXN0PENvbXBsZXRpb25zUmVzdWx0Pih7XG4gICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgdXJsLFxuICAgICAgaGVhZGVyczogeyBBY2NlcHQ6ICdhcHBsaWNhdGlvbi9qc29uJyB9LFxuICAgIH0pO1xuICB9XG59XG5cbi8qLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuLypcbiAqIFJlZ2lzdGVyIGhvb2sgaW4gY29ubmVjdGlvbiBpbnN0YW50aWF0aW9uIGZvciBkeW5hbWljYWxseSBhZGRpbmcgdGhpcyBBUEkgbW9kdWxlIGZlYXR1cmVzXG4gKi9cbnJlZ2lzdGVyTW9kdWxlKCd0b29saW5nJywgKGNvbm4pID0+IG5ldyBUb29saW5nKGNvbm4pKTtcblxuZXhwb3J0IGRlZmF1bHQgVG9vbGluZztcbiJdfQ==