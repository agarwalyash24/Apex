import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _assertThisInitialized from "@babel/runtime-corejs3/helpers/assertThisInitialized";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = _Reflect$construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !_Reflect$construct) return false; if (_Reflect$construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(_Reflect$construct(Date, [], function () {})); return true; } catch (e) { return false; } }

import { EventEmitter } from 'events';
import VERSION from './VERSION';
import Connection from './connection';
import OAuth2 from './oauth2';
import SfDate from './date';
import registry from './registry';
import client, { BrowserClient } from './browser/client';
import { JwtOAuth2 } from './jwtOAuth2';
/**
 *
 */

var JSforce = /*#__PURE__*/function (_EventEmitter) {
  _inherits(JSforce, _EventEmitter);

  var _super = _createSuper(JSforce);

  function JSforce() {
    var _context;

    var _this;

    _classCallCheck(this, JSforce);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _super.call.apply(_super, _concatInstanceProperty(_context = [this]).call(_context, args));

    _defineProperty(_assertThisInitialized(_this), "VERSION", VERSION);

    _defineProperty(_assertThisInitialized(_this), "Connection", Connection);

    _defineProperty(_assertThisInitialized(_this), "OAuth2", OAuth2);

    _defineProperty(_assertThisInitialized(_this), "JwtOAuth2", JwtOAuth2);

    _defineProperty(_assertThisInitialized(_this), "SfDate", SfDate);

    _defineProperty(_assertThisInitialized(_this), "Date", SfDate);

    _defineProperty(_assertThisInitialized(_this), "BrowserClient", BrowserClient);

    _defineProperty(_assertThisInitialized(_this), "registry", registry);

    _defineProperty(_assertThisInitialized(_this), "browser", client);

    return _this;
  }

  return JSforce;
}(EventEmitter);

export function registerModule(name, factory) {
  jsforce.on('connection:new', function (conn) {
    var obj = undefined;

    _Object$defineProperty(conn, name, {
      get: function get() {
        var _obj;

        obj = (_obj = obj) !== null && _obj !== void 0 ? _obj : factory(conn);
        return obj;
      },
      enumerable: true,
      configurable: true
    });
  });
}
var jsforce = new JSforce();
export default jsforce;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9qc2ZvcmNlLnRzIl0sIm5hbWVzIjpbIkV2ZW50RW1pdHRlciIsIlZFUlNJT04iLCJDb25uZWN0aW9uIiwiT0F1dGgyIiwiU2ZEYXRlIiwicmVnaXN0cnkiLCJjbGllbnQiLCJCcm93c2VyQ2xpZW50IiwiSnd0T0F1dGgyIiwiSlNmb3JjZSIsInJlZ2lzdGVyTW9kdWxlIiwibmFtZSIsImZhY3RvcnkiLCJqc2ZvcmNlIiwib24iLCJjb25uIiwib2JqIiwidW5kZWZpbmVkIiwiZ2V0IiwiZW51bWVyYWJsZSIsImNvbmZpZ3VyYWJsZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7QUFBQSxTQUFTQSxZQUFULFFBQTZCLFFBQTdCO0FBQ0EsT0FBT0MsT0FBUCxNQUFvQixXQUFwQjtBQUNBLE9BQU9DLFVBQVAsTUFBdUIsY0FBdkI7QUFDQSxPQUFPQyxNQUFQLE1BQW1CLFVBQW5CO0FBQ0EsT0FBT0MsTUFBUCxNQUFtQixRQUFuQjtBQUNBLE9BQU9DLFFBQVAsTUFBbUMsWUFBbkM7QUFDQSxPQUFPQyxNQUFQLElBQWlCQyxhQUFqQixRQUFzQyxrQkFBdEM7QUFDQSxTQUFTQyxTQUFULFFBQTBCLGFBQTFCO0FBRUE7QUFDQTtBQUNBOztJQUNNQyxPOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OERBQ3NCUixPOztpRUFDTUMsVTs7NkRBQ1JDLE07O2dFQUNNSyxTOzs2REFDTkosTTs7MkRBQ0ZBLE07O29FQUNnQkcsYTs7K0RBQ2pCRixROzs4REFDSUMsTTs7Ozs7O0VBVExOLFk7O0FBWXRCLE9BQU8sU0FBU1UsY0FBVCxDQUNMQyxJQURLLEVBRUxDLE9BRkssRUFHTDtBQUNBQyxFQUFBQSxPQUFPLENBQUNDLEVBQVIsQ0FBVyxnQkFBWCxFQUE2QixVQUFDQyxJQUFELEVBQXNCO0FBQ2pELFFBQUlDLEdBQVEsR0FBR0MsU0FBZjs7QUFDQSwyQkFBc0JGLElBQXRCLEVBQTRCSixJQUE1QixFQUFrQztBQUNoQ08sTUFBQUEsR0FEZ0MsaUJBQzFCO0FBQUE7O0FBQ0pGLFFBQUFBLEdBQUcsV0FBR0EsR0FBSCx1Q0FBVUosT0FBTyxDQUFDRyxJQUFELENBQXBCO0FBQ0EsZUFBT0MsR0FBUDtBQUNELE9BSitCO0FBS2hDRyxNQUFBQSxVQUFVLEVBQUUsSUFMb0I7QUFNaENDLE1BQUFBLFlBQVksRUFBRTtBQU5rQixLQUFsQztBQVFELEdBVkQ7QUFXRDtBQUVELElBQU1QLE9BQU8sR0FBRyxJQUFJSixPQUFKLEVBQWhCO0FBQ0EsZUFBZUksT0FBZiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEV2ZW50RW1pdHRlciB9IGZyb20gJ2V2ZW50cyc7XG5pbXBvcnQgVkVSU0lPTiBmcm9tICcuL1ZFUlNJT04nO1xuaW1wb3J0IENvbm5lY3Rpb24gZnJvbSAnLi9jb25uZWN0aW9uJztcbmltcG9ydCBPQXV0aDIgZnJvbSAnLi9vYXV0aDInO1xuaW1wb3J0IFNmRGF0ZSBmcm9tICcuL2RhdGUnO1xuaW1wb3J0IHJlZ2lzdHJ5LCB7IFJlZ2lzdHJ5IH0gZnJvbSAnLi9yZWdpc3RyeSc7XG5pbXBvcnQgY2xpZW50LCB7IEJyb3dzZXJDbGllbnQgfSBmcm9tICcuL2Jyb3dzZXIvY2xpZW50JztcbmltcG9ydCB7IEp3dE9BdXRoMiB9IGZyb20gJy4vand0T0F1dGgyJztcblxuLyoqXG4gKlxuICovXG5jbGFzcyBKU2ZvcmNlIGV4dGVuZHMgRXZlbnRFbWl0dGVyIHtcbiAgVkVSU0lPTjogdHlwZW9mIFZFUlNJT04gPSBWRVJTSU9OO1xuICBDb25uZWN0aW9uOiB0eXBlb2YgQ29ubmVjdGlvbiA9IENvbm5lY3Rpb247XG4gIE9BdXRoMjogdHlwZW9mIE9BdXRoMiA9IE9BdXRoMjtcbiAgSnd0T0F1dGgyOiB0eXBlb2YgSnd0T0F1dGgyID0gSnd0T0F1dGgyO1xuICBTZkRhdGU6IHR5cGVvZiBTZkRhdGUgPSBTZkRhdGU7XG4gIERhdGU6IHR5cGVvZiBTZkRhdGUgPSBTZkRhdGU7XG4gIEJyb3dzZXJDbGllbnQ6IHR5cGVvZiBCcm93c2VyQ2xpZW50ID0gQnJvd3NlckNsaWVudDtcbiAgcmVnaXN0cnk6IFJlZ2lzdHJ5ID0gcmVnaXN0cnk7XG4gIGJyb3dzZXI6IEJyb3dzZXJDbGllbnQgPSBjbGllbnQ7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiByZWdpc3Rlck1vZHVsZShcbiAgbmFtZTogc3RyaW5nLFxuICBmYWN0b3J5OiAoY29ubjogQ29ubmVjdGlvbikgPT4gYW55LFxuKSB7XG4gIGpzZm9yY2Uub24oJ2Nvbm5lY3Rpb246bmV3JywgKGNvbm46IENvbm5lY3Rpb24pID0+IHtcbiAgICBsZXQgb2JqOiBhbnkgPSB1bmRlZmluZWQ7XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGNvbm4sIG5hbWUsIHtcbiAgICAgIGdldCgpIHtcbiAgICAgICAgb2JqID0gb2JqID8/IGZhY3RvcnkoY29ubik7XG4gICAgICAgIHJldHVybiBvYmo7XG4gICAgICB9LFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICB9KTtcbiAgfSk7XG59XG5cbmNvbnN0IGpzZm9yY2UgPSBuZXcgSlNmb3JjZSgpO1xuZXhwb3J0IGRlZmF1bHQganNmb3JjZTtcbiJdfQ==