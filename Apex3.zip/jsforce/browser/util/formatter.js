import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";

/**
 *
 */
export function zeroPad(num) {
  var digits = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 2;
  var nstr = '';

  for (var d = digits - 1; d > 0; d--) {
    if (num >= Math.pow(10, d)) {
      break;
    }

    nstr += '0';
  }

  return nstr + String(num);
}
/**
 *
 */

export function formatDate(date) {
  var _context, _context2, _context3, _context4, _context5;

  return _concatInstanceProperty(_context = _concatInstanceProperty(_context2 = _concatInstanceProperty(_context3 = _concatInstanceProperty(_context4 = _concatInstanceProperty(_context5 = "".concat(date.getUTCFullYear(), "-")).call(_context5, zeroPad(date.getUTCMonth() + 1), "-")).call(_context4, zeroPad(date.getUTCDate()), "T")).call(_context3, zeroPad(date.getUTCHours()), ":")).call(_context2, zeroPad(date.getUTCMinutes()), ":")).call(_context, zeroPad(date.getUTCSeconds()), "+00:00");
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy91dGlsL2Zvcm1hdHRlci50cyJdLCJuYW1lcyI6WyJ6ZXJvUGFkIiwibnVtIiwiZGlnaXRzIiwibnN0ciIsImQiLCJTdHJpbmciLCJmb3JtYXREYXRlIiwiZGF0ZSIsImdldFVUQ0Z1bGxZZWFyIiwiZ2V0VVRDTW9udGgiLCJnZXRVVENEYXRlIiwiZ2V0VVRDSG91cnMiLCJnZXRVVENNaW51dGVzIiwiZ2V0VVRDU2Vjb25kcyJdLCJtYXBwaW5ncyI6Ijs7QUFBQTtBQUNBO0FBQ0E7QUFDQSxPQUFPLFNBQVNBLE9BQVQsQ0FBaUJDLEdBQWpCLEVBQTBEO0FBQUEsTUFBNUJDLE1BQTRCLHVFQUFYLENBQVc7QUFDL0QsTUFBSUMsSUFBSSxHQUFHLEVBQVg7O0FBQ0EsT0FBSyxJQUFJQyxDQUFDLEdBQUdGLE1BQU0sR0FBRyxDQUF0QixFQUF5QkUsQ0FBQyxHQUFHLENBQTdCLEVBQWdDQSxDQUFDLEVBQWpDLEVBQXFDO0FBQ25DLFFBQUlILEdBQUcsYUFBSSxFQUFKLEVBQVVHLENBQVYsQ0FBUCxFQUFvQjtBQUNsQjtBQUNEOztBQUNERCxJQUFBQSxJQUFJLElBQUksR0FBUjtBQUNEOztBQUNELFNBQU9BLElBQUksR0FBR0UsTUFBTSxDQUFDSixHQUFELENBQXBCO0FBQ0Q7QUFFRDtBQUNBO0FBQ0E7O0FBQ0EsT0FBTyxTQUFTSyxVQUFULENBQW9CQyxJQUFwQixFQUFnQztBQUFBOztBQUNyQyxzTUFBVUEsSUFBSSxDQUFDQyxjQUFMLEVBQVYsd0JBQW1DUixPQUFPLENBQUNPLElBQUksQ0FBQ0UsV0FBTCxLQUFxQixDQUF0QixDQUExQyx3QkFBc0VULE9BQU8sQ0FDM0VPLElBQUksQ0FBQ0csVUFBTCxFQUQyRSxDQUE3RSx3QkFFS1YsT0FBTyxDQUFDTyxJQUFJLENBQUNJLFdBQUwsRUFBRCxDQUZaLHdCQUVvQ1gsT0FBTyxDQUFDTyxJQUFJLENBQUNLLGFBQUwsRUFBRCxDQUYzQyx1QkFFcUVaLE9BQU8sQ0FDMUVPLElBQUksQ0FBQ00sYUFBTCxFQUQwRSxDQUY1RTtBQUtEIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKlxuICovXG5leHBvcnQgZnVuY3Rpb24gemVyb1BhZChudW06IG51bWJlciwgZGlnaXRzOiBudW1iZXIgPSAyKTogc3RyaW5nIHtcbiAgbGV0IG5zdHIgPSAnJztcbiAgZm9yIChsZXQgZCA9IGRpZ2l0cyAtIDE7IGQgPiAwOyBkLS0pIHtcbiAgICBpZiAobnVtID49IDEwICoqIGQpIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBuc3RyICs9ICcwJztcbiAgfVxuICByZXR1cm4gbnN0ciArIFN0cmluZyhudW0pO1xufVxuXG4vKipcbiAqXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXREYXRlKGRhdGU6IERhdGUpIHtcbiAgcmV0dXJuIGAke2RhdGUuZ2V0VVRDRnVsbFllYXIoKX0tJHt6ZXJvUGFkKGRhdGUuZ2V0VVRDTW9udGgoKSArIDEpfS0ke3plcm9QYWQoXG4gICAgZGF0ZS5nZXRVVENEYXRlKCksXG4gICl9VCR7emVyb1BhZChkYXRlLmdldFVUQ0hvdXJzKCkpfToke3plcm9QYWQoZGF0ZS5nZXRVVENNaW51dGVzKCkpfToke3plcm9QYWQoXG4gICAgZGF0ZS5nZXRVVENTZWNvbmRzKCksXG4gICl9KzAwOjAwYDtcbn1cbiJdfQ==