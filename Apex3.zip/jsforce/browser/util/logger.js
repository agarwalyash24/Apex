import _toConsumableArray from "@babel/runtime-corejs3/helpers/toConsumableArray";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

/**
 *
 */
export var LogLevels = {
  DEBUG: 1,
  INFO: 2,
  WARN: 3,
  ERROR: 4,
  FATAL: 5,
  NONE: 6
};
var LogLevelLabels = ['', 'DEBUG', 'INFO', 'WARN', 'ERROR', 'FATAL', 'NONE'];

var globalLogLevelConfig = function () {
  var globalLogLevelStr = process.env.JSFORCE_LOG_LEVEL || global.__JSFORCE_LOG_LEVEL__ || 'NONE';

  if (/^(DEBUG|INFO|WARN|ERROR|FATAL|NONE)$/i.test(globalLogLevelStr)) {
    return {
      '*': globalLogLevelStr
    };
  }

  try {
    return JSON.parse(globalLogLevelStr);
  } catch (e) {
    return {
      '*': 'NONE'
    };
  }
}();

function getModuleLogLevel(logLevelConfig, moduleName) {
  var logLevel = logLevelConfig[moduleName] || logLevelConfig['*'];
  return typeof logLevel === 'number' ? logLevel : LogLevels[logLevel] || LogLevels.NONE;
}
/**
 *
 */


export var Logger = /*#__PURE__*/function () {
  function Logger(moduleName) {
    var logLevelConfig = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : globalLogLevelConfig;

    _classCallCheck(this, Logger);

    _defineProperty(this, "_moduleName", void 0);

    _defineProperty(this, "_logLevel", void 0);

    this._moduleName = moduleName;
    this._logLevel = typeof logLevelConfig === 'number' ? logLevelConfig : typeof logLevelConfig === 'string' ? LogLevels[logLevelConfig] || LogLevels.NONE : getModuleLogLevel(logLevelConfig, moduleName);
  }

  _createClass(Logger, [{
    key: "createInstance",
    value: function createInstance() {
      var logLevelConfig = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this._logLevel;
      return new Logger(this._moduleName, logLevelConfig);
    }
  }, {
    key: "setLogLevel",
    value: function setLogLevel(logLevel) {
      if (typeof logLevel === 'string') {
        this._logLevel = LogLevels[logLevel] || LogLevels.NONE;
      } else {
        this._logLevel = logLevel;
      }
    }
  }, {
    key: "log",
    value: function log(logLevel) {
      if (this._logLevel <= logLevel) {
        var _context, _context2;

        for (var _len = arguments.length, messages = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
          messages[_key - 1] = arguments[_key];
        }

        var msgs = _concatInstanceProperty(_context = [_concatInstanceProperty(_context2 = "".concat(LogLevelLabels[logLevel], "\t[")).call(_context2, this._moduleName, "] ")]).call(_context, messages);

        if (logLevel < LogLevels.ERROR) {
          var _console;

          (_console = console).log.apply(_console, _toConsumableArray(msgs)); // eslint-disable-line no-console

        } else {
          var _console2;

          (_console2 = console).error.apply(_console2, _toConsumableArray(msgs)); // eslint-disable-line no-console

        }
      }
    }
  }, {
    key: "debug",
    value: function debug() {
      var _context3;

      for (var _len2 = arguments.length, messages = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        messages[_key2] = arguments[_key2];
      }

      this.log.apply(this, _concatInstanceProperty(_context3 = [LogLevels.DEBUG]).call(_context3, messages));
    }
  }, {
    key: "info",
    value: function info() {
      var _context4;

      for (var _len3 = arguments.length, messages = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
        messages[_key3] = arguments[_key3];
      }

      this.log.apply(this, _concatInstanceProperty(_context4 = [LogLevels.INFO]).call(_context4, messages));
    }
  }, {
    key: "warn",
    value: function warn() {
      var _context5;

      for (var _len4 = arguments.length, messages = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
        messages[_key4] = arguments[_key4];
      }

      this.log.apply(this, _concatInstanceProperty(_context5 = [LogLevels.WARN]).call(_context5, messages));
    }
  }, {
    key: "error",
    value: function error() {
      var _context6;

      for (var _len5 = arguments.length, messages = new Array(_len5), _key5 = 0; _key5 < _len5; _key5++) {
        messages[_key5] = arguments[_key5];
      }

      this.log.apply(this, _concatInstanceProperty(_context6 = [LogLevels.ERROR]).call(_context6, messages));
    }
  }, {
    key: "fatal",
    value: function fatal() {
      var _context7;

      for (var _len6 = arguments.length, messages = new Array(_len6), _key6 = 0; _key6 < _len6; _key6++) {
        messages[_key6] = arguments[_key6];
      }

      this.log.apply(this, _concatInstanceProperty(_context7 = [LogLevels.FATAL]).call(_context7, messages));
    }
  }]);

  return Logger;
}();
var loggers = {};
/**
 *
 */

export function getLogger(moduleName) {
  var logger = loggers[moduleName] || new Logger(moduleName);
  loggers[moduleName] = logger;
  return logger;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy91dGlsL2xvZ2dlci50cyJdLCJuYW1lcyI6WyJMb2dMZXZlbHMiLCJERUJVRyIsIklORk8iLCJXQVJOIiwiRVJST1IiLCJGQVRBTCIsIk5PTkUiLCJMb2dMZXZlbExhYmVscyIsImdsb2JhbExvZ0xldmVsQ29uZmlnIiwiZ2xvYmFsTG9nTGV2ZWxTdHIiLCJwcm9jZXNzIiwiZW52IiwiSlNGT1JDRV9MT0dfTEVWRUwiLCJnbG9iYWwiLCJfX0pTRk9SQ0VfTE9HX0xFVkVMX18iLCJ0ZXN0IiwiSlNPTiIsInBhcnNlIiwiZSIsImdldE1vZHVsZUxvZ0xldmVsIiwibG9nTGV2ZWxDb25maWciLCJtb2R1bGVOYW1lIiwibG9nTGV2ZWwiLCJMb2dnZXIiLCJfbW9kdWxlTmFtZSIsIl9sb2dMZXZlbCIsIm1lc3NhZ2VzIiwibXNncyIsImNvbnNvbGUiLCJsb2ciLCJlcnJvciIsImxvZ2dlcnMiLCJnZXRMb2dnZXIiLCJsb2dnZXIiXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBLE9BQU8sSUFBTUEsU0FBc0MsR0FBRztBQUNwREMsRUFBQUEsS0FBSyxFQUFFLENBRDZDO0FBRXBEQyxFQUFBQSxJQUFJLEVBQUUsQ0FGOEM7QUFHcERDLEVBQUFBLElBQUksRUFBRSxDQUg4QztBQUlwREMsRUFBQUEsS0FBSyxFQUFFLENBSjZDO0FBS3BEQyxFQUFBQSxLQUFLLEVBQUUsQ0FMNkM7QUFNcERDLEVBQUFBLElBQUksRUFBRTtBQU44QyxDQUEvQztBQVNQLElBQU1DLGNBQWMsR0FBRyxDQUFDLEVBQUQsRUFBSyxPQUFMLEVBQWMsTUFBZCxFQUFzQixNQUF0QixFQUE4QixPQUE5QixFQUF1QyxPQUF2QyxFQUFnRCxNQUFoRCxDQUF2Qjs7QUFFQSxJQUFNQyxvQkFBb0IsR0FBSSxZQUFNO0FBQ2xDLE1BQU1DLGlCQUFpQixHQUNyQkMsT0FBTyxDQUFDQyxHQUFSLENBQVlDLGlCQUFaLElBQ0NDLE1BQUQsQ0FBZ0JDLHFCQURoQixJQUVBLE1BSEY7O0FBSUEsTUFBSSx3Q0FBd0NDLElBQXhDLENBQTZDTixpQkFBN0MsQ0FBSixFQUFxRTtBQUNuRSxXQUFPO0FBQUUsV0FBS0E7QUFBUCxLQUFQO0FBQ0Q7O0FBQ0QsTUFBSTtBQUNGLFdBQU9PLElBQUksQ0FBQ0MsS0FBTCxDQUFXUixpQkFBWCxDQUFQO0FBQ0QsR0FGRCxDQUVFLE9BQU9TLENBQVAsRUFBVTtBQUNWLFdBQU87QUFBRSxXQUFLO0FBQVAsS0FBUDtBQUNEO0FBQ0YsQ0FiNEIsRUFBN0I7O0FBb0JBLFNBQVNDLGlCQUFULENBQ0VDLGNBREYsRUFFRUMsVUFGRixFQUdFO0FBQ0EsTUFBTUMsUUFBUSxHQUFHRixjQUFjLENBQUNDLFVBQUQsQ0FBZCxJQUE4QkQsY0FBYyxDQUFDLEdBQUQsQ0FBN0Q7QUFDQSxTQUFPLE9BQU9FLFFBQVAsS0FBb0IsUUFBcEIsR0FDSEEsUUFERyxHQUVIdEIsU0FBUyxDQUFDc0IsUUFBRCxDQUFULElBQXVCdEIsU0FBUyxDQUFDTSxJQUZyQztBQUdEO0FBRUQ7QUFDQTtBQUNBOzs7QUFDQSxXQUFhaUIsTUFBYjtBQUlFLGtCQUNFRixVQURGLEVBR0U7QUFBQSxRQURBRCxjQUNBLHVFQURpQ1osb0JBQ2pDOztBQUFBOztBQUFBOztBQUFBOztBQUNBLFNBQUtnQixXQUFMLEdBQW1CSCxVQUFuQjtBQUNBLFNBQUtJLFNBQUwsR0FDRSxPQUFPTCxjQUFQLEtBQTBCLFFBQTFCLEdBQ0lBLGNBREosR0FFSSxPQUFPQSxjQUFQLEtBQTBCLFFBQTFCLEdBQ0FwQixTQUFTLENBQUNvQixjQUFELENBQVQsSUFBNkJwQixTQUFTLENBQUNNLElBRHZDLEdBRUFhLGlCQUFpQixDQUFDQyxjQUFELEVBQWlCQyxVQUFqQixDQUx2QjtBQU1EOztBQWZIO0FBQUE7QUFBQSxxQ0FpQmtFO0FBQUEsVUFBakRELGNBQWlELHVFQUFoQixLQUFLSyxTQUFXO0FBQzlELGFBQU8sSUFBSUYsTUFBSixDQUFXLEtBQUtDLFdBQWhCLEVBQTZCSixjQUE3QixDQUFQO0FBQ0Q7QUFuQkg7QUFBQTtBQUFBLGdDQXFCY0UsUUFyQmQsRUFxQnlDO0FBQ3JDLFVBQUksT0FBT0EsUUFBUCxLQUFvQixRQUF4QixFQUFrQztBQUNoQyxhQUFLRyxTQUFMLEdBQWlCekIsU0FBUyxDQUFDc0IsUUFBRCxDQUFULElBQXVCdEIsU0FBUyxDQUFDTSxJQUFsRDtBQUNELE9BRkQsTUFFTztBQUNMLGFBQUttQixTQUFMLEdBQWlCSCxRQUFqQjtBQUNEO0FBQ0Y7QUEzQkg7QUFBQTtBQUFBLHdCQTZCTUEsUUE3Qk4sRUE2QmlEO0FBQzdDLFVBQUksS0FBS0csU0FBTCxJQUFrQkgsUUFBdEIsRUFBZ0M7QUFBQTs7QUFBQSwwQ0FEVEksUUFDUztBQURUQSxVQUFBQSxRQUNTO0FBQUE7O0FBQzlCLFlBQU1DLElBQUkscUZBQ0xwQixjQUFjLENBQUNlLFFBQUQsQ0FEVCwwQkFDeUIsS0FBS0UsV0FEOUIseUJBRUxFLFFBRkssQ0FBVjs7QUFJQSxZQUFJSixRQUFRLEdBQUd0QixTQUFTLENBQUNJLEtBQXpCLEVBQWdDO0FBQUE7O0FBQzlCLHNCQUFBd0IsT0FBTyxFQUFDQyxHQUFSLG9DQUFlRixJQUFmLEdBRDhCLENBQ1I7O0FBQ3ZCLFNBRkQsTUFFTztBQUFBOztBQUNMLHVCQUFBQyxPQUFPLEVBQUNFLEtBQVIscUNBQWlCSCxJQUFqQixHQURLLENBQ21COztBQUN6QjtBQUNGO0FBQ0Y7QUF6Q0g7QUFBQTtBQUFBLDRCQTJDaUM7QUFBQTs7QUFBQSx5Q0FBdEJELFFBQXNCO0FBQXRCQSxRQUFBQSxRQUFzQjtBQUFBOztBQUM3QixXQUFLRyxHQUFMLGtEQUFTN0IsU0FBUyxDQUFDQyxLQUFuQixtQkFBNkJ5QixRQUE3QjtBQUNEO0FBN0NIO0FBQUE7QUFBQSwyQkErQ2dDO0FBQUE7O0FBQUEseUNBQXRCQSxRQUFzQjtBQUF0QkEsUUFBQUEsUUFBc0I7QUFBQTs7QUFDNUIsV0FBS0csR0FBTCxrREFBUzdCLFNBQVMsQ0FBQ0UsSUFBbkIsbUJBQTRCd0IsUUFBNUI7QUFDRDtBQWpESDtBQUFBO0FBQUEsMkJBbURnQztBQUFBOztBQUFBLHlDQUF0QkEsUUFBc0I7QUFBdEJBLFFBQUFBLFFBQXNCO0FBQUE7O0FBQzVCLFdBQUtHLEdBQUwsa0RBQVM3QixTQUFTLENBQUNHLElBQW5CLG1CQUE0QnVCLFFBQTVCO0FBQ0Q7QUFyREg7QUFBQTtBQUFBLDRCQXVEaUM7QUFBQTs7QUFBQSx5Q0FBdEJBLFFBQXNCO0FBQXRCQSxRQUFBQSxRQUFzQjtBQUFBOztBQUM3QixXQUFLRyxHQUFMLGtEQUFTN0IsU0FBUyxDQUFDSSxLQUFuQixtQkFBNkJzQixRQUE3QjtBQUNEO0FBekRIO0FBQUE7QUFBQSw0QkEyRGlDO0FBQUE7O0FBQUEseUNBQXRCQSxRQUFzQjtBQUF0QkEsUUFBQUEsUUFBc0I7QUFBQTs7QUFDN0IsV0FBS0csR0FBTCxrREFBUzdCLFNBQVMsQ0FBQ0ssS0FBbkIsbUJBQTZCcUIsUUFBN0I7QUFDRDtBQTdESDs7QUFBQTtBQUFBO0FBZ0VBLElBQU1LLE9BQW1DLEdBQUcsRUFBNUM7QUFFQTtBQUNBO0FBQ0E7O0FBQ0EsT0FBTyxTQUFTQyxTQUFULENBQW1CWCxVQUFuQixFQUF1QztBQUM1QyxNQUFNWSxNQUFNLEdBQUdGLE9BQU8sQ0FBQ1YsVUFBRCxDQUFQLElBQXVCLElBQUlFLE1BQUosQ0FBV0YsVUFBWCxDQUF0QztBQUNBVSxFQUFBQSxPQUFPLENBQUNWLFVBQUQsQ0FBUCxHQUFzQlksTUFBdEI7QUFDQSxTQUFPQSxNQUFQO0FBQ0QiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqXG4gKi9cbmV4cG9ydCBjb25zdCBMb2dMZXZlbHM6IHsgW2xldmVsOiBzdHJpbmddOiBudW1iZXIgfSA9IHtcbiAgREVCVUc6IDEsXG4gIElORk86IDIsXG4gIFdBUk46IDMsXG4gIEVSUk9SOiA0LFxuICBGQVRBTDogNSxcbiAgTk9ORTogNixcbn07XG5cbmNvbnN0IExvZ0xldmVsTGFiZWxzID0gWycnLCAnREVCVUcnLCAnSU5GTycsICdXQVJOJywgJ0VSUk9SJywgJ0ZBVEFMJywgJ05PTkUnXTtcblxuY29uc3QgZ2xvYmFsTG9nTGV2ZWxDb25maWcgPSAoKCkgPT4ge1xuICBjb25zdCBnbG9iYWxMb2dMZXZlbFN0ciA9XG4gICAgcHJvY2Vzcy5lbnYuSlNGT1JDRV9MT0dfTEVWRUwgfHxcbiAgICAoZ2xvYmFsIGFzIGFueSkuX19KU0ZPUkNFX0xPR19MRVZFTF9fIHx8XG4gICAgJ05PTkUnO1xuICBpZiAoL14oREVCVUd8SU5GT3xXQVJOfEVSUk9SfEZBVEFMfE5PTkUpJC9pLnRlc3QoZ2xvYmFsTG9nTGV2ZWxTdHIpKSB7XG4gICAgcmV0dXJuIHsgJyonOiBnbG9iYWxMb2dMZXZlbFN0ciB9O1xuICB9XG4gIHRyeSB7XG4gICAgcmV0dXJuIEpTT04ucGFyc2UoZ2xvYmFsTG9nTGV2ZWxTdHIpO1xuICB9IGNhdGNoIChlKSB7XG4gICAgcmV0dXJuIHsgJyonOiAnTk9ORScgfTtcbiAgfVxufSkoKTtcblxuZXhwb3J0IHR5cGUgTG9nTGV2ZWxDb25maWcgPVxuICB8IHN0cmluZ1xuICB8IG51bWJlclxuICB8IHsgW25hbWU6IHN0cmluZ106IHN0cmluZyB8IG51bWJlciB9O1xuXG5mdW5jdGlvbiBnZXRNb2R1bGVMb2dMZXZlbChcbiAgbG9nTGV2ZWxDb25maWc6IHsgW25hbWU6IHN0cmluZ106IHN0cmluZyB8IG51bWJlciB9LFxuICBtb2R1bGVOYW1lOiBzdHJpbmcsXG4pIHtcbiAgY29uc3QgbG9nTGV2ZWwgPSBsb2dMZXZlbENvbmZpZ1ttb2R1bGVOYW1lXSB8fCBsb2dMZXZlbENvbmZpZ1snKiddO1xuICByZXR1cm4gdHlwZW9mIGxvZ0xldmVsID09PSAnbnVtYmVyJ1xuICAgID8gbG9nTGV2ZWxcbiAgICA6IExvZ0xldmVsc1tsb2dMZXZlbF0gfHwgTG9nTGV2ZWxzLk5PTkU7XG59XG5cbi8qKlxuICpcbiAqL1xuZXhwb3J0IGNsYXNzIExvZ2dlciB7XG4gIF9tb2R1bGVOYW1lOiBzdHJpbmc7XG4gIF9sb2dMZXZlbDogbnVtYmVyO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIG1vZHVsZU5hbWU6IHN0cmluZyxcbiAgICBsb2dMZXZlbENvbmZpZzogTG9nTGV2ZWxDb25maWcgPSBnbG9iYWxMb2dMZXZlbENvbmZpZyxcbiAgKSB7XG4gICAgdGhpcy5fbW9kdWxlTmFtZSA9IG1vZHVsZU5hbWU7XG4gICAgdGhpcy5fbG9nTGV2ZWwgPVxuICAgICAgdHlwZW9mIGxvZ0xldmVsQ29uZmlnID09PSAnbnVtYmVyJ1xuICAgICAgICA/IGxvZ0xldmVsQ29uZmlnXG4gICAgICAgIDogdHlwZW9mIGxvZ0xldmVsQ29uZmlnID09PSAnc3RyaW5nJ1xuICAgICAgICA/IExvZ0xldmVsc1tsb2dMZXZlbENvbmZpZ10gfHwgTG9nTGV2ZWxzLk5PTkVcbiAgICAgICAgOiBnZXRNb2R1bGVMb2dMZXZlbChsb2dMZXZlbENvbmZpZywgbW9kdWxlTmFtZSk7XG4gIH1cblxuICBjcmVhdGVJbnN0YW5jZShsb2dMZXZlbENvbmZpZzogTG9nTGV2ZWxDb25maWcgPSB0aGlzLl9sb2dMZXZlbCkge1xuICAgIHJldHVybiBuZXcgTG9nZ2VyKHRoaXMuX21vZHVsZU5hbWUsIGxvZ0xldmVsQ29uZmlnKTtcbiAgfVxuXG4gIHNldExvZ0xldmVsKGxvZ0xldmVsOiBzdHJpbmcgfCBudW1iZXIpIHtcbiAgICBpZiAodHlwZW9mIGxvZ0xldmVsID09PSAnc3RyaW5nJykge1xuICAgICAgdGhpcy5fbG9nTGV2ZWwgPSBMb2dMZXZlbHNbbG9nTGV2ZWxdIHx8IExvZ0xldmVscy5OT05FO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLl9sb2dMZXZlbCA9IGxvZ0xldmVsO1xuICAgIH1cbiAgfVxuXG4gIGxvZyhsb2dMZXZlbDogbnVtYmVyLCAuLi5tZXNzYWdlczogQXJyYXk8YW55Pikge1xuICAgIGlmICh0aGlzLl9sb2dMZXZlbCA8PSBsb2dMZXZlbCkge1xuICAgICAgY29uc3QgbXNncyA9IFtcbiAgICAgICAgYCR7TG9nTGV2ZWxMYWJlbHNbbG9nTGV2ZWxdfVxcdFske3RoaXMuX21vZHVsZU5hbWV9XSBgLFxuICAgICAgICAuLi5tZXNzYWdlcyxcbiAgICAgIF07XG4gICAgICBpZiAobG9nTGV2ZWwgPCBMb2dMZXZlbHMuRVJST1IpIHtcbiAgICAgICAgY29uc29sZS5sb2coLi4ubXNncyk7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tY29uc29sZVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc29sZS5lcnJvciguLi5tc2dzKTsgLy8gZXNsaW50LWRpc2FibGUtbGluZSBuby1jb25zb2xlXG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgZGVidWcoLi4ubWVzc2FnZXM6IEFycmF5PGFueT4pIHtcbiAgICB0aGlzLmxvZyhMb2dMZXZlbHMuREVCVUcsIC4uLm1lc3NhZ2VzKTtcbiAgfVxuXG4gIGluZm8oLi4ubWVzc2FnZXM6IEFycmF5PGFueT4pIHtcbiAgICB0aGlzLmxvZyhMb2dMZXZlbHMuSU5GTywgLi4ubWVzc2FnZXMpO1xuICB9XG5cbiAgd2FybiguLi5tZXNzYWdlczogQXJyYXk8YW55Pikge1xuICAgIHRoaXMubG9nKExvZ0xldmVscy5XQVJOLCAuLi5tZXNzYWdlcyk7XG4gIH1cblxuICBlcnJvciguLi5tZXNzYWdlczogQXJyYXk8YW55Pikge1xuICAgIHRoaXMubG9nKExvZ0xldmVscy5FUlJPUiwgLi4ubWVzc2FnZXMpO1xuICB9XG5cbiAgZmF0YWwoLi4ubWVzc2FnZXM6IEFycmF5PGFueT4pIHtcbiAgICB0aGlzLmxvZyhMb2dMZXZlbHMuRkFUQUwsIC4uLm1lc3NhZ2VzKTtcbiAgfVxufVxuXG5jb25zdCBsb2dnZXJzOiB7IFtuYW1lOiBzdHJpbmddOiBMb2dnZXIgfSA9IHt9O1xuXG4vKipcbiAqXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRMb2dnZXIobW9kdWxlTmFtZTogc3RyaW5nKSB7XG4gIGNvbnN0IGxvZ2dlciA9IGxvZ2dlcnNbbW9kdWxlTmFtZV0gfHwgbmV3IExvZ2dlcihtb2R1bGVOYW1lKTtcbiAgbG9nZ2Vyc1ttb2R1bGVOYW1lXSA9IGxvZ2dlcjtcbiAgcmV0dXJuIGxvZ2dlcjtcbn1cbiJdfQ==