import "core-js/modules/es.array.join";
import "core-js/modules/es.function.name";
import "core-js/modules/es.object.to-string";
import "core-js/modules/es.regexp.to-string";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _toConsumableArray from "@babel/runtime-corejs3/helpers/toConsumableArray";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import "regenerator-runtime/runtime";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import { exec } from 'child_process';
import stripAnsi from 'strip-ansi';
import Connection from '../connection';

function isNotNullOrUndefined(v) {
  return v != null;
}
/**
 *
 */


export var SfdxRegistry = /*#__PURE__*/function () {
  function SfdxRegistry(_ref) {
    var cliPath = _ref.cliPath;

    _classCallCheck(this, SfdxRegistry);

    _defineProperty(this, "_cliPath", void 0);

    _defineProperty(this, "_orgList", void 0);

    _defineProperty(this, "_orgInfoMap", {});

    _defineProperty(this, "_defaultOrgInfo", void 0);

    this._cliPath = cliPath;
  }

  _createClass(SfdxRegistry, [{
    key: "_createCommand",
    value: function _createCommand(command) {
      var _context, _context2, _context3, _context4;

      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      var args = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : [];
      return _concatInstanceProperty(_context = _concatInstanceProperty(_context2 = _concatInstanceProperty(_context3 = "".concat(this._cliPath ? this._cliPath + '/' : '', "sfdx ")).call(_context3, command, " ")).call(_context2, _mapInstanceProperty(_context4 = _Object$keys(options)).call(_context4, function (option) {
        var _context5, _context6;

        return _concatInstanceProperty(_context5 = _concatInstanceProperty(_context6 = "".concat(option.length > 1 ? '--' : '-')).call(_context6, option)).call(_context5, options[option] != null ? ' ' + options[option] : '');
      }).join(' '), " --json ")).call(_context, args.join(' '));
    }
  }, {
    key: "_execCommand",
    value: function () {
      var _execCommand2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee(command) {
        var options,
            args,
            cmd,
            buf,
            body,
            ret,
            err,
            _args = arguments;
        return _regeneratorRuntime.wrap(function _callee$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                options = _args.length > 1 && _args[1] !== undefined ? _args[1] : {};
                args = _args.length > 2 && _args[2] !== undefined ? _args[2] : [];
                cmd = this._createCommand(command, options, args);
                _context7.next = 5;
                return new _Promise(function (resolve, reject) {
                  exec(cmd, function (err, ret) {
                    if (err && !ret) {
                      reject(err);
                    } else {
                      resolve(ret);
                    }
                  });
                });

              case 5:
                buf = _context7.sent;
                body = stripAnsi(buf.toString());
                _context7.prev = 7;
                ret = JSON.parse(body);
                _context7.next = 14;
                break;

              case 11:
                _context7.prev = 11;
                _context7.t0 = _context7["catch"](7);
                throw new Error("Unexpectedd output from Sfdx cli: ".concat(body));

              case 14:
                if (!(ret.status === 0 && ret.result)) {
                  _context7.next = 18;
                  break;
                }

                return _context7.abrupt("return", ret.result);

              case 18:
                err = new Error(ret.message);
                err.name = ret.name;
                throw err;

              case 21:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee, this, [[7, 11]]);
      }));

      function _execCommand(_x) {
        return _execCommand2.apply(this, arguments);
      }

      return _execCommand;
    }()
  }, {
    key: "_getOrgList",
    value: function () {
      var _getOrgList2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee2() {
        return _regeneratorRuntime.wrap(function _callee2$(_context8) {
          while (1) {
            switch (_context8.prev = _context8.next) {
              case 0:
                if (!this._orgList) {
                  this._orgList = this._execCommand('force:org:list');
                }

                return _context8.abrupt("return", this._orgList);

              case 2:
              case "end":
                return _context8.stop();
            }
          }
        }, _callee2, this);
      }));

      function _getOrgList() {
        return _getOrgList2.apply(this, arguments);
      }

      return _getOrgList;
    }()
  }, {
    key: "getConnectionNames",
    value: function () {
      var _getConnectionNames = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee3() {
        var _context9, _context10, _context11;

        var _yield$this$_getOrgLi, nonScratchOrgs, scratchOrgs;

        return _regeneratorRuntime.wrap(function _callee3$(_context12) {
          while (1) {
            switch (_context12.prev = _context12.next) {
              case 0:
                _context12.next = 2;
                return this._getOrgList();

              case 2:
                _yield$this$_getOrgLi = _context12.sent;
                nonScratchOrgs = _yield$this$_getOrgLi.nonScratchOrgs;
                scratchOrgs = _yield$this$_getOrgLi.scratchOrgs;
                return _context12.abrupt("return", _concatInstanceProperty(_context9 = []).call(_context9, _toConsumableArray(_filterInstanceProperty(_context10 = _mapInstanceProperty(nonScratchOrgs).call(nonScratchOrgs, function (o) {
                  return o.alias;
                })).call(_context10, isNotNullOrUndefined)), _toConsumableArray(_filterInstanceProperty(_context11 = _mapInstanceProperty(scratchOrgs).call(scratchOrgs, function (o) {
                  return o.alias;
                })).call(_context11, isNotNullOrUndefined)), _toConsumableArray(_mapInstanceProperty(nonScratchOrgs).call(nonScratchOrgs, function (o) {
                  return o.username;
                })), _toConsumableArray(_mapInstanceProperty(scratchOrgs).call(scratchOrgs, function (o) {
                  return o.username;
                }))));

              case 6:
              case "end":
                return _context12.stop();
            }
          }
        }, _callee3, this);
      }));

      function getConnectionNames() {
        return _getConnectionNames.apply(this, arguments);
      }

      return getConnectionNames;
    }()
  }, {
    key: "getConnection",
    value: function () {
      var _getConnection = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee4(name) {
        var config;
        return _regeneratorRuntime.wrap(function _callee4$(_context13) {
          while (1) {
            switch (_context13.prev = _context13.next) {
              case 0:
                _context13.next = 2;
                return this.getConnectionConfig(name);

              case 2:
                config = _context13.sent;
                return _context13.abrupt("return", config ? new Connection(config) : null);

              case 4:
              case "end":
                return _context13.stop();
            }
          }
        }, _callee4, this);
      }));

      function getConnection(_x2) {
        return _getConnection.apply(this, arguments);
      }

      return getConnection;
    }()
  }, {
    key: "_getOrgInfo",
    value: function () {
      var _getOrgInfo2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee5(username) {
        var options, pOrgInfo, orgInfo;
        return _regeneratorRuntime.wrap(function _callee5$(_context14) {
          while (1) {
            switch (_context14.prev = _context14.next) {
              case 0:
                options = username ? {
                  u: username
                } : {};

                if (!username || !this._orgInfoMap[username]) {
                  pOrgInfo = this._execCommand('force:org:display', options);

                  this._memoOrgInfo(pOrgInfo, username);
                }

                orgInfo = username ? this._orgInfoMap[username] : this._defaultOrgInfo;

                if (orgInfo) {
                  _context14.next = 5;
                  break;
                }

                throw new Error('no orginfo found');

              case 5:
                return _context14.abrupt("return", orgInfo);

              case 6:
              case "end":
                return _context14.stop();
            }
          }
        }, _callee5, this);
      }));

      function _getOrgInfo(_x3) {
        return _getOrgInfo2.apply(this, arguments);
      }

      return _getOrgInfo;
    }()
  }, {
    key: "_memoOrgInfo",
    value: function _memoOrgInfo(pOrgInfo, username) {
      var _this = this;

      var pOrgInfo_ = pOrgInfo.then(function (orgInfo) {
        _this._orgInfoMap[orgInfo.username] = pOrgInfo_;

        if (orgInfo.alias) {
          _this._orgInfoMap[orgInfo.alias] = pOrgInfo_;
        }

        return orgInfo;
      });

      if (username) {
        this._orgInfoMap[username] = pOrgInfo_;
      } else {
        this._defaultOrgInfo = pOrgInfo_;
      }
    }
  }, {
    key: "getConnectionConfig",
    value: function () {
      var _getConnectionConfig = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee6(name) {
        var orgInfo, accessToken, instanceUrl, loginUrl;
        return _regeneratorRuntime.wrap(function _callee6$(_context15) {
          while (1) {
            switch (_context15.prev = _context15.next) {
              case 0:
                _context15.next = 2;
                return this._getOrgInfo(name);

              case 2:
                orgInfo = _context15.sent;

                if (orgInfo) {
                  _context15.next = 5;
                  break;
                }

                return _context15.abrupt("return", null);

              case 5:
                accessToken = orgInfo.accessToken, instanceUrl = orgInfo.instanceUrl, loginUrl = orgInfo.loginUrl;
                return _context15.abrupt("return", {
                  accessToken: accessToken,
                  instanceUrl: instanceUrl,
                  loginUrl: loginUrl
                });

              case 7:
              case "end":
                return _context15.stop();
            }
          }
        }, _callee6, this);
      }));

      function getConnectionConfig(_x4) {
        return _getConnectionConfig.apply(this, arguments);
      }

      return getConnectionConfig;
    }()
  }, {
    key: "saveConnectionConfig",
    value: function () {
      var _saveConnectionConfig = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee7(_name, _connConfig) {
        return _regeneratorRuntime.wrap(function _callee7$(_context16) {
          while (1) {
            switch (_context16.prev = _context16.next) {
              case 0:
              case "end":
                return _context16.stop();
            }
          }
        }, _callee7);
      }));

      function saveConnectionConfig(_x5, _x6) {
        return _saveConnectionConfig.apply(this, arguments);
      }

      return saveConnectionConfig;
    }()
  }, {
    key: "setDefaultConnection",
    value: function () {
      var _setDefaultConnection = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee8(_name) {
        return _regeneratorRuntime.wrap(function _callee8$(_context17) {
          while (1) {
            switch (_context17.prev = _context17.next) {
              case 0:
              case "end":
                return _context17.stop();
            }
          }
        }, _callee8);
      }));

      function setDefaultConnection(_x7) {
        return _setDefaultConnection.apply(this, arguments);
      }

      return setDefaultConnection;
    }()
  }, {
    key: "removeConnectionConfig",
    value: function () {
      var _removeConnectionConfig = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee9(name) {
        return _regeneratorRuntime.wrap(function _callee9$(_context18) {
          while (1) {
            switch (_context18.prev = _context18.next) {
              case 0:
                _context18.next = 2;
                return this._execCommand('force:org:delete', {
                  u: name
                });

              case 2:
              case "end":
                return _context18.stop();
            }
          }
        }, _callee9, this);
      }));

      function removeConnectionConfig(_x8) {
        return _removeConnectionConfig.apply(this, arguments);
      }

      return removeConnectionConfig;
    }()
  }, {
    key: "getClientConfig",
    value: function () {
      var _getClientConfig = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee10(_name) {
        return _regeneratorRuntime.wrap(function _callee10$(_context19) {
          while (1) {
            switch (_context19.prev = _context19.next) {
              case 0:
                return _context19.abrupt("return", null);

              case 1:
              case "end":
                return _context19.stop();
            }
          }
        }, _callee10);
      }));

      function getClientConfig(_x9) {
        return _getClientConfig.apply(this, arguments);
      }

      return getClientConfig;
    }()
  }, {
    key: "getClientNames",
    value: function () {
      var _getClientNames = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee11() {
        return _regeneratorRuntime.wrap(function _callee11$(_context20) {
          while (1) {
            switch (_context20.prev = _context20.next) {
              case 0:
                return _context20.abrupt("return", []);

              case 1:
              case "end":
                return _context20.stop();
            }
          }
        }, _callee11);
      }));

      function getClientNames() {
        return _getClientNames.apply(this, arguments);
      }

      return getClientNames;
    }()
  }, {
    key: "registerClientConfig",
    value: function () {
      var _registerClientConfig = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee12(_name, _clientConfig) {
        return _regeneratorRuntime.wrap(function _callee12$(_context21) {
          while (1) {
            switch (_context21.prev = _context21.next) {
              case 0:
              case "end":
                return _context21.stop();
            }
          }
        }, _callee12);
      }));

      function registerClientConfig(_x10, _x11) {
        return _registerClientConfig.apply(this, arguments);
      }

      return registerClientConfig;
    }()
  }]);

  return SfdxRegistry;
}();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9yZWdpc3RyeS9zZmR4LnRzIl0sIm5hbWVzIjpbImV4ZWMiLCJzdHJpcEFuc2kiLCJDb25uZWN0aW9uIiwiaXNOb3ROdWxsT3JVbmRlZmluZWQiLCJ2IiwiU2ZkeFJlZ2lzdHJ5IiwiY2xpUGF0aCIsIl9jbGlQYXRoIiwiY29tbWFuZCIsIm9wdGlvbnMiLCJhcmdzIiwib3B0aW9uIiwibGVuZ3RoIiwiam9pbiIsImNtZCIsIl9jcmVhdGVDb21tYW5kIiwicmVzb2x2ZSIsInJlamVjdCIsImVyciIsInJldCIsImJ1ZiIsImJvZHkiLCJ0b1N0cmluZyIsIkpTT04iLCJwYXJzZSIsIkVycm9yIiwic3RhdHVzIiwicmVzdWx0IiwibWVzc2FnZSIsIm5hbWUiLCJfb3JnTGlzdCIsIl9leGVjQ29tbWFuZCIsIl9nZXRPcmdMaXN0Iiwibm9uU2NyYXRjaE9yZ3MiLCJzY3JhdGNoT3JncyIsIm8iLCJhbGlhcyIsInVzZXJuYW1lIiwiZ2V0Q29ubmVjdGlvbkNvbmZpZyIsImNvbmZpZyIsInUiLCJfb3JnSW5mb01hcCIsInBPcmdJbmZvIiwiX21lbW9PcmdJbmZvIiwib3JnSW5mbyIsIl9kZWZhdWx0T3JnSW5mbyIsInBPcmdJbmZvXyIsInRoZW4iLCJfZ2V0T3JnSW5mbyIsImFjY2Vzc1Rva2VuIiwiaW5zdGFuY2VVcmwiLCJsb2dpblVybCIsIl9uYW1lIiwiX2Nvbm5Db25maWciLCJfY2xpZW50Q29uZmlnIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsU0FBU0EsSUFBVCxRQUFxQixlQUFyQjtBQUNBLE9BQU9DLFNBQVAsTUFBc0IsWUFBdEI7QUFDQSxPQUFPQyxVQUFQLE1BQXVCLGVBQXZCOztBQTZCQSxTQUFTQyxvQkFBVCxDQUFpQ0MsQ0FBakMsRUFBa0U7QUFDaEUsU0FBT0EsQ0FBQyxJQUFJLElBQVo7QUFDRDtBQUVEO0FBQ0E7QUFDQTs7O0FBQ0EsV0FBYUMsWUFBYjtBQU1FLDhCQUErQztBQUFBLFFBQWpDQyxPQUFpQyxRQUFqQ0EsT0FBaUM7O0FBQUE7O0FBQUE7O0FBQUE7O0FBQUEseUNBSFMsRUFHVDs7QUFBQTs7QUFDN0MsU0FBS0MsUUFBTCxHQUFnQkQsT0FBaEI7QUFDRDs7QUFSSDtBQUFBO0FBQUEsbUNBV0lFLE9BWEosRUFjSTtBQUFBOztBQUFBLFVBRkFDLE9BRUEsdUVBRnFDLEVBRXJDO0FBQUEsVUFEQUMsSUFDQSx1RUFEaUIsRUFDakI7QUFDQSxrSUFDRSxLQUFLSCxRQUFMLEdBQWdCLEtBQUtBLFFBQUwsR0FBZ0IsR0FBaEMsR0FBc0MsRUFEeEMsNEJBRVFDLE9BRlIsd0JBRW1CLDhDQUFZQyxPQUFaLG1CQUVmLFVBQUNFLE1BQUQ7QUFBQTs7QUFBQSxpR0FDS0EsTUFBTSxDQUFDQyxNQUFQLEdBQWdCLENBQWhCLEdBQW9CLElBQXBCLEdBQTJCLEdBRGhDLG1CQUNzQ0QsTUFEdEMsbUJBRUlGLE9BQU8sQ0FBQ0UsTUFBRCxDQUFQLElBQW1CLElBQW5CLEdBQTBCLE1BQU1GLE9BQU8sQ0FBQ0UsTUFBRCxDQUF2QyxHQUFrRCxFQUZ0RDtBQUFBLE9BRmUsRUFPaEJFLElBUGdCLENBT1gsR0FQVyxDQUZuQiw4QkFTdUJILElBQUksQ0FBQ0csSUFBTCxDQUFVLEdBQVYsQ0FUdkI7QUFVRDtBQXpCSDtBQUFBO0FBQUE7QUFBQSxvR0E0QklMLE9BNUJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBNkJJQyxnQkFBQUEsT0E3QkosMkRBNkJ5QyxFQTdCekM7QUE4QklDLGdCQUFBQSxJQTlCSiwyREE4QnFCLEVBOUJyQjtBQWdDVUksZ0JBQUFBLEdBaENWLEdBZ0NnQixLQUFLQyxjQUFMLENBQW9CUCxPQUFwQixFQUE2QkMsT0FBN0IsRUFBc0NDLElBQXRDLENBaENoQjtBQUFBO0FBQUEsdUJBaUNzQixhQUFvQixVQUFDTSxPQUFELEVBQVVDLE1BQVYsRUFBcUI7QUFDekRqQixrQkFBQUEsSUFBSSxDQUFDYyxHQUFELEVBQU0sVUFBQ0ksR0FBRCxFQUFNQyxHQUFOLEVBQWM7QUFDdEIsd0JBQUlELEdBQUcsSUFBSSxDQUFDQyxHQUFaLEVBQWlCO0FBQ2ZGLHNCQUFBQSxNQUFNLENBQUNDLEdBQUQsQ0FBTjtBQUNELHFCQUZELE1BRU87QUFDTEYsc0JBQUFBLE9BQU8sQ0FBQ0csR0FBRCxDQUFQO0FBQ0Q7QUFDRixtQkFORyxDQUFKO0FBT0QsaUJBUmlCLENBakN0Qjs7QUFBQTtBQWlDVUMsZ0JBQUFBLEdBakNWO0FBMENVQyxnQkFBQUEsSUExQ1YsR0EwQ2lCcEIsU0FBUyxDQUFDbUIsR0FBRyxDQUFDRSxRQUFKLEVBQUQsQ0ExQzFCO0FBQUE7QUE2Q01ILGdCQUFBQSxHQUFHLEdBQUdJLElBQUksQ0FBQ0MsS0FBTCxDQUFXSCxJQUFYLENBQU47QUE3Q047QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkErQ1ksSUFBSUksS0FBSiw2Q0FBK0NKLElBQS9DLEVBL0NaOztBQUFBO0FBQUEsc0JBaURRRixHQUFHLENBQUNPLE1BQUosS0FBZSxDQUFmLElBQW9CUCxHQUFHLENBQUNRLE1BakRoQztBQUFBO0FBQUE7QUFBQTs7QUFBQSxrREFrRGFSLEdBQUcsQ0FBQ1EsTUFsRGpCOztBQUFBO0FBb0RZVCxnQkFBQUEsR0FwRFosR0FvRGtCLElBQUlPLEtBQUosQ0FBVU4sR0FBRyxDQUFDUyxPQUFkLENBcERsQjtBQXFETVYsZ0JBQUFBLEdBQUcsQ0FBQ1csSUFBSixHQUFXVixHQUFHLENBQUNVLElBQWY7QUFyRE4sc0JBc0RZWCxHQXREWjs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUEyREksb0JBQUksQ0FBQyxLQUFLWSxRQUFWLEVBQW9CO0FBQ2xCLHVCQUFLQSxRQUFMLEdBQWdCLEtBQUtDLFlBQUwsQ0FBK0IsZ0JBQS9CLENBQWhCO0FBQ0Q7O0FBN0RMLGtEQThEVyxLQUFLRCxRQTlEaEI7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFrRWtELEtBQUtFLFdBQUwsRUFsRWxEOztBQUFBO0FBQUE7QUFrRVlDLGdCQUFBQSxjQWxFWix5QkFrRVlBLGNBbEVaO0FBa0U0QkMsZ0JBQUFBLFdBbEU1Qix5QkFrRTRCQSxXQWxFNUI7QUFBQSw4SEFvRVMsMERBQUFELGNBQWMsTUFBZCxDQUFBQSxjQUFjLEVBQUssVUFBQ0UsQ0FBRDtBQUFBLHlCQUFPQSxDQUFDLENBQUNDLEtBQVQ7QUFBQSxpQkFBTCxDQUFkLG1CQUEwQ2pDLG9CQUExQyxDQXBFVCxzQkFxRVMsMERBQUErQixXQUFXLE1BQVgsQ0FBQUEsV0FBVyxFQUFLLFVBQUNDLENBQUQ7QUFBQSx5QkFBT0EsQ0FBQyxDQUFDQyxLQUFUO0FBQUEsaUJBQUwsQ0FBWCxtQkFBdUNqQyxvQkFBdkMsQ0FyRVQsc0JBc0VTLHFCQUFBOEIsY0FBYyxNQUFkLENBQUFBLGNBQWMsRUFBSyxVQUFDRSxDQUFEO0FBQUEseUJBQU9BLENBQUMsQ0FBQ0UsUUFBVDtBQUFBLGlCQUFMLENBdEV2QixzQkF1RVMscUJBQUFILFdBQVcsTUFBWCxDQUFBQSxXQUFXLEVBQUssVUFBQ0MsQ0FBRDtBQUFBLHlCQUFPQSxDQUFDLENBQUNFLFFBQVQ7QUFBQSxpQkFBTCxDQXZFcEI7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzR0EyRWlEUixJQTNFakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE0RXlCLEtBQUtTLG1CQUFMLENBQXlCVCxJQUF6QixDQTVFekI7O0FBQUE7QUE0RVVVLGdCQUFBQSxNQTVFVjtBQUFBLG1EQTZFV0EsTUFBTSxHQUFHLElBQUlyQyxVQUFKLENBQWtCcUMsTUFBbEIsQ0FBSCxHQUErQixJQTdFaEQ7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvR0FnRm9CRixRQWhGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBaUZVNUIsZ0JBQUFBLE9BakZWLEdBaUZvQjRCLFFBQVEsR0FBRztBQUFFRyxrQkFBQUEsQ0FBQyxFQUFFSDtBQUFMLGlCQUFILEdBQXFCLEVBakZqRDs7QUFrRkksb0JBQUksQ0FBQ0EsUUFBRCxJQUFhLENBQUMsS0FBS0ksV0FBTCxDQUFpQkosUUFBakIsQ0FBbEIsRUFBOEM7QUFDdENLLGtCQUFBQSxRQURzQyxHQUMzQixLQUFLWCxZQUFMLENBQ2YsbUJBRGUsRUFFZnRCLE9BRmUsQ0FEMkI7O0FBSzVDLHVCQUFLa0MsWUFBTCxDQUFrQkQsUUFBbEIsRUFBNEJMLFFBQTVCO0FBQ0Q7O0FBQ0tPLGdCQUFBQSxPQXpGVixHQXlGb0JQLFFBQVEsR0FDcEIsS0FBS0ksV0FBTCxDQUFpQkosUUFBakIsQ0FEb0IsR0FFcEIsS0FBS1EsZUEzRmI7O0FBQUEsb0JBNEZTRCxPQTVGVDtBQUFBO0FBQUE7QUFBQTs7QUFBQSxzQkE2RlksSUFBSW5CLEtBQUosQ0FBVSxrQkFBVixDQTdGWjs7QUFBQTtBQUFBLG1EQStGV21CLE9BL0ZYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQWtHZUYsUUFsR2YsRUFrRytDTCxRQWxHL0MsRUFrR2tFO0FBQUE7O0FBQzlELFVBQU1TLFNBQVMsR0FBR0osUUFBUSxDQUFDSyxJQUFULENBQWMsVUFBQ0gsT0FBRCxFQUFhO0FBQzNDLFFBQUEsS0FBSSxDQUFDSCxXQUFMLENBQWlCRyxPQUFPLENBQUNQLFFBQXpCLElBQXFDUyxTQUFyQzs7QUFDQSxZQUFJRixPQUFPLENBQUNSLEtBQVosRUFBbUI7QUFDakIsVUFBQSxLQUFJLENBQUNLLFdBQUwsQ0FBaUJHLE9BQU8sQ0FBQ1IsS0FBekIsSUFBa0NVLFNBQWxDO0FBQ0Q7O0FBQ0QsZUFBT0YsT0FBUDtBQUNELE9BTmlCLENBQWxCOztBQU9BLFVBQUlQLFFBQUosRUFBYztBQUNaLGFBQUtJLFdBQUwsQ0FBaUJKLFFBQWpCLElBQTZCUyxTQUE3QjtBQUNELE9BRkQsTUFFTztBQUNMLGFBQUtELGVBQUwsR0FBdUJDLFNBQXZCO0FBQ0Q7QUFDRjtBQS9HSDtBQUFBO0FBQUE7QUFBQSw0R0FpSDRCakIsSUFqSDVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBa0gwQixLQUFLbUIsV0FBTCxDQUFpQm5CLElBQWpCLENBbEgxQjs7QUFBQTtBQWtIVWUsZ0JBQUFBLE9BbEhWOztBQUFBLG9CQW1IU0EsT0FuSFQ7QUFBQTtBQUFBO0FBQUE7O0FBQUEsbURBb0hhLElBcEhiOztBQUFBO0FBc0hZSyxnQkFBQUEsV0F0SFosR0FzSG1ETCxPQXRIbkQsQ0FzSFlLLFdBdEhaLEVBc0h5QkMsV0F0SHpCLEdBc0htRE4sT0F0SG5ELENBc0h5Qk0sV0F0SHpCLEVBc0hzQ0MsUUF0SHRDLEdBc0htRFAsT0F0SG5ELENBc0hzQ08sUUF0SHRDO0FBQUEsbURBdUhXO0FBQUVGLGtCQUFBQSxXQUFXLEVBQVhBLFdBQUY7QUFBZUMsa0JBQUFBLFdBQVcsRUFBWEEsV0FBZjtBQUE0QkMsa0JBQUFBLFFBQVEsRUFBUkE7QUFBNUIsaUJBdkhYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkdBMEg2QkMsS0ExSDdCLEVBMEg0Q0MsV0ExSDVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2R0E4SDZCRCxLQTlIN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtHQWtJK0J2QixJQWxJL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBbUlVLEtBQUtFLFlBQUwsQ0FBa0Isa0JBQWxCLEVBQXNDO0FBQUVTLGtCQUFBQSxDQUFDLEVBQUVYO0FBQUwsaUJBQXRDLENBbklWOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUdBc0l3QnVCLEtBdEl4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbURBdUlXLElBdklYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1EQTJJVyxFQTNJWDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDhHQThJNkJBLEtBOUk3QixFQThJNENFLGFBOUk1QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGV4ZWMgfSBmcm9tICdjaGlsZF9wcm9jZXNzJztcbmltcG9ydCBzdHJpcEFuc2kgZnJvbSAnc3RyaXAtYW5zaSc7XG5pbXBvcnQgQ29ubmVjdGlvbiBmcm9tICcuLi9jb25uZWN0aW9uJztcbmltcG9ydCB7IFJlZ2lzdHJ5LCBDb25uZWN0aW9uQ29uZmlnLCBDbGllbnRDb25maWcgfSBmcm9tICcuL3R5cGVzJztcbmltcG9ydCB7IFNjaGVtYSB9IGZyb20gJy4uL3R5cGVzJztcblxudHlwZSBTZmR4Q29tbWFuZE91dHB1dCA9IHtcbiAgc3RhdHVzOiBudW1iZXI7XG4gIG5hbWU/OiBzdHJpbmc7XG4gIG1lc3NhZ2U/OiBzdHJpbmc7XG4gIHJlc3VsdD86IGFueTtcbn07XG5cbnR5cGUgU2ZkeE9yZ0xpc3QgPSB7XG4gIG5vblNjcmF0Y2hPcmdzOiBTZmR4T3JnSW5mb1tdO1xuICBzY3JhdGNoT3JnczogU2ZkeE9yZ0luZm9bXTtcbn07XG5cbnR5cGUgU2ZkeE9yZ0luZm8gPSB7XG4gIG9yZ0lkOiBzdHJpbmc7XG4gIGFjY2Vzc1Rva2VuOiBzdHJpbmc7XG4gIGluc3RhbmNlVXJsOiBzdHJpbmc7XG4gIGxvZ2luVXJsOiBzdHJpbmc7XG4gIHVzZXJuYW1lOiBzdHJpbmc7XG4gIGNsaWVudElkOiBzdHJpbmc7XG4gIGlzRGV2SHViOiBib29sZWFuO1xuICBjb25uZWN0ZWRTdGF0dXM6IHN0cmluZztcbiAgbGFzdFVzZWQ6IHN0cmluZztcbiAgYWxpYXM/OiBzdHJpbmc7XG59O1xuXG5mdW5jdGlvbiBpc05vdE51bGxPclVuZGVmaW5lZDxUPih2OiBUIHwgbnVsbCB8IHVuZGVmaW5lZCk6IHYgaXMgVCB7XG4gIHJldHVybiB2ICE9IG51bGw7XG59XG5cbi8qKlxuICpcbiAqL1xuZXhwb3J0IGNsYXNzIFNmZHhSZWdpc3RyeSBpbXBsZW1lbnRzIFJlZ2lzdHJ5IHtcbiAgX2NsaVBhdGg6IHN0cmluZyB8IHVuZGVmaW5lZDtcbiAgX29yZ0xpc3Q6IFByb21pc2U8U2ZkeE9yZ0xpc3Q+IHwgdW5kZWZpbmVkO1xuICBfb3JnSW5mb01hcDogeyBbbmFtZTogc3RyaW5nXTogUHJvbWlzZTxTZmR4T3JnSW5mbz4gfSA9IHt9O1xuICBfZGVmYXVsdE9yZ0luZm86IFByb21pc2U8U2ZkeE9yZ0luZm8+IHwgdW5kZWZpbmVkO1xuXG4gIGNvbnN0cnVjdG9yKHsgY2xpUGF0aCB9OiB7IGNsaVBhdGg/OiBzdHJpbmcgfSkge1xuICAgIHRoaXMuX2NsaVBhdGggPSBjbGlQYXRoO1xuICB9XG5cbiAgX2NyZWF0ZUNvbW1hbmQoXG4gICAgY29tbWFuZDogc3RyaW5nLFxuICAgIG9wdGlvbnM6IHsgW29wdGlvbjogc3RyaW5nXTogYW55IH0gPSB7fSxcbiAgICBhcmdzOiBzdHJpbmdbXSA9IFtdLFxuICApIHtcbiAgICByZXR1cm4gYCR7XG4gICAgICB0aGlzLl9jbGlQYXRoID8gdGhpcy5fY2xpUGF0aCArICcvJyA6ICcnXG4gICAgfXNmZHggJHtjb21tYW5kfSAke09iamVjdC5rZXlzKG9wdGlvbnMpXG4gICAgICAubWFwKFxuICAgICAgICAob3B0aW9uKSA9PlxuICAgICAgICAgIGAke29wdGlvbi5sZW5ndGggPiAxID8gJy0tJyA6ICctJ30ke29wdGlvbn0ke1xuICAgICAgICAgICAgb3B0aW9uc1tvcHRpb25dICE9IG51bGwgPyAnICcgKyBvcHRpb25zW29wdGlvbl0gOiAnJ1xuICAgICAgICAgIH1gLFxuICAgICAgKVxuICAgICAgLmpvaW4oJyAnKX0gLS1qc29uICR7YXJncy5qb2luKCcgJyl9YDtcbiAgfVxuXG4gIGFzeW5jIF9leGVjQ29tbWFuZDxUPihcbiAgICBjb21tYW5kOiBzdHJpbmcsXG4gICAgb3B0aW9uczogeyBbb3B0aW9uOiBzdHJpbmddOiBhbnkgfSA9IHt9LFxuICAgIGFyZ3M6IHN0cmluZ1tdID0gW10sXG4gICkge1xuICAgIGNvbnN0IGNtZCA9IHRoaXMuX2NyZWF0ZUNvbW1hbmQoY29tbWFuZCwgb3B0aW9ucywgYXJncyk7XG4gICAgY29uc3QgYnVmID0gYXdhaXQgbmV3IFByb21pc2U8c3RyaW5nPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICBleGVjKGNtZCwgKGVyciwgcmV0KSA9PiB7XG4gICAgICAgIGlmIChlcnIgJiYgIXJldCkge1xuICAgICAgICAgIHJlamVjdChlcnIpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJlc29sdmUocmV0KTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfSk7XG4gICAgY29uc3QgYm9keSA9IHN0cmlwQW5zaShidWYudG9TdHJpbmcoKSk7XG4gICAgbGV0IHJldDogU2ZkeENvbW1hbmRPdXRwdXQ7XG4gICAgdHJ5IHtcbiAgICAgIHJldCA9IEpTT04ucGFyc2UoYm9keSkgYXMgU2ZkeENvbW1hbmRPdXRwdXQ7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmV4cGVjdGVkZCBvdXRwdXQgZnJvbSBTZmR4IGNsaTogJHtib2R5fWApO1xuICAgIH1cbiAgICBpZiAocmV0LnN0YXR1cyA9PT0gMCAmJiByZXQucmVzdWx0KSB7XG4gICAgICByZXR1cm4gcmV0LnJlc3VsdCBhcyBUO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBlcnIgPSBuZXcgRXJyb3IocmV0Lm1lc3NhZ2UgYXMgc3RyaW5nKTtcbiAgICAgIGVyci5uYW1lID0gcmV0Lm5hbWUgYXMgc3RyaW5nO1xuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIF9nZXRPcmdMaXN0KCkge1xuICAgIGlmICghdGhpcy5fb3JnTGlzdCkge1xuICAgICAgdGhpcy5fb3JnTGlzdCA9IHRoaXMuX2V4ZWNDb21tYW5kPFNmZHhPcmdMaXN0PignZm9yY2U6b3JnOmxpc3QnKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX29yZ0xpc3Q7XG4gIH1cblxuICBhc3luYyBnZXRDb25uZWN0aW9uTmFtZXMoKSB7XG4gICAgY29uc3QgeyBub25TY3JhdGNoT3Jncywgc2NyYXRjaE9yZ3MgfSA9IGF3YWl0IHRoaXMuX2dldE9yZ0xpc3QoKTtcbiAgICByZXR1cm4gW1xuICAgICAgLi4ubm9uU2NyYXRjaE9yZ3MubWFwKChvKSA9PiBvLmFsaWFzKS5maWx0ZXIoaXNOb3ROdWxsT3JVbmRlZmluZWQpLFxuICAgICAgLi4uc2NyYXRjaE9yZ3MubWFwKChvKSA9PiBvLmFsaWFzKS5maWx0ZXIoaXNOb3ROdWxsT3JVbmRlZmluZWQpLFxuICAgICAgLi4ubm9uU2NyYXRjaE9yZ3MubWFwKChvKSA9PiBvLnVzZXJuYW1lKSxcbiAgICAgIC4uLnNjcmF0Y2hPcmdzLm1hcCgobykgPT4gby51c2VybmFtZSksXG4gICAgXTtcbiAgfVxuXG4gIGFzeW5jIGdldENvbm5lY3Rpb248UyBleHRlbmRzIFNjaGVtYSA9IFNjaGVtYT4obmFtZT86IHN0cmluZykge1xuICAgIGNvbnN0IGNvbmZpZyA9IGF3YWl0IHRoaXMuZ2V0Q29ubmVjdGlvbkNvbmZpZyhuYW1lKTtcbiAgICByZXR1cm4gY29uZmlnID8gbmV3IENvbm5lY3Rpb248Uz4oY29uZmlnKSA6IG51bGw7XG4gIH1cblxuICBhc3luYyBfZ2V0T3JnSW5mbyh1c2VybmFtZT86IHN0cmluZykge1xuICAgIGNvbnN0IG9wdGlvbnMgPSB1c2VybmFtZSA/IHsgdTogdXNlcm5hbWUgfSA6IHt9O1xuICAgIGlmICghdXNlcm5hbWUgfHwgIXRoaXMuX29yZ0luZm9NYXBbdXNlcm5hbWVdKSB7XG4gICAgICBjb25zdCBwT3JnSW5mbyA9IHRoaXMuX2V4ZWNDb21tYW5kPFNmZHhPcmdJbmZvPihcbiAgICAgICAgJ2ZvcmNlOm9yZzpkaXNwbGF5JyxcbiAgICAgICAgb3B0aW9ucyxcbiAgICAgICk7XG4gICAgICB0aGlzLl9tZW1vT3JnSW5mbyhwT3JnSW5mbywgdXNlcm5hbWUpO1xuICAgIH1cbiAgICBjb25zdCBvcmdJbmZvID0gdXNlcm5hbWVcbiAgICAgID8gdGhpcy5fb3JnSW5mb01hcFt1c2VybmFtZV1cbiAgICAgIDogdGhpcy5fZGVmYXVsdE9yZ0luZm87XG4gICAgaWYgKCFvcmdJbmZvKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ25vIG9yZ2luZm8gZm91bmQnKTtcbiAgICB9XG4gICAgcmV0dXJuIG9yZ0luZm87XG4gIH1cblxuICBfbWVtb09yZ0luZm8ocE9yZ0luZm86IFByb21pc2U8U2ZkeE9yZ0luZm8+LCB1c2VybmFtZT86IHN0cmluZykge1xuICAgIGNvbnN0IHBPcmdJbmZvXyA9IHBPcmdJbmZvLnRoZW4oKG9yZ0luZm8pID0+IHtcbiAgICAgIHRoaXMuX29yZ0luZm9NYXBbb3JnSW5mby51c2VybmFtZV0gPSBwT3JnSW5mb187XG4gICAgICBpZiAob3JnSW5mby5hbGlhcykge1xuICAgICAgICB0aGlzLl9vcmdJbmZvTWFwW29yZ0luZm8uYWxpYXNdID0gcE9yZ0luZm9fO1xuICAgICAgfVxuICAgICAgcmV0dXJuIG9yZ0luZm87XG4gICAgfSk7XG4gICAgaWYgKHVzZXJuYW1lKSB7XG4gICAgICB0aGlzLl9vcmdJbmZvTWFwW3VzZXJuYW1lXSA9IHBPcmdJbmZvXztcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5fZGVmYXVsdE9yZ0luZm8gPSBwT3JnSW5mb187XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgZ2V0Q29ubmVjdGlvbkNvbmZpZyhuYW1lPzogc3RyaW5nKSB7XG4gICAgY29uc3Qgb3JnSW5mbyA9IGF3YWl0IHRoaXMuX2dldE9yZ0luZm8obmFtZSk7XG4gICAgaWYgKCFvcmdJbmZvKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgY29uc3QgeyBhY2Nlc3NUb2tlbiwgaW5zdGFuY2VVcmwsIGxvZ2luVXJsIH0gPSBvcmdJbmZvO1xuICAgIHJldHVybiB7IGFjY2Vzc1Rva2VuLCBpbnN0YW5jZVVybCwgbG9naW5VcmwgfTtcbiAgfVxuXG4gIGFzeW5jIHNhdmVDb25uZWN0aW9uQ29uZmlnKF9uYW1lOiBzdHJpbmcsIF9jb25uQ29uZmlnOiBDb25uZWN0aW9uQ29uZmlnKSB7XG4gICAgLy8gbm90aGluZyB0byBkb1xuICB9XG5cbiAgYXN5bmMgc2V0RGVmYXVsdENvbm5lY3Rpb24oX25hbWU6IHN0cmluZykge1xuICAgIC8vIG5vdGhpbmcgdG8gZG9cbiAgfVxuXG4gIGFzeW5jIHJlbW92ZUNvbm5lY3Rpb25Db25maWcobmFtZTogc3RyaW5nKSB7XG4gICAgYXdhaXQgdGhpcy5fZXhlY0NvbW1hbmQoJ2ZvcmNlOm9yZzpkZWxldGUnLCB7IHU6IG5hbWUgfSk7XG4gIH1cblxuICBhc3luYyBnZXRDbGllbnRDb25maWcoX25hbWU6IHN0cmluZykge1xuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAgYXN5bmMgZ2V0Q2xpZW50TmFtZXMoKSB7XG4gICAgcmV0dXJuIFtdO1xuICB9XG5cbiAgYXN5bmMgcmVnaXN0ZXJDbGllbnRDb25maWcoX25hbWU6IHN0cmluZywgX2NsaWVudENvbmZpZzogQ2xpZW50Q29uZmlnKSB7XG4gICAgLy8gbm90aGluZyB0byBkb1xuICB9XG59XG4iXX0=