import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = _Reflect$construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !_Reflect$construct) return false; if (_Reflect$construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(_Reflect$construct(Date, [], function () {})); return true; } catch (e) { return false; } }

import { BaseRegistry } from './base';
/**
 *
 */

export var EmptyRegistry = /*#__PURE__*/function (_BaseRegistry) {
  _inherits(EmptyRegistry, _BaseRegistry);

  var _super = _createSuper(EmptyRegistry);

  function EmptyRegistry() {
    _classCallCheck(this, EmptyRegistry);

    return _super.apply(this, arguments);
  }

  _createClass(EmptyRegistry, [{
    key: "_saveConfig",
    value: function _saveConfig() {// ignore all call requests
    }
  }]);

  return EmptyRegistry;
}(BaseRegistry);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9yZWdpc3RyeS9lbXB0eS50cyJdLCJuYW1lcyI6WyJCYXNlUmVnaXN0cnkiLCJFbXB0eVJlZ2lzdHJ5Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUFBLFNBQVNBLFlBQVQsUUFBNkIsUUFBN0I7QUFFQTtBQUNBO0FBQ0E7O0FBQ0EsV0FBYUMsYUFBYjtBQUFBOztBQUFBOztBQUFBO0FBQUE7O0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUEsa0NBQ2dCLENBQ1o7QUFDRDtBQUhIOztBQUFBO0FBQUEsRUFBbUNELFlBQW5DIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQmFzZVJlZ2lzdHJ5IH0gZnJvbSAnLi9iYXNlJztcblxuLyoqXG4gKlxuICovXG5leHBvcnQgY2xhc3MgRW1wdHlSZWdpc3RyeSBleHRlbmRzIEJhc2VSZWdpc3RyeSB7XG4gIF9zYXZlQ29uZmlnKCkge1xuICAgIC8vIGlnbm9yZSBhbGwgY2FsbCByZXF1ZXN0c1xuICB9XG59XG4iXX0=