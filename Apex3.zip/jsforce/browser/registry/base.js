import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _objectWithoutProperties from "@babel/runtime-corejs3/helpers/objectWithoutProperties";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import "regenerator-runtime/runtime";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context10; _forEachInstanceProperty(_context10 = ownKeys(Object(source), true)).call(_context10, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context11; _forEachInstanceProperty(_context11 = ownKeys(Object(source))).call(_context11, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

import Connection from '../connection';

/**
 *
 */
export var BaseRegistry = /*#__PURE__*/function () {
  function BaseRegistry() {
    _classCallCheck(this, BaseRegistry);

    _defineProperty(this, "_registryConfig", {});
  }

  _createClass(BaseRegistry, [{
    key: "_saveConfig",
    value: function _saveConfig() {
      throw new Error('_saveConfig must be implemented in subclass');
    }
  }, {
    key: "_getClients",
    value: function _getClients() {
      return this._registryConfig.clients || (this._registryConfig.clients = {});
    }
  }, {
    key: "_getConnections",
    value: function _getConnections() {
      return this._registryConfig.connections || (this._registryConfig.connections = {});
    }
  }, {
    key: "getConnectionNames",
    value: function () {
      var _getConnectionNames = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee() {
        return _regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                return _context.abrupt("return", _Object$keys(this._getConnections()));

              case 1:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function getConnectionNames() {
        return _getConnectionNames.apply(this, arguments);
      }

      return getConnectionNames;
    }()
  }, {
    key: "getConnection",
    value: function () {
      var _getConnection = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee2(name) {
        var config;
        return _regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return this.getConnectionConfig(name);

              case 2:
                config = _context2.sent;
                return _context2.abrupt("return", config ? new Connection(config) : null);

              case 4:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      function getConnection(_x) {
        return _getConnection.apply(this, arguments);
      }

      return getConnection;
    }()
  }, {
    key: "getConnectionConfig",
    value: function () {
      var _getConnectionConfig = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee3(name) {
        var connections, connConfig, client, connConfig_;
        return _regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                if (!name) {
                  name = this._registryConfig['default'];
                }

                connections = this._getConnections();
                connConfig = name ? connections[name] : undefined;

                if (connConfig) {
                  _context3.next = 5;
                  break;
                }

                return _context3.abrupt("return", null);

              case 5:
                client = connConfig.client, connConfig_ = _objectWithoutProperties(connConfig, ["client"]);

                if (!client) {
                  _context3.next = 18;
                  break;
                }

                _context3.t0 = _objectSpread;
                _context3.t1 = _objectSpread({}, connConfig_);
                _context3.t2 = {};
                _context3.t3 = _objectSpread;
                _context3.t4 = {};
                _context3.next = 14;
                return this.getClientConfig(client);

              case 14:
                _context3.t5 = _context3.sent;
                _context3.t6 = (0, _context3.t3)(_context3.t4, _context3.t5);
                _context3.t7 = {
                  oauth2: _context3.t6
                };
                return _context3.abrupt("return", (0, _context3.t0)(_context3.t1, _context3.t2, _context3.t7));

              case 18:
                return _context3.abrupt("return", connConfig_);

              case 19:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      function getConnectionConfig(_x2) {
        return _getConnectionConfig.apply(this, arguments);
      }

      return getConnectionConfig;
    }()
  }, {
    key: "saveConnectionConfig",
    value: function () {
      var _saveConnectionConfig = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee4(name, connConfig) {
        var connections, oauth2, connConfig_, persistConnConfig, clientName;
        return _regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                connections = this._getConnections();
                oauth2 = connConfig.oauth2, connConfig_ = _objectWithoutProperties(connConfig, ["oauth2"]);
                persistConnConfig = connConfig_;

                if (oauth2) {
                  clientName = this._findClientName(oauth2);

                  if (clientName) {
                    persistConnConfig = _objectSpread(_objectSpread({}, persistConnConfig), {}, {
                      client: clientName
                    });
                  }

                  delete connConfig.oauth2;
                }

                connections[name] = persistConnConfig;

                this._saveConfig();

              case 6:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      function saveConnectionConfig(_x3, _x4) {
        return _saveConnectionConfig.apply(this, arguments);
      }

      return saveConnectionConfig;
    }()
  }, {
    key: "_findClientName",
    value: function _findClientName(_ref) {
      var clientId = _ref.clientId,
          loginUrl = _ref.loginUrl;

      var clients = this._getClients();

      for (var _i = 0, _Object$keys2 = _Object$keys(clients); _i < _Object$keys2.length; _i++) {
        var name = _Object$keys2[_i];
        var client = clients[name];

        if (client.clientId === clientId && (client.loginUrl || 'https://login.salesforce.com') === loginUrl) {
          return name;
        }
      }

      return null;
    }
  }, {
    key: "setDefaultConnection",
    value: function () {
      var _setDefaultConnection = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee5(name) {
        return _regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                this._registryConfig['default'] = name;

                this._saveConfig();

              case 2:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));

      function setDefaultConnection(_x5) {
        return _setDefaultConnection.apply(this, arguments);
      }

      return setDefaultConnection;
    }()
  }, {
    key: "removeConnectionConfig",
    value: function () {
      var _removeConnectionConfig = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee6(name) {
        var connections;
        return _regeneratorRuntime.wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                connections = this._getConnections();
                delete connections[name];

                this._saveConfig();

              case 3:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));

      function removeConnectionConfig(_x6) {
        return _removeConnectionConfig.apply(this, arguments);
      }

      return removeConnectionConfig;
    }()
  }, {
    key: "getClientConfig",
    value: function () {
      var _getClientConfig = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee7(name) {
        var clients, clientConfig;
        return _regeneratorRuntime.wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                clients = this._getClients();
                clientConfig = clients[name];
                return _context7.abrupt("return", clientConfig && _objectSpread({}, clientConfig));

              case 3:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7, this);
      }));

      function getClientConfig(_x7) {
        return _getClientConfig.apply(this, arguments);
      }

      return getClientConfig;
    }()
  }, {
    key: "getClientNames",
    value: function () {
      var _getClientNames = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee8() {
        return _regeneratorRuntime.wrap(function _callee8$(_context8) {
          while (1) {
            switch (_context8.prev = _context8.next) {
              case 0:
                return _context8.abrupt("return", _Object$keys(this._getClients()));

              case 1:
              case "end":
                return _context8.stop();
            }
          }
        }, _callee8, this);
      }));

      function getClientNames() {
        return _getClientNames.apply(this, arguments);
      }

      return getClientNames;
    }()
  }, {
    key: "registerClientConfig",
    value: function () {
      var _registerClientConfig = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee9(name, clientConfig) {
        var clients;
        return _regeneratorRuntime.wrap(function _callee9$(_context9) {
          while (1) {
            switch (_context9.prev = _context9.next) {
              case 0:
                clients = this._getClients();
                clients[name] = clientConfig;

                this._saveConfig();

              case 3:
              case "end":
                return _context9.stop();
            }
          }
        }, _callee9, this);
      }));

      function registerClientConfig(_x8, _x9) {
        return _registerClientConfig.apply(this, arguments);
      }

      return registerClientConfig;
    }()
  }]);

  return BaseRegistry;
}();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9yZWdpc3RyeS9iYXNlLnRzIl0sIm5hbWVzIjpbIkNvbm5lY3Rpb24iLCJCYXNlUmVnaXN0cnkiLCJFcnJvciIsIl9yZWdpc3RyeUNvbmZpZyIsImNsaWVudHMiLCJjb25uZWN0aW9ucyIsIl9nZXRDb25uZWN0aW9ucyIsIm5hbWUiLCJnZXRDb25uZWN0aW9uQ29uZmlnIiwiY29uZmlnIiwiY29ubkNvbmZpZyIsInVuZGVmaW5lZCIsImNsaWVudCIsImNvbm5Db25maWdfIiwiZ2V0Q2xpZW50Q29uZmlnIiwib2F1dGgyIiwicGVyc2lzdENvbm5Db25maWciLCJjbGllbnROYW1lIiwiX2ZpbmRDbGllbnROYW1lIiwiX3NhdmVDb25maWciLCJjbGllbnRJZCIsImxvZ2luVXJsIiwiX2dldENsaWVudHMiLCJjbGllbnRDb25maWciXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsT0FBT0EsVUFBUCxNQUF1QixlQUF2Qjs7QUFVQTtBQUNBO0FBQ0E7QUFDQSxXQUFhQyxZQUFiO0FBQUE7QUFBQTs7QUFBQSw2Q0FDb0MsRUFEcEM7QUFBQTs7QUFBQTtBQUFBO0FBQUEsa0NBR2dCO0FBQ1osWUFBTSxJQUFJQyxLQUFKLENBQVUsNkNBQVYsQ0FBTjtBQUNEO0FBTEg7QUFBQTtBQUFBLGtDQU9nQjtBQUNaLGFBQU8sS0FBS0MsZUFBTCxDQUFxQkMsT0FBckIsS0FBaUMsS0FBS0QsZUFBTCxDQUFxQkMsT0FBckIsR0FBK0IsRUFBaEUsQ0FBUDtBQUNEO0FBVEg7QUFBQTtBQUFBLHNDQVdvQjtBQUNoQixhQUNFLEtBQUtELGVBQUwsQ0FBcUJFLFdBQXJCLEtBQ0MsS0FBS0YsZUFBTCxDQUFxQkUsV0FBckIsR0FBbUMsRUFEcEMsQ0FERjtBQUlEO0FBaEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpREFtQlcsYUFBWSxLQUFLQyxlQUFMLEVBQVosQ0FuQlg7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzR0FzQmlEQyxJQXRCakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF1QnlCLEtBQUtDLG1CQUFMLENBQXlCRCxJQUF6QixDQXZCekI7O0FBQUE7QUF1QlVFLGdCQUFBQSxNQXZCVjtBQUFBLGtEQXdCV0EsTUFBTSxHQUFHLElBQUlULFVBQUosQ0FBa0JTLE1BQWxCLENBQUgsR0FBK0IsSUF4QmhEOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEdBMkI0QkYsSUEzQjVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQTRCSSxvQkFBSSxDQUFDQSxJQUFMLEVBQVc7QUFDVEEsa0JBQUFBLElBQUksR0FBRyxLQUFLSixlQUFMLENBQXFCLFNBQXJCLENBQVA7QUFDRDs7QUFDS0UsZ0JBQUFBLFdBL0JWLEdBK0J3QixLQUFLQyxlQUFMLEVBL0J4QjtBQWdDVUksZ0JBQUFBLFVBaENWLEdBZ0N1QkgsSUFBSSxHQUFHRixXQUFXLENBQUNFLElBQUQsQ0FBZCxHQUF1QkksU0FoQ2xEOztBQUFBLG9CQWlDU0QsVUFqQ1Q7QUFBQTtBQUFBO0FBQUE7O0FBQUEsa0RBa0NhLElBbENiOztBQUFBO0FBb0NZRSxnQkFBQUEsTUFwQ1osR0FvQ3VDRixVQXBDdkMsQ0FvQ1lFLE1BcENaLEVBb0N1QkMsV0FwQ3ZCLDRCQW9DdUNILFVBcEN2Qzs7QUFBQSxxQkFxQ1FFLE1BckNSO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEsaURBdUNXQyxXQXZDWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBd0M0QixLQUFLQyxlQUFMLENBQXFCRixNQUFyQixDQXhDNUI7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUF3Q1FHLGtCQUFBQSxNQXhDUjtBQUFBO0FBQUE7O0FBQUE7QUFBQSxrREEyQ1dGLFdBM0NYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkdBOEM2Qk4sSUE5QzdCLEVBOEMyQ0csVUE5QzNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQStDVUwsZ0JBQUFBLFdBL0NWLEdBK0N3QixLQUFLQyxlQUFMLEVBL0N4QjtBQWdEWVMsZ0JBQUFBLE1BaERaLEdBZ0R1Q0wsVUFoRHZDLENBZ0RZSyxNQWhEWixFQWdEdUJGLFdBaER2Qiw0QkFnRHVDSCxVQWhEdkM7QUFpRFFNLGdCQUFBQSxpQkFqRFIsR0FpRHFESCxXQWpEckQ7O0FBa0RJLG9CQUFJRSxNQUFKLEVBQVk7QUFDSkUsa0JBQUFBLFVBREksR0FDUyxLQUFLQyxlQUFMLENBQXFCSCxNQUFyQixDQURUOztBQUVWLHNCQUFJRSxVQUFKLEVBQWdCO0FBQ2RELG9CQUFBQSxpQkFBaUIsbUNBQVFBLGlCQUFSO0FBQTJCSixzQkFBQUEsTUFBTSxFQUFFSztBQUFuQyxzQkFBakI7QUFDRDs7QUFDRCx5QkFBT1AsVUFBVSxDQUFDSyxNQUFsQjtBQUNEOztBQUNEVixnQkFBQUEsV0FBVyxDQUFDRSxJQUFELENBQVgsR0FBb0JTLGlCQUFwQjs7QUFDQSxxQkFBS0csV0FBTDs7QUExREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMENBNkR3RDtBQUFBLFVBQXBDQyxRQUFvQyxRQUFwQ0EsUUFBb0M7QUFBQSxVQUExQkMsUUFBMEIsUUFBMUJBLFFBQTBCOztBQUNwRCxVQUFNakIsT0FBTyxHQUFHLEtBQUtrQixXQUFMLEVBQWhCOztBQUNBLHVDQUFtQixhQUFZbEIsT0FBWixDQUFuQixtQ0FBeUM7QUFBcEMsWUFBTUcsSUFBSSxvQkFBVjtBQUNILFlBQU1LLE1BQU0sR0FBR1IsT0FBTyxDQUFDRyxJQUFELENBQXRCOztBQUNBLFlBQ0VLLE1BQU0sQ0FBQ1EsUUFBUCxLQUFvQkEsUUFBcEIsSUFDQSxDQUFDUixNQUFNLENBQUNTLFFBQVAsSUFBbUIsOEJBQXBCLE1BQXdEQSxRQUYxRCxFQUdFO0FBQ0EsaUJBQU9kLElBQVA7QUFDRDtBQUNGOztBQUNELGFBQU8sSUFBUDtBQUNEO0FBekVIO0FBQUE7QUFBQTtBQUFBLDZHQTJFNkJBLElBM0U3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBNEVJLHFCQUFLSixlQUFMLENBQXFCLFNBQXJCLElBQWtDSSxJQUFsQzs7QUFDQSxxQkFBS1ksV0FBTDs7QUE3RUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwrR0FnRitCWixJQWhGL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBaUZVRixnQkFBQUEsV0FqRlYsR0FpRndCLEtBQUtDLGVBQUwsRUFqRnhCO0FBa0ZJLHVCQUFPRCxXQUFXLENBQUNFLElBQUQsQ0FBbEI7O0FBQ0EscUJBQUtZLFdBQUw7O0FBbkZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0dBc0Z3QlosSUF0RnhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQXVGVUgsZ0JBQUFBLE9BdkZWLEdBdUZvQixLQUFLa0IsV0FBTCxFQXZGcEI7QUF3RlVDLGdCQUFBQSxZQXhGVixHQXdGeUJuQixPQUFPLENBQUNHLElBQUQsQ0F4RmhDO0FBQUEsa0RBeUZXZ0IsWUFBWSxzQkFBU0EsWUFBVCxDQXpGdkI7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0RBNkZXLGFBQVksS0FBS0QsV0FBTCxFQUFaLENBN0ZYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkdBZ0c2QmYsSUFoRzdCLEVBZ0cyQ2dCLFlBaEczQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFpR1VuQixnQkFBQUEsT0FqR1YsR0FpR29CLEtBQUtrQixXQUFMLEVBakdwQjtBQWtHSWxCLGdCQUFBQSxPQUFPLENBQUNHLElBQUQsQ0FBUCxHQUFnQmdCLFlBQWhCOztBQUNBLHFCQUFLSixXQUFMOztBQW5HSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgQ29ubmVjdGlvbiBmcm9tICcuLi9jb25uZWN0aW9uJztcbmltcG9ydCB7XG4gIFJlZ2lzdHJ5Q29uZmlnLFxuICBSZWdpc3RyeSxcbiAgQ29ubmVjdGlvbkNvbmZpZyxcbiAgUGVyc2lzdENvbm5lY3Rpb25Db25maWcsXG4gIENsaWVudENvbmZpZyxcbn0gZnJvbSAnLi90eXBlcyc7XG5pbXBvcnQgeyBTY2hlbWEgfSBmcm9tICcuLi90eXBlcyc7XG5cbi8qKlxuICpcbiAqL1xuZXhwb3J0IGNsYXNzIEJhc2VSZWdpc3RyeSBpbXBsZW1lbnRzIFJlZ2lzdHJ5IHtcbiAgX3JlZ2lzdHJ5Q29uZmlnOiBSZWdpc3RyeUNvbmZpZyA9IHt9O1xuXG4gIF9zYXZlQ29uZmlnKCkge1xuICAgIHRocm93IG5ldyBFcnJvcignX3NhdmVDb25maWcgbXVzdCBiZSBpbXBsZW1lbnRlZCBpbiBzdWJjbGFzcycpO1xuICB9XG5cbiAgX2dldENsaWVudHMoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3JlZ2lzdHJ5Q29uZmlnLmNsaWVudHMgfHwgKHRoaXMuX3JlZ2lzdHJ5Q29uZmlnLmNsaWVudHMgPSB7fSk7XG4gIH1cblxuICBfZ2V0Q29ubmVjdGlvbnMoKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIHRoaXMuX3JlZ2lzdHJ5Q29uZmlnLmNvbm5lY3Rpb25zIHx8XG4gICAgICAodGhpcy5fcmVnaXN0cnlDb25maWcuY29ubmVjdGlvbnMgPSB7fSlcbiAgICApO1xuICB9XG5cbiAgYXN5bmMgZ2V0Q29ubmVjdGlvbk5hbWVzKCkge1xuICAgIHJldHVybiBPYmplY3Qua2V5cyh0aGlzLl9nZXRDb25uZWN0aW9ucygpKTtcbiAgfVxuXG4gIGFzeW5jIGdldENvbm5lY3Rpb248UyBleHRlbmRzIFNjaGVtYSA9IFNjaGVtYT4obmFtZTogc3RyaW5nKSB7XG4gICAgY29uc3QgY29uZmlnID0gYXdhaXQgdGhpcy5nZXRDb25uZWN0aW9uQ29uZmlnKG5hbWUpO1xuICAgIHJldHVybiBjb25maWcgPyBuZXcgQ29ubmVjdGlvbjxTPihjb25maWcpIDogbnVsbDtcbiAgfVxuXG4gIGFzeW5jIGdldENvbm5lY3Rpb25Db25maWcobmFtZT86IHN0cmluZykge1xuICAgIGlmICghbmFtZSkge1xuICAgICAgbmFtZSA9IHRoaXMuX3JlZ2lzdHJ5Q29uZmlnWydkZWZhdWx0J107XG4gICAgfVxuICAgIGNvbnN0IGNvbm5lY3Rpb25zID0gdGhpcy5fZ2V0Q29ubmVjdGlvbnMoKTtcbiAgICBjb25zdCBjb25uQ29uZmlnID0gbmFtZSA/IGNvbm5lY3Rpb25zW25hbWVdIDogdW5kZWZpbmVkO1xuICAgIGlmICghY29ubkNvbmZpZykge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGNvbnN0IHsgY2xpZW50LCAuLi5jb25uQ29uZmlnXyB9ID0gY29ubkNvbmZpZztcbiAgICBpZiAoY2xpZW50KSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICAuLi5jb25uQ29uZmlnXyxcbiAgICAgICAgb2F1dGgyOiB7IC4uLihhd2FpdCB0aGlzLmdldENsaWVudENvbmZpZyhjbGllbnQpKSB9LFxuICAgICAgfTtcbiAgICB9XG4gICAgcmV0dXJuIGNvbm5Db25maWdfO1xuICB9XG5cbiAgYXN5bmMgc2F2ZUNvbm5lY3Rpb25Db25maWcobmFtZTogc3RyaW5nLCBjb25uQ29uZmlnOiBDb25uZWN0aW9uQ29uZmlnKSB7XG4gICAgY29uc3QgY29ubmVjdGlvbnMgPSB0aGlzLl9nZXRDb25uZWN0aW9ucygpO1xuICAgIGNvbnN0IHsgb2F1dGgyLCAuLi5jb25uQ29uZmlnXyB9ID0gY29ubkNvbmZpZztcbiAgICBsZXQgcGVyc2lzdENvbm5Db25maWc6IFBlcnNpc3RDb25uZWN0aW9uQ29uZmlnID0gY29ubkNvbmZpZ187XG4gICAgaWYgKG9hdXRoMikge1xuICAgICAgY29uc3QgY2xpZW50TmFtZSA9IHRoaXMuX2ZpbmRDbGllbnROYW1lKG9hdXRoMik7XG4gICAgICBpZiAoY2xpZW50TmFtZSkge1xuICAgICAgICBwZXJzaXN0Q29ubkNvbmZpZyA9IHsgLi4ucGVyc2lzdENvbm5Db25maWcsIGNsaWVudDogY2xpZW50TmFtZSB9O1xuICAgICAgfVxuICAgICAgZGVsZXRlIGNvbm5Db25maWcub2F1dGgyO1xuICAgIH1cbiAgICBjb25uZWN0aW9uc1tuYW1lXSA9IHBlcnNpc3RDb25uQ29uZmlnO1xuICAgIHRoaXMuX3NhdmVDb25maWcoKTtcbiAgfVxuXG4gIF9maW5kQ2xpZW50TmFtZSh7IGNsaWVudElkLCBsb2dpblVybCB9OiBDbGllbnRDb25maWcpIHtcbiAgICBjb25zdCBjbGllbnRzID0gdGhpcy5fZ2V0Q2xpZW50cygpO1xuICAgIGZvciAoY29uc3QgbmFtZSBvZiBPYmplY3Qua2V5cyhjbGllbnRzKSkge1xuICAgICAgY29uc3QgY2xpZW50ID0gY2xpZW50c1tuYW1lXTtcbiAgICAgIGlmIChcbiAgICAgICAgY2xpZW50LmNsaWVudElkID09PSBjbGllbnRJZCAmJlxuICAgICAgICAoY2xpZW50LmxvZ2luVXJsIHx8ICdodHRwczovL2xvZ2luLnNhbGVzZm9yY2UuY29tJykgPT09IGxvZ2luVXJsXG4gICAgICApIHtcbiAgICAgICAgcmV0dXJuIG5hbWU7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAgYXN5bmMgc2V0RGVmYXVsdENvbm5lY3Rpb24obmFtZTogc3RyaW5nKSB7XG4gICAgdGhpcy5fcmVnaXN0cnlDb25maWdbJ2RlZmF1bHQnXSA9IG5hbWU7XG4gICAgdGhpcy5fc2F2ZUNvbmZpZygpO1xuICB9XG5cbiAgYXN5bmMgcmVtb3ZlQ29ubmVjdGlvbkNvbmZpZyhuYW1lOiBzdHJpbmcpIHtcbiAgICBjb25zdCBjb25uZWN0aW9ucyA9IHRoaXMuX2dldENvbm5lY3Rpb25zKCk7XG4gICAgZGVsZXRlIGNvbm5lY3Rpb25zW25hbWVdO1xuICAgIHRoaXMuX3NhdmVDb25maWcoKTtcbiAgfVxuXG4gIGFzeW5jIGdldENsaWVudENvbmZpZyhuYW1lOiBzdHJpbmcpIHtcbiAgICBjb25zdCBjbGllbnRzID0gdGhpcy5fZ2V0Q2xpZW50cygpO1xuICAgIGNvbnN0IGNsaWVudENvbmZpZyA9IGNsaWVudHNbbmFtZV07XG4gICAgcmV0dXJuIGNsaWVudENvbmZpZyAmJiB7IC4uLmNsaWVudENvbmZpZyB9O1xuICB9XG5cbiAgYXN5bmMgZ2V0Q2xpZW50TmFtZXMoKSB7XG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKHRoaXMuX2dldENsaWVudHMoKSk7XG4gIH1cblxuICBhc3luYyByZWdpc3RlckNsaWVudENvbmZpZyhuYW1lOiBzdHJpbmcsIGNsaWVudENvbmZpZzogQ2xpZW50Q29uZmlnKSB7XG4gICAgY29uc3QgY2xpZW50cyA9IHRoaXMuX2dldENsaWVudHMoKTtcbiAgICBjbGllbnRzW25hbWVdID0gY2xpZW50Q29uZmlnO1xuICAgIHRoaXMuX3NhdmVDb25maWcoKTtcbiAgfVxufVxuIl19