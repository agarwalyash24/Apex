import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import "core-js/modules/es.array.join";
import "core-js/modules/es.number.constructor";
import "core-js/modules/es.regexp.exec";
import "core-js/modules/es.string.replace";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import "regenerator-runtime/runtime";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _assertThisInitialized from "@babel/runtime-corejs3/helpers/assertThisInitialized";
import _get from "@babel/runtime-corejs3/helpers/get";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _reduceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/reduce";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = _Reflect$construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !_Reflect$construct) return false; if (_Reflect$construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(_Reflect$construct(Date, [], function () {})); return true; } catch (e) { return false; } }

function ownKeys(object, enumerableOnly) { var keys = _Object$keys(object); if (_Object$getOwnPropertySymbols) { var symbols = _Object$getOwnPropertySymbols(object); if (enumerableOnly) symbols = _filterInstanceProperty(symbols).call(symbols, function (sym) { return _Object$getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context5; _forEachInstanceProperty(_context5 = ownKeys(Object(source), true)).call(_context5, function (key) { _defineProperty(target, key, source[key]); }); } else if (_Object$getOwnPropertyDescriptors) { _Object$defineProperties(target, _Object$getOwnPropertyDescriptors(source)); } else { var _context6; _forEachInstanceProperty(_context6 = ownKeys(Object(source))).call(_context6, function (key) { _Object$defineProperty(target, key, _Object$getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 * @file Manages method call to SOAP endpoint
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import HttpApi from './http-api';
import { isMapObject, isObject } from './util/function';
/**
 *
 */

function getPropsSchema(schema, schemaDict) {
  if (schema.extends && schemaDict[schema.extends]) {
    var extendSchema = schemaDict[schema.extends];
    return _objectSpread(_objectSpread({}, getPropsSchema(extendSchema, schemaDict)), schema.props);
  }

  return schema.props;
}

function isNillValue(value) {
  return value == null || isMapObject(value) && isMapObject(value.$) && value.$['xsi:nil'] === 'true';
}
/**
 *
 */


export function castTypeUsingSchema(value, schema) {
  var schemaDict = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

  if (_Array$isArray(schema)) {
    var _context;

    var nillable = schema.length === 2 && schema[0] === '?';
    var schema_ = nillable ? schema[1] : schema[0];

    if (value == null) {
      return nillable ? null : [];
    }

    return _mapInstanceProperty(_context = _Array$isArray(value) ? value : [value]).call(_context, function (v) {
      return castTypeUsingSchema(v, schema_, schemaDict);
    });
  } else if (isMapObject(schema)) {
    var _context2;

    // if schema is Schema Definition, not schema element
    if ('type' in schema && 'props' in schema && isMapObject(schema.props)) {
      var props = getPropsSchema(schema, schemaDict);
      return castTypeUsingSchema(value, props, schemaDict);
    }

    var _nillable = ('?' in schema);

    var _schema_ = '?' in schema ? schema['?'] : schema;

    if (_nillable && isNillValue(value)) {
      return null;
    }

    var obj = isMapObject(value) ? value : {};
    return _reduceInstanceProperty(_context2 = _Object$keys(_schema_)).call(_context2, function (o, k) {
      var s = _schema_[k];
      var v = obj[k];
      var nillable = _Array$isArray(s) && s.length === 2 && s[0] === '?' || isMapObject(s) && '?' in s || typeof s === 'string' && s[0] === '?';

      if (typeof v === 'undefined' && nillable) {
        return o;
      }

      return _objectSpread(_objectSpread({}, o), {}, _defineProperty({}, k, castTypeUsingSchema(v, s, schemaDict)));
    }, obj);
  } else {
    var _nillable2 = typeof schema === 'string' && schema[0] === '?';

    var type = typeof schema === 'string' ? _nillable2 ? schema.substring(1) : schema : 'any';

    switch (type) {
      case 'string':
        return isNillValue(value) ? _nillable2 ? null : '' : String(value);

      case 'number':
        return isNillValue(value) ? _nillable2 ? null : 0 : Number(value);

      case 'boolean':
        return isNillValue(value) ? _nillable2 ? null : false : value === 'true';

      case 'null':
        return null;

      default:
        {
          if (schemaDict[type]) {
            var cvalue = castTypeUsingSchema(value, schemaDict[type], schemaDict);
            var isEmpty = isMapObject(cvalue) && _Object$keys(cvalue).length === 0;
            return isEmpty && _nillable2 ? null : cvalue;
          }

          return value;
        }
    }
  }
}
/**
 * @private
 */

function lookupValue(obj, propRegExps) {
  var regexp = propRegExps.shift();

  if (!regexp) {
    return obj;
  }

  if (isMapObject(obj)) {
    for (var _i = 0, _Object$keys2 = _Object$keys(obj); _i < _Object$keys2.length; _i++) {
      var prop = _Object$keys2[_i];

      if (regexp.test(prop)) {
        return lookupValue(obj[prop], propRegExps);
      }
    }

    return null;
  }
}
/**
 * @private
 */


function toXML(name, value) {
  if (isObject(name)) {
    value = name;
    name = null;
  }

  if (_Array$isArray(value)) {
    return _mapInstanceProperty(value).call(value, function (v) {
      return toXML(name, v);
    }).join('');
  } else {
    var attrs = [];
    var elems = [];

    if (isMapObject(value)) {
      for (var _i2 = 0, _Object$keys3 = _Object$keys(value); _i2 < _Object$keys3.length; _i2++) {
        var k = _Object$keys3[_i2];
        var v = value[k];

        if (k[0] === '@') {
          var kk = k.substring(1);
          attrs.push(kk + '="' + v + '"');
        } else {
          elems.push(toXML(k, v));
        }
      }

      value = elems.join('');
    } else {
      value = String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
    }

    var startTag = name ? '<' + name + (attrs.length > 0 ? ' ' + attrs.join(' ') : '') + '>' : '';
    var endTag = name ? '</' + name + '>' : '';
    return startTag + value + endTag;
  }
}
/**
 *
 */


/**
 * Class for SOAP endpoint of Salesforce
 *
 * @protected
 * @class
 * @constructor
 * @param {Connection} conn - Connection instance
 * @param {Object} options - SOAP endpoint setting options
 * @param {String} options.endpointUrl - SOAP endpoint URL
 * @param {String} [options.xmlns] - XML namespace for method call (default is "urn:partner.soap.sforce.com")
 */
export var SOAP = /*#__PURE__*/function (_HttpApi) {
  _inherits(SOAP, _HttpApi);

  var _super = _createSuper(SOAP);

  function SOAP(conn, options) {
    var _this;

    _classCallCheck(this, SOAP);

    _this = _super.call(this, conn, options);

    _defineProperty(_assertThisInitialized(_this), "_endpointUrl", void 0);

    _defineProperty(_assertThisInitialized(_this), "_xmlns", void 0);

    _this._endpointUrl = options.endpointUrl;
    _this._xmlns = options.xmlns || 'urn:partner.soap.sforce.com';
    return _this;
  }
  /**
   * Invoke SOAP call using method and arguments
   */


  _createClass(SOAP, [{
    key: "invoke",
    value: function () {
      var _invoke = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee(method, args, schema, schemaDict) {
        var res;
        return _regeneratorRuntime.wrap(function _callee$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.next = 2;
                return this.request({
                  method: 'POST',
                  url: this._endpointUrl,
                  headers: {
                    'Content-Type': 'text/xml',
                    SOAPAction: '""'
                  },
                  _message: _defineProperty({}, method, args)
                });

              case 2:
                res = _context3.sent;
                return _context3.abrupt("return", schema ? castTypeUsingSchema(res, schema, schemaDict) : res);

              case 4:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee, this);
      }));

      function invoke(_x, _x2, _x3, _x4) {
        return _invoke.apply(this, arguments);
      }

      return invoke;
    }()
    /** @override */

  }, {
    key: "beforeSend",
    value: function beforeSend(request) {
      request.body = this._createEnvelope(request._message);
    }
    /** @override **/

  }, {
    key: "isSessionExpired",
    value: function isSessionExpired(response) {
      return response.statusCode === 500 && /<faultcode>[a-zA-Z]+:INVALID_SESSION_ID<\/faultcode>/.test(response.body);
    }
    /** @override **/

  }, {
    key: "parseError",
    value: function parseError(body) {
      var error = lookupValue(body, [/:Envelope$/, /:Body$/, /:Fault$/]);
      return {
        errorCode: error.faultcode,
        message: error.faultstring
      };
    }
    /** @override **/

  }, {
    key: "getResponseBody",
    value: function () {
      var _getResponseBody = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime.mark(function _callee2(response) {
        var body;
        return _regeneratorRuntime.wrap(function _callee2$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return _get(_getPrototypeOf(SOAP.prototype), "getResponseBody", this).call(this, response);

              case 2:
                body = _context4.sent;
                return _context4.abrupt("return", lookupValue(body, [/:Envelope$/, /:Body$/, /.+/]));

              case 4:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee2, this);
      }));

      function getResponseBody(_x5) {
        return _getResponseBody.apply(this, arguments);
      }

      return getResponseBody;
    }()
    /**
     * @private
     */

  }, {
    key: "_createEnvelope",
    value: function _createEnvelope(message) {
      var header = {};
      var conn = this._conn;

      if (conn.accessToken) {
        header.SessionHeader = {
          sessionId: conn.accessToken
        };
      }

      if (conn._callOptions) {
        header.CallOptions = conn._callOptions;
      }

      return ['<?xml version="1.0" encoding="UTF-8"?>', '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"', ' xmlns:xsd="http://www.w3.org/2001/XMLSchema"', ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">', '<soapenv:Header xmlns="' + this._xmlns + '">', toXML(header), '</soapenv:Header>', '<soapenv:Body xmlns="' + this._xmlns + '">', toXML(message), '</soapenv:Body>', '</soapenv:Envelope>'].join('');
    }
  }]);

  return SOAP;
}(HttpApi);
export default SOAP;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9zb2FwLnRzIl0sIm5hbWVzIjpbIkh0dHBBcGkiLCJpc01hcE9iamVjdCIsImlzT2JqZWN0IiwiZ2V0UHJvcHNTY2hlbWEiLCJzY2hlbWEiLCJzY2hlbWFEaWN0IiwiZXh0ZW5kcyIsImV4dGVuZFNjaGVtYSIsInByb3BzIiwiaXNOaWxsVmFsdWUiLCJ2YWx1ZSIsIiQiLCJjYXN0VHlwZVVzaW5nU2NoZW1hIiwibmlsbGFibGUiLCJsZW5ndGgiLCJzY2hlbWFfIiwidiIsIm9iaiIsIm8iLCJrIiwicyIsInR5cGUiLCJzdWJzdHJpbmciLCJTdHJpbmciLCJOdW1iZXIiLCJjdmFsdWUiLCJpc0VtcHR5IiwibG9va3VwVmFsdWUiLCJwcm9wUmVnRXhwcyIsInJlZ2V4cCIsInNoaWZ0IiwicHJvcCIsInRlc3QiLCJ0b1hNTCIsIm5hbWUiLCJqb2luIiwiYXR0cnMiLCJlbGVtcyIsImtrIiwicHVzaCIsInJlcGxhY2UiLCJzdGFydFRhZyIsImVuZFRhZyIsIlNPQVAiLCJjb25uIiwib3B0aW9ucyIsIl9lbmRwb2ludFVybCIsImVuZHBvaW50VXJsIiwiX3htbG5zIiwieG1sbnMiLCJtZXRob2QiLCJhcmdzIiwicmVxdWVzdCIsInVybCIsImhlYWRlcnMiLCJTT0FQQWN0aW9uIiwiX21lc3NhZ2UiLCJyZXMiLCJib2R5IiwiX2NyZWF0ZUVudmVsb3BlIiwicmVzcG9uc2UiLCJzdGF0dXNDb2RlIiwiZXJyb3IiLCJlcnJvckNvZGUiLCJmYXVsdGNvZGUiLCJtZXNzYWdlIiwiZmF1bHRzdHJpbmciLCJoZWFkZXIiLCJfY29ubiIsImFjY2Vzc1Rva2VuIiwiU2Vzc2lvbkhlYWRlciIsInNlc3Npb25JZCIsIl9jYWxsT3B0aW9ucyIsIkNhbGxPcHRpb25zIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU9BLE9BQVAsTUFBb0IsWUFBcEI7QUFTQSxTQUFTQyxXQUFULEVBQXNCQyxRQUF0QixRQUFzQyxpQkFBdEM7QUFFQTtBQUNBO0FBQ0E7O0FBQ0EsU0FBU0MsY0FBVCxDQUNFQyxNQURGLEVBRUVDLFVBRkYsRUFHMEI7QUFDeEIsTUFBSUQsTUFBTSxDQUFDRSxPQUFQLElBQWtCRCxVQUFVLENBQUNELE1BQU0sQ0FBQ0UsT0FBUixDQUFoQyxFQUFrRDtBQUNoRCxRQUFNQyxZQUFZLEdBQUdGLFVBQVUsQ0FBQ0QsTUFBTSxDQUFDRSxPQUFSLENBQS9CO0FBQ0EsMkNBQ0tILGNBQWMsQ0FBQ0ksWUFBRCxFQUFlRixVQUFmLENBRG5CLEdBRUtELE1BQU0sQ0FBQ0ksS0FGWjtBQUlEOztBQUNELFNBQU9KLE1BQU0sQ0FBQ0ksS0FBZDtBQUNEOztBQUVELFNBQVNDLFdBQVQsQ0FBcUJDLEtBQXJCLEVBQXFDO0FBQ25DLFNBQ0VBLEtBQUssSUFBSSxJQUFULElBQ0NULFdBQVcsQ0FBQ1MsS0FBRCxDQUFYLElBQ0NULFdBQVcsQ0FBQ1MsS0FBSyxDQUFDQyxDQUFQLENBRFosSUFFQ0QsS0FBSyxDQUFDQyxDQUFOLENBQVEsU0FBUixNQUF1QixNQUozQjtBQU1EO0FBRUQ7QUFDQTtBQUNBOzs7QUFDQSxPQUFPLFNBQVNDLG1CQUFULENBQ0xGLEtBREssRUFFTE4sTUFGSyxFQUlBO0FBQUEsTUFETEMsVUFDSyx1RUFEMkMsRUFDM0M7O0FBQ0wsTUFBSSxlQUFjRCxNQUFkLENBQUosRUFBMkI7QUFBQTs7QUFDekIsUUFBTVMsUUFBUSxHQUFHVCxNQUFNLENBQUNVLE1BQVAsS0FBa0IsQ0FBbEIsSUFBdUJWLE1BQU0sQ0FBQyxDQUFELENBQU4sS0FBYyxHQUF0RDtBQUNBLFFBQU1XLE9BQU8sR0FBR0YsUUFBUSxHQUFHVCxNQUFNLENBQUMsQ0FBRCxDQUFULEdBQWVBLE1BQU0sQ0FBQyxDQUFELENBQTdDOztBQUNBLFFBQUlNLEtBQUssSUFBSSxJQUFiLEVBQW1CO0FBQ2pCLGFBQU9HLFFBQVEsR0FBRyxJQUFILEdBQVUsRUFBekI7QUFDRDs7QUFDRCxXQUFPLGdDQUFDLGVBQWNILEtBQWQsSUFBdUJBLEtBQXZCLEdBQStCLENBQUNBLEtBQUQsQ0FBaEMsaUJBQTZDLFVBQUNNLENBQUQ7QUFBQSxhQUNsREosbUJBQW1CLENBQUNJLENBQUQsRUFBSUQsT0FBSixFQUFhVixVQUFiLENBRCtCO0FBQUEsS0FBN0MsQ0FBUDtBQUdELEdBVEQsTUFTTyxJQUFJSixXQUFXLENBQUNHLE1BQUQsQ0FBZixFQUF5QjtBQUFBOztBQUM5QjtBQUNBLFFBQUksVUFBVUEsTUFBVixJQUFvQixXQUFXQSxNQUEvQixJQUF5Q0gsV0FBVyxDQUFDRyxNQUFNLENBQUNJLEtBQVIsQ0FBeEQsRUFBd0U7QUFDdEUsVUFBTUEsS0FBSyxHQUFHTCxjQUFjLENBQUNDLE1BQUQsRUFBMEJDLFVBQTFCLENBQTVCO0FBQ0EsYUFBT08sbUJBQW1CLENBQUNGLEtBQUQsRUFBUUYsS0FBUixFQUFlSCxVQUFmLENBQTFCO0FBQ0Q7O0FBQ0QsUUFBTVEsU0FBUSxJQUFHLE9BQU9ULE1BQVYsQ0FBZDs7QUFDQSxRQUFNVyxRQUFPLEdBQ1gsT0FBT1gsTUFBUCxHQUFpQkEsTUFBTSxDQUFDLEdBQUQsQ0FBdkIsR0FBMERBLE1BRDVEOztBQUVBLFFBQUlTLFNBQVEsSUFBSUosV0FBVyxDQUFDQyxLQUFELENBQTNCLEVBQW9DO0FBQ2xDLGFBQU8sSUFBUDtBQUNEOztBQUNELFFBQU1PLEdBQUcsR0FBR2hCLFdBQVcsQ0FBQ1MsS0FBRCxDQUFYLEdBQXFCQSxLQUFyQixHQUE2QixFQUF6QztBQUNBLFdBQU8saURBQVlLLFFBQVosbUJBQTRCLFVBQUNHLENBQUQsRUFBSUMsQ0FBSixFQUFVO0FBQzNDLFVBQU1DLENBQUMsR0FBR0wsUUFBTyxDQUFDSSxDQUFELENBQWpCO0FBQ0EsVUFBTUgsQ0FBQyxHQUFHQyxHQUFHLENBQUNFLENBQUQsQ0FBYjtBQUNBLFVBQU1OLFFBQVEsR0FDWCxlQUFjTyxDQUFkLEtBQW9CQSxDQUFDLENBQUNOLE1BQUYsS0FBYSxDQUFqQyxJQUFzQ00sQ0FBQyxDQUFDLENBQUQsQ0FBRCxLQUFTLEdBQWhELElBQ0NuQixXQUFXLENBQUNtQixDQUFELENBQVgsSUFBa0IsT0FBT0EsQ0FEMUIsSUFFQyxPQUFPQSxDQUFQLEtBQWEsUUFBYixJQUF5QkEsQ0FBQyxDQUFDLENBQUQsQ0FBRCxLQUFTLEdBSHJDOztBQUlBLFVBQUksT0FBT0osQ0FBUCxLQUFhLFdBQWIsSUFBNEJILFFBQWhDLEVBQTBDO0FBQ3hDLGVBQU9LLENBQVA7QUFDRDs7QUFDRCw2Q0FDS0EsQ0FETCwyQkFFR0MsQ0FGSCxFQUVPUCxtQkFBbUIsQ0FBQ0ksQ0FBRCxFQUFJSSxDQUFKLEVBQU9mLFVBQVAsQ0FGMUI7QUFJRCxLQWRNLEVBY0pZLEdBZEksQ0FBUDtBQWVELEdBNUJNLE1BNEJBO0FBQ0wsUUFBTUosVUFBUSxHQUFHLE9BQU9ULE1BQVAsS0FBa0IsUUFBbEIsSUFBOEJBLE1BQU0sQ0FBQyxDQUFELENBQU4sS0FBYyxHQUE3RDs7QUFDQSxRQUFNaUIsSUFBSSxHQUNSLE9BQU9qQixNQUFQLEtBQWtCLFFBQWxCLEdBQ0lTLFVBQVEsR0FDTlQsTUFBTSxDQUFDa0IsU0FBUCxDQUFpQixDQUFqQixDQURNLEdBRU5sQixNQUhOLEdBSUksS0FMTjs7QUFNQSxZQUFRaUIsSUFBUjtBQUNFLFdBQUssUUFBTDtBQUNFLGVBQU9aLFdBQVcsQ0FBQ0MsS0FBRCxDQUFYLEdBQXNCRyxVQUFRLEdBQUcsSUFBSCxHQUFVLEVBQXhDLEdBQThDVSxNQUFNLENBQUNiLEtBQUQsQ0FBM0Q7O0FBQ0YsV0FBSyxRQUFMO0FBQ0UsZUFBT0QsV0FBVyxDQUFDQyxLQUFELENBQVgsR0FBc0JHLFVBQVEsR0FBRyxJQUFILEdBQVUsQ0FBeEMsR0FBNkNXLE1BQU0sQ0FBQ2QsS0FBRCxDQUExRDs7QUFDRixXQUFLLFNBQUw7QUFDRSxlQUFPRCxXQUFXLENBQUNDLEtBQUQsQ0FBWCxHQUNIRyxVQUFRLEdBQ04sSUFETSxHQUVOLEtBSEMsR0FJSEgsS0FBSyxLQUFLLE1BSmQ7O0FBS0YsV0FBSyxNQUFMO0FBQ0UsZUFBTyxJQUFQOztBQUNGO0FBQVM7QUFDUCxjQUFJTCxVQUFVLENBQUNnQixJQUFELENBQWQsRUFBc0I7QUFDcEIsZ0JBQU1JLE1BQU0sR0FBR2IsbUJBQW1CLENBQ2hDRixLQURnQyxFQUVoQ0wsVUFBVSxDQUFDZ0IsSUFBRCxDQUZzQixFQUdoQ2hCLFVBSGdDLENBQWxDO0FBS0EsZ0JBQU1xQixPQUFPLEdBQ1h6QixXQUFXLENBQUN3QixNQUFELENBQVgsSUFBdUIsYUFBWUEsTUFBWixFQUFvQlgsTUFBcEIsS0FBK0IsQ0FEeEQ7QUFFQSxtQkFBT1ksT0FBTyxJQUFJYixVQUFYLEdBQXNCLElBQXRCLEdBQTZCWSxNQUFwQztBQUNEOztBQUNELGlCQUFPZixLQUFQO0FBQ0Q7QUF6Qkg7QUEyQkQ7QUFDRjtBQUVEO0FBQ0E7QUFDQTs7QUFDQSxTQUFTaUIsV0FBVCxDQUFxQlYsR0FBckIsRUFBbUNXLFdBQW5DLEVBQW1FO0FBQ2pFLE1BQU1DLE1BQU0sR0FBR0QsV0FBVyxDQUFDRSxLQUFaLEVBQWY7O0FBQ0EsTUFBSSxDQUFDRCxNQUFMLEVBQWE7QUFDWCxXQUFPWixHQUFQO0FBQ0Q7O0FBQ0QsTUFBSWhCLFdBQVcsQ0FBQ2dCLEdBQUQsQ0FBZixFQUFzQjtBQUNwQixxQ0FBbUIsYUFBWUEsR0FBWixDQUFuQixtQ0FBcUM7QUFBaEMsVUFBTWMsSUFBSSxvQkFBVjs7QUFDSCxVQUFJRixNQUFNLENBQUNHLElBQVAsQ0FBWUQsSUFBWixDQUFKLEVBQXVCO0FBQ3JCLGVBQU9KLFdBQVcsQ0FBQ1YsR0FBRyxDQUFDYyxJQUFELENBQUosRUFBWUgsV0FBWixDQUFsQjtBQUNEO0FBQ0Y7O0FBQ0QsV0FBTyxJQUFQO0FBQ0Q7QUFDRjtBQUVEO0FBQ0E7QUFDQTs7O0FBQ0EsU0FBU0ssS0FBVCxDQUFlQyxJQUFmLEVBQTZDeEIsS0FBN0MsRUFBa0U7QUFDaEUsTUFBSVIsUUFBUSxDQUFDZ0MsSUFBRCxDQUFaLEVBQW9CO0FBQ2xCeEIsSUFBQUEsS0FBSyxHQUFHd0IsSUFBUjtBQUNBQSxJQUFBQSxJQUFJLEdBQUcsSUFBUDtBQUNEOztBQUNELE1BQUksZUFBY3hCLEtBQWQsQ0FBSixFQUEwQjtBQUN4QixXQUFPLHFCQUFBQSxLQUFLLE1BQUwsQ0FBQUEsS0FBSyxFQUFLLFVBQUNNLENBQUQ7QUFBQSxhQUFPaUIsS0FBSyxDQUFDQyxJQUFELEVBQU9sQixDQUFQLENBQVo7QUFBQSxLQUFMLENBQUwsQ0FBaUNtQixJQUFqQyxDQUFzQyxFQUF0QyxDQUFQO0FBQ0QsR0FGRCxNQUVPO0FBQ0wsUUFBTUMsS0FBSyxHQUFHLEVBQWQ7QUFDQSxRQUFNQyxLQUFLLEdBQUcsRUFBZDs7QUFDQSxRQUFJcEMsV0FBVyxDQUFDUyxLQUFELENBQWYsRUFBd0I7QUFDdEIsd0NBQWdCLGFBQVlBLEtBQVosQ0FBaEIscUNBQW9DO0FBQS9CLFlBQU1TLENBQUMscUJBQVA7QUFDSCxZQUFNSCxDQUFDLEdBQUdOLEtBQUssQ0FBQ1MsQ0FBRCxDQUFmOztBQUNBLFlBQUlBLENBQUMsQ0FBQyxDQUFELENBQUQsS0FBUyxHQUFiLEVBQWtCO0FBQ2hCLGNBQU1tQixFQUFFLEdBQUduQixDQUFDLENBQUNHLFNBQUYsQ0FBWSxDQUFaLENBQVg7QUFDQWMsVUFBQUEsS0FBSyxDQUFDRyxJQUFOLENBQVdELEVBQUUsR0FBRyxJQUFMLEdBQVl0QixDQUFaLEdBQWdCLEdBQTNCO0FBQ0QsU0FIRCxNQUdPO0FBQ0xxQixVQUFBQSxLQUFLLENBQUNFLElBQU4sQ0FBV04sS0FBSyxDQUFDZCxDQUFELEVBQUlILENBQUosQ0FBaEI7QUFDRDtBQUNGOztBQUNETixNQUFBQSxLQUFLLEdBQUcyQixLQUFLLENBQUNGLElBQU4sQ0FBVyxFQUFYLENBQVI7QUFDRCxLQVhELE1BV087QUFDTHpCLE1BQUFBLEtBQUssR0FBR2EsTUFBTSxDQUFDYixLQUFELENBQU4sQ0FDTDhCLE9BREssQ0FDRyxJQURILEVBQ1MsT0FEVCxFQUVMQSxPQUZLLENBRUcsSUFGSCxFQUVTLE1BRlQsRUFHTEEsT0FISyxDQUdHLElBSEgsRUFHUyxNQUhULEVBSUxBLE9BSkssQ0FJRyxJQUpILEVBSVMsUUFKVCxFQUtMQSxPQUxLLENBS0csSUFMSCxFQUtTLFFBTFQsQ0FBUjtBQU1EOztBQUNELFFBQU1DLFFBQVEsR0FBR1AsSUFBSSxHQUNqQixNQUFNQSxJQUFOLElBQWNFLEtBQUssQ0FBQ3RCLE1BQU4sR0FBZSxDQUFmLEdBQW1CLE1BQU1zQixLQUFLLENBQUNELElBQU4sQ0FBVyxHQUFYLENBQXpCLEdBQTJDLEVBQXpELElBQStELEdBRDlDLEdBRWpCLEVBRko7QUFHQSxRQUFNTyxNQUFNLEdBQUdSLElBQUksR0FBRyxPQUFPQSxJQUFQLEdBQWMsR0FBakIsR0FBdUIsRUFBMUM7QUFDQSxXQUFPTyxRQUFRLEdBQUcvQixLQUFYLEdBQW1CZ0MsTUFBMUI7QUFDRDtBQUNGO0FBRUQ7QUFDQTtBQUNBOzs7QUFNQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBYUMsSUFBYjtBQUFBOztBQUFBOztBQUlFLGdCQUFZQyxJQUFaLEVBQWlDQyxPQUFqQyxFQUF1RDtBQUFBOztBQUFBOztBQUNyRCw4QkFBTUQsSUFBTixFQUFZQyxPQUFaOztBQURxRDs7QUFBQTs7QUFFckQsVUFBS0MsWUFBTCxHQUFvQkQsT0FBTyxDQUFDRSxXQUE1QjtBQUNBLFVBQUtDLE1BQUwsR0FBY0gsT0FBTyxDQUFDSSxLQUFSLElBQWlCLDZCQUEvQjtBQUhxRDtBQUl0RDtBQUVEO0FBQ0Y7QUFDQTs7O0FBWkE7QUFBQTtBQUFBO0FBQUEsOEZBY0lDLE1BZEosRUFlSUMsSUFmSixFQWdCSS9DLE1BaEJKLEVBaUJJQyxVQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW1Cc0IsS0FBSytDLE9BQUwsQ0FBYTtBQUM3QkYsa0JBQUFBLE1BQU0sRUFBRSxNQURxQjtBQUU3Qkcsa0JBQUFBLEdBQUcsRUFBRSxLQUFLUCxZQUZtQjtBQUc3QlEsa0JBQUFBLE9BQU8sRUFBRTtBQUNQLG9DQUFnQixVQURUO0FBRVBDLG9CQUFBQSxVQUFVLEVBQUU7QUFGTCxtQkFIb0I7QUFPN0JDLGtCQUFBQSxRQUFRLHNCQUFLTixNQUFMLEVBQWNDLElBQWQ7QUFQcUIsaUJBQWIsQ0FuQnRCOztBQUFBO0FBbUJVTSxnQkFBQUEsR0FuQlY7QUFBQSxrREE0QldyRCxNQUFNLEdBQUdRLG1CQUFtQixDQUFDNkMsR0FBRCxFQUFNckQsTUFBTixFQUFjQyxVQUFkLENBQXRCLEdBQWtEb0QsR0E1Qm5FOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBK0JFOztBQS9CRjtBQUFBO0FBQUEsK0JBZ0NhTCxPQWhDYixFQWdDMEQ7QUFDdERBLE1BQUFBLE9BQU8sQ0FBQ00sSUFBUixHQUFlLEtBQUtDLGVBQUwsQ0FBcUJQLE9BQU8sQ0FBQ0ksUUFBN0IsQ0FBZjtBQUNEO0FBRUQ7O0FBcENGO0FBQUE7QUFBQSxxQ0FxQ21CSSxRQXJDbkIsRUFxQzJDO0FBQ3ZDLGFBQ0VBLFFBQVEsQ0FBQ0MsVUFBVCxLQUF3QixHQUF4QixJQUNBLHVEQUF1RDdCLElBQXZELENBQTRENEIsUUFBUSxDQUFDRixJQUFyRSxDQUZGO0FBSUQ7QUFFRDs7QUE1Q0Y7QUFBQTtBQUFBLCtCQTZDYUEsSUE3Q2IsRUE2QzJCO0FBQ3ZCLFVBQU1JLEtBQUssR0FBR25DLFdBQVcsQ0FBQytCLElBQUQsRUFBTyxDQUFDLFlBQUQsRUFBZSxRQUFmLEVBQXlCLFNBQXpCLENBQVAsQ0FBekI7QUFHQSxhQUFPO0FBQ0xLLFFBQUFBLFNBQVMsRUFBRUQsS0FBSyxDQUFDRSxTQURaO0FBRUxDLFFBQUFBLE9BQU8sRUFBRUgsS0FBSyxDQUFDSTtBQUZWLE9BQVA7QUFJRDtBQUVEOztBQXZERjtBQUFBO0FBQUE7QUFBQSx3R0F3RHdCTixRQXhEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpR0F5RDZDQSxRQXpEN0M7O0FBQUE7QUF5RFVGLGdCQUFBQSxJQXpEVjtBQUFBLGtEQTBEVy9CLFdBQVcsQ0FBQytCLElBQUQsRUFBTyxDQUFDLFlBQUQsRUFBZSxRQUFmLEVBQXlCLElBQXpCLENBQVAsQ0ExRHRCOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBNkRFO0FBQ0Y7QUFDQTs7QUEvREE7QUFBQTtBQUFBLG9DQWdFa0JPLE9BaEVsQixFQWdFbUM7QUFDL0IsVUFBTUUsTUFBK0IsR0FBRyxFQUF4QztBQUNBLFVBQU12QixJQUFJLEdBQUcsS0FBS3dCLEtBQWxCOztBQUNBLFVBQUl4QixJQUFJLENBQUN5QixXQUFULEVBQXNCO0FBQ3BCRixRQUFBQSxNQUFNLENBQUNHLGFBQVAsR0FBdUI7QUFBRUMsVUFBQUEsU0FBUyxFQUFFM0IsSUFBSSxDQUFDeUI7QUFBbEIsU0FBdkI7QUFDRDs7QUFDRCxVQUFJekIsSUFBSSxDQUFDNEIsWUFBVCxFQUF1QjtBQUNyQkwsUUFBQUEsTUFBTSxDQUFDTSxXQUFQLEdBQXFCN0IsSUFBSSxDQUFDNEIsWUFBMUI7QUFDRDs7QUFDRCxhQUFPLENBQ0wsd0NBREssRUFFTCw2RUFGSyxFQUdMLCtDQUhLLEVBSUwseURBSkssRUFLTCw0QkFBNEIsS0FBS3hCLE1BQWpDLEdBQTBDLElBTHJDLEVBTUxmLEtBQUssQ0FBQ2tDLE1BQUQsQ0FOQSxFQU9MLG1CQVBLLEVBUUwsMEJBQTBCLEtBQUtuQixNQUEvQixHQUF3QyxJQVJuQyxFQVNMZixLQUFLLENBQUNnQyxPQUFELENBVEEsRUFVTCxpQkFWSyxFQVdMLHFCQVhLLEVBWUw5QixJQVpLLENBWUEsRUFaQSxDQUFQO0FBYUQ7QUF0Rkg7O0FBQUE7QUFBQSxFQUE0Q25DLE9BQTVDO0FBeUZBLGVBQWUyQyxJQUFmIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAZmlsZSBNYW5hZ2VzIG1ldGhvZCBjYWxsIHRvIFNPQVAgZW5kcG9pbnRcbiAqIEBhdXRob3IgU2hpbmljaGkgVG9taXRhIDxzaGluaWNoaS50b21pdGFAZ21haWwuY29tPlxuICovXG5pbXBvcnQgSHR0cEFwaSBmcm9tICcuL2h0dHAtYXBpJztcbmltcG9ydCBDb25uZWN0aW9uIGZyb20gJy4vY29ubmVjdGlvbic7XG5pbXBvcnQge1xuICBTY2hlbWEsXG4gIEh0dHBSZXNwb25zZSxcbiAgSHR0cFJlcXVlc3QsXG4gIFNvYXBTY2hlbWEsXG4gIFNvYXBTY2hlbWFEZWYsXG59IGZyb20gJy4vdHlwZXMnO1xuaW1wb3J0IHsgaXNNYXBPYmplY3QsIGlzT2JqZWN0IH0gZnJvbSAnLi91dGlsL2Z1bmN0aW9uJztcblxuLyoqXG4gKlxuICovXG5mdW5jdGlvbiBnZXRQcm9wc1NjaGVtYShcbiAgc2NoZW1hOiBTb2FwU2NoZW1hRGVmLFxuICBzY2hlbWFEaWN0OiB7IFtuYW1lOiBzdHJpbmddOiBTb2FwU2NoZW1hRGVmIH0sXG4pOiBTb2FwU2NoZW1hRGVmWydwcm9wcyddIHtcbiAgaWYgKHNjaGVtYS5leHRlbmRzICYmIHNjaGVtYURpY3Rbc2NoZW1hLmV4dGVuZHNdKSB7XG4gICAgY29uc3QgZXh0ZW5kU2NoZW1hID0gc2NoZW1hRGljdFtzY2hlbWEuZXh0ZW5kc107XG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLmdldFByb3BzU2NoZW1hKGV4dGVuZFNjaGVtYSwgc2NoZW1hRGljdCksXG4gICAgICAuLi5zY2hlbWEucHJvcHMsXG4gICAgfTtcbiAgfVxuICByZXR1cm4gc2NoZW1hLnByb3BzO1xufVxuXG5mdW5jdGlvbiBpc05pbGxWYWx1ZSh2YWx1ZTogdW5rbm93bikge1xuICByZXR1cm4gKFxuICAgIHZhbHVlID09IG51bGwgfHxcbiAgICAoaXNNYXBPYmplY3QodmFsdWUpICYmXG4gICAgICBpc01hcE9iamVjdCh2YWx1ZS4kKSAmJlxuICAgICAgdmFsdWUuJFsneHNpOm5pbCddID09PSAndHJ1ZScpXG4gICk7XG59XG5cbi8qKlxuICpcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNhc3RUeXBlVXNpbmdTY2hlbWEoXG4gIHZhbHVlOiB1bmtub3duLFxuICBzY2hlbWE/OiBTb2FwU2NoZW1hIHwgU29hcFNjaGVtYURlZixcbiAgc2NoZW1hRGljdDogeyBbbmFtZTogc3RyaW5nXTogU29hcFNjaGVtYURlZiB9ID0ge30sXG4pOiBhbnkge1xuICBpZiAoQXJyYXkuaXNBcnJheShzY2hlbWEpKSB7XG4gICAgY29uc3QgbmlsbGFibGUgPSBzY2hlbWEubGVuZ3RoID09PSAyICYmIHNjaGVtYVswXSA9PT0gJz8nO1xuICAgIGNvbnN0IHNjaGVtYV8gPSBuaWxsYWJsZSA/IHNjaGVtYVsxXSA6IHNjaGVtYVswXTtcbiAgICBpZiAodmFsdWUgPT0gbnVsbCkge1xuICAgICAgcmV0dXJuIG5pbGxhYmxlID8gbnVsbCA6IFtdO1xuICAgIH1cbiAgICByZXR1cm4gKEFycmF5LmlzQXJyYXkodmFsdWUpID8gdmFsdWUgOiBbdmFsdWVdKS5tYXAoKHYpID0+XG4gICAgICBjYXN0VHlwZVVzaW5nU2NoZW1hKHYsIHNjaGVtYV8sIHNjaGVtYURpY3QpLFxuICAgICk7XG4gIH0gZWxzZSBpZiAoaXNNYXBPYmplY3Qoc2NoZW1hKSkge1xuICAgIC8vIGlmIHNjaGVtYSBpcyBTY2hlbWEgRGVmaW5pdGlvbiwgbm90IHNjaGVtYSBlbGVtZW50XG4gICAgaWYgKCd0eXBlJyBpbiBzY2hlbWEgJiYgJ3Byb3BzJyBpbiBzY2hlbWEgJiYgaXNNYXBPYmplY3Qoc2NoZW1hLnByb3BzKSkge1xuICAgICAgY29uc3QgcHJvcHMgPSBnZXRQcm9wc1NjaGVtYShzY2hlbWEgYXMgU29hcFNjaGVtYURlZiwgc2NoZW1hRGljdCk7XG4gICAgICByZXR1cm4gY2FzdFR5cGVVc2luZ1NjaGVtYSh2YWx1ZSwgcHJvcHMsIHNjaGVtYURpY3QpO1xuICAgIH1cbiAgICBjb25zdCBuaWxsYWJsZSA9ICc/JyBpbiBzY2hlbWE7XG4gICAgY29uc3Qgc2NoZW1hXyA9XG4gICAgICAnPycgaW4gc2NoZW1hID8gKHNjaGVtYVsnPyddIGFzIHsgW2tleTogc3RyaW5nXTogYW55IH0pIDogc2NoZW1hO1xuICAgIGlmIChuaWxsYWJsZSAmJiBpc05pbGxWYWx1ZSh2YWx1ZSkpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBjb25zdCBvYmogPSBpc01hcE9iamVjdCh2YWx1ZSkgPyB2YWx1ZSA6IHt9O1xuICAgIHJldHVybiBPYmplY3Qua2V5cyhzY2hlbWFfKS5yZWR1Y2UoKG8sIGspID0+IHtcbiAgICAgIGNvbnN0IHMgPSBzY2hlbWFfW2tdO1xuICAgICAgY29uc3QgdiA9IG9ialtrXTtcbiAgICAgIGNvbnN0IG5pbGxhYmxlID1cbiAgICAgICAgKEFycmF5LmlzQXJyYXkocykgJiYgcy5sZW5ndGggPT09IDIgJiYgc1swXSA9PT0gJz8nKSB8fFxuICAgICAgICAoaXNNYXBPYmplY3QocykgJiYgJz8nIGluIHMpIHx8XG4gICAgICAgICh0eXBlb2YgcyA9PT0gJ3N0cmluZycgJiYgc1swXSA9PT0gJz8nKTtcbiAgICAgIGlmICh0eXBlb2YgdiA9PT0gJ3VuZGVmaW5lZCcgJiYgbmlsbGFibGUpIHtcbiAgICAgICAgcmV0dXJuIG87XG4gICAgICB9XG4gICAgICByZXR1cm4ge1xuICAgICAgICAuLi5vLFxuICAgICAgICBba106IGNhc3RUeXBlVXNpbmdTY2hlbWEodiwgcywgc2NoZW1hRGljdCksXG4gICAgICB9O1xuICAgIH0sIG9iaik7XG4gIH0gZWxzZSB7XG4gICAgY29uc3QgbmlsbGFibGUgPSB0eXBlb2Ygc2NoZW1hID09PSAnc3RyaW5nJyAmJiBzY2hlbWFbMF0gPT09ICc/JztcbiAgICBjb25zdCB0eXBlID1cbiAgICAgIHR5cGVvZiBzY2hlbWEgPT09ICdzdHJpbmcnXG4gICAgICAgID8gbmlsbGFibGVcbiAgICAgICAgICA/IHNjaGVtYS5zdWJzdHJpbmcoMSlcbiAgICAgICAgICA6IHNjaGVtYVxuICAgICAgICA6ICdhbnknO1xuICAgIHN3aXRjaCAodHlwZSkge1xuICAgICAgY2FzZSAnc3RyaW5nJzpcbiAgICAgICAgcmV0dXJuIGlzTmlsbFZhbHVlKHZhbHVlKSA/IChuaWxsYWJsZSA/IG51bGwgOiAnJykgOiBTdHJpbmcodmFsdWUpO1xuICAgICAgY2FzZSAnbnVtYmVyJzpcbiAgICAgICAgcmV0dXJuIGlzTmlsbFZhbHVlKHZhbHVlKSA/IChuaWxsYWJsZSA/IG51bGwgOiAwKSA6IE51bWJlcih2YWx1ZSk7XG4gICAgICBjYXNlICdib29sZWFuJzpcbiAgICAgICAgcmV0dXJuIGlzTmlsbFZhbHVlKHZhbHVlKVxuICAgICAgICAgID8gbmlsbGFibGVcbiAgICAgICAgICAgID8gbnVsbFxuICAgICAgICAgICAgOiBmYWxzZVxuICAgICAgICAgIDogdmFsdWUgPT09ICd0cnVlJztcbiAgICAgIGNhc2UgJ251bGwnOlxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIGRlZmF1bHQ6IHtcbiAgICAgICAgaWYgKHNjaGVtYURpY3RbdHlwZV0pIHtcbiAgICAgICAgICBjb25zdCBjdmFsdWUgPSBjYXN0VHlwZVVzaW5nU2NoZW1hKFxuICAgICAgICAgICAgdmFsdWUsXG4gICAgICAgICAgICBzY2hlbWFEaWN0W3R5cGVdLFxuICAgICAgICAgICAgc2NoZW1hRGljdCxcbiAgICAgICAgICApO1xuICAgICAgICAgIGNvbnN0IGlzRW1wdHkgPVxuICAgICAgICAgICAgaXNNYXBPYmplY3QoY3ZhbHVlKSAmJiBPYmplY3Qua2V5cyhjdmFsdWUpLmxlbmd0aCA9PT0gMDtcbiAgICAgICAgICByZXR1cm4gaXNFbXB0eSAmJiBuaWxsYWJsZSA/IG51bGwgOiBjdmFsdWU7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHZhbHVlIGFzIGFueTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxuLyoqXG4gKiBAcHJpdmF0ZVxuICovXG5mdW5jdGlvbiBsb29rdXBWYWx1ZShvYmo6IHVua25vd24sIHByb3BSZWdFeHBzOiBSZWdFeHBbXSk6IHVua25vd24ge1xuICBjb25zdCByZWdleHAgPSBwcm9wUmVnRXhwcy5zaGlmdCgpO1xuICBpZiAoIXJlZ2V4cCkge1xuICAgIHJldHVybiBvYmo7XG4gIH1cbiAgaWYgKGlzTWFwT2JqZWN0KG9iaikpIHtcbiAgICBmb3IgKGNvbnN0IHByb3Agb2YgT2JqZWN0LmtleXMob2JqKSkge1xuICAgICAgaWYgKHJlZ2V4cC50ZXN0KHByb3ApKSB7XG4gICAgICAgIHJldHVybiBsb29rdXBWYWx1ZShvYmpbcHJvcF0sIHByb3BSZWdFeHBzKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn1cblxuLyoqXG4gKiBAcHJpdmF0ZVxuICovXG5mdW5jdGlvbiB0b1hNTChuYW1lOiBvYmplY3QgfCBzdHJpbmcgfCBudWxsLCB2YWx1ZT86IGFueSk6IHN0cmluZyB7XG4gIGlmIChpc09iamVjdChuYW1lKSkge1xuICAgIHZhbHVlID0gbmFtZTtcbiAgICBuYW1lID0gbnVsbDtcbiAgfVxuICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICByZXR1cm4gdmFsdWUubWFwKCh2KSA9PiB0b1hNTChuYW1lLCB2KSkuam9pbignJyk7XG4gIH0gZWxzZSB7XG4gICAgY29uc3QgYXR0cnMgPSBbXTtcbiAgICBjb25zdCBlbGVtcyA9IFtdO1xuICAgIGlmIChpc01hcE9iamVjdCh2YWx1ZSkpIHtcbiAgICAgIGZvciAoY29uc3QgayBvZiBPYmplY3Qua2V5cyh2YWx1ZSkpIHtcbiAgICAgICAgY29uc3QgdiA9IHZhbHVlW2tdO1xuICAgICAgICBpZiAoa1swXSA9PT0gJ0AnKSB7XG4gICAgICAgICAgY29uc3Qga2sgPSBrLnN1YnN0cmluZygxKTtcbiAgICAgICAgICBhdHRycy5wdXNoKGtrICsgJz1cIicgKyB2ICsgJ1wiJyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZWxlbXMucHVzaCh0b1hNTChrLCB2KSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHZhbHVlID0gZWxlbXMuam9pbignJyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHZhbHVlID0gU3RyaW5nKHZhbHVlKVxuICAgICAgICAucmVwbGFjZSgvJi9nLCAnJmFtcDsnKVxuICAgICAgICAucmVwbGFjZSgvPC9nLCAnJmx0OycpXG4gICAgICAgIC5yZXBsYWNlKC8+L2csICcmZ3Q7JylcbiAgICAgICAgLnJlcGxhY2UoL1wiL2csICcmcXVvdDsnKVxuICAgICAgICAucmVwbGFjZSgvJy9nLCAnJmFwb3M7Jyk7XG4gICAgfVxuICAgIGNvbnN0IHN0YXJ0VGFnID0gbmFtZVxuICAgICAgPyAnPCcgKyBuYW1lICsgKGF0dHJzLmxlbmd0aCA+IDAgPyAnICcgKyBhdHRycy5qb2luKCcgJykgOiAnJykgKyAnPidcbiAgICAgIDogJyc7XG4gICAgY29uc3QgZW5kVGFnID0gbmFtZSA/ICc8LycgKyBuYW1lICsgJz4nIDogJyc7XG4gICAgcmV0dXJuIHN0YXJ0VGFnICsgdmFsdWUgKyBlbmRUYWc7XG4gIH1cbn1cblxuLyoqXG4gKlxuICovXG5leHBvcnQgdHlwZSBTT0FQT3B0aW9ucyA9IHtcbiAgZW5kcG9pbnRVcmw6IHN0cmluZztcbiAgeG1sbnM/OiBzdHJpbmc7XG59O1xuXG4vKipcbiAqIENsYXNzIGZvciBTT0FQIGVuZHBvaW50IG9mIFNhbGVzZm9yY2VcbiAqXG4gKiBAcHJvdGVjdGVkXG4gKiBAY2xhc3NcbiAqIEBjb25zdHJ1Y3RvclxuICogQHBhcmFtIHtDb25uZWN0aW9ufSBjb25uIC0gQ29ubmVjdGlvbiBpbnN0YW5jZVxuICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnMgLSBTT0FQIGVuZHBvaW50IHNldHRpbmcgb3B0aW9uc1xuICogQHBhcmFtIHtTdHJpbmd9IG9wdGlvbnMuZW5kcG9pbnRVcmwgLSBTT0FQIGVuZHBvaW50IFVSTFxuICogQHBhcmFtIHtTdHJpbmd9IFtvcHRpb25zLnhtbG5zXSAtIFhNTCBuYW1lc3BhY2UgZm9yIG1ldGhvZCBjYWxsIChkZWZhdWx0IGlzIFwidXJuOnBhcnRuZXIuc29hcC5zZm9yY2UuY29tXCIpXG4gKi9cbmV4cG9ydCBjbGFzcyBTT0FQPFMgZXh0ZW5kcyBTY2hlbWE+IGV4dGVuZHMgSHR0cEFwaTxTPiB7XG4gIF9lbmRwb2ludFVybDogc3RyaW5nO1xuICBfeG1sbnM6IHN0cmluZztcblxuICBjb25zdHJ1Y3Rvcihjb25uOiBDb25uZWN0aW9uPFM+LCBvcHRpb25zOiBTT0FQT3B0aW9ucykge1xuICAgIHN1cGVyKGNvbm4sIG9wdGlvbnMpO1xuICAgIHRoaXMuX2VuZHBvaW50VXJsID0gb3B0aW9ucy5lbmRwb2ludFVybDtcbiAgICB0aGlzLl94bWxucyA9IG9wdGlvbnMueG1sbnMgfHwgJ3VybjpwYXJ0bmVyLnNvYXAuc2ZvcmNlLmNvbSc7XG4gIH1cblxuICAvKipcbiAgICogSW52b2tlIFNPQVAgY2FsbCB1c2luZyBtZXRob2QgYW5kIGFyZ3VtZW50c1xuICAgKi9cbiAgYXN5bmMgaW52b2tlKFxuICAgIG1ldGhvZDogc3RyaW5nLFxuICAgIGFyZ3M6IG9iamVjdCxcbiAgICBzY2hlbWE/OiBTb2FwU2NoZW1hIHwgU29hcFNjaGVtYURlZixcbiAgICBzY2hlbWFEaWN0PzogeyBbbmFtZTogc3RyaW5nXTogU29hcFNjaGVtYURlZiB9LFxuICApIHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLnJlcXVlc3Qoe1xuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICB1cmw6IHRoaXMuX2VuZHBvaW50VXJsLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICAnQ29udGVudC1UeXBlJzogJ3RleHQveG1sJyxcbiAgICAgICAgU09BUEFjdGlvbjogJ1wiXCInLFxuICAgICAgfSxcbiAgICAgIF9tZXNzYWdlOiB7IFttZXRob2RdOiBhcmdzIH0sXG4gICAgfSBhcyBIdHRwUmVxdWVzdCk7XG4gICAgcmV0dXJuIHNjaGVtYSA/IGNhc3RUeXBlVXNpbmdTY2hlbWEocmVzLCBzY2hlbWEsIHNjaGVtYURpY3QpIDogcmVzO1xuICB9XG5cbiAgLyoqIEBvdmVycmlkZSAqL1xuICBiZWZvcmVTZW5kKHJlcXVlc3Q6IEh0dHBSZXF1ZXN0ICYgeyBfbWVzc2FnZTogb2JqZWN0IH0pIHtcbiAgICByZXF1ZXN0LmJvZHkgPSB0aGlzLl9jcmVhdGVFbnZlbG9wZShyZXF1ZXN0Ll9tZXNzYWdlKTtcbiAgfVxuXG4gIC8qKiBAb3ZlcnJpZGUgKiovXG4gIGlzU2Vzc2lvbkV4cGlyZWQocmVzcG9uc2U6IEh0dHBSZXNwb25zZSkge1xuICAgIHJldHVybiAoXG4gICAgICByZXNwb25zZS5zdGF0dXNDb2RlID09PSA1MDAgJiZcbiAgICAgIC88ZmF1bHRjb2RlPlthLXpBLVpdKzpJTlZBTElEX1NFU1NJT05fSUQ8XFwvZmF1bHRjb2RlPi8udGVzdChyZXNwb25zZS5ib2R5KVxuICAgICk7XG4gIH1cblxuICAvKiogQG92ZXJyaWRlICoqL1xuICBwYXJzZUVycm9yKGJvZHk6IHN0cmluZykge1xuICAgIGNvbnN0IGVycm9yID0gbG9va3VwVmFsdWUoYm9keSwgWy86RW52ZWxvcGUkLywgLzpCb2R5JC8sIC86RmF1bHQkL10pIGFzIHtcbiAgICAgIFtuYW1lOiBzdHJpbmddOiBzdHJpbmcgfCB1bmRlZmluZWQ7XG4gICAgfTtcbiAgICByZXR1cm4ge1xuICAgICAgZXJyb3JDb2RlOiBlcnJvci5mYXVsdGNvZGUsXG4gICAgICBtZXNzYWdlOiBlcnJvci5mYXVsdHN0cmluZyxcbiAgICB9O1xuICB9XG5cbiAgLyoqIEBvdmVycmlkZSAqKi9cbiAgYXN5bmMgZ2V0UmVzcG9uc2VCb2R5KHJlc3BvbnNlOiBIdHRwUmVzcG9uc2UpIHtcbiAgICBjb25zdCBib2R5ID0gYXdhaXQgc3VwZXIuZ2V0UmVzcG9uc2VCb2R5KHJlc3BvbnNlKTtcbiAgICByZXR1cm4gbG9va3VwVmFsdWUoYm9keSwgWy86RW52ZWxvcGUkLywgLzpCb2R5JC8sIC8uKy9dKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX2NyZWF0ZUVudmVsb3BlKG1lc3NhZ2U6IG9iamVjdCkge1xuICAgIGNvbnN0IGhlYWRlcjogeyBbbmFtZTogc3RyaW5nXTogYW55IH0gPSB7fTtcbiAgICBjb25zdCBjb25uID0gdGhpcy5fY29ubjtcbiAgICBpZiAoY29ubi5hY2Nlc3NUb2tlbikge1xuICAgICAgaGVhZGVyLlNlc3Npb25IZWFkZXIgPSB7IHNlc3Npb25JZDogY29ubi5hY2Nlc3NUb2tlbiB9O1xuICAgIH1cbiAgICBpZiAoY29ubi5fY2FsbE9wdGlvbnMpIHtcbiAgICAgIGhlYWRlci5DYWxsT3B0aW9ucyA9IGNvbm4uX2NhbGxPcHRpb25zO1xuICAgIH1cbiAgICByZXR1cm4gW1xuICAgICAgJzw/eG1sIHZlcnNpb249XCIxLjBcIiBlbmNvZGluZz1cIlVURi04XCI/PicsXG4gICAgICAnPHNvYXBlbnY6RW52ZWxvcGUgeG1sbnM6c29hcGVudj1cImh0dHA6Ly9zY2hlbWFzLnhtbHNvYXAub3JnL3NvYXAvZW52ZWxvcGUvXCInLFxuICAgICAgJyB4bWxuczp4c2Q9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYVwiJyxcbiAgICAgICcgeG1sbnM6eHNpPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEtaW5zdGFuY2VcIj4nLFxuICAgICAgJzxzb2FwZW52OkhlYWRlciB4bWxucz1cIicgKyB0aGlzLl94bWxucyArICdcIj4nLFxuICAgICAgdG9YTUwoaGVhZGVyKSxcbiAgICAgICc8L3NvYXBlbnY6SGVhZGVyPicsXG4gICAgICAnPHNvYXBlbnY6Qm9keSB4bWxucz1cIicgKyB0aGlzLl94bWxucyArICdcIj4nLFxuICAgICAgdG9YTUwobWVzc2FnZSksXG4gICAgICAnPC9zb2FwZW52OkJvZHk+JyxcbiAgICAgICc8L3NvYXBlbnY6RW52ZWxvcGU+JyxcbiAgICBdLmpvaW4oJycpO1xuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IFNPQVA7XG4iXX0=