import './typings';
import jsforce from './lib/index';
export * from './lib/index';
export default jsforce;
