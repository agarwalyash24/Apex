import { BaseRegistry } from './base';
/**
 *
 */
export declare class EmptyRegistry extends BaseRegistry {
    _saveConfig(): void;
}
