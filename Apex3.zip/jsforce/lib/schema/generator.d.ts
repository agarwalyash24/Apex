/**
 *
 */
export default function main(): Promise<void>;
