declare const _default: "2.0.0-beta.8";
export default _default;
