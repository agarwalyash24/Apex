import { EmptyRegistry } from '../registry/empty';
declare const registry: EmptyRegistry;
export default registry;
