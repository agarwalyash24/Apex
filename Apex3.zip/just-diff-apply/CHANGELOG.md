# just-diff-apply

## 5.4.1

### Patch Changes

- fix: reorder exports to set default last #488

## 5.4.0

### Minor Changes

- package.json updates to fix #467 and #483

## 5.3.1

### Patch Changes

- Fix README

## 5.3.0

### Minor Changes

- Update .mjs module and d.ts

## 5.2.0

### Minor Changes

- Add support for 'move' op (https://datatracker.ietf.org/doc/html/rfc6902#section-4.4)

## 5.0.0

### Major Changes

- Disallow prototype updates
